import jwt from 'jsonwebtoken'
import { siteConfig } from '../lib/system/config.js'

export default (req, res, next) => {
  const authHeader = req.headers['authorization']
  
  if (!authHeader) {
    return res.status(401).json({
      status: 401,
      success: false,
      author: global.creator,
      message: 'Authorization header missing',
      data: null
    })
  }

  const parts = authHeader.split(' ')
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({
      status: 401,
      success: false,
      author: global.creator,
      message: 'Invalid authorization format',
      data: null
    })
  }

  const token = parts[1].trim()

  if (token !== siteConfig.bearerToken) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: global.creator,
      message: 'Invalid bearer token',
      data: null
    })
  }

  try {
    jwt.verify(token, siteConfig.jwtSecret)
    next()
  } catch (error) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: global.creator,
      message: 'Invalid or expired token',
      data: null
    })
  }
}