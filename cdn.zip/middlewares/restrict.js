import { allowedMimes, maxFileSize } from '../lib/system/config.js'

export default (req, res, next) => {
  if (req.method === 'POST' && req.headers['content-type']?.includes('multipart/form-data')) {
    if (!req.file && !req.files) {
      return res.status(400).json({
        status: 400,
        success: false,
        author: global.creator,
        message: 'No file uploaded',
        data: null
      })
    }

    const files = req.file ? [req.file] : (req.files ? Object.values(req.files).flat() : [])
    
    for (const file of files) {
      if (!global.validator.fileType(file.mimetype)) {
        return res.status(415).json({
          status: 415,
          success: false,
          author: global.creator,
          message: `File type ${file.mimetype} is not supported`,
          data: null
        })
      }

      if (file.size > maxFileSize) {
        return res.status(413).json({
          status: 413,
          success: false,
          author: global.creator,
          message: `File size exceeds limit of ${maxFileSize / (1024 * 1024)}MB`,
          data: null
        })
      }
    }
  }

  next()
}