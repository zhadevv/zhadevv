import { allowedIPs } from '../lib/system/config.js'
import requestIp from 'request-ip'
import { CloudflareIPBlocker } from '../lib/cloudflare.js'
const blockedIps = new Map()

const blocker = new CloudflareIPBlocker(process.env.CF_API_TOKEN, process.env.CF_ZONE_ID)
const requestMap = {}

export default async (req, res, next) => {
  try {
    const userIP = requestIp.getClientIp(req)

    if (!userIP) {
      return res.status(400).json({
        status: 400,
        success: false,
        author: global.creator,
        message: 'Unable to determine client IP',
        data: null
      })
    }

    if (blockedIps.has(userIP)) {
      return res.status(403).json({
        status: 403,
        success: false,
        author: global.creator,
        message: 'IP address is blocked',
        data: null
      })
    }

    if (allowedIPs.includes(userIP)) {
      return next()
    }

    if (blocker.detectSpam(userIP, requestMap)) {
      console.log(`Spam detected from IP: ${userIP}`)
      blockedIps.set(userIP, Date.now())
      
      if (process.env.CF_API_TOKEN && process.env.CF_ZONE_ID) {
        await blocker.blockIP(userIP, 'Automatically blocked due to suspicious activity')
      }

      return res.status(403).json({
        status: 403,
        success: false,
        author: global.creator,
        message: 'Access denied due to suspicious activity',
        data: null
      })
    }

    next()
  } catch (error) {
    console.error('Protector middleware error:', error)
    return res.status(500).json({
      status: 500,
      success: false,
      author: global.creator,
      message: 'Internal server error',
      data: null
    })
  }
}