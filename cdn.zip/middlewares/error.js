export default (req, res) => {
  res.status(404).json({
    status: 404,
    success: false,
    author: global.creator,
    message: 'Endpoint not found or currently unavailable',
    data: null
  })
}