export default (requiredParams) => {
  return (req, res, next) => {
    const method = req.method.toLowerCase()
    let source
    let paramType

    switch (method) {
      case 'get':
        source = req.query
        paramType = 'query parameters'
        break
      case 'post':
      case 'put':
      case 'patch':
        source = req.body
        paramType = 'body parameters'
        break
      default:
        source = {}
        paramType = 'parameters'
    }

    const missingParams = []

    for (const param of requiredParams) {
      if (!source[param] || (typeof source[param] === 'string' && source[param].trim() === '')) {
        missingParams.push(param)
      }
    }

    if (missingParams.length > 0) {
      return res.status(400).json({
        status: 400,
        success: false,
        author: global.creator,
        message: `Missing required ${paramType}: ${missingParams.join(', ')}`,
        data: null
      })
    }

    next()
  }
}