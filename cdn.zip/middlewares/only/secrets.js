import { siteConfig } from '../../lib/system/config.js'

export default (req, res, next) => {
  const method = req.method.toLowerCase()
  const source = method === 'get' ? req.query : req.body
  
  const secret = source.secret
  
  if (!secret) {
    return res.status(400).json({
      status: 400,
      success: false,
      author: global.creator,
      message: 'Secret key is required',
      data: null
    })
  }

  if (secret !== siteConfig.secretKey) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: global.creator,
      message: 'Invalid secret key',
      data: null
    })
  }

  next()
}