export default (route) => {
  return (req, res, next) => {
    const source = req.method.toLowerCase() === 'get' ? req.query : req.body
    
    const requiredParams = route.parameter || []
    
    for (const paramName of requiredParams) {
      const value = source[paramName]
      
      if (!value) {
        return res.status(400).json({
          status: 400,
          success: false,
          author: global.creator,
          message: `Missing required parameter: ${paramName}`,
          data: null
        })
      }

      let formatCheck = { status: true }

      if (paramName === 'url') {
        formatCheck = global.validator.url(value)
      } else if (paramName.includes('number') || paramName.includes('count') || paramName.includes('size')) {
        formatCheck = global.validator.number(value)
      }

      if (!formatCheck.status) {
        return res.status(400).json({
          status: 400,
          success: false,
          author: global.creator,
          message: formatCheck.message || `Invalid format for parameter: ${paramName}`,
          data: null
        })
      }
    }

    next()
  }
}