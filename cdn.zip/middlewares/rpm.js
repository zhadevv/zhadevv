import requestIp from 'request-ip'
import { siteConfig } from '../lib/system/config.js'

const ipRequests = new Map()
const cleanupInterval = 60000

setInterval(() => {
  const now = Date.now()
  for (const [ip, timestamps] of ipRequests.entries()) {
    const filtered = timestamps.filter(timestamp => now - timestamp < 60000)
    if (filtered.length === 0) {
      ipRequests.delete(ip)
    } else {
      ipRequests.set(ip, filtered)
    }
  }
}, cleanupInterval)

export default (req, res, next) => {
  const userIP = requestIp.getClientIp(req) || 'unknown'
  const currentTime = Date.now()
  const limit = siteConfig.defaultRPM

  if (!ipRequests.has(userIP)) {
    ipRequests.set(userIP, [])
  }

  const requests = ipRequests.get(userIP)
  const windowStart = currentTime - 60000
  const recentRequests = requests.filter(timestamp => timestamp > windowStart)

  if (recentRequests.length >= limit) {
    res.setHeader('X-RateLimit-Limit', limit)
    res.setHeader('X-RateLimit-Remaining', 0)
    res.setHeader('X-RateLimit-Reset', Math.ceil((requests[0] + 60000) / 1000))
    
    return res.status(429).json({
      status: 429,
      success: false,
      author: global.creator,
      message: 'Too many requests',
      data: null
    })
  }

  requests.push(currentTime)
  ipRequests.set(userIP, requests)

  res.setHeader('X-RateLimit-Limit', limit)
  res.setHeader('X-RateLimit-Remaining', limit - recentRequests.length - 1)
  res.setHeader('X-RateLimit-Reset', Math.ceil((currentTime + 60000) / 1000))

  next()
}