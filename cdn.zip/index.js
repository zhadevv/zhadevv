import Webly, { App, Loader } from '@neoxr/webly'
import './lib/global.js'
import middleware from './lib/system/middleware.js'
import { db } from './lib/database.js'
import { storage } from './lib/storage.js'
import os from 'os'
import fs from 'fs'
import path from 'path'

const ensureDataDir = () => {
  const dataDir = './data'
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true })
  }
  
  const filesDir = './data/files'
  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir, { recursive: true })
  }
  
  const tempDir = './data/temp'
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true })
  }
  
  const cacheDir = './data/cache'
  if (!fs.existsSync(cacheDir)) {
    fs.mkdirSync(cacheDir, { recursive: true })
  }
}

ensureDataDir()

const startServer = async () => {
  try {
    await db.connect()
    console.log('Database initialized successfully')

    const app = new App({
      name: 'zhadev-cdn',
      staticPath: ['public'],
      routePath: './routers',
      middleware,
      socket: true,
      port: process.env.PORT || 3000,
      session: {
        name: 'zhadev_token',
        keys: ['zhadev_session'],
        maxAge: 72 * 60 * 60 * 1000,
        httpOnly: true,
        sameSite: 'strict'
      },
      cors: {
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: '*',
        preflightContinue: false,
        optionsSuccessStatus: 204,
        exposedHeaders: '*',
        credentials: true
      },
      error: (req, res) => {
        res.status(404).sendFile('./public/404.html', { root: process.cwd() })
      }
    })

    app.socket?.on('connection', (socket) => {
      console.log(`Client connected: ${socket.id}`)

      const systemMonitorInterval = setInterval(() => {
        const totalMemory = os.totalmem()
        const freeMemory = os.freemem()
        const usedMemory = totalMemory - freeMemory
        const usagePercentage = (usedMemory / totalMemory) * 100

        const cpuLoad = os.loadavg()
        const uptime = os.uptime()

        const stats = {
          memory: {
            total: `${(totalMemory / 1024 / 1024).toFixed(2)} MB`,
            free: `${(freeMemory / 1024 / 1024).toFixed(2)} MB`,
            used: `${(usedMemory / 1024 / 1024).toFixed(2)} MB`,
            usagePercentage: usagePercentage.toFixed(2)
          },
          cpu: {
            load1: cpuLoad[0].toFixed(2),
            load5: cpuLoad[1].toFixed(2),
            load15: cpuLoad[2].toFixed(2),
            cores: os.cpus().length
          },
          system: {
            uptime: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`,
            platform: os.platform(),
            arch: os.arch()
          }
        }

        socket.emit('system_update', stats)
      }, 2000)

      socket.on('disconnect', () => {
        console.log(`Client disconnected: ${socket.id}`)
        clearInterval(systemMonitorInterval)
      })
    })

    app.start()

    process.on('SIGINT', async () => {
      console.log('Shutting down server...')
      await db.disconnect()
      process.exit(0)
    })

    process.on('SIGTERM', async () => {
      console.log('Terminating server...')
      await db.disconnect()
      process.exit(0)
    })

  } catch (error) {
    console.error('Failed to start server:', error)
    process.exit(1)
  }
}

startServer()