import { spawn } from 'child_process'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const prismaBin = join(__dirname, 'node_modules', '.bin', 'prisma')

const runPrismaCommand = (args) => {
  return new Promise((resolve, reject) => {
    const prisma = spawn(prismaBin, args, {
      stdio: 'inherit',
      shell: true
    })

    prisma.on('close', (code) => {
      if (code === 0) {
        resolve()
      } else {
        reject(new Error(`Prisma command failed with code ${code}`))
      }
    })

    prisma.on('error', (err) => {
      reject(err)
    })
  })
}

export const migrate = async () => {
  console.log('Running database migrations...')
  await runPrismaCommand(['migrate', 'dev', '--name', 'init'])
  console.log('Migrations completed successfully!')
}

export const generate = async () => {
  console.log('Generating Prisma Client...')
  await runPrismaCommand(['generate'])
  console.log('Prisma Client generated successfully!')
}

export const seed = async () => {
  console.log('Seeding database...')
  const { spawn } = await import('child_process')
  const seedProcess = spawn('node', ['prisma/seed.js'], {
    stdio: 'inherit',
    shell: true
  })

  return new Promise((resolve, reject) => {
    seedProcess.on('close', (code) => {
      if (code === 0) {
        resolve()
      } else {
        reject(new Error(`Seed process failed with code ${code}`))
      }
    })
  })
}