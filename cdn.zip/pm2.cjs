const pm2 = require('pm2')

const start = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('PM2 connection error:', err)
      process.exit(1)
    }

    pm2.start({
      script: './index.js',
      name: 'zhadev-cdn',
      exec_mode: 'cluster',
      instances: 'max',
      max_memory_restart: '1G',
      watch: false,
      autorestart: true,
      env: {
        NODE_ENV: 'production'
      }
    }, (err, apps) => {
      pm2.disconnect()
      
      if (err) {
        console.error('PM2 start error:', err)
        process.exit(1)
      }
      
      console.log('zhadev-cdn started with PM2')
    })
  })
}

const stop = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('PM2 connection error:', err)
      process.exit(1)
    }

    pm2.stop('zhadev-cdn', (err) => {
      pm2.disconnect()
      
      if (err) {
        console.error('PM2 stop error:', err)
        process.exit(1)
      }
      
      console.log('zhadev-cdn stopped')
    })
  })
}

const restart = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('PM2 connection error:', err)
      process.exit(1)
    }

    pm2.restart('zhadev-cdn', (err) => {
      pm2.disconnect()
      
      if (err) {
        console.error('PM2 restart error:', err)
        process.exit(1)
      }
      
      console.log('zhadev-cdn restarted')
    })
  })
}

const status = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('PM2 connection error:', err)
      process.exit(1)
    }

    pm2.list((err, list) => {
      pm2.disconnect()
      
      if (err) {
        console.error('PM2 list error:', err)
        process.exit(1)
      }
      
      const app = list.find(app => app.name === 'zhadev-cdn')
      if (app) {
        console.log('zhadev-cdn status:')
        console.log(`  Name: ${app.name}`)
        console.log(`  Status: ${app.pm2_env.status}`)
        console.log(`  Uptime: ${app.pm2_env.pm_uptime}`)
        console.log(`  CPU: ${app.monit.cpu}%`)
        console.log(`  Memory: ${(app.monit.memory / 1024 / 1024).toFixed(2)} MB`)
        console.log(`  Instances: ${app.pm2_env.instances}`)
      } else {
        console.log('zhadev-cdn is not running')
      }
    })
  })
}

const command = process.argv[2]

switch (command) {
  case 'start':
    start()
    break
  case 'stop':
    stop()
    break
  case 'restart':
    restart()
    break
  case 'status':
    status()
    break
  default:
    console.log('Usage: node pm2.cjs [start|stop|restart|status]')
    process.exit(1)
}