export const routes = {
  category: 'main',
  path: '/',
  method: 'get',
  execution: async (req, res, next) => {
    try {
      res.json({
        status: 200,
        success: true,
        author: global.creator,
        message: 'zhadev-cdn API is running',
        data: {
          name: 'zhadev-cdn',
          version: '1.0.0',
          description: 'Content Delivery Network by Zhadev Creative',
          endpoints: {
            upload: '/api/upload',
            files: '/api/files',
            file: '/api/file/:id',
            stats: '/api/stats',
            health: '/api/health'
          }
        }
      })
    } catch (error) {
      res.status(500).json({
        status: 500,
        success: false,
        author: global.creator,
        message: error.message,
        data: null
      })
    }
  },
  error: false,
  authorize: false,
  rpm: false,
  protect: true,
  premium: false,
  restrict: false
}