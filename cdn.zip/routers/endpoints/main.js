import { db } from '../../lib/database.js'
import fs from 'fs/promises'
import os from 'os'
import { siteConfig } from '../../lib/system/config.js'

export const routes = [
  {
    category: 'system',
    path: '/api/health',
    method: 'get',
    execution: async (req, res, next) => {
      const startTime = process.hrtime()
      
      try {
        const healthChecks = {
          database: false,
          storage: false,
          memory: false,
          uptime: process.uptime()
        }

        try {
          await db.prisma.$queryRaw`SELECT 1`
          healthChecks.database = true
        } catch (error) {
          console.error('Database health check failed:', error)
        }

        try {
          await fs.access(siteConfig.uploadDir)
          const stats = await fs.stat(siteConfig.uploadDir)
          healthChecks.storage = stats.isDirectory()
        } catch (error) {
          console.error('Storage health check failed:', error)
        }

        const totalMemory = os.totalmem()
        const freeMemory = os.freemem()
        const usedMemory = totalMemory - freeMemory
        const memoryUsage = (usedMemory / totalMemory) * 100
        healthChecks.memory = memoryUsage < 90

        const endTime = process.hrtime(startTime)
        const responseTime = (endTime[0] * 1000 + endTime[1] / 1000000).toFixed(2)

        res.setHeader('X-Process-Time', `${responseTime}ms`)
        
        const isHealthy = Object.values(healthChecks).every(check => check === true)
        
        res.status(isHealthy ? 200 : 503).json({
          status: isHealthy ? 200 : 503,
          success: isHealthy,
          author: global.creator,
          message: isHealthy ? 'System is healthy' : 'System is unhealthy',
          data: {
            ...healthChecks,
            memory: {
              total: `${(totalMemory / 1024 / 1024 / 1024).toFixed(2)} GB`,
              used: `${(usedMemory / 1024 / 1024 / 1024).toFixed(2)} GB`,
              free: `${(freeMemory / 1024 / 1024 / 1024).toFixed(2)} GB`,
              usage: `${memoryUsage.toFixed(2)}%`
            },
            system: {
              platform: os.platform(),
              arch: os.arch(),
              cpus: os.cpus().length,
              load: os.loadavg(),
              uptime: os.uptime()
            },
            responseTime: `${responseTime}ms`
          }
        })
      } catch (error) {
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: 'Health check failed',
          data: null
        })
      }
    },
    error: false,
    authorize: false,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'system',
    path: '/api/stats',
    method: 'get',
    execution: async (req, res, next) => {
      try {
        const stats = await db.getStats()
        const diskUsage = await fs.stat(siteConfig.uploadDir).catch(() => ({ size: 0 }))
        
        res.json({
          status: 200,
          success: true,
          author: global.creator,
          message: 'Statistics retrieved successfully',
          data: {
            ...stats,
            diskUsage: {
              used: `${(diskUsage.size / 1024 / 1024).toFixed(2)} MB`,
              maxSize: `${(siteConfig.maxFileSize * stats.totalFiles / 1024 / 1024).toFixed(2)} MB`
            },
            limits: {
              maxFileSize: `${siteConfig.maxFileSize / (1024 * 1024)} MB`,
              rpm: siteConfig.defaultRPM
            }
          }
        })
      } catch (error) {
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: 'Failed to retrieve statistics',
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  }
]