import { storage } from '../../lib/storage.js'
import { db } from '../../lib/database.js'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { uploadDir, allowedMimes, maxFileSize } from '../../lib/system/config.js'
import { fileTypeFromBuffer } from 'file-type'
import sizeOf from 'image-size'
import getVideoDuration from 'get-video-duration'

const storageConfig = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, uniqueSuffix + path.extname(file.originalname))
  }
})

const fileFilter = (req, file, cb) => {
  const allMimes = Object.values(allowedMimes).flat()
  if (allMimes.includes(file.mimetype)) {
    cb(null, true)
  } else {
    cb(new Error('Unsupported file type'), false)
  }
}

const upload = multer({
  storage: storageConfig,
  fileFilter,
  limits: {
    fileSize: maxFileSize
  }
})

export const routes = [
  {
    category: 'files',
    path: '/api/upload',
    method: 'post',
    middleware: [upload.single('file')],
    execution: async (req, res, next) => {
      const startTime = process.hrtime()
      
      try {
        if (!req.file) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: global.creator,
            message: 'No file uploaded',
            data: null
          })
        }

        const fileBuffer = await fs.promises.readFile(req.file.path)
        
        const metadata = {
          tags: req.body.tags ? req.body.tags.split(',').map(tag => tag.trim()) : [],
          isPrivate: req.body.isPrivate === 'true',
          expiresIn: req.body.expiresIn || null,
          generateCache: req.body.generateCache === 'true'
        }

        let additionalMetadata = {}

        if (req.file.mimetype.startsWith('image/')) {
          try {
            const dimensions = sizeOf(fileBuffer)
            additionalMetadata.dimensions = {
              width: dimensions.width,
              height: dimensions.height,
              type: dimensions.type
            }
          } catch (error) {
            console.error('Failed to get image dimensions:', error)
          }
        }

        if (req.file.mimetype.startsWith('video/')) {
          try {
            const duration = await getVideoDuration(fileBuffer)
            additionalMetadata.duration = Math.round(duration * 1000)
          } catch (error) {
            console.error('Failed to get video duration:', error)
          }
        }

        if (req.file.mimetype.startsWith('audio/')) {
          try {
            const audioContext = new (require('web-audio-api').AudioContext)()
            const audioBuffer = await audioContext.decodeAudioData(fileBuffer)
            additionalMetadata.duration = Math.round(audioBuffer.duration * 1000)
            additionalMetadata.bitrate = Math.round((fileBuffer.length * 8) / audioBuffer.duration / 1000)
          } catch (error) {
            console.error('Failed to get audio metadata:', error)
          }
        }

        const fileType = await fileTypeFromBuffer(fileBuffer)
        if (fileType && fileType.mime !== req.file.mimetype) {
          console.warn(`MIME type mismatch: detected ${fileType.mime}, reported ${req.file.mimetype}`)
        }

        const savedFile = await storage.saveFile(
          fileBuffer,
          req.file.originalname,
          req.file.mimetype,
          {
            ...metadata,
            ...additionalMetadata,
            detectedMime: fileType?.mime || req.file.mimetype
          }
        )

        await fs.promises.unlink(req.file.path).catch(console.error)

        const endTime = process.hrtime(startTime)
        const responseTime = (endTime[0] * 1000 + endTime[1] / 1000000).toFixed(2)

        res.setHeader('X-Process-Time', `${responseTime}ms`)
        
        res.status(201).json({
          status: 201,
          success: true,
          author: global.creator,
          message: 'File uploaded successfully',
          data: {
            id: savedFile.id,
            filename: savedFile.filename,
            originalName: savedFile.originalName,
            size: savedFile.size,
            mimeType: savedFile.mimeType,
            url: `/api/file/${savedFile.id}/download`,
            rawUrl: `/raws/${savedFile.path}`,
            hash: savedFile.hash,
            uploadedAt: savedFile.uploadedAt,
            expiresAt: savedFile.expiresAt,
            metadata: savedFile.metadata
          }
        })
      } catch (error) {
        if (req.file && req.file.path) {
          await fs.promises.unlink(req.file.path).catch(console.error)
        }
        
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: error.message,
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: true
  },
  {
    category: 'files',
    path: '/api/files',
    method: 'get',
    execution: async (req, res, next) => {
      try {
        const { q = '', page = '1', limit = '50', type = '' } = req.query
        const pageNum = parseInt(page)
        const limitNum = parseInt(limit)
        const offset = (pageNum - 1) * limitNum

        let where = {}

        if (q) {
          where.OR = [
            { filename: { contains: q, mode: 'insensitive' } },
            { originalName: { contains: q, mode: 'insensitive' } },
            { tags: { has: q } }
          ]
        }

        if (type) {
          if (type === 'image') {
            where.mimeType = { startsWith: 'image/' }
          } else if (type === 'video') {
            where.mimeType = { startsWith: 'video/' }
          } else if (type === 'audio') {
            where.mimeType = { startsWith: 'audio/' }
          } else if (type === 'text') {
            where.mimeType = { startsWith: 'text/' }
          }
        }

        const [files, total] = await Promise.all([
          db.prisma.file.findMany({
            where,
            take: limitNum,
            skip: offset,
            orderBy: { uploadedAt: 'desc' },
            select: {
              id: true,
              filename: true,
              originalName: true,
              size: true,
              mimeType: true,
              extension: true,
              uploadedAt: true,
              downloadCount: true,
              views: true,
              tags: true
            }
          }),
          db.prisma.file.count({ where })
        ])

        res.json({
          status: 200,
          success: true,
          author: global.creator,
          message: 'Files retrieved successfully',
          data: {
            files,
            pagination: {
              total,
              page: pageNum,
              limit: limitNum,
              pages: Math.ceil(total / limitNum),
              hasNext: offset + limitNum < total,
              hasPrev: pageNum > 1
            }
          }
        })
      } catch (error) {
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: 'Failed to retrieve files',
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'files',
    path: '/api/file/:id',
    method: 'get',
    execution: async (req, res, next) => {
      try {
        const { id } = req.params
        const file = await storage.getFileInfo(id)

        res.json({
          status: 200,
          success: true,
          author: global.creator,
          message: 'File information retrieved',
          data: file
        })
      } catch (error) {
        res.status(404).json({
          status: 404,
          success: false,
          author: global.creator,
          message: error.message,
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'files',
    path: '/api/file/:id/download',
    method: 'get',
    execution: async (req, res, next) => {
      try {
        const { id } = req.params
        const { stream, file, stats } = await storage.getFileStream(id)

        res.setHeader('Content-Type', file.mimeType)
        res.setHeader('Content-Length', stats.size)
        res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.originalName)}"`)
        res.setHeader('Cache-Control', 'public, max-age=31536000')
        res.setHeader('ETag', file.hash)
        res.setHeader('Last-Modified', stats.mtime.toUTCString())
        
        if (req.headers['if-none-match'] === file.hash) {
          return res.status(304).end()
        }

        stream.pipe(res)
      } catch (error) {
        res.status(404).json({
          status: 404,
          success: false,
          author: global.creator,
          message: error.message,
          data: null
        })
      }
    },
    error: false,
    authorize: false,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'files',
    path: '/api/file/:id',
    method: 'delete',
    execution: async (req, res, next) => {
      try {
        const { id } = req.params
        const deletedFile = await storage.deleteFile(id)

        res.json({
          status: 200,
          success: true,
          author: global.creator,
          message: 'File deleted successfully',
          data: {
            id: deletedFile.id,
            filename: deletedFile.filename,
            deletedAt: new Date().toISOString()
          }
        })
      } catch (error) {
        res.status(404).json({
          status: 404,
          success: false,
          author: global.creator,
          message: error.message,
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'raw',
    path: '/raws/:filename',
    method: 'get',
    execution: async (req, res, next) => {
      try {
        const { filename } = req.params
        const filePath = path.join(uploadDir, filename)

        const stats = await fs.promises.stat(filePath).catch(() => null)
        if (!stats || !stats.isFile()) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: global.creator,
            message: 'File not found',
            data: null
          })
        }

        const file = await db.prisma.file.findFirst({
          where: { path: filename }
        })

        if (!file) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: global.creator,
            message: 'File not found in database',
            data: null
          })
        }

        if (file.isPrivate) {
          const authHeader = req.headers['authorization']
          if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(403).json({
              status: 403,
              success: false,
              author: global.creator,
              message: 'Private file requires authorization',
              data: null
            })
          }
        }

        await db.incrementViews(file.id)

        res.setHeader('Content-Type', file.mimeType)
        res.setHeader('Content-Length', stats.size)
        res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.originalName)}"`)
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable')
        res.setHeader('ETag', file.hash)
        res.setHeader('Last-Modified', stats.mtime.toUTCString())
        res.setHeader('Access-Control-Allow-Origin', '*')
        res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Type, ETag')
        
        if (req.headers['if-none-match'] === file.hash) {
          return res.status(304).end()
        }

        const stream = fs.createReadStream(filePath)
        stream.pipe(res)
      } catch (error) {
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: 'Failed to serve file',
          data: null
        })
      }
    },
    error: false,
    authorize: false,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  },
  {
    category: 'tools',
    path: '/api/cleanup',
    method: 'post',
    execution: async (req, res, next) => {
      try {
        const cleanedCount = await storage.cleanupExpiredFiles()
        
        res.json({
          status: 200,
          success: true,
          author: global.creator,
          message: 'Cleanup completed',
          data: {
            cleanedFiles: cleanedCount,
            timestamp: new Date().toISOString()
          }
        })
      } catch (error) {
        res.status(500).json({
          status: 500,
          success: false,
          author: global.creator,
          message: 'Cleanup failed',
          data: null
        })
      }
    },
    error: false,
    authorize: true,
    rpm: true,
    protect: true,
    premium: false,
    restrict: false
  }
]