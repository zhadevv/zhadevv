from pydantic import BaseModel, Field
from typing import TypeVar, Generic, Optional, Any, Dict, List, Union
from datetime import datetime

T = TypeVar("T")

class BaseResponse(BaseModel, Generic[T]):
    status: int = Field(..., description="HTTP status code")
    success: bool = Field(..., description="Request success status")
    author: str = Field(default="zhadevv", description="API author")
    data: Optional[T] = Field(default=None, description="Response data")
    message: Optional[str] = Field(default=None, description="Error message if success=False")

    class Config:
        json_schema_extra = {
            "example": {
                "status": 200,
                "success": True,
                "author": "zhadevv",
                "data": {"key": "value"},
                "message": None
            }
        }


class ErrorResponse(BaseModel):
    status: int = Field(..., description="HTTP status code")
    success: bool = Field(default=False, description="Request success status")
    author: str = Field(default="zhadevv", description="API author")
    data: Optional[Any] = Field(default=None, description="Response data")
    message: str = Field(..., description="Error message")
    error_id: Optional[str] = Field(default=None, description="Error ID for debugging")
    errors: Optional[List[Dict[str, Any]]] = Field(default=None, description="Validation errors")

    class Config:
        json_schema_extra = {
            "example": {
                "status": 400,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": "Invalid request parameters",
                "error_id": "ERR_123456"
            }
        }


class HealthResponse(BaseModel):
    status: str = Field(..., description="API status")
    version: str = Field(..., description="API version")
    timestamp: datetime = Field(..., description="Current server timestamp")
    uptime: float = Field(..., description="Server uptime in seconds")
    database: str = Field(..., description="Database status")
    cache: str = Field(..., description="Cache status")
    requests_total: int = Field(..., description="Total requests served")
    requests_today: int = Field(..., description="Requests served today")
    active_apikeys: int = Field(..., description="Active API keys")


class StatsResponse(BaseModel):
    total_requests: int = Field(..., description="Total requests served")
    total_unique_ips: int = Field(..., description="Total unique IP addresses")
    total_apikeys: int = Field(..., description="Total API keys")
    avg_response_time: float = Field(..., description="Average response time in seconds")
    banned_ips: int = Field(..., description="Number of banned IP addresses")
    daily_stats: List[Dict[str, Any]] = Field(..., description="Daily statistics for last 30 days")


class APIKeyResponse(BaseModel):
    apikey: str = Field(..., description="Generated API key")
    username: str = Field(..., description="Username for the key")
    role: str = Field(..., description="Key role (free, starter, medium, etc)")
    rpm: int = Field(..., description="Requests per minute limit")
    monthly_limit: int = Field(..., description="Monthly request limit")
    created_at: datetime = Field(..., description="Creation timestamp")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")
    active_versions: List[str] = Field(default=["v1"], description="Active API versions")
    custom_key: Optional[str] = Field(default=None, description="Custom key if provided")


class CheckKeyResponse(BaseModel):
    valid: bool = Field(..., description="Key validity status")
    role: str = Field(..., description="Key role")
    username: str = Field(..., description="Username")
    active: bool = Field(..., description="Key active status")
    suspended: bool = Field(..., description="Key suspended status")
    requests_count: int = Field(..., description="Total requests count")
    requests_month: int = Field(..., description="Monthly requests count")
    monthly_limit: int = Field(..., description="Monthly limit")
    remaining_monthly: int = Field(..., description="Remaining monthly requests")
    created_at: datetime = Field(..., description="Creation timestamp")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")
    active_versions: List[str] = Field(..., description="Active API versions")


class RemoveKeyResponse(BaseModel):
    success: bool = Field(..., description="Removal success status")
    apikey: str = Field(..., description="Removed API key")
    message: str = Field(..., description="Removal message")


class SuspensionResponse(BaseModel):
    success: bool = Field(..., description="Suspension operation success status")
    apikey: str = Field(..., description="API key")
    suspended: bool = Field(..., description="Current suspension status")
    message: str = Field(..., description="Operation message")


class IPInfoResponse(BaseModel):
    ip: str = Field(..., description="IP address")
    country: Optional[str] = Field(default=None, description="Country code")
    region: Optional[str] = Field(default=None, description="Region/State")
    city: Optional[str] = Field(default=None, description="City")
    isp: Optional[str] = Field(default=None, description="Internet Service Provider")
    latitude: Optional[float] = Field(default=None, description="Latitude")
    longitude: Optional[float] = Field(default=None, description="Longitude")
    timezone: Optional[str] = Field(default=None, description="Timezone")
    asn: Optional[str] = Field(default=None, description="Autonomous System Number")
    is_hosting: Optional[bool] = Field(default=None, description="Is hosting/VPN")
    is_proxy: Optional[bool] = Field(default=None, description="Is proxy")
    is_tor: Optional[bool] = Field(default=None, description="Is TOR exit node")
    threat_level: Optional[str] = Field(default=None, description="Threat level")


class AdminStatsResponse(BaseModel):
    total_requests: int = Field(..., description="Total requests")
    successful_requests: int = Field(..., description="Successful requests")
    failed_requests: int = Field(..., description="Failed requests")
    avg_response_time: float = Field(..., description="Average response time")
    unique_ips: int = Field(..., description="Unique IP addresses")
    active_apikeys: int = Field(..., description="Active API keys")
    total_apikeys: int = Field(..., description="Total API keys")
    banned_ips: int = Field(..., description="Banned IP addresses")
    by_role: Dict[str, Dict[str, Any]] = Field(..., description="Statistics by role")
    by_endpoint: Dict[str, Dict[str, Any]] = Field(..., description="Statistics by endpoint")
    daily_totals: List[Dict[str, Any]] = Field(..., description="Daily totals")


class IPLogResponse(BaseModel):
    id: int = Field(..., description="Log ID")
    ip: str = Field(..., description="IP address")
    apikey: Optional[str] = Field(default=None, description="API key (masked)")
    endpoint: str = Field(..., description="Request endpoint")
    method: str = Field(..., description="HTTP method")
    timestamp: datetime = Field(..., description="Request timestamp")
    user_agent: Optional[str] = Field(default=None, description="User agent")
    response_time: float = Field(..., description="Response time in seconds")
    status_code: int = Field(..., description="HTTP status code")


class BannedIPResponse(BaseModel):
    ip: str = Field(..., description="IP address")
    reason: str = Field(..., description="Ban reason")
    banned_at: datetime = Field(..., description="Ban timestamp")
    banned_by: str = Field(..., description="Who banned")
    expires_at: Optional[datetime] = Field(default=None, description="Expiration timestamp")


class AnimeSearchResponse(BaseModel):
    query: str = Field(..., description="Search query")
    results_count: int = Field(..., description="Number of results")
    lists: List[Dict[str, Any]] = Field(..., description="Search results")
    pagination: Dict[str, Any] = Field(..., description="Pagination info")


class AnimeDetailResponse(BaseModel):
    id: str = Field(..., description="Anime ID")
    slug: str = Field(..., description="Anime slug")
    title: str = Field(..., description="Anime title")
    alter_title: Optional[str] = Field(default=None, description="Alternative title")
    cover: Dict[str, str] = Field(..., description="Cover images")
    rating: Dict[str, Any] = Field(..., description="Rating info")
    information: Dict[str, Any] = Field(..., description="Anime information")
    genres: List[Dict[str, str]] = Field(..., description="Genres")
    episodes: List[Dict[str, Any]] = Field(..., description="Episode list")
    url: str = Field(..., description="Source URL")


class WatchResponse(BaseModel):
    id: str = Field(..., description="Episode ID")
    title: str = Field(..., description="Episode title")
    slug: str = Field(..., description="Episode slug")
    episode_number: str = Field(..., description="Episode number")
    thumbnail: str = Field(..., description="Thumbnail URL")
    servers: List[Dict[str, str]] = Field(..., description="Video servers")
    current_server: Dict[str, str] = Field(..., description="Current server")
    downloads: List[Dict[str, Any]] = Field(..., description="Download links")
    series_info: Dict[str, Any] = Field(..., description="Series information")
    episode_navigation: Dict[str, Dict[str, str]] = Field(..., description="Navigation")
    url: str = Field(..., description="Source URL")


class ScheduleResponse(BaseModel):
    title: str = Field(..., description="Schedule title")
    days: Dict[str, Dict[str, Any]] = Field(..., description="Schedule by days")
    notice: Optional[str] = Field(default=None, description="Schedule notice")


class SidebarResponse(BaseModel):
    quick_filter: Dict[str, Any] = Field(..., description="Quick filter options")
    new_movie: Optional[Dict[str, Any]] = Field(default=None, description="New movies")
    ongoing_series: Optional[Dict[str, Any]] = Field(default=None, description="Ongoing series")
    popular_series: Optional[Dict[str, Any]] = Field(default=None, description="Popular series")
    genres: Optional[Dict[str, Any]] = Field(default=None, description="Genres list")
    seasons: Optional[Dict[str, Any]] = Field(default=None, description="Seasons list")


class HomeResponse(BaseModel):
    slider: List[Dict[str, Any]] = Field(..., description="Home slider")
    popular_today: List[Dict[str, Any]] = Field(..., description="Popular today")
    latest_release: List[Dict[str, Any]] = Field(..., description="Latest releases")
    recommendation: Dict[str, Any] = Field(..., description="Recommendations")
    pagination: Dict[str, Any] = Field(..., description="Pagination")


class FiltersResponse(BaseModel):
    mode: str = Field(..., description="Filter mode (image/text)")
    title: str = Field(..., description="Filter title")
    applied_filters: Dict[str, Any] = Field(..., description="Applied filters")
    quick_filter: Dict[str, Any] = Field(..., description="Quick filter options")
    lists: List[Dict[str, Any]] = Field(..., description="Filter results")
    pagination: Dict[str, Any] = Field(..., description="Pagination")
    alphabet_nav: Optional[List[Dict[str, Any]]] = Field(default=None, description="Alphabet navigation")
    text_mode: Optional[Dict[str, Any]] = Field(default=None, description="Text mode data")


class DonghuaAZResponse(BaseModel):
    page_type: str = Field(..., description="Page type (az_list)")
    list_type: str = Field(..., description="List type (letter/all)")
    current_letter: Optional[str] = Field(default=None, description="Current letter")
    title: str = Field(..., description="Page title")
    alphabet: Dict[str, Any] = Field(..., description="Alphabet navigation")
    lists: List[Dict[str, Any]] = Field(..., description="Content list")
    pagination: Dict[str, Any] = Field(..., description="Pagination")


class DracinHomeResponse(BaseModel):
    slider: List[Dict[str, Any]] = Field(..., description="Home slider")
    featured: List[Dict[str, Any]] = Field(..., description="Featured dramas")
    latest: List[Dict[str, Any]] = Field(..., description="Latest episodes")
    popular: List[Dict[str, Any]] = Field(..., description="Popular dramas")
    channels: List[Dict[str, Any]] = Field(..., description="Channels")


class DracinChannelResponse(BaseModel):
    slug: str = Field(..., description="Channel slug")
    page: int = Field(..., description="Current page")
    title: str = Field(..., description="Channel title")
    description: str = Field(..., description="Channel description")
    total_pages: int = Field(..., description="Total pages")
    total_items: int = Field(..., description="Total items")
    dramas: List[Dict[str, Any]] = Field(..., description="Dramas list")
    pagination: Dict[str, Any] = Field(..., description="Pagination")


class DracinBrowseResponse(BaseModel):
    category_id: str = Field(..., description="Category ID")
    category_name: str = Field(..., description="Category name")
    page: int = Field(..., description="Current page")
    total_pages: int = Field(..., description="Total pages")
    total_items: int = Field(..., description="Total items")
    dramas: List[Dict[str, Any]] = Field(..., description="Dramas list")
    categories: List[Dict[str, Any]] = Field(..., description="Categories list")
    pagination: Dict[str, Any] = Field(..., description="Pagination")


class DracinDramaResponse(BaseModel):
    id: str = Field(..., description="Drama ID")
    slug: str = Field(..., description="Drama slug")
    title: str = Field(..., description="Drama title")
    original_title: str = Field(..., description="Original title")
    poster: str = Field(..., description="Poster URL")
    backdrop: str = Field(..., description="Backdrop URL")
    year: str = Field(..., description="Release year")
    rating: float = Field(..., description="Rating")
    duration: str = Field(..., description="Duration")
    episodes: int = Field(..., description="Number of episodes")
    views: int = Field(..., description="View count")
    description: str = Field(..., description="Description")
    genres: List[str] = Field(..., description="Genres")
    casts: List[Dict[str, Any]] = Field(..., description="Cast list")
    directors: List[Dict[str, Any]] = Field(..., description="Directors list")
    studios: List[str] = Field(..., description="Studios")
    countries: List[str] = Field(..., description="Countries")
    episode_list: List[Dict[str, Any]] = Field(..., description="Episode list")
    recommendations: List[Dict[str, Any]] = Field(..., description="Recommendations")
    metadata: Dict[str, Any] = Field(..., description="Metadata")


class DracinWatchResponse(BaseModel):
    drama_id: str = Field(..., description="Drama ID")
    drama_slug: str = Field(..., description="Drama slug")
    episode_id: str = Field(..., description="Episode ID")
    episode_slug: str = Field(..., description="Episode slug")
    drama_title: str = Field(..., description="Drama title")
    episode_title: str = Field(..., description="Episode title")
    episode_number: str = Field(..., description="Episode number")
    video_url: str = Field(..., description="Video URL")
    video_sources: List[Dict[str, str]] = Field(..., description="Video sources")
    subtitles: List[Dict[str, str]] = Field(..., description="Subtitles")
    qualities: List[str] = Field(..., description="Available qualities")
    duration: int = Field(..., description="Duration in seconds")
    thumbnail: str = Field(..., description="Thumbnail URL")
    description: str = Field(..., description="Description")
    uploaded_at: str = Field(..., description="Upload timestamp")
    views: int = Field(..., description="View count")
    next_episode: Optional[Dict[str, Any]] = Field(default=None, description="Next episode")
    prev_episode: Optional[Dict[str, Any]] = Field(default=None, description="Previous episode")
    episode_list: List[Dict[str, Any]] = Field(..., description="Episode list")


class ResourcesResponse(BaseModel):
    categories: List[Dict[str, Any]] = Field(..., description="Resource categories")
    latest_updates: List[Dict[str, Any]] = Field(..., description="Latest updates")
    featured_resources: List[Dict[str, Any]] = Field(..., description="Featured resources")