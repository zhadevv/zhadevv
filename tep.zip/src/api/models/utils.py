import hashlib
import json
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
import secrets
import string
from urllib.parse import urlencode

class APIUtils:
    @staticmethod
    def generate_id(length: int = 12) -> str:
        chars = string.ascii_letters + string.digits
        return ''.join(secrets.choice(chars) for _ in range(length))
    
    @staticmethod
    def hash_string(text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()
    
    @staticmethod
    def create_cache_key(endpoint: str, params: Dict[str, Any]) -> str:
        sorted_params = dict(sorted(params.items()))
        param_str = urlencode(sorted_params)
        key_string = f"{endpoint}:{param_str}"
        return APIUtils.hash_string(key_string)[:32]
    
    @staticmethod
    def mask_apikey(apikey: str) -> str:
        if not apikey or len(apikey) < 8:
            return "***"
        return f"{apikey[:4]}...{apikey[-4:]}"
    
    @staticmethod
    def mask_ip(ip: str) -> str:
        if not ip:
            return "0.0.0.0"
        
        parts = ip.split('.')
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.***.***"
        return "***"
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f}m"
        else:
            hours = seconds / 3600
            return f"{hours:.1f}h"
    
    @staticmethod
    def format_bytes(size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"
    
    @staticmethod
    def sanitize_html(text: str) -> str:
        import html
        return html.escape(text)
    
    @staticmethod
    def truncate_text(text: str, max_length: int = 100) -> str:
        if len(text) <= max_length:
            return text
        return text[:max_length-3] + "..."
    
    @staticmethod
    def validate_slug(slug: str) -> bool:
        import re
        pattern = r'^[a-z0-9]+(?:-[a-z0-9]+)*$'
        return bool(re.match(pattern, slug))
    
    @staticmethod
    def parse_query_string(query_str: str) -> Dict[str, Union[str, List[str]]]:
        result = {}
        
        if not query_str:
            return result
        
        params = query_str.split('&')
        
        for param in params:
            if '=' in param:
                key, value = param.split('=', 1)
                
                if key.endswith('[]'):
                    key = key[:-2]
                    if key not in result:
                        result[key] = []
                    if isinstance(result[key], list):
                        result[key].append(value)
                else:
                    result[key] = value
        
        return result


class RateLimitUtils:
    @staticmethod
    def calculate_retry_after(rpm: int, current_count: int) -> int:
        if current_count >= rpm:
            window_end = time.time() + 60
            return int(window_end - time.time())
        return 0
    
    @staticmethod
    def get_reset_time() -> int:
        now = time.time()
        next_minute = (int(now) // 60 + 1) * 60
        return int(next_minute - now)
    
    @staticmethod
    def format_rate_limit_headers(
        limit: int,
        remaining: int,
        reset: int
    ) -> Dict[str, str]:
        return {
            "X-RateLimit-Limit": str(limit),
            "X-RateLimit-Remaining": str(remaining),
            "X-RateLimit-Reset": str(reset)
        }


class PaginationUtils:
    @staticmethod
    def create_pagination(
        current_page: int,
        total_pages: int,
        total_items: int,
        base_url: str,
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        pagination = {
            "current_page": current_page,
            "total_pages": total_pages,
            "total_items": total_items,
            "has_prev": current_page > 1,
            "has_next": current_page < total_pages
        }
        
        if pagination["has_prev"]:
            prev_params = params.copy()
            prev_params["page"] = current_page - 1
            pagination["prev_url"] = f"{base_url}?{urlencode(prev_params)}"
        else:
            pagination["prev_url"] = None
        
        if pagination["has_next"]:
            next_params = params.copy()
            next_params["page"] = current_page + 1
            pagination["next_url"] = f"{base_url}?{urlencode(next_params)}"
        else:
            pagination["next_url"] = None
        
        pagination["pages"] = []
        
        start_page = max(1, current_page - 2)
        end_page = min(total_pages, current_page + 2)
        
        for page in range(start_page, end_page + 1):
            page_params = params.copy()
            page_params["page"] = page
            pagination["pages"].append({
                "number": page,
                "url": f"{base_url}?{urlencode(page_params)}",
                "is_current": page == current_page
            })
        
        return pagination
    
    @staticmethod
    def validate_page(page: int, max_page: int = 1000) -> int:
        page = max(1, page)
        page = min(page, max_page)
        return page


class ResponseFormatter:
    @staticmethod
    def format_response(
        success: bool,
        data: Any = None,
        message: str = None,
        status_code: int = 200,
        meta: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        response = {
            "status": status_code,
            "success": success,
            "author": "zhadevv",
            "data": data if success else None,
            "message": message if not success else None
        }
        
        if meta:
            response["meta"] = meta
        
        return response
    
    @staticmethod
    def format_error(
        message: str,
        status_code: int = 400,
        error_code: str = None,
        errors: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        error_response = {
            "status": status_code,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": message
        }
        
        if error_code:
            error_response["error_code"] = error_code
        
        if errors:
            error_response["errors"] = errors
        
        return error_response
    
    @staticmethod
    def add_pagination_to_response(
        response: Dict[str, Any],
        pagination: Dict[str, Any]
    ) -> Dict[str, Any]:
        if "meta" not in response:
            response["meta"] = {}
        
        response["meta"]["pagination"] = pagination
        return response


api_utils = APIUtils()
rate_limit_utils = RateLimitUtils()
pagination_utils = PaginationUtils()
response_formatter = ResponseFormatter()