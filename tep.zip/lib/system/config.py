#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field, validator
from datetime import datetime, timedelta
import secrets
import string

class EnvironmentConfig(BaseModel):
    JWT_SECRET: str = ""
    JWT_EXPIRE: int = 3
    
    DEFAULT_RPM: int = 25
    
    ADMIN_APIKEY: str = ""
    DEV_APIKEY: str = ""
    OWNER_APIKEY: str = ""
    
    CF_API_TOKEN: str = ""
    CF_ZONE_ID: str = ""
    
    DATABASE_URL: str = "sqlite:///./data/zhadev.db"
    
    @validator("DEV_APIKEY")
    def validate_dev_apikey(cls, v):
        if v == "":
            return secrets.token_urlsafe(16)
        return v
    
    @validator("OWNER_APIKEY")
    def validate_owner_apikey(cls, v):
        if v == "":
            return secrets.token_urlsafe(32)
        return v


class APIRateLimit(BaseModel):
    rpm: int
    monthly_limit: int


class RateLimits(BaseModel):
    guest: APIRateLimit = APIRateLimit(rpm=25, monthly_limit=1000)
    free: APIRateLimit = APIRateLimit(rpm=50, monthly_limit=5000)
    starter: APIRateLimit = APIRateLimit(rpm=100, monthly_limit=10000)
    medium: APIRateLimit = APIRateLimit(rpm=150, monthly_limit=50000)
    highest: APIRateLimit = APIRateLimit(rpm=200, monthly_limit=100000)
    enterprise: APIRateLimit = APIRateLimit(rpm=0, monthly_limit=0)
    admin: APIRateLimit = APIRateLimit(rpm=1000, monthly_limit=1000000)
    developer: APIRateLimit = APIRateLimit(rpm=2000, monthly_limit=5000000)
    owner: APIRateLimit = APIRateLimit(rpm=10000, monthly_limit=10000000)


class ApiKeyConfig(BaseModel):
    key: str
    username: str
    role: str
    active: bool = True
    active_versions: list = ["v1"]
    rpm: int
    monthly_limit: int
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    requests_count: int = 0
    requests_month: int = 0
    last_reset: datetime = Field(default_factory=datetime.utcnow)
    suspended: bool = False
    custom_key: Optional[str] = None


class IPLog(BaseModel):
    ip: str
    apikey: Optional[str]
    endpoint: str
    method: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    user_agent: Optional[str]
    response_time: float
    status_code: int


class BannedIP(BaseModel):
    ip: str
    reason: str
    banned_at: datetime = Field(default_factory=datetime.utcnow)
    banned_by: str
    expires_at: Optional[datetime]


class ConfigManager:
    _instance = None
    _config = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._config is None:
            self.load_config()
    
    def load_config(self):
        env_config = {}
        
        for key in EnvironmentConfig.__fields__.keys():
            env_value = os.getenv(key)
            if env_value is not None:
                try:
                    if key in ["JWT_EXPIRE", "DEFAULT_RPM"]:
                        env_config[key] = int(env_value)
                    else:
                        env_config[key] = env_value
                except ValueError:
                    env_config[key] = env_value
        
        self.env = EnvironmentConfig(**env_config)
        
        config_path = Path("config.yaml")
        self.yaml_config = {}
        
        if config_path.exists():
            with open(config_path, 'r') as f:
                self.yaml_config = yaml.safe_load(f) or {}
        
        self.rate_limits = RateLimits()
        
        self.data_dir = Path("data")
        self.data_dir.mkdir(exist_ok=True)
    
    def get_rate_limit(self, role: str) -> APIRateLimit:
        if hasattr(self.rate_limits, role):
            return getattr(self.rate_limits, role)
        return self.rate_limits.guest
    
    def is_valid_apikey_format(self, apikey: str) -> bool:
        if not apikey:
            return False
        
        if apikey == self.env.OWNER_APIKEY:
            return True
        
        if apikey == self.env.DEV_APIKEY:
            return True
        
        if apikey == self.env.ADMIN_APIKEY:
            return True
        
        return True
    
    def generate_apikey(self, role: str = "free", custom_key: Optional[str] = None) -> str:
        if custom_key:
            return custom_key
        
        if role == "free":
            prefix = "SK_zhadev-freekeys_"
            length = 16
        elif role in ["starter", "medium", "highest", "enterprise"]:
            prefix = "SK_zhadev_"
            length = 32
        else:
            prefix = f"SK_zhadev-{role}_"
            length = 32
        
        chars = string.ascii_letters + string.digits
        random_part = ''.join(secrets.choice(chars) for _ in range(length - len(prefix)))
        
        return f"{prefix}{random_part}"
    
    def get_jwt_expire_delta(self) -> timedelta:
        return timedelta(days=self.env.JWT_EXPIRE)


config = ConfigManager()