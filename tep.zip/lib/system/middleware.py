#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

import time
import json
from typing import Dict, Any, Optional, Callable
from datetime import datetime, timedelta
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint
import asyncio
from collections import defaultdict
import hashlib

class RateLimiter:
    def __init__(self):
        self.requests = defaultdict(list)
        self.monthly_requests = defaultdict(int)
        self.locks = defaultdict(asyncio.Lock)
        
    def is_rate_limited(self, identifier: str, rpm: int) -> bool:
        now = time.time()
        
        if identifier not in self.requests:
            return False
        
        window_start = now - 60
        
        recent_requests = [
            req_time for req_time in self.requests[identifier] 
            if req_time > window_start
        ]
        
        self.requests[identifier] = recent_requests
        
        return len(recent_requests) >= rpm
    
    def add_request(self, identifier: str):
        now = time.time()
        self.requests[identifier].append(now)
        
        current_month = datetime.utcnow().strftime("%Y-%m")
        monthly_key = f"{identifier}:{current_month}"
        self.monthly_requests[monthly_key] += 1
    
    def get_monthly_count(self, identifier: str) -> int:
        current_month = datetime.utcnow().strftime("%Y-%m")
        monthly_key = f"{identifier}:{current_month}"
        return self.monthly_requests.get(monthly_key, 0)
    
    async def acquire(self, identifier: str, rpm: int) -> bool:
        async with self.locks[identifier]:
            if self.is_rate_limited(identifier, rpm):
                return False
            self.add_request(identifier)
            return True


class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = hashlib.sha256(
            f"{request.client.host}:{time.time()}".encode()
        ).hexdigest()[:16]
        
        request.state.request_id = request_id
        
        response = await call_next(request)
        
        response.headers["X-Request-ID"] = request_id
        
        return response


class TimingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.time()
        
        response = await call_next(request)
        
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = f"{process_time:.3f}"
        
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        
        security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
            "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self'"
        }
        
        for header, value in security_headers.items():
            response.headers[header] = value
        
        return response


class IPBlockMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.banned_ips = set()
        
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        client_ip = request.client.host
        
        if client_ip in self.banned_ips:
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "IP address banned"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        response = await call_next(request)
        return response
    
    def ban_ip(self, ip: str):
        self.banned_ips.add(ip)
    
    def unban_ip(self, ip: str):
        self.banned_ips.discard(ip)


class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.time()
        
        client_ip = request.client.host
        user_agent = request.headers.get("user-agent", "")
        method = request.method
        url = str(request.url)
        
        try:
            response = await call_next(request)
            process_time = time.time() - start_time
            
            from lib.database import DatabaseManager
            db = DatabaseManager()
            
            log_data = {
                "ip": client_ip,
                "endpoint": url,
                "method": method,
                "user_agent": user_agent[:500] if user_agent else None,
                "response_time": process_time,
                "status_code": response.status_code,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            auth_header = request.headers.get("authorization")
            if auth_header and auth_header.startswith("Bearer "):
                apikey = auth_header[7:]
                from .validator import validator
                valid, _ = validator.validate_apikey(apikey)
                if valid:
                    log_data["apikey"] = apikey
            
            db.log_request(**log_data)
            
            return response
            
        except Exception as e:
            process_time = time.time() - start_time
            
            from lib.database import DatabaseManager
            db = DatabaseManager()
            
            log_data = {
                "ip": client_ip,
                "endpoint": url,
                "method": method,
                "user_agent": user_agent[:500] if user_agent else None,
                "response_time": process_time,
                "status_code": 500,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            db.log_request(**log_data)
            
            raise


class CompressionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        
        accept_encoding = request.headers.get("accept-encoding", "")
        
        if "gzip" in accept_encoding:
            import gzip
            import io
            
            if response.body:
                body = response.body
                
                if not isinstance(body, bytes):
                    body = body.encode('utf-8')
                
                compressed = gzip.compress(body)
                
                response.body = compressed
                response.headers["Content-Encoding"] = "gzip"
                response.headers["Content-Length"] = str(len(compressed))
        
        return response


class CacheMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self.cache = {}
        self.cache_ttl = {}
        
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        if request.method != "GET":
            return await call_next(request)
        
        cache_key = f"{request.url}:{request.headers.get('authorization', '')}"
        current_time = time.time()
        
        if cache_key in self.cache:
            cache_data = self.cache[cache_key]
            cache_time = self.cache_ttl[cache_key]
            
            if current_time - cache_time < 300:
                response_data, headers = cache_data
                
                response = Response(
                    content=json.dumps(response_data),
                    status_code=200,
                    headers=dict(headers),
                    media_type="application/json"
                )
                
                response.headers["X-Cache"] = "HIT"
                return response
        
        response = await call_next(request)
        
        if response.status_code == 200 and "no-cache" not in request.headers.get("cache-control", ""):
            try:
                response_data = json.loads(response.body.decode())
                
                if response_data.get("success", False):
                    self.cache[cache_key] = (response_data, dict(response.headers))
                    self.cache_ttl[cache_key] = current_time
                    
                    response.headers["X-Cache"] = "MISS"
                    response.headers["Cache-Control"] = "public, max-age=300"
            except:
                pass
              
        return response
        
    def clear_cache(self):
        self.cache.clear()
        self.cache_ttl.clear()

rate_limiter = RateLimiter()