#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

import httpx
import asyncio
from bs4 import BeautifulSoup
import re
from typing import Dict, List, Any, Optional, Union
from urllib.parse import urljoin, urlparse, parse_qs, urlencode
import time
import json

class OploverzParser:
    def __init__(self, base_url: str = "https://oploverz.mom", timeout: int = 30, retries: int = 3):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.retries = retries
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0',
        }
        self.client = None

    async def __aenter__(self):
        limits = httpx.Limits(max_keepalive_connections=5, max_connections=10)
        self.client = httpx.AsyncClient(
            timeout=self.timeout,
            limits=limits,
            headers=self.headers,
            follow_redirects=True
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    async def fetch(self, url: str) -> Optional[str]:
        full_url = urljoin(self.base_url, url)
        
        for attempt in range(self.retries):
            try:
                response = await self.client.get(full_url)
                response.raise_for_status()
                return response.text
            except (httpx.TimeoutException, httpx.NetworkError):
                if attempt < self.retries - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise
            except httpx.HTTPStatusError as e:
                if e.response.status_code in [403, 429] and attempt < self.retries - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise

    def build_response(self, success: bool, data: Any = None, message: str = None) -> Dict:
        return {
            "status": 200,
            "success": success,
            "author": "zhadevv",
            "data": data,
            "message": message
        }

    def extract_slug(self, url: str) -> str:
        if not url:
            return ""
        
        path = urlparse(url).path.strip('/')
        parts = [p for p in path.split('/') if p]
        return parts[-1] if parts else ""

    def parse_list_item(self, article: BeautifulSoup) -> Dict:
        bsx = article.find('div', class_='bsx')
        if not bsx:
            return {}
        
        link = bsx.find('a', class_='tip')
        typez = bsx.find('div', class_='typez')
        bt = bsx.find('div', class_='bt')
        img = bsx.find('img', class_='ts-post-image')
        tt = bsx.find('div', class_='tt')
        h2 = bsx.find('h2', itemprop='headline')
        
        badges = []
        if bt:
            epx_badges = bt.find_all('span', class_='epx')
            for badge in epx_badges:
                badges.append({
                    "type": "episode",
                    "text": badge.get_text(strip=True)
                })
            
            sb_badges = bt.find_all('span', class_='sb')
            for badge in sb_badges:
                badges.append({
                    "type": "subtitle",
                    "text": badge.get_text(strip=True)
                })
        
        return {
            "title": h2.get_text(strip=True) if h2 else "",
            "series_name": tt.get_text(strip=True) if tt else "",
            "slug": self.extract_slug(link.get('href')) if link else "",
            "thumbnail": img.get('src') if img else "",
            "badges": badges,
            "type": typez.get_text(strip=True) if typez else "",
            "rel_id": link.get('rel') if link else "",
            "url": urljoin(self.base_url, link.get('href')) if link else ""
        }
        
    async def sidebar(self) -> Dict:
        """Parse sidebar content from home page"""
        try:
            html = await self.fetch("/")
            return await self._parse_sidebar_content(html)
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse sidebar: {str(e)}")
    
    async def _parse_sidebar_content(self, html: str) -> Dict:
        """Internal method to parse sidebar content"""
        soup = BeautifulSoup(html, 'html.parser')
        sidebar = {}
    
        quick_filter = soup.find('div', class_='quickfilter')
        if quick_filter:
            sidebar["quick_filter"] = {
                "checkbox_filters": {},
                "radio_filters": {}
            }
    
            genre_filter = quick_filter.find('div', class_='filter dropdown', string=lambda x: x and 'Genre' in str(x))
            if genre_filter:
                items = []
                genre_items = genre_filter.find('ul', class_='dropdown-menu').find_all('li')
                for item in genre_items:
                    checkbox = item.find('input', type='checkbox', name='genre[]')
                    label = item.find('label')
                    count = item.find('span', class_='count')
                    
                    items.append({
                        "value": checkbox.get('value', '') if checkbox else '',
                        "label": label.get_text(strip=True) if label else '',
                        "count": count.get_text(strip=True) if count else '',
                        "checked": checkbox.has_attr('checked') if checkbox else False
                    })
                
                sidebar["quick_filter"]["checkbox_filters"]["genre"] = {
                    "label": genre_filter.find('button', class_='dropdown-toggle').get_text(strip=True),
                    "type": "checkbox",
                    "multiple": True,
                    "items": items
                }
    
            season_filter = quick_filter.find('div', class_='filter dropdown', string=lambda x: x and 'Season' in str(x))
            if season_filter:
                items = []
                season_items = season_filter.find('ul', class_='dropdown-menu').find_all('li')
                for item in season_items:
                    checkbox = item.find('input', type='checkbox', name='season[]')
                    label = item.find('label')
                    count = item.find('span', class_='count')
                    
                    items.append({
                        "value": checkbox.get('value', '') if checkbox else '',
                        "label": label.get_text(strip=True) if label else '',
                        "count": count.get_text(strip=True) if count else '',
                        "checked": checkbox.has_attr('checked') if checkbox else False
                    })
                
                sidebar["quick_filter"]["checkbox_filters"]["season"] = {
                    "label": season_filter.find('button', class_='dropdown-toggle').get_text(strip=True),
                    "type": "checkbox",
                    "multiple": True,
                    "items": items
                }
    
            studio_filter = quick_filter.find('div', class_='filter dropdown', string=lambda x: x and 'Studio' in str(x))
            if studio_filter:
                items = []
                studio_items = studio_filter.find('ul', class_='dropdown-menu').find_all('li')
                for item in studio_items:
                    checkbox = item.find('input', type='checkbox', name='studio[]')
                    label = item.find('label')
                    count = item.find('span', class_='count')
                    
                    items.append({
                        "value": checkbox.get('value', '') if checkbox else '',
                        "label": label.get_text(strip=True) if label else '',
                        "count": count.get_text(strip=True) if count else '',
                        "checked": checkbox.has_attr('checked') if checkbox else False
                    })
                
                sidebar["quick_filter"]["checkbox_filters"]["studio"] = {
                    "label": studio_filter.find('button', class_='dropdown-toggle').get_text(strip=True),
                    "type": "checkbox",
                    "multiple": True,
                    "items": items
                }
    
            status_filter = quick_filter.find('div', class_='filter', string=lambda x: x and 'Status' in str(x))
            if status_filter:
                items = []
                radio_items = status_filter.find('div', class_='radio-group').find_all('label')
                for item in radio_items:
                    radio = item.find('input', type='radio', name='status')
                    span = item.find('span')
                    
                    items.append({
                        "value": radio.get('value', '') if radio else '',
                        "label": span.get_text(strip=True) if span else '',
                        "checked": radio.has_attr('checked') if radio else False
                    })
                
                sidebar["quick_filter"]["radio_filters"]["status"] = {
                    "label": "Status",
                    "type": "radio",
                    "multiple": False,
                    "items": items
                }
    
            type_filter = quick_filter.find('div', class_='filter', string=lambda x: x and 'Type' in str(x))
            if type_filter:
                items = []
                radio_items = type_filter.find('div', class_='radio-group').find_all('label')
                for item in radio_items:
                    radio = item.find('input', type='radio', name='type')
                    span = item.find('span')
                    
                    items.append({
                        "value": radio.get('value', '') if radio else '',
                        "label": span.get_text(strip=True) if span else '',
                        "checked": radio.has_attr('checked') if radio else False
                    })
                
                sidebar["quick_filter"]["radio_filters"]["type"] = {
                    "label": "Type",
                    "type": "radio",
                    "multiple": False,
                    "items": items
                }
    
            order_filter = quick_filter.find('div', class_='filter', string=lambda x: x and 'Order' in str(x))
            if order_filter:
                items = []
                radio_items = order_filter.find('div', class_='radio-group').find_all('label')
                for item in radio_items:
                    radio = item.find('input', type='radio', name='order')
                    span = item.find('span')
                    
                    items.append({
                        "value": radio.get('value', '') if radio else '',
                        "label": span.get_text(strip=True) if span else '',
                        "checked": radio.has_attr('checked') if radio else False
                    })
                
                sidebar["quick_filter"]["radio_filters"]["order"] = {
                    "label": "Order",
                    "type": "radio",
                    "multiple": False,
                    "items": items
                }
    
        movie_section = soup.find('div', class_='releases', string=lambda x: x and 'NEW MOVIE' in str(x))
        if movie_section:
            sidebar["new_movie"] = {
                "title": movie_section.find('h3').get_text(strip=True) if movie_section.find('h3') else "",
                "lists": []
            }
            
            movie_items = movie_section.find('div', class_='serieslist').find_all('li')
            for item in movie_items:
                image = item.find('div', class_='imgseries').find('img')
                title_link = item.find('h4').find('a', class_='series')
                genres = item.find('span', string=lambda x: x and 'Genres' in str(x)).find_all('a')
                date_span = item.find_all('span')[-1]
                
                genre_list = []
                for genre in genres:
                    genre_list.append({
                        "name": genre.get_text(strip=True),
                        "slug": self.extract_slug(genre.get('href'))
                    })
                
                sidebar["new_movie"]["lists"].append({
                    "title": title_link.get_text(strip=True) if title_link else "",
                    "slug": self.extract_slug(title_link.get('href')) if title_link else "",
                    "thumbnail": image.get('src') if image else "",
                    "release_date": date_span.get_text(strip=True) if date_span else "",
                    "genres": genre_list,
                    "url": urljoin(self.base_url, title_link.get('href')) if title_link else ""
                })
    
        return self.build_response(True, {"sidebar": sidebar})

    async def home(self, page: int = 1) -> Dict:
        try:
            if page == 1:
                url = "/"
            else:
                url = f"/page/{page}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "slider": [],
                "popular_today": [],
                "latest_release": [],
                "recommendation": {},
                "pagination": {}
            }
            
            slider = soup.find('div', id='slidertwo', class_='swiper-container')
            if slider:
                slides = slider.find_all('div', class_='swiper-slide item')
                for slide in slides:
                    backdrop = slide.find('div', class_='backdrop')
                    info = slide.find('div', class_='info')
                    watch_btn = info.find('a', class_='watch') if info else None
                    title_link = info.find('h2').find('a') if info and info.find('h2') else None
                    
                    bg_style = backdrop.get('style') if backdrop else ''
                    bg_match = re.search(r"url\(['\"]?(.*?)['\"]?\)", bg_style)
                    
                    data["slider"].append({
                        "title": title_link.get_text(strip=True) if title_link else "",
                        "slug": self.extract_slug(title_link.get('href')) if title_link else "",
                        "data_title": slide.get('data-title', ''),
                        "description": info.find('p').get_text(strip=True) if info and info.find('p') else "",
                        "thumbnail": bg_match.group(1) if bg_match else "",
                        "watch_url": urljoin(self.base_url, watch_btn.get('href')) if watch_btn else "",
                        "series_url": urljoin(self.base_url, title_link.get('href')) if title_link else ""
                    })
            
            popular_section = soup.find('div', class_='bixbox bbnofrm', string=lambda x: x and 'Popular Today' in str(x))
            if popular_section:
                articles = popular_section.find_all('article', class_='bs')
                for article in articles:
                    data["popular_today"].append(self.parse_list_item(article))
            
            latest_section = soup.find('div', class_='releases latesthome')
            if latest_section:
                articles = latest_section.find_next('div', class_='listupd normal').find_all('article', class_='bs')
                for article in articles:
                    data["latest_release"].append(self.parse_list_item(article))
            
            rec_section = soup.find('div', class_='bixbox bbnofrm', string=lambda x: x and 'Recommendation' in str(x))
            if rec_section:
                tabs = rec_section.find('ul', class_='nav-tabs').find_all('li')
                data["recommendation"]["tabs"] = []
                
                for tab in tabs:
                    link = tab.find('a')
                    data["recommendation"]["tabs"].append({
                        "id": link.get('href', '').replace('#', ''),
                        "name": link.get_text(strip=True),
                        "active": 'active' in tab.get('class', [])
                    })
                
                panes = rec_section.find_all('div', class_='tab-pane')
                data["recommendation"]["contents"] = {}
                
                for pane in panes:
                    tab_id = pane.get('id', '')
                    articles = pane.find_all('article', class_='bs')
                    
                    data["recommendation"]["contents"][tab_id] = []
                    for article in articles:
                        data["recommendation"]["contents"][tab_id].append(self.parse_list_item(article))
            
            pagination = soup.find('div', class_='hpage')
            if pagination:
                prev_link = pagination.find('a', class_='l')
                next_link = pagination.find('a', class_='r')
                
                data["pagination"] = {
                    "prev": {
                        "url": urljoin(self.base_url, prev_link.get('href')) if prev_link else "",
                        "text": prev_link.get_text(strip=True) if prev_link else "",
                        "has_prev": bool(prev_link)
                    },
                    "next": {
                        "url": urljoin(self.base_url, next_link.get('href')) if next_link else "",
                        "text": next_link.get_text(strip=True) if next_link else "",
                        "has_next": bool(next_link)
                    }
                }
            
            return self.build_response(True, {"home": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse home: {str(e)}")

    async def search(self, query: str, page: int = 1) -> Dict:
        try:
            encoded_query = query.replace(' ', '+')
            if page == 1:
                url = f"/?s={encoded_query}"
            else:
                url = f"/page/{page}/?s={encoded_query}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "query": query,
                "title": "",
                "results_count": 0,
                "lists": [],
                "pagination": {}
            }
            
            header = soup.find('div', class_='bixbox')
            if header:
                title_span = header.find('div', class_='releases').find('h1').find('span')
                if title_span:
                    title_text = title_span.get_text(strip=True)
                    data["title"] = title_text
                    match = re.search(r"Search\s+['\"](.+?)['\"]", title_text)
                    if match:
                        data["query"] = match.group(1)
            
            results = soup.find('div', class_='listupd')
            if results:
                articles = results.find_all('article', class_='bs')
                for article in articles:
                    data["lists"].append(self.parse_list_item(article))
                data["results_count"] = len(data["lists"])
            
            pagination = soup.find('div', class_='pagination')
            if pagination:
                current_page = pagination.find('span', class_='page-numbers current')
                prev_link = pagination.find('a', class_='prev page-numbers')
                next_link = pagination.find('a', class_='next page-numbers')
                
                data["pagination"] = {
                    "current_page": int(current_page.get_text(strip=True)) if current_page else 1,
                    "total_pages": 0,
                    "has_prev": bool(prev_link),
                    "has_next": bool(next_link),
                    "prev": {
                        "url": urljoin(self.base_url, prev_link.get('href')) if prev_link else "",
                        "text": prev_link.get_text(strip=True) if prev_link else ""
                    },
                    "next": {
                        "url": urljoin(self.base_url, next_link.get('href')) if next_link else "",
                        "text": next_link.get_text(strip=True) if next_link else ""
                    },
                    "pages": []
                }
                
                page_links = pagination.find_all('a', class_='page-numbers')
                for link in page_links:
                    if 'prev' not in link.get('class', []) and 'next' not in link.get('class', []):
                        try:
                            page_num = int(link.get_text(strip=True))
                            data["pagination"]["pages"].append({
                                "number": page_num,
                                "url": urljoin(self.base_url, link.get('href')),
                                "is_current": 'current' in link.get('class', [])
                            })
                        except ValueError:
                            continue
                
                if data["pagination"]["pages"]:
                    data["pagination"]["total_pages"] = max(p["number"] for p in data["pagination"]["pages"])
                elif data["pagination"]["has_next"]:
                    data["pagination"]["total_pages"] = data["pagination"]["current_page"] + 1
                else:
                    data["pagination"]["total_pages"] = data["pagination"]["current_page"]
            
            return self.build_response(True, {"search": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse search: {str(e)}")

    async def schedule(self) -> Dict:
        try:
            html = await self.fetch("/jadwal-rilis")
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "title": "",
                "notice": "",
                "days": {}
            }
            
            header = soup.find('div', class_='bixbox')
            if header:
                title_span = header.find('div', class_='releases').find('h1').find('span')
                if title_span:
                    data["title"] = title_span.get_text(strip=True)
            
            notice_div = soup.find('div', class_='listupd', style=lambda x: x and 'line-height' in x)
            if notice_div:
                data["notice"] = notice_div.get_text(strip=True)
            
            days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
            
            for day in days:
                day_section = soup.find('div', class_=f'bixbox schedulepage sch_{day}')
                if day_section:
                    day_title = day_section.find('div', class_='releases').find('h3').find('span')
                    
                    data["days"][day] = {
                        "title": day_title.get_text(strip=True) if day_title else day.capitalize(),
                        "lists": []
                    }
                    
                    items = day_section.find_all('div', class_='bs')
                    for item in items:
                        bsx = item.find('div', class_='bsx')
                        link = bsx.find('a')
                        countdown = bsx.find('span', class_='epx cndwn')
                        episode_badge = bsx.find('span', class_='sb')
                        img = bsx.find('img', class_='attachment-post-thumbnail')
                        tt = bsx.find('div', class_='tt')
                        
                        item_data = {
                            "title": tt.get_text(strip=True) if tt else "",
                            "slug": self.extract_slug(link.get('href')) if link else "",
                            "thumbnail": img.get('src') if img else "",
                            "countdown": {
                                "raw": countdown.get('data-cndwn') if countdown else "",
                                "text": countdown.get_text(strip=True) if countdown else "",
                                "timestamp": countdown.get('data-rlsdt') if countdown else "",
                                "formatted": countdown.get_text(strip=True) if countdown else ""
                            } if countdown else {},
                            "release_time": {
                                "raw": countdown.get('data-rlsdt') if countdown else "",
                                "formatted": ""
                            } if countdown else {},
                            "current_episode": episode_badge.get_text(strip=True) if episode_badge else "",
                            "url": urljoin(self.base_url, link.get('href')) if link else ""
                        }
                        
                        if countdown and countdown.get('data-rlsdt'):
                            try:
                                timestamp = int(countdown.get('data-rlsdt'))
                                dt = time.localtime(timestamp)
                                item_data["release_time"]["formatted"] = time.strftime("%Y-%m-%d %H:%M:%S", dt)
                            except:
                                item_data["release_time"]["formatted"] = ""
                        
                        data["days"][day]["lists"].append(item_data)
                else:
                    data["days"][day] = {
                        "title": day.capitalize(),
                        "lists": []
                    }
            
            return self.build_response(True, {"schedule": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse schedule: {str(e)}")

    async def genres(self, slug: str, page: int = 1) -> Dict:
        try:
            if page == 1:
                url = f"/genres/{slug}"
            else:
                url = f"/genres/{slug}/page/{page}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "page_type": "genres",
                "genre": {
                    "name": "",
                    "slug": slug,
                    "total_pages": 0
                },
                "lists": [],
                "pagination": {}
            }
            
            header = soup.find('div', class_='bixbox bbnofrm')
            if header:
                title_span = header.find('div', class_='releases').find('h1').find('span')
                if title_span:
                    genre_name = title_span.get_text(strip=True).replace('Genre:', '').strip()
                    data["genre"]["name"] = genre_name
            
            articles = soup.find_all('article', class_='bs')
            for article in articles:
                data["lists"].append(self.parse_list_item(article))
            
            pagination = soup.find('div', class_='pagination')
            if pagination:
                current_page = pagination.find('span', class_='page-numbers current')
                prev_link = pagination.find('a', class_='prev page-numbers')
                next_link = pagination.find('a', class_='next page-numbers')
                
                data["pagination"] = {
                    "current_page": int(current_page.get_text(strip=True)) if current_page else 1,
                    "total_pages": 0,
                    "has_prev": bool(prev_link),
                    "has_next": bool(next_link),
                    "prev": {
                        "url": urljoin(self.base_url, prev_link.get('href')) if prev_link else "",
                        "text": prev_link.get_text(strip=True) if prev_link else ""
                    },
                    "next": {
                        "url": urljoin(self.base_url, next_link.get('href')) if next_link else "",
                        "text": next_link.get_text(strip=True) if next_link else ""
                    },
                    "pages": []
                }
                
                page_links = pagination.find_all('a', class_='page-numbers')
                for link in page_links:
                    if 'prev' not in link.get('class', []) and 'next' not in link.get('class', []):
                        try:
                            page_num = int(link.get_text(strip=True))
                            data["pagination"]["pages"].append({
                                "number": page_num,
                                "url": urljoin(self.base_url, link.get('href')),
                                "is_current": 'current' in link.get('class', [])
                            })
                        except ValueError:
                            continue
                
                if data["pagination"]["pages"]:
                    data["pagination"]["total_pages"] = max(p["number"] for p in data["pagination"]["pages"])
                elif data["pagination"]["has_next"]:
                    data["pagination"]["total_pages"] = data["pagination"]["current_page"] + 1
                else:
                    data["pagination"]["total_pages"] = data["pagination"]["current_page"]
            
            data["genre"]["total_pages"] = data["pagination"]["total_pages"]
            
            return self.build_response(True, data)
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse genres: {str(e)}")

    async def watch(self, slug: str, ep_num: int) -> Dict:
        try:
            url = f"/{slug}-episode-{ep_num}-subtitle-indonesia"
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "id": "",
                "title": "",
                "slug": slug,
                "episode_number": str(ep_num),
                "thumbnail": "",
                "type": "",
                "subtitle": "",
                "release_date": "",
                "posted_by": "",
                "series": {"title": "", "url": "", "slug": ""},
                "servers": [],
                "current_server": {"iframe_src": "", "iframe_title": ""},
                "downloads": [],
                "description": "",
                "series_info": {
                    "title": "",
                    "alter_title": "",
                    "thumbnail": "",
                    "rating": {"text": "", "percentage": 0},
                    "information": {
                        "status": "",
                        "network": [],
                        "studio": [],
                        "released": "",
                        "duration": "",
                        "season": "",
                        "country": "",
                        "type": "",
                        "total_episodes": ""
                    },
                    "genres": [],
                    "synopsis": ""
                },
                "episode_navigation": {
                    "prev_episode": {"text": "", "url": ""},
                    "all_episodes": {"text": "", "url": ""},
                    "next_episode": {"text": "", "url": ""}
                },
                "related_episodes": [],
                "sidebar_episodes": {
                    "series": {"title": "", "url": "", "thumbnail": "", "status": "", "current_episode": "", "total_episodes": 0},
                    "episodes": []
                },
                "meta": {
                    "author": "",
                    "date_published": "",
                    "date_modified": "",
                    "publisher": {"name": "", "logo": ""}
                },
                "url": urljoin(self.base_url, url)
            }
            
            player_section = soup.find('div', class_='megavid')
            if player_section:
                thumbnail = player_section.find('div', class_='tb').find('img')
                if thumbnail:
                    data["thumbnail"] = thumbnail.get('src', '')
                
                title = player_section.find('h1', class_='entry-title')
                if title:
                    data["title"] = title.get_text(strip=True)
                
                ep_number_meta = player_section.find('meta', itemprop='episodeNumber')
                if ep_number_meta:
                    data["episode_number"] = ep_number_meta.get('content', str(ep_num))
                
                lm_section = player_section.find('div', class_='lm')
                if lm_section:
                    type_badge = lm_section.find('span', class_='epx')
                    if type_badge:
                        data["type"] = type_badge.get_text(strip=True)
                    
                    subtitle_badge = lm_section.find('span', class_='lg')
                    if subtitle_badge:
                        data["subtitle"] = subtitle_badge.get_text(strip=True)
                    
                    release_date = lm_section.find('span', class_='updated')
                    if release_date:
                        data["release_date"] = release_date.get_text(strip=True)
                    
                    posted_by = lm_section.find('span', class_='vcard').find('a')
                    if posted_by:
                        data["posted_by"] = posted_by.get_text(strip=True)
                    
                    series_link = lm_section.find('span', class_='year').find('a')
                    if series_link:
                        data["series"] = {
                            "title": series_link.get_text(strip=True),
                            "url": urljoin(self.base_url, series_link.get('href', '')),
                            "slug": self.extract_slug(series_link.get('href', ''))
                        }
            
            video_nav = soup.find('div', class_='item video-nav')
            if video_nav:
                server_select = video_nav.find('select', class_='mirror')
                if server_select:
                    options = server_select.find_all('option')
                    for option in options:
                        data["servers"].append({
                            "server_id": option.get('value', ''),
                            "server_name": option.get_text(strip=True),
                            "server_url": option.get('value', ''),
                            "iframe_code": option.get('value', '')
                        })
            
            video_content = soup.find('div', class_='video-content')
            if video_content:
                iframe = video_content.find('div', id='pembed').find('iframe')
                if iframe:
                    data["current_server"] = {
                        "iframe_src": iframe.get('src', ''),
                        "iframe_title": iframe.get('title', '')
                    }
            
            download_section = soup.find('div', class_='bixbox', string=lambda x: x and 'Download' in str(x))
            if download_section:
                batch_divs = download_section.find_all('div', class_='soraddlx')
                for batch in batch_divs:
                    batch_title = batch.find('div', class_='sorattlx').find('h3')
                    
                    batch_data = {
                        "title": batch_title.get_text(strip=True) if batch_title else "",
                        "qualities": []
                    }
                    
                    quality_divs = batch.find_all('div', class_='soraurlx')
                    for quality_div in quality_divs:
                        quality_name = quality_div.find('strong')
                        
                        quality_data = {
                            "quality": quality_name.get_text(strip=True) if quality_name else "",
                            "links": []
                        }
                        
                        links = quality_div.find_all('a')
                        for link in links:
                            quality_data["links"].append({
                                "name": link.get_text(strip=True),
                                "url": link.get('href', '')
                            })
                        
                        batch_data["qualities"].append(quality_data)
                    
                    data["downloads"].append(batch_data)
            
            description_section = soup.find('div', class_='entry-content').find('div', class_='bixbox infx')
            if description_section:
                description = description_section.find('p')
                if description:
                    data["description"] = description.get_text(strip=True)
            
            series_info = soup.find('div', class_='single-info')
            if series_info:
                series_title = series_info.find('h2', itemprop='partOfSeries')
                if series_title:
                    data["series_info"]["title"] = series_title.get_text(strip=True)
                
                alter_title = series_info.find('span', class_='alter')
                if alter_title:
                    data["series_info"]["alter_title"] = alter_title.get_text(strip=True)
                
                series_thumb = series_info.find('div', class_='thumb').find('img')
                if series_thumb:
                    data["series_info"]["thumbnail"] = series_thumb.get('src', '')
                
                rating_text = series_info.find('div', class_='rating').find('strong')
                if rating_text:
                    data["series_info"]["rating"]["text"] = rating_text.get_text(strip=True)
                
                rating_bar = series_info.find('div', class_='rtb').find('span')
                if rating_bar:
                    style = rating_bar.get('style', '')
                    match = re.search(r'width:\s*(\d+)%', style)
                    if match:
                        data["series_info"]["rating"]["percentage"] = int(match.group(1))
                
                info_content = series_info.find('div', class_='info-content')
                if info_content:
                    status_span = info_content.find('span', string=lambda x: x and 'Status:' in str(x))
                    if status_span:
                        data["series_info"]["information"]["status"] = status_span.get_text(strip=True).replace('Status:', '').strip()
                    
                    released_span = info_content.find('span', string=lambda x: x and 'Released:' in str(x))
                    if released_span:
                        data["series_info"]["information"]["released"] = released_span.get_text(strip=True).replace('Released:', '').strip()
                    
                    duration_span = info_content.find('span', string=lambda x: x and 'Duration:' in str(x))
                    if duration_span:
                        data["series_info"]["information"]["duration"] = duration_span.get_text(strip=True).replace('Duration:', '').strip()
                    
                    type_span = info_content.find('span', string=lambda x: x and 'Type:' in str(x))
                    if type_span:
                        data["series_info"]["information"]["type"] = type_span.get_text(strip=True).replace('Type:', '').strip()
                    
                    episodes_span = info_content.find('span', string=lambda x: x and 'Episodes:' in str(x))
                    if episodes_span:
                        data["series_info"]["information"]["total_episodes"] = episodes_span.get_text(strip=True).replace('Episodes:', '').strip()
                    
                    network_links = info_content.find('span', string=lambda x: x and 'Network:' in str(x)).find_all('a')
                    for link in network_links:
                        data["series_info"]["information"]["network"].append({
                            "name": link.get_text(strip=True),
                            "url": link.get('href', '')
                        })
                    
                    studio_links = info_content.find('span', string=lambda x: x and 'Studio:' in str(x)).find_all('a')
                    for link in studio_links:
                        data["series_info"]["information"]["studio"].append({
                            "name": link.get_text(strip=True),
                            "url": link.get('href', '')
                        })
                    
                    season_span = info_content.find('span', string=lambda x: x and 'Season:' in str(x))
                    if season_span:
                        data["series_info"]["information"]["season"] = season_span.get_text(strip=True).replace('Season:', '').strip()
                    
                    country_span = info_content.find('span', string=lambda x: x and 'Country:' in str(x))
                    if country_span:
                        data["series_info"]["information"]["country"] = country_span.get_text(strip=True).replace('Country:', '').strip()
                
                genres_div = series_info.find('div', class_='genxed')
                if genres_div:
                    genre_links = genres_div.find_all('a', rel='tag')
                    for link in genre_links:
                        data["series_info"]["genres"].append({
                            "name": link.get_text(strip=True),
                            "slug": self.extract_slug(link.get('href', '')),
                            "url": link.get('href', '')
                        })
                
                synopsis_div = series_info.find('div', class_='desc mindes')
                if synopsis_div:
                    data["series_info"]["synopsis"] = synopsis_div.get_text(strip=True)
            
            episode_nav = soup.find('div', class_='naveps bignav')
            if episode_nav:
                prev_ep = episode_nav.find('div', class_='nvs').find('div', class_='tex')
                if prev_ep:
                    data["episode_navigation"]["prev_episode"]["text"] = prev_ep.get_text(strip=True)
                    prev_link = episode_nav.find('div', class_='nvs').find('a')
                    if prev_link:
                        data["episode_navigation"]["prev_episode"]["url"] = urljoin(self.base_url, prev_link.get('href', ''))
                
                all_eps = episode_nav.find('div', class_='nvsc').find('div', class_='tex')
                if all_eps:
                    data["episode_navigation"]["all_episodes"]["text"] = all_eps.get_text(strip=True)
                    all_link = episode_nav.find('div', class_='nvsc').find('a')
                    if all_link:
                        data["episode_navigation"]["all_episodes"]["url"] = urljoin(self.base_url, all_link.get('href', ''))
                
                next_ep = episode_nav.find_all('div', class_='nvs')[-1].find('div', class_='tex')
                if next_ep:
                    data["episode_navigation"]["next_episode"]["text"] = next_ep.get_text(strip=True)
                    next_link = episode_nav.find_all('div', class_='nvs')[-1].find('a')
                    if next_link:
                        data["episode_navigation"]["next_episode"]["url"] = urljoin(self.base_url, next_link.get('href', ''))
            
            related_section = soup.find('div', class_='bixbox', string=lambda x: x and 'Related Episodes' in str(x))
            if related_section:
                items = related_section.find_all('div', class_='stylefiv')
                for item in items:
                    thumb = item.find('div', class_='thumb').find('img')
                    title_link = item.find('div', class_='inf').find('h2').find('a')
                    spans = item.find('div', class_='inf').find_all('span')
                    
                    related_item = {
                        "title": title_link.get_text(strip=True) if title_link else "",
                        "url": urljoin(self.base_url, title_link.get('href', '')) if title_link else "",
                        "thumbnail": thumb.get('src', '') if thumb else "",
                        "posted_by": spans[0].get_text(strip=True) if len(spans) > 0 else "",
                        "released": spans[1].get_text(strip=True) if len(spans) > 1 else ""
                    }
                    data["related_episodes"].append(related_item)
            
            sidebar = soup.find('div', id='singlepisode')
            if sidebar:
                series_header = sidebar.find('div', class_='headlist')
                if series_header:
                    series_title_link = series_header.find('div', class_='det').find('h3').find('a')
                    series_thumb = series_header.find('div', class_='thumb').find('img')
                    status_span = series_header.find('div', class_='det').find('span').find('i')
                    episode_span = series_header.find('div', class_='det').find('span').find('em')
                    
                    data["sidebar_episodes"]["series"] = {
                        "title": series_title_link.get_text(strip=True) if series_title_link else "",
                        "url": urljoin(self.base_url, series_title_link.get('href', '')) if series_title_link else "",
                        "thumbnail": series_thumb.get('src', '') if series_thumb else "",
                        "status": status_span.get_text(strip=True) if status_span else "",
                        "current_episode": episode_span.get_text(strip=True) if episode_span else "",
                        "total_episodes": 0
                    }
                
                episode_list = sidebar.find('div', class_='episodelist').find_all('li')
                for ep in episode_list:
                    thumb = ep.find('div', class_='thumbnel').find('img')
                    title = ep.find('div', class_='playinfo').find('h4')
                    info = ep.find('div', class_='playinfo').find('span')
                    link = ep.find('a')
                    
                    info_text = info.get_text(strip=True) if info else ""
                    ep_match = re.search(r'Eps\s+(\d+)', info_text)
                    date_match = re.search(r'(\w+\s+\d{1,2},\s+\d{4})', info_text)
                    
                    episode_data = {
                        "data_id": ep.get('data-id', ''),
                        "title": title.get_text(strip=True) if title else "",
                        "episode_number": ep_match.group(1) if ep_match else "",
                        "release_date": date_match.group(1) if date_match else "",
                        "url": urljoin(self.base_url, link.get('href', '')) if link else "",
                        "thumbnail": thumb.get('src', '') if thumb else ""
                    }
                    data["sidebar_episodes"]["episodes"].append(episode_data)
            
            author_meta = soup.find('meta', itemprop='author')
            if author_meta:
                data["meta"]["author"] = author_meta.get('content', '')
            
            date_published_meta = soup.find('meta', itemprop='datePublished')
            if date_published_meta:
                data["meta"]["date_published"] = date_published_meta.get('content', '')
            
            date_modified_meta = soup.find('meta', itemprop='dateModified')
            if date_modified_meta:
                data["meta"]["date_modified"] = date_modified_meta.get('content', '')
            
            publisher_name_meta = soup.find('span', itemprop='publisher').find('meta', itemprop='name')
            if publisher_name_meta:
                data["meta"]["publisher"]["name"] = publisher_name_meta.get('content', '')
            
            publisher_logo_meta = soup.find('span', itemprop='logo').find('meta', itemprop='url')
            if publisher_logo_meta:
                data["meta"]["publisher"]["logo"] = publisher_logo_meta.get('content', '')
            
            return self.build_response(True, {"watch": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse watch: {str(e)}")

    async def anime_detail(self, slug: str) -> Dict:
        try:
            url = f"/anime/{slug}"
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "id": "",
                "slug": slug,
                "cover": {"banner": "", "thumbnail": ""},
                "title": "",
                "alter_title": "",
                "mindesc": "",
                "synopsis": "",
                "information": {
                    "status": "",
                    "network": [],
                    "studio": [],
                    "released": "",
                    "duration": "",
                    "season": "",
                    "country": "",
                    "type": "",
                    "total_episode": "",
                    "posted_by": "",
                    "released_on": "",
                    "updated_on": ""
                },
                "rating": {"value": 0, "count": 0, "percentage": 0, "text": ""},
                "trailer": {"url": "", "text": ""},
                "bookmark": {"count": 0, "text": ""},
                "genres": [],
                "tags": [],
                "social_share": [],
                "download_batch": [],
                "episode_nav": {
                    "first_episode": {"name": "", "number": "", "url": ""},
                    "new_episode": {"name": "", "number": "", "url": ""}
                },
                "episodes": [],
                "url": urljoin(self.base_url, url)
            }
            
            cover_section = soup.find('div', class_='bixbox animefull')
            if cover_section:
                banner_img = cover_section.find('div', class_='ime').find('img')
                if banner_img:
                    data["cover"]["banner"] = banner_img.get('src', '')
                
                thumb_img = cover_section.find('div', class_='thumb').find('img')
                if thumb_img:
                    data["cover"]["thumbnail"] = thumb_img.get('src', '')
                
                rating_value_meta = cover_section.find('meta', itemprop='ratingValue')
                if rating_value_meta:
                    data["rating"]["value"] = float(rating_value_meta.get('content', 0))
                
                rating_count_meta = cover_section.find('meta', itemprop='ratingCount')
                if rating_count_meta:
                    data["rating"]["count"] = int(rating_count_meta.get('content', 0))
                
                rating_bar = cover_section.find('div', class_='rtb').find('span')
                if rating_bar:
                    style = rating_bar.get('style', '')
                    match = re.search(r'width:\s*(\d+)%', style)
                    if match:
                        data["rating"]["percentage"] = int(match.group(1))
                
                rating_text = cover_section.find('div', class_='rating').find('strong')
                if rating_text:
                    data["rating"]["text"] = rating_text.get_text(strip=True)
                
                trailer_btn = cover_section.find('a', class_='trailerbutton')
                if trailer_btn:
                    data["trailer"] = {
                        "url": trailer_btn.get('href', ''),
                        "text": trailer_btn.get_text(strip=True)
                    }
                
                bookmark_div = cover_section.find('div', class_='bookmark').find('div', class_='bmc')
                if bookmark_div:
                    text = bookmark_div.get_text(strip=True)
                    match = re.search(r'(\d+)', text)
                    data["bookmark"] = {
                        "count": int(match.group(1)) if match else 0,
                        "text": text
                    }
            
            info_section = soup.find('div', class_='infox')
            if info_section:
                title = info_section.find('h1', class_='entry-title')
                if title:
                    data["title"] = title.get_text(strip=True)
                
                alter_title = info_section.find('span', class_='alter')
                if alter_title:
                    data["alter_title"] = alter_title.get_text(strip=True)
                
                mindesc = info_section.find('div', class_='mindesc')
                if mindesc:
                    data["mindesc"] = mindesc.get_text(strip=True)
                
                synopsis = info_section.find('div', class_='desc')
                if synopsis:
                    data["synopsis"] = synopsis.get_text(strip=True)
                
                info_content = info_section.find('div', class_='info-content')
                if info_content:
                    status_span = info_content.find('span', string=lambda x: x and 'Status:' in str(x))
                    if status_span:
                        data["information"]["status"] = status_span.get_text(strip=True).replace('Status:', '').strip()
                    
                    released_span = info_content.find('span', string=lambda x: x and 'Released:' in str(x))
                    if released_span:
                        data["information"]["released"] = released_span.get_text(strip=True).replace('Released:', '').strip()
                    
                    duration_span = info_content.find('span', string=lambda x: x and 'Duration:' in str(x))
                    if duration_span:
                        data["information"]["duration"] = duration_span.get_text(strip=True).replace('Duration:', '').strip()
                    
                    type_span = info_content.find('span', string=lambda x: x and 'Type:' in str(x))
                    if type_span:
                        data["information"]["type"] = type_span.get_text(strip=True).replace('Type:', '').strip()
                    
                    episodes_span = info_content.find('span', string=lambda x: x and 'Episodes:' in str(x))
                    if episodes_span:
                        data["information"]["total_episode"] = episodes_span.get_text(strip=True).replace('Episodes:', '').strip()
                    
                    author_span = info_content.find('span', class_='author')
                    if author_span:
                        data["information"]["posted_by"] = author_span.get_text(strip=True)
                    
                    date_published = info_content.find('time', itemprop='datePublished')
                    if date_published:
                        data["information"]["released_on"] = date_published.get('datetime', '')
                    
                    date_modified = info_content.find('time', itemprop='dateModified')
                    if date_modified:
                        data["information"]["updated_on"] = date_modified.get('datetime', '')
                    
                    network_links = info_content.find('span', string=lambda x: x and 'Network:' in str(x)).find_all('a')
                    for link in network_links:
                        data["information"]["network"].append({
                            "name": link.get_text(strip=True),
                            "url": link.get('href', '')
                        })
                    
                    studio_links = info_content.find('span', string=lambda x: x and 'Studio:' in str(x)).find_all('a')
                    for link in studio_links:
                        data["information"]["studio"].append({
                            "name": link.get_text(strip=True),
                            "url": link.get('href', '')
                        })
                    
                    season_span = info_content.find('span', string=lambda x: x and 'Season:' in str(x))
                    if season_span:
                        data["information"]["season"] = season_span.get_text(strip=True).replace('Season:', '').strip()
                    
                    country_span = info_content.find('span', string=lambda x: x and 'Country:' in str(x))
                    if country_span:
                        data["information"]["country"] = country_span.get_text(strip=True).replace('Country:', '').strip()
                
                genres_div = info_section.find('div', class_='genxed')
                if genres_div:
                    genre_links = genres_div.find_all('a', rel='tag')
                    for link in genre_links:
                        data["genres"].append({
                            "name": link.get_text(strip=True),
                            "slug": self.extract_slug(link.get('href', '')),
                            "url": link.get('href', '')
                        })
            
            tags_section = soup.find('div', class_='bottom tags')
            if tags_section:
                tag_links = tags_section.find_all('a', rel='tag')
                for link in tag_links:
                    data["tags"].append({
                        "name": link.get_text(strip=True),
                        "url": link.get('href', '')
                    })
            
            social_section = soup.find('div', class_='socialts')
            if social_section:
                social_links = social_section.find_all('a')
                for link in social_links:
                    span = link.find('span')
                    data["social_share"].append({
                        "type": ' '.join(link.get('class', [])),
                        "text": span.get_text(strip=True) if span else "",
                        "url": link.get('href', '')
                    })
            
            download_section = soup.find('div', class_='bixbox', string=lambda x: x and 'Download' in str(x))
            if download_section:
                batch_divs = download_section.find_all('div', class_='soraddlx')
                for batch in batch_divs:
                    batch_title = batch.find('div', class_='sorattlx').find('h3')
                    
                    batch_data = {
                        "title": batch_title.get_text(strip=True) if batch_title else "",
                        "qualities": []
                    }
                    
                    quality_divs = batch.find_all('div', class_='soraurlx')
                    for quality_div in quality_divs:
                        quality_name = quality_div.find('strong')
                        
                        quality_data = {
                            "quality": quality_name.get_text(strip=True) if quality_name else "",
                            "links": []
                        }
                        
                        links = quality_div.find_all('a')
                        for link in links:
                            quality_data["links"].append({
                                "name": link.get_text(strip=True),
                                "url": link.get('href', '')
                            })
                        
                        batch_data["qualities"].append(quality_data)
                    
                    data["download_batch"].append(batch_data)
            
            episode_section = soup.find('div', class_='bixbox bxcl epcheck')
            if episode_section:
                episode_nav = episode_section.find('div', class_='lastend')
                if episode_nav:
                    first_ep = episode_nav.find('div', class_='inepcx')
                    if first_ep:
                        name = first_ep.find('span')
                        number = first_ep.find(class_='epcurfirst')
                        link = first_ep.find('a')
                        
                        data["episode_nav"]["first_episode"] = {
                            "name": name.get_text(strip=True) if name else "",
                            "number": number.get_text(strip=True) if number else "",
                            "url": link.get('href', '') if link else ""
                        }
                    
                    new_ep = episode_nav.find_all('div', class_='inepcx')[-1]
                    if new_ep:
                        name = new_ep.find('span')
                        number = new_ep.find(class_='epcurlast')
                        link = new_ep.find('a')
                        
                        data["episode_nav"]["new_episode"] = {
                            "name": name.get_text(strip=True) if name else "",
                            "number": number.get_text(strip=True) if number else "",
                            "url": link.get('href', '') if link else ""
                        }
                
                episode_list = episode_section.find('div', class_='eplister').find_all('li')
                for i, ep in enumerate(episode_list):
                    link = ep.find('a')
                    number = ep.find('div', class_='epl-num')
                    title = ep.find('div', class_='epl-title')
                    subtitle = ep.find('div', class_='epl-sub').find('span')
                    date = ep.find('div', class_='epl-date')
                    
                    episode_data = {
                        "index": i,
                        "number": number.get_text(strip=True) if number else "",
                        "title": title.get_text(strip=True) if title else "",
                        "subtitle": subtitle.get_text(strip=True) if subtitle else "",
                        "release_date": date.get_text(strip=True) if date else "",
                        "url": link.get('href', '') if link else ""
                    }
                    data["episodes"].append(episode_data)
            
            return self.build_response(True, {"detail": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse anime detail: {str(e)}")

    async def advanced_search(self, page: int = 1, filters: Optional[Dict] = None, mode: str = "image") -> Dict:
        try:
            base_params = {}
            
            if filters:
                for key, value in filters.items():
                    if isinstance(value, list):
                        for item in value:
                            base_params[f"{key}[]"] = item
                    else:
                        base_params[key] = value
            
            if page > 1:
                base_params['page'] = str(page)
            
            if mode == "text":
                url = "/anime/list-mode"
                if base_params:
                    url = f"{url}?{urlencode(base_params)}"
            else:
                if base_params:
                    url = f"/anime/?{urlencode(base_params)}"
                else:
                    url = "/anime" if page == 1 else f"/anime/page/{page}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            
            if mode == "text":
                return await self._parse_advanced_search_text_mode(soup, url)
            else:
                return await self._parse_advanced_search_image_mode(soup, url, filters)
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse advanced search: {str(e)}")

    async def _parse_advanced_search_image_mode(self, soup: BeautifulSoup, url: str, filters: Optional[Dict]) -> Dict:
        data = {
            "filters": {
                "mode": "image",
                "title": "",
                "applied_filters": filters or {},
                "quick_filter": {},
                "lists": [],
                "pagination": {}
            }
        }
        
        header = soup.find('div', class_='bixbox bixboxarc bbnofrm')
        if header:
            title_span = header.find('div', class_='releases').find('h1').find('span')
            if title_span:
                data["filters"]["title"] = title_span.get_text(strip=True)
        
        quick_filter = soup.find('div', class_='advancedsearch')
        if quick_filter:
            data["filters"]["quick_filter"] = {
                "checkbox_filters": {},
                "radio_filters": {}
            }
            
            genre_filter = quick_filter.find('div', class_='filter dropdown', string=lambda x: x and 'Genre' in str(x))
            if genre_filter:
                items = []
                genre_items = genre_filter.find('ul', class_='dropdown-menu c4 scrollz').find_all('li')
                for item in genre_items:
                    checkbox = item.find('input', type='checkbox', name='genre[]')
                    label = item.find('label')
                    
                    if checkbox and label:
                        items.append({
                            "value": checkbox.get('value', ''),
                            "label": label.get_text(strip=True),
                            "checked": checkbox.has_attr('checked')
                        })
                
                data["filters"]["quick_filter"]["checkbox_filters"]["genre"] = {
                    "label": genre_filter.find('button', class_='dropdown-toggle').get_text(strip=True),
                    "type": "checkbox",
                    "multiple": True,
                    "items": items
                }
            
            status_filter = quick_filter.find('div', class_='filter', string=lambda x: x and 'Status' in str(x))
            if status_filter:
                items = []
                radio_items = status_filter.find('div', class_='radio-group').find_all('label')
                for item in radio_items:
                    radio = item.find('input', type='radio', name='status')
                    span = item.find('span')
                    
                    if radio and span:
                        items.append({
                            "value": radio.get('value', ''),
                            "label": span.get_text(strip=True),
                            "checked": radio.has_attr('checked')
                        })
                
                data["filters"]["quick_filter"]["radio_filters"]["status"] = {
                    "label": "Status",
                    "type": "radio",
                    "multiple": False,
                    "items": items
                }
        
        results = soup.find('div', class_='listupd')
        if results:
            articles = results.find_all('article', class_='bs')
            for article in articles:
                data["filters"]["lists"].append(self.parse_list_item(article))
        
        pagination = soup.find('div', class_='hpage')
        if pagination:
            prev_link = pagination.find('a', class_='l')
            next_link = pagination.find('a', class_='r')
            
            data["filters"]["pagination"] = {
                "prev": {
                    "url": urljoin(self.base_url, prev_link.get('href')) if prev_link else "",
                    "text": prev_link.get_text(strip=True) if prev_link else ""
                },
                "next": {
                    "url": urljoin(self.base_url, next_link.get('href')) if next_link else "",
                    "text": next_link.get_text(strip=True) if next_link else ""
                }
            }
        
        return self.build_response(True, data)

    async def _parse_advanced_search_text_mode(self, soup: BeautifulSoup, url: str) -> Dict:
        data = {
            "filters": {
                "mode": "text",
                "title": "",
                "quick_filter": {},
                "alphabet_nav": [],
                "text_mode": {}
            }
        }
        
        header = soup.find('div', class_='bixbox bixboxarc bbnofrm')
        if header:
            title_span = header.find('div', class_='releases').find('h1').find('span')
            if title_span:
                data["filters"]["title"] = title_span.get_text(strip=True)
        
        quick_filter = soup.find('div', class_='advancedsearch')
        if quick_filter:
            data["filters"]["quick_filter"] = {
                "checkbox_filters": {},
                "radio_filters": {}
            }
            
            genre_filter = quick_filter.find('div', class_='filter dropdown', string=lambda x: x and 'Genre' in str(x))
            if genre_filter:
                items = []
                genre_items = genre_filter.find('ul', class_='dropdown-menu c4 scrollz').find_all('li')
                for item in genre_items:
                    checkbox = item.find('input', type='checkbox', name='genre[]')
                    label = item.find('label')
                    
                    if checkbox and label:
                        items.append({
                            "value": checkbox.get('value', ''),
                            "label": label.get_text(strip=True),
                            "checked": checkbox.has_attr('checked')
                        })
                
                data["filters"]["quick_filter"]["checkbox_filters"]["genre"] = {
                    "label": genre_filter.find('button', class_='dropdown-toggle').get_text(strip=True),
                    "type": "checkbox",
                    "multiple": True,
                    "items": items
                }
        
        alphabet_nav = soup.find('div', id='tsnlistssc', class_='nav_apb')
        if alphabet_nav:
            links = alphabet_nav.find_all('a')
            for link in links:
                data["filters"]["alphabet_nav"].append({
                    "letter": link.get_text(strip=True),
                    "url": urljoin(self.base_url, link.get('href', '')),
                    "is_current": 'background' in link.get('style', '')
                })
        
        results = soup.find('div', class_='soralist')
        if results:
            groups = results.find_all('div', class_='blix')
            for group in groups:
                letter_span = group.find('span').find('a')
                letter = letter_span.get_text(strip=True) if letter_span else letter_span.get('name', '')
                
                if letter:
                    data["filters"]["text_mode"][letter] = []
                    
                    items = group.find('ul').find_all('li')
                    for item in items:
                        link = item.find('a', class_='series tip')
                        
                        if link:
                            data["filters"]["text_mode"][letter].append({
                                "title": link.get_text(strip=True),
                                "slug": self.extract_slug(link.get('href', '')),
                                "rel_id": link.get('rel', ''),
                                "url": urljoin(self.base_url, link.get('href', ''))
                            })
        
        return self.build_response(True, data)