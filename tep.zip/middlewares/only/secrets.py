#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import HTTPException, Request
from fastapi.security import HTTPBearer
from typing import Optional
import secrets
import hmac
import hashlib
import time

class SecretValidator:
    def __init__(self, app):
        self.secrets_cache = {}
    
    def validate_secret_header(self, app, request: Request, required_secret: str) -> bool:
        secret_header = request.headers.get("X-Secret-Token")
        
        if not secret_header:
            return False
        
        return hmac.compare_digest(secret_header, required_secret)
    
    def generate_secret_token(self, app, length: int = 32) -> str:
        return secrets.token_urlsafe(length)
    
    def create_hmac_signature(self, app, data: str, secret: str) -> str:
        return hmac.new(
            secret.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()
    
    def verify_hmac_signature(self, app, data: str, signature: str, secret: str) -> bool:
        expected_signature = self.create_hmac_signature(data, secret)
        return hmac.compare_digest(signature, expected_signature)
    
    def validate_timestamp(self, app, timestamp: str, max_age: int = 300) -> bool:
        try:
            request_time = int(timestamp)
            current_time = int(time.time())
            
            if current_time - request_time > max_age:
                return False
            
            return True
        except:
            return False


class SecretMiddleware:
    def __init__(self, app, secret_token: str):
        self.secret_token = secret_token
        self.validator = SecretValidator()
    
    async def __call__(self, app, request: Request, call_next):
        if request.method == "OPTIONS":
            return await call_next(request)
        
        if not self.validator.validate_secret_header(request, self.secret_token):
            raise HTTPException(
                status_code=403,
                detail="Invalid or missing secret token"
            )
        
        return await call_next(request)