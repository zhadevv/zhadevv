#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import HTTPException, Request
from lib.system.config import config
from lib.system.middleware import rate_limiter
from lib.system.validator import validator
import time

class AdminRateLimiter:
    def __init__(self, app):
        self.rpm = config.get_rate_limit("admin").rpm
        self.monthly_limit = config.get_rate_limit("admin").monthly_limit
    
    async def __call__(self, app, request: Request, call_next):
        auth_header = request.headers.get("authorization")
        
        if not auth_header or not auth_header.startswith("Bearer "):
            raise HTTPException(
                status_code=401,
                detail="Missing or invalid authorization header"
            )
        
        apikey = auth_header[7:]
        valid, role = validator.validate_apikey(apikey)
        
        if not valid or role != "admin":
            raise HTTPException(
                status_code=403,
                detail="Invalid API key for admin tier"
            )
        
        identifier = f"admin:{apikey}"
        allowed = await rate_limiter.acquire(identifier, self.rpm)
        
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded. Admin limit: {self.rpm} RPM"
            )
        
        response = await call_next(request)
        
        response.headers["X-Rate-Limit-Limit"] = str(self.rpm)
        response.headers["X-Rate-Limit-Remaining"] = str(
            self.rpm - len(rate_limiter.requests.get(identifier, []))
        )
        response.headers["X-Rate-Limit-Reset"] = str(int(time.time() + 60))
        
        return response