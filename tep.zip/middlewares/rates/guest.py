#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import HTTPException, Request
from lib.system.config import config
from lib.system.middleware import rate_limiter
import time

class GuestRateLimiter:
    def __init__(self, app):
        self.rpm = config.get_rate_limit("guest").rpm
    
    async def __call__(self, app, request: Request, call_next):
        client_ip = request.client.host
        identifier = f"guest:{client_ip}"
        
        allowed = await rate_limiter.acquire(identifier, self.rpm)
        
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded. Guest limit: {self.rpm} RPM"
            )
        
        response = await call_next(request)
        
        response.headers["X-Rate-Limit-Limit"] = str(self, app.rpm)
        response.headers["X-Rate-Limit-Remaining"] = str(
            self.rpm - len(rate_limiter.requests.get(identifier, []))
        )
        response.headers["X-Rate-Limit-Reset"] = str(int(time.time() + 60))
        
        return response