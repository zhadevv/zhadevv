# Anidong - Streaming Donghua Platform

Anidong adalah aplikasi web streaming Donghua (Anime China) yang dibangun menggunakan **Next.js**, **SQLite**, dan **NextAuth**. Aplikasi ini memiliki fitur lengkap mulai dari streaming, bookmark, riwayat tontonan, komentar, hingga panel admin untuk manajemen konten dan pengguna.

## Fitur Utama

### User
*   **Streaming**: Nonton Donghua dengan dukungan server multi-mirror.
*   **Discovery**: Pencarian, Jadwal Rilis, Daftar A-Z, Genre, dll.
*   **User Dashboard**: Riwayat tontonan, Bookmark/Favorit, Edit Profil.
*   **Interaksi**: Sistem Komentar, Lapor Video Rusak.
*   **PWA**: Installable web app (Progressive Web App).
*   **Responsive**: Tampilan optimal di Mobile dan Desktop (Light/Dark Mode).

### Admin
*   **Dashboard**: Statistik user, bookmark, dan history.
*   **User Management**: Lihat, edit, hapus, dan reset password user.
*   **Ad Management**: Kelola slot iklan (Header, Footer, Sidebar).
*   **Report System**: Lihat dan kelola laporan video rusak dari user.
*   **System Tools**: Clear Cache API, Broadcast Message, Site Settings.

## Persyaratan Sistem

*   Node.js (v18.x atau lebih baru)
*   NPM atau Yarn

## Cara Install & Setup

Ikuti langkah-langkah berikut untuk menjalankan aplikasi di komputer lokal atau server Anda.

1.  **Clone Repository**
    ```bash
    git clone https://github.com/yourusername/anidong.git
    cd anidong
    ```

2.  **Install Dependencies**
    ```bash
    npm install
    ```

3.  **Setup Environment Variables**
    Salin file `.env.example` menjadi `.env` dan sesuaikan isinya.

    ```bash
    cp .env.example .env
    ```

    Isi file `.env` sebagai berikut:
    ```env
    # Database Configuration
    DATABASE_URL=./data/anidong.db

    # Scraper Configuration
    SCRAPER_BASE_URL=https://anichin.cafe
    API_TIMEOUT=30000

    # NextAuth Configuration
    # Wajib diganti dengan random string yang aman!
    NEXTAUTH_SECRET=rahasia_dapur_bikin_sendiri_ya
    NEXTAUTH_URL=http://localhost:3000

    # Server Configuration
    PORT=3000
    NODE_ENV=development
    ```

4.  **Inisialisasi Database**
    Jalankan script untuk membuat file database SQLite dan tabel yang diperlukan secara otomatis.
    ```bash
    npm run db:init
    ```

5.  **Prefetch Data (Opsional tapi Disarankan)**
    Untuk mempercepat loading awal (Home, Schedule, Ongoing), jalankan script prefetch untuk mengisi cache lokal.
    ```bash
    npm run prefetch
    ```

6.  **Jalankan Aplikasi**

    *   **Mode Development** (untuk pengembangan):
        ```bash
        npm run dev
        ```
        Akses di `http://localhost:3000`

    *   **Mode Production** (untuk live):
        ```bash
        npm run build
        npm start
        ```

## Akun Admin

Saat Anda melakukan registrasi user pertama kali melalui halaman `/auth`, akun tersebut akan secara otomatis diberikan role **Admin**. User yang mendaftar setelahnya akan menjadi **User** biasa.

## Struktur Project

*   `src/pages`: Routing Next.js (File-based routing).
*   `src/models`: Konfigurasi Database (SQLite) dan Schema.
*   `src/services`: Logic scraper ke sumber pihak ketiga dan fallback API.
*   `src/components`: Komponen React (UI/UX).
*   `src/middlewares`: Global middleware untuk auth dan proteksi route.
*   `data/`: Lokasi penyimpanan file database (`anidong.db`) dan cache JSON.

## Disclaimer

Aplikasi ini menggunakan teknik scraping dari pihak ketiga untuk menampilkan konten. Aplikasi ini dibuat semata-mata untuk tujuan edukasi dan pembelajaran pengembangan web modern dengan Next.js. Pengembang tidak bertanggung jawab atas penyalahgunaan aplikasi ini.