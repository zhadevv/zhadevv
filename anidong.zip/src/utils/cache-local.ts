import fs from 'fs';
import path from 'path';

const CACHE_DIR = path.join((process as any).cwd(), 'src', 'data', 'api.loaded');

if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

export const LocalCache = {
  write: (filename: string, data: any) => {
    try {
      const filePath = path.join(CACHE_DIR, `${filename}.json`);
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
      console.log(`[Cache] Wrote to ${filename}.json`);
    } catch (error) {
      console.error(`[Cache] Error writing ${filename}:`, error);
    }
  },

  read: (filename: string) => {
    try {
      const filePath = path.join(CACHE_DIR, `${filename}.json`);
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        return JSON.parse(fileContent);
      }
    } catch (error) {
      console.error(`[Cache] Error reading ${filename}:`, error);
    }
    return null;
  }
};