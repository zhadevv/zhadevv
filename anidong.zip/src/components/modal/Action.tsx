import React from 'react';

export default function Action({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex gap-2 items-center justify-end mt-4">
      {children}
    </div>
  );
}