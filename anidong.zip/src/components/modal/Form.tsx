import React from 'react';

interface FormProps extends React.FormHTMLAttributes<HTMLFormElement> {
  title?: string;
  loading?: boolean;
}

export default function Form({ title, children, loading, className = '', ...props }: FormProps) {
  return (
    <div className={`bg-white p-6 rounded shadow-md ${className}`}>
      {title && <h2 className="text-xl font-bold mb-4">{title}</h2>}
      <form {...props}>
        {children}
        {loading && <div className="text-center text-sm text-gray-500 mt-2">Processing...</div>}
      </form>
    </div>
  );
}