import Link from 'next/link';

export default function SeriesGrid({ items }: { items: any[] }) {
  if (!items || items.length === 0) {
      return <div className="p-4 text-center">No series found.</div>;
  }

  return (
    <div className="listupd normal">
        <div className="excstf">
            {items.map((item: any, idx: number) => (
                <div className="bs" key={idx}>
                    <div className="bsx">
                        <Link href={item.url.replace('https://anichin.cafe', '')}>
                            <div className="limit">
                                <img src={item.thumbnail} alt={item.title} />
                                {item.badges && item.badges[0] && (
                                    <div className="bt"><span className="epx">{item.badges[0].text}</span></div>
                                )}
                                {item.episode && (
                                    <div className="bt"><span className="epx">{item.episode}</span></div>
                                )}
                                {item.type && (
                                    <div className="type z-10 absolute top-0 left-0 bg-blue-600 text-white text-xs px-1">{item.type}</div>
                                )}
                            </div>
                            <div className="tt">
                                <h2>{item.title}</h2>
                            </div>
                        </Link>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
}
