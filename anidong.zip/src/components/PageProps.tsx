export interface BasePageProps {
  session?: any;
}

export interface SeriesData {
  title: string;
  slug: string;
  thumbnail: string;
  url: string;
  episode?: string;
  type?: string;
}

export interface PaginationData {
  has_next: boolean;
  has_prev: boolean;
  current_page: number;
}