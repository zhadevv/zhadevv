import Link from 'next/link';

export default function Low() {
  return (
    <div className="bixbox">
      <div className="releases"><h3>Quick Links</h3></div>
      <div className="textwidget">
        <ul className="flex gap-4 p-4 text-sm">
            <li><Link href="/dmca">DMCA</Link></li>
            <li><Link href="/contact">Contact</Link></li>
            <li><Link href="/terms">Terms of Service</Link></li>
        </ul>
      </div>
    </div>
  );
}