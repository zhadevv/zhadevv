import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Footer() {
  const [footerAd, setFooterAd] = useState<string | null>(null);

  useEffect(() => {
    axios.get('/api/public/ads?position=footer').then(res => {
        if(res.data.success && res.data.data) {
            setFooterAd(res.data.data);
        }
    }).catch(() => {});
  }, []);

  return (
    <div id="footer">
      {footerAd && (
          <div className="wrapper" style={{marginBottom: '20px', textAlign: 'center'}}>
              <div dangerouslySetInnerHTML={{ __html: footerAd }} />
          </div>
      )}
      <div className="footercopyright">
        <div className="copyright marx">
            <div className="txt">
                <p>Copyright © {new Date().getFullYear()} Anidong. All Rights Reserved</p>
                <p>Disclaimer: This site does not store any files on its server. All contents are provided by non-affiliated third parties.</p>
            </div>
        </div>
      </div>
    </div>
  );
}