import Link from 'next/link';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Sidebar() {
  const [sidebarAd, setSidebarAd] = useState<string | null>(null);

  useEffect(() => {
    axios.get('/api/public/ads?position=sidebar').then(res => {
        if(res.data.success && res.data.data) {
            setSidebarAd(res.data.data);
        }
    }).catch(() => {});
  }, []);

  return (
    <div id="sidebar">
        {sidebarAd && (
            <div className="section" style={{textAlign: 'center', marginBottom: '15px'}}>
                <div dangerouslySetInnerHTML={{ __html: sidebarAd }} />
            </div>
        )}
        <div className="section">
            <div className="releases"><h3>Stay Updated</h3></div>
            <div className="textwidget">
                <p>Join our community for updates and discussions about Donghua.</p>
                <div className="socialts">
                    <a href="#" className="fb"><i className="fab fa-facebook-f"></i> Facebook</a>
                    <a href="#" className="twt"><i className="fab fa-twitter"></i> Twitter</a>
                    <a href="#" className="wa"><i className="fab fa-whatsapp"></i> Whatsapp</a>
                </div>
            </div>
        </div>
        <div className="section">
            <div className="releases"><h3>Genres</h3></div>
            <ul className="genre">
                <li><Link href="/genres/action">Action</Link></li>
                <li><Link href="/genres/adventure">Adventure</Link></li>
                <li><Link href="/genres/martial-arts">Martial Arts</Link></li>
                <li><Link href="/genres/fantasy">Fantasy</Link></li>
                <li><Link href="/genres/magic">Magic</Link></li>
                <li><Link href="/genres/demons">Demons</Link></li>
                <li><Link href="/genres/romance">Romance</Link></li>
                <li><Link href="/genres/school">School</Link></li>
            </ul>
        </div>
        <div className="section">
            <div className="releases"><h3>Partners</h3></div>
            <div className="textwidget">
                <Link href="https://anichin.cafe">Anichin</Link>
            </div>
        </div>
    </div>
  );
}