import Link from 'next/link';
import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';

export default function Header() {
  const router = useRouter();
  const [showMenu, setShowMenu] = useState(false);
  const [headerAd, setHeaderAd] = useState<string | null>(null);
  const [broadcast, setBroadcast] = useState<string | null>(null);
  const [siteName, setSiteName] = useState('ANIDONG');
  
  // Live Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Fetch Ads & Config
    axios.get('/api/public/ads?position=header').then(res => {
        if(res.data.success && res.data.data) setHeaderAd(res.data.data);
    }).catch(() => {});

    axios.get('/api/public/config').then(res => {
        if(res.data.success) {
            const data = res.data.data;
            if(data.broadcast) setBroadcast(data.broadcast);
            if(data.site_name) setSiteName(data.site_name.toUpperCase());
        }
    }).catch(() => {});

    // Theme Toggle
    const toggle = document.getElementById('thememode_toggle') as HTMLInputElement;
    if (toggle && localStorage.getItem('theme') === 'dark') {
        toggle.checked = true;
    }

    // Click outside to close search
    const handleClickOutside = (event: MouseEvent) => {
        if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
            setShowResults(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const query = e.target.value;
      setSearchQuery(query);
      
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);

      if (query.length < 3) {
          setSearchResults([]);
          setShowResults(false);
          return;
      }

      setIsSearching(true);
      searchTimeoutRef.current = setTimeout(async () => {
          try {
              const res = await axios.get(`/api/public/search?q=${query}`);
              if (res.data.success) {
                  setSearchResults(res.data.data);
                  setShowResults(true);
              }
          } catch (err) {
              console.error(err);
          } finally {
              setIsSearching(false);
          }
      }, 500); // Debounce 500ms
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if(searchQuery.trim()) {
          setShowResults(false);
          router.push(`/search?s=${searchQuery}`);
      }
  };

  return (
    <>
      <header className="mainheader">
        <div className="th">
          <div className="centernav">
            <div className="shme" onClick={() => setShowMenu(!showMenu)}>
              <i className="fas fa-bars"></i>
            </div>
            <div className="logos">
              <Link href="/">
                <span className="text-white font-bold text-2xl tracking-wide" style={{lineHeight: '60px'}}>{siteName}</span>
              </Link>
            </div>
            <div className="mobilelogo">
               <Link href="/">
                  <span className="text-white font-bold text-xl tracking-wide">{siteName}</span>
               </Link>
            </div>
            <div id="main-menu" className={showMenu ? 'show' : ''}>
               <ul className="menu">
                  <li><Link href="/">Home</Link></li>
                  <li><Link href="/ongoing">Ongoing</Link></li>
                  <li><Link href="/completed">Completed</Link></li>
                  <li><Link href="/schedule">Jadwal</Link></li>
                  <li><Link href="/az_lists">List Anime</Link></li>
                  <li>
                      <Link href="/api/public/random" className="random" title="Surprise Me!">
                          <i className="fas fa-random mr-2"></i> Random
                      </Link>
                  </li>
               </ul>
            </div>
            
            <div id="thememode">
                <label className="switch">
                    <input type="checkbox" id="thememode_toggle" />
                    <span className="slider round"></span>
                </label>
            </div>

            <div className="searchx" ref={searchContainerRef}>
              <form onSubmit={handleSearchSubmit} id="form">
                  <input 
                    type="text" 
                    id="s" 
                    name="s" 
                    placeholder="Search..." 
                    autoComplete="off"
                    value={searchQuery}
                    onChange={handleSearchChange}
                  />
                  <button type="submit" id="submitsearch">
                      {isSearching ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-search"></i>}
                  </button>
              </form>
              
              {showResults && searchResults.length > 0 && (
                  <div id="live-search_sb" style={{position: 'absolute', top: '40px', left: 0, width: '100%', zIndex: 999}}>
                      <div id="live-search_results" className="live-search_result_container">
                          <ul className="live-search_main">
                              {searchResults.map((item, idx) => (
                                  <li key={idx}>
                                      <Link href={item.url.replace('https://anichin.cafe', '')} onClick={() => setShowResults(false)}>
                                          <div className="post-thumbnail">
                                              <img src={item.thumbnail} alt={item.title} />
                                          </div>
                                          <div className="over">
                                              <span className="autotitle">{item.title}</span>
                                              <span>
                                                  {item.status && <i></i>} {item.status}
                                                  {item.type && <i></i>} {item.type}
                                              </span>
                                          </div>
                                      </Link>
                                  </li>
                              ))}
                              <li className="text-center font-bold">
                                  <Link href={`/search?s=${searchQuery}`} onClick={() => setShowResults(false)}>
                                      View all results
                                  </Link>
                              </li>
                          </ul>
                      </div>
                  </div>
              )}
            </div>
          </div>
        </div>
      </header>
      
      {broadcast && (
          <div className="wrapper">
              <div className="announ">
                  <div dangerouslySetInnerHTML={{ __html: broadcast }} />
              </div>
          </div>
      )}

      {headerAd && (
          <div className="wrapper" style={{marginBottom: '20px', textAlign: 'center'}}>
              <div dangerouslySetInnerHTML={{ __html: headerAd }} />
          </div>
      )}
    </>
  );
}