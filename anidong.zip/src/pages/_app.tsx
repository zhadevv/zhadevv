import '@/assets/css/main.css';
import '@/assets/css/light.css';
import '@/assets/css/dark.css';
import { SessionProvider, useSession } from 'next-auth/react';
import Head from 'next/head';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { initTheme } from '@/assets/js/main';
import axios from 'axios';
import { NotificationProvider } from '@/context/NotificationContext';

type AppProps = {
  Component: any;
  pageProps: any;
};

function MaintenanceChecker({ children }: { children: React.ReactNode }) {
    const { data: session, status } = useSession();
    const router = useRouter();
    const [checking, setChecking] = useState(true);

    useEffect(() => {
        // Skip check for login/admin pages or if already on maintenance
        if (router.pathname.startsWith('/auth') || router.pathname.startsWith('/dashboard/admin') || router.pathname === '/maintenance') {
            setChecking(false);
            return;
        }

        axios.get('/api/public/config').then(res => {
            if (res.data.success && res.data.data.maintenance_mode) {
                // If maintenance is ON and user is NOT admin
                if (status !== 'loading') {
                    if (!session || session.user.role !== 'admin') {
                        router.push('/maintenance');
                    }
                }
            }
        }).finally(() => setChecking(false));
    }, [router.pathname, session, status]);

    if (checking && router.pathname !== '/maintenance') return null; // Prevent flash of content

    return <>{children}</>;
}

export default function App({ Component, pageProps: { session, ...pageProps } }: AppProps) {
  useEffect(() => {
    initTheme();
    
    // Register Service Worker
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then(
          (registration) => {
            console.log('Service Worker registration successful with scope: ', registration.scope);
          },
          (err) => {
            console.log('Service Worker registration failed: ', err);
          }
        );
      });
    }
  }, []);

  return (
    <SessionProvider session={session}>
        <NotificationProvider>
            <Head>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="theme-color" content="#0c70de" />
                <title>Anidong - Streaming Donghua</title>
            </Head>
            <MaintenanceChecker>
                <Component {...pageProps} />
            </MaintenanceChecker>
        </NotificationProvider>
    </SessionProvider>
  );
}