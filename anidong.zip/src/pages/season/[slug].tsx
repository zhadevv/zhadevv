import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Sidebar from '@/components/partial/Sidebar';
import SeriesGrid from '@/components/modal/SeriesGrid';
import { ZhadevService } from '@/services/zhadev';

export default function SeasonPage({ data, slug }: { data: any, slug: string }) {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>Season: {slug}</h3></div>
                <SeriesGrid items={data?.lists || []} />
            </div>
        </div>
        <Sidebar />
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const slug = context.params?.slug as string;
  const page = parseInt(context.query.page as string || '1');
  const data = await ZhadevService.getSeason(slug, page);
  return { props: { data, slug } };
};
