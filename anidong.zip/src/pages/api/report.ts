import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { slug, episode, reason, description } = req.body;
    
    if (!slug || !reason) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    try {
        const stmt = db.prepare('INSERT INTO reports (slug, episode, reason, description) VALUES (?, ?, ?, ?)');
        stmt.run(slug, episode || 'unknown', reason, description || '');
        return res.status(200).json({ success: true, message: 'Report submitted' });
    } catch (e) {
        return res.status(500).json({ message: 'Database error' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}