import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const stmt = db.prepare('SELECT key, value FROM settings');
      const rows = stmt.all() as {key: string, value: string}[];
      const settings: Record<string, string> = {};
      rows.forEach(r => settings[r.key] = r.value);
      return res.status(200).json({ success: true, data: settings });
    } catch (e) {
      return res.status(500).json({ message: 'Error fetching settings' });
    }
  }

  if (req.method === 'POST') {
    const { settings } = req.body; // Expect object { key: value }
    try {
      const stmt = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
      const insert = db.transaction((data) => {
        for (const [key, value] of Object.entries(data)) {
          stmt.run(key, String(value));
        }
      });
      insert(settings);
      return res.status(200).json({ success: true });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ message: 'Error saving settings' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);