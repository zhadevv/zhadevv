import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;

  if (req.method === 'GET') {
      try {
          const historyStmt = db.prepare('SELECT slug, episode, watched_at as date, "history" as type FROM history WHERE user_id = ? ORDER BY watched_at DESC LIMIT 20');
          const bookmarkStmt = db.prepare('SELECT slug, title, created_at as date, "bookmark" as type FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC LIMIT 20');
          
          const history = historyStmt.all(id) as any[];
          const bookmarks = bookmarkStmt.all(id) as any[];
          
          // Merge and sort
          const activities = [...history, ...bookmarks].sort((a, b) => 
              new Date(b.date).getTime() - new Date(a.date).getTime()
          );

          return res.status(200).json({ success: true, data: activities });
      } catch(e) {
          return res.status(500).json({ message: 'Database error' });
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);