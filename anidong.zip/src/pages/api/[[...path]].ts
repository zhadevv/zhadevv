import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  res.status(404).json({
    status: 404,
    error: 'API Endpoint Not Found',
    path: req.query.path
  });
}