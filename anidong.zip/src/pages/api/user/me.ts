import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import db from '@/models/database';
import { withAuth } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const session = await getServerSession(req, res, authOptions);
  
  try {
    const userStmt = db.prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?');
    const user = userStmt.get(session?.user?.id);

    if (!user) {
        return res.status(404).json({ message: 'User data not found' });
    }

    const bookmarkStmt = db.prepare('SELECT COUNT(*) as count FROM bookmarks WHERE user_id = ?');
    const bookmarks = bookmarkStmt.get(session?.user?.id) as any;

    return res.status(200).json({
      success: true,
      profile: user,
      stats: {
          bookmarks: bookmarks.count
      }
    });
  } catch (error) {
    return res.status(500).json({ message: 'Database error' });
  }
}

export default withAuth(handler);