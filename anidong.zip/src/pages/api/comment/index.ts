import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import db from '@/models/database';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);

  if (req.method === 'GET') {
    const { slug } = req.query;
    if (!slug) return res.status(400).json({ message: 'Slug required' });

    try {
      const stmt = db.prepare(`
        SELECT c.id, c.content, c.created_at, u.name as user_name, u.role as user_role 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.slug = ? 
        ORDER BY c.created_at DESC
      `);
      const comments = stmt.all(slug);
      return res.status(200).json({ success: true, data: comments });
    } catch (e) {
      return res.status(500).json({ message: 'Database error' });
    }
  }

  if (req.method === 'POST') {
    if (!session) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const { slug, content } = req.body;
    if (!slug || !content) return res.status(400).json({ message: 'Data incomplete' });

    try {
      const stmt = db.prepare('INSERT INTO comments (user_id, slug, content) VALUES (?, ?, ?)');
      stmt.run(session.user.id, slug, content);
      return res.status(200).json({ success: true });
    } catch (e) {
      return res.status(500).json({ message: 'Database error' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}