import type { NextApiRequest, NextApiResponse } from 'next';
import { getAdSlot, getAllAds } from '@/middlewares/adslots.global';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const { position } = req.query;
    if (position) {
        const content = getAdSlot(position as string);
        return res.status(200).json({ success: true, data: content });
    }
    const all = getAllAds().filter((ad: any) => ad.is_active === 1);
    return res.status(200).json({ success: true, data: all });
  }
  return res.status(405).json({ message: 'Method not allowed' });
}