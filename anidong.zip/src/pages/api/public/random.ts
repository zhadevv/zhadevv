import type { NextApiRequest, NextApiResponse } from 'next';
import { ZhadevService } from '@/services/zhadev';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    try {
        // Fetch Home data to get a pool of popular/latest anime
        const data = await ZhadevService.getHome(1);
        let items: any[] = [];
        
        if (data) {
            if (data.popular_today) items = [...items, ...data.popular_today];
            if (data.latest_release) items = [...items, ...data.latest_release];
        }

        if (items.length > 0) {
            const randomItem = items[Math.floor(Math.random() * items.length)];
            const url = randomItem.url.replace('https://anichin.cafe', '');
            return res.redirect(url);
        }

        return res.redirect('/');
    } catch (e) {
        return res.redirect('/');
    }
}