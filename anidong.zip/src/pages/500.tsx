import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Link from 'next/link';

export default function Custom500() {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox text-center p-20">
                <div className="releases"><h1 className="text-red-600">500 - Internal Server Error</h1></div>
                <div className="text-6xl text-gray-300 my-6">
                    <i className="fas fa-server"></i>
                </div>
                <p className="mb-6 text-lg text-gray-600">Terjadi kesalahan pada server kami. Silahkan coba beberapa saat lagi.</p>
                <div className="flex justify-center gap-4">
                    <button onClick={() => window.location.reload()} className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition">
                        <i className="fas fa-sync-alt mr-2"></i> Refresh Halaman
                    </button>
                    <Link href="/" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                        Kembali ke Home
                    </Link>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}