import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Link from 'next/link';

export default function Custom404() {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox text-center p-20">
                <div className="releases"><h1>404 - Page Not Found</h1></div>
                <p className="mb-6">Halaman yang Anda cari tidak ditemukan atau telah dihapus.</p>
                <Link href="/" className="bg-blue-600 text-white px-4 py-2 rounded">
                    Kembali ke Home
                </Link>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}