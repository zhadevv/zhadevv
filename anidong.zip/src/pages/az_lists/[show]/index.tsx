import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';
import SeriesGrid from '@/components/modal/SeriesGrid';

export default function AzListDynamicPage({ data, currentLetter }: { data: any, currentLetter: string }) {
  const letters = ['All', '#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>List Anime - {currentLetter}</h3></div>
                <div className="soralist">
                    <div className="nav_apb">
                        {letters.map(l => (
                            <Link 
                                key={l} 
                                href={l === 'All' ? '/az_lists' : `/az_lists/${l}`}
                                className={currentLetter === l ? 'active' : ''}
                                style={{ fontWeight: currentLetter === l ? 'bold' : 'normal', background: currentLetter === l ? '#0c70de' : '#eee', color: currentLetter === l ? '#fff' : '#333' }}
                            >
                                {l}
                            </Link>
                        ))}
                    </div>
                    <SeriesGrid items={data?.lists || []} />
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const show = context.params?.show as string;
  const page = parseInt(context.query.page as string || '1');
  const data = await ZhadevService.getAzList(show, page);
  
  return { props: { data, currentLetter: show } };
};