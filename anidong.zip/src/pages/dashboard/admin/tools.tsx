import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import AdminNav from '@/components/partial/AdminNav';
import Button from '@/components/modal/Button';
import { useState } from 'react';
import axios from 'axios';

export default function ToolsPage() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const clearCache = async () => {
      setLoading(true);
      setMessage('');
      try {
          const res = await axios.post('/api/admin/cache');
          setMessage(res.data.message);
      } catch (e) {
          setMessage('Failed to clear cache.');
      } finally {
          setLoading(false);
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>System Tools</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="border p-6 rounded bg-gray-50">
                            <h4 className="font-bold text-lg mb-2 text-gray-800">Clear API Cache</h4>
                            <p className="text-sm text-gray-600 mb-4">
                                Remove all locally cached JSON files fetched from the scraper. 
                                Useful if data on the homepage or schedule is outdated or broken.
                            </p>
                            <Button onClick={clearCache} isLoading={loading} variant="secondary">
                                <i className="fas fa-trash-alt mr-2"></i> Clear Cache Now
                            </Button>
                            {message && <p className="mt-4 text-sm font-bold text-blue-600">{message}</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}