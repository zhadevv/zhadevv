import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Button from '@/components/modal/Button';
import Input from '@/components/modal/Input';
import AdminNav from '@/components/partial/AdminNav';
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function AdSlotsPage() {
  const [ads, setAds] = useState<any[]>([]);
  const [formData, setFormData] = useState({ position: '', content: '', is_active: true });

  useEffect(() => {
    fetchAds();
  }, []);

  const fetchAds = async () => {
    const res = await axios.get('/api/admin/ads');
    if (res.data.success) setAds(res.data.data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await axios.post('/api/admin/ads', formData);
    setFormData({ position: '', content: '', is_active: true });
    fetchAds();
  };

  const handleDelete = async (id: number) => {
      if(confirm('Are you sure?')) {
          await axios.delete('/api/admin/ads', { data: { id } });
          fetchAds();
      }
  }

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Manage Ad Slots</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-1">
                            <form onSubmit={handleSubmit} className="bg-gray-50 border p-6 rounded shadow-sm sticky top-4">
                                <h4 className="font-bold mb-4 text-gray-700 text-lg border-b pb-2">Add / Update Ad</h4>
                                <Input 
                                    label="Position Key" 
                                    value={formData.position} 
                                    onChange={(e) => setFormData({...formData, position: e.target.value})} 
                                    required
                                    placeholder="e.g. header, sidebar, footer"
                                />
                                <div className="mb-4">
                                    <label className="block text-gray-700 text-sm font-bold mb-2">HTML Content</label>
                                    <textarea 
                                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none h-40 font-mono text-xs"
                                        value={formData.content}
                                        onChange={(e) => setFormData({...formData, content: e.target.value})}
                                        required
                                        placeholder="<script>...</script> or <img src='...' />"
                                    ></textarea>
                                </div>
                                <div className="mb-6">
                                    <label className="flex items-center cursor-pointer select-none">
                                        <input 
                                            type="checkbox" 
                                            checked={formData.is_active} 
                                            onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                                            className="mr-2 h-5 w-5 text-blue-600"
                                        />
                                        <span className="text-gray-700 font-bold">Active</span>
                                    </label>
                                </div>
                                <Button type="submit" className="w-full">Save Ad Slot</Button>
                            </form>
                        </div>

                        <div className="lg:col-span-2">
                            <h4 className="font-bold mb-4 text-gray-700 text-lg">Existing Slots</h4>
                            <div className="overflow-x-auto rounded-lg border">
                                <table className="min-w-full bg-white">
                                    <thead className="bg-gray-100 border-b">
                                        <tr>
                                            <th className="py-3 px-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Position</th>
                                            <th className="py-3 px-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Content Preview</th>
                                            <th className="py-3 px-4 text-center text-xs font-bold text-gray-600 uppercase tracking-wider">Status</th>
                                            <th className="py-3 px-4 text-center text-xs font-bold text-gray-600 uppercase tracking-wider">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                        {ads.map((ad) => (
                                            <tr key={ad.id} className="hover:bg-gray-50 transition">
                                                <td className="py-3 px-4 font-bold text-blue-600">{ad.position}</td>
                                                <td className="py-3 px-4 text-xs font-mono text-gray-500 max-w-xs truncate">
                                                    {ad.content.substring(0, 50)}...
                                                </td>
                                                <td className="py-3 px-4 text-center">
                                                    <span className={`px-2 py-1 rounded-full text-xs font-bold text-white ${ad.is_active ? 'bg-green-500' : 'bg-gray-400'}`}>
                                                        {ad.is_active ? 'Active' : 'Inactive'}
                                                    </span>
                                                </td>
                                                <td className="py-3 px-4 text-center">
                                                    <div className="flex justify-center gap-2">
                                                        <button 
                                                            onClick={() => setFormData({ position: ad.position, content: ad.content, is_active: !!ad.is_active })}
                                                            className="text-blue-600 hover:text-blue-800"
                                                            title="Edit"
                                                        >
                                                            <i className="fas fa-edit"></i>
                                                        </button>
                                                        <button 
                                                            onClick={() => handleDelete(ad.id)}
                                                            className="text-red-600 hover:text-red-800"
                                                            title="Delete"
                                                        >
                                                            <i className="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                        {ads.length === 0 && (
                                            <tr><td colSpan={4} className="py-8 text-center text-gray-500">No ad slots found. Create one on the left.</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}