import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Sidebar from '@/components/partial/Sidebar';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Button from '@/components/modal/Button';

export default function UserDetailPage() {
  const router = useRouter();
  const { userId } = router.query;
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      axios.get(`/api/admin/user/${userId}`)
        .then(res => {
          if(res.data.success) {
              setUser(res.data.data);
          }
        })
        .catch(() => setUser(null))
        .finally(() => setLoading(false));
    }
  }, [userId]);

  if (loading) return <div id="content"><div className="wrapper p-10 text-center">Loading...</div></div>;
  if (!user) return <div id="content"><div className="wrapper p-10 text-center">User Not Found</div></div>;

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>User Detail: {user.name}</h3></div>
                <div className="p-8">
                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div>
                            <label className="block text-sm text-gray-500">User ID</label>
                            <p className="font-bold">{user.id}</p>
                        </div>
                        <div>
                            <label className="block text-sm text-gray-500">Email</label>
                            <p className="font-bold">{user.email}</p>
                        </div>
                        <div>
                            <label className="block text-sm text-gray-500">Role</label>
                            <p className="uppercase font-bold text-blue-600">{user.role}</p>
                        </div>
                        <div>
                            <label className="block text-sm text-gray-500">Joined Date</label>
                            <p className="font-bold">{new Date(user.created_at).toLocaleDateString()}</p>
                        </div>
                    </div>
                    
                    <div className="mt-6 flex gap-3 border-t pt-4">
                        <Button variant="secondary" onClick={() => router.push(`/dashboard/admin/user/${userId}/activity`)}>View Activity</Button>
                        <Button variant="danger" onClick={() => router.push(`/dashboard/admin/user/${userId}/moderate`)}>Moderate User</Button>
                    </div>
                </div>
            </div>
        </div>
        <Sidebar />
      </div>
      <Footer />
    </div>
  );
}