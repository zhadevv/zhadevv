import DashboardLayout from '@/components/layout/DashboardLayout';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState({ bookmarks: 0 });

  useEffect(() => {
    if(session) {
        axios.get('/api/user/me').then(res => {
            if(res.data.success) {
                setStats(res.data.stats);
            }
        }).catch(err => console.error(err));
    }
  }, [session]);

  return (
    <DashboardLayout>
        <h2 className="text-xl font-bold mb-6 text-gray-800 border-b pb-2">Overview</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-6 flex items-center">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                    <i className="fas fa-bookmark text-2xl"></i>
                </div>
                <div>
                    <p className="text-sm text-gray-500 font-medium">Saved Series</p>
                    <p className="text-2xl font-bold text-gray-800">{stats.bookmarks}</p>
                </div>
            </div>

            <div className="bg-purple-50 border border-purple-100 rounded-lg p-6 flex items-center">
                 <div className="p-3 rounded-full bg-purple-100 text-purple-600 mr-4">
                    <i className="fas fa-user-shield text-2xl"></i>
                </div>
                <div>
                    <p className="text-sm text-gray-500 font-medium">Account Status</p>
                    <p className="text-lg font-bold text-gray-800 capitalize">{session?.user?.role || 'User'}</p>
                </div>
            </div>
        </div>

        <div className="mt-8">
            <h3 className="font-bold text-lg mb-4 text-gray-700">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Link href="/dashboard/profile" className="block p-4 border rounded hover:shadow-md transition text-center hover:border-blue-500 group">
                    <i className="fas fa-list text-gray-400 group-hover:text-blue-500 text-3xl mb-2 block"></i>
                    <span className="font-medium text-gray-600 group-hover:text-blue-600">My List</span>
                </Link>
                <Link href="/" className="block p-4 border rounded hover:shadow-md transition text-center hover:border-blue-500 group">
                    <i className="fas fa-search text-gray-400 group-hover:text-blue-500 text-3xl mb-2 block"></i>
                    <span className="font-medium text-gray-600 group-hover:text-blue-600">Browse Anime</span>
                </Link>
                <Link href="/dashboard/settings" className="block p-4 border rounded hover:shadow-md transition text-center hover:border-blue-500 group">
                    <i className="fas fa-user-edit text-gray-400 group-hover:text-blue-500 text-3xl mb-2 block"></i>
                    <span className="font-medium text-gray-600 group-hover:text-blue-600">Edit Profile</span>
                </Link>
            </div>
        </div>
    </DashboardLayout>
  );
}