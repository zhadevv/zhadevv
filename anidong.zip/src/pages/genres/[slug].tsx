import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';

export default function GenrePage({ data, slug }: { data: any, slug: string }) {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>Genre: {data?.genre?.name || slug}</h3></div>
                <div className="listupd">
                    <div className="excstf">
                        {data?.lists?.map((item: any, idx: number) => (
                            <div className="bs" key={idx}>
                                <div className="bsx">
                                    <Link href={item.url.replace('https://anichin.cafe', '')}>
                                        <div className="limit">
                                            <img src={item.thumbnail} alt={item.title} />
                                            <div className="bt"><span className="epx">{item.badges?.[0]?.text || item.episode}</span></div>
                                        </div>
                                        <div className="tt"><h2>{item.title}</h2></div>
                                    </Link>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
        <div id="sidebar">
             <div className="section">
                <div className="releases"><h3>Popular Genres</h3></div>
                <ul className="genre">
                    <li><Link href="/genres/action">Action</Link></li>
                    <li><Link href="/genres/adventure">Adventure</Link></li>
                    <li><Link href="/genres/fantasy">Fantasy</Link></li>
                    <li><Link href="/genres/magic">Magic</Link></li>
                    <li><Link href="/genres/martial-arts">Martial Arts</Link></li>
                </ul>
             </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const slug = context.params?.slug as string;
  const page = parseInt(context.query.page as string || '1');
  const data = await ZhadevService.getGenre(slug, page);
  return { props: { data, slug } };
};