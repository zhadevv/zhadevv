import React, { ReactNode, useEffect, useState } from 'react';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Head from 'next/head';
import axios from 'axios';

interface LayoutProps {
  children: ReactNode;
  title?: string;
  description?: string;
  image?: string;
  type?: string;
}

export default function Layout({ 
    children, 
    title, 
    description, 
    image = "/images/noimg165px.png",
    type = "website"
}: LayoutProps) {
  
  const [siteConfig, setSiteConfig] = useState({
      site_name: 'Anidong',
      site_description: 'Streaming Donghua Subtitle Indonesia Terlengkap dan Terbaru secara Gratis.'
  });

  useEffect(() => {
      // Fetch dynamic config client side for meta defaults if not provided explicitly
      const cached = sessionStorage.getItem('site_config');
      if (cached) {
          setSiteConfig(JSON.parse(cached));
      } else {
          axios.get('/api/public/config').then(res => {
              if (res.data.success) {
                  const newConfig = {
                      site_name: res.data.data.site_name || 'Anidong',
                      site_description: res.data.data.site_description || 'Streaming Donghua Subtitle Indonesia'
                  };
                  setSiteConfig(newConfig);
                  sessionStorage.setItem('site_config', JSON.stringify(newConfig));
              }
          }).catch(() => {});
      }
  }, []);

  const fullTitle = title 
    ? (title.includes(siteConfig.site_name) ? title : `${title} - ${siteConfig.site_name}`)
    : `${siteConfig.site_name} - ${siteConfig.site_description}`;

  const finalDescription = description || siteConfig.site_description;

  return (
    <>
      <Head>
        <title>{fullTitle}</title>
        <meta name="description" content={finalDescription} />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content={type} />
        <meta property="og:title" content={fullTitle} />
        <meta property="og:description" content={finalDescription} />
        <meta property="og:image" content={image} />
        <meta property="og:site_name" content={siteConfig.site_name} />

        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:title" content={fullTitle} />
        <meta property="twitter:description" content={finalDescription} />
        <meta property="twitter:image" content={image} />
      </Head>
      <div id="content">
        <Header />
        <div className="wrapper">
            {children}
        </div>
        <Footer />
      </div>
    </>
  );
}