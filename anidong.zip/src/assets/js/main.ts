export const initTheme = () => {
  if (typeof window === 'undefined') return;

  const toggle = document.getElementById('thememode_toggle') as HTMLInputElement;
  const body = document.body;

  // Check Local Storage
  const currentTheme = localStorage.getItem('theme');
  if (currentTheme === 'dark') {
    body.classList.remove('lightmode');
    body.classList.add('darkmode');
    if (toggle) toggle.checked = true;
  }

  // Event Listener
  if (toggle) {
    toggle.addEventListener('change', () => {
      if (toggle.checked) {
        body.classList.remove('lightmode');
        body.classList.add('darkmode');
        localStorage.setItem('theme', 'dark');
      } else {
        body.classList.remove('darkmode');
        body.classList.add('lightmode');
        localStorage.setItem('theme', 'light');
      }
    });
  }
};