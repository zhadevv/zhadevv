import { authMiddleware } from '@/middlewares/auth.global';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  return authMiddleware(req);
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/api/admin/:path*',
    '/api/user/:path*'
  ],
};