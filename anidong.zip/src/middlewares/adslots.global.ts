import db from '@/models/database';

export const getAdSlot = (position: string) => {
  try {
    const stmt = db.prepare('SELECT content FROM ad_slots WHERE position = ? AND is_active = 1');
    const ad = stmt.get(position) as { content: string };
    return ad ? ad.content : null;
  } catch (error) {
    return null;
  }
};

export const getAllAds = () => {
    try {
        const stmt = db.prepare('SELECT * FROM ad_slots');
        return stmt.all();
    } catch (e) {
        return [];
    }
}