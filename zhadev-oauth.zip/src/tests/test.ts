import { OAuth2Factory, PKCE, Security, JWTValidator, RateLimiter, TokenManager, OAuth2Error, TokenError, ValidationError } from '../index';

describe('PKCE', () => {
  test('should generate S256 challenge', () => {
    const challenge = PKCE.generateChallenge();
    expect(challenge.codeVerifier).toBeDefined();
    expect(challenge.codeChallenge).toBeDefined();
    expect(challenge.method).toBe('S256');
    expect(challenge.createdAt).toBeInstanceOf(Date);
  });

  test('should validate S256 challenge', () => {
    const challenge = PKCE.generateChallenge();
    const isValid = PKCE.validateChallenge(challenge.codeVerifier, challenge.codeChallenge, challenge.method);
    expect(isValid).toBe(true);
  });

  test('should throw error for invalid length', () => {
    expect(() => PKCE.generateChallenge(20, 'S256')).toThrow(ValidationError);
  });
});

describe('Security', () => {
  const mockReq = { session: {} } as any;

  test('should generate and validate CSRF token', () => {
    const token = Security.generateCSRFToken(mockReq);
    expect(token).toBeDefined();
    
    const isValid = Security.validateCSRFToken(mockReq, token);
    expect(isValid).toBe(true);
  });

  test('should generate and validate secure state', () => {
    const context = { userId: '123' };
    const secureState = Security.generateSecureState(context);
    
    expect(secureState.state).toBeDefined();
    expect(secureState.encrypted).toBeDefined();
    expect(secureState.expiresAt).toBeInstanceOf(Date);
    
    const validated = Security.validateSecureState(secureState.encrypted);
    expect(validated.state).toBe(secureState.state);
    expect(validated.context.userId).toBe(context.userId);
  });
});

describe('RateLimiter', () => {
  test('should limit attempts', () => {
    const limiter = new RateLimiter(3, 1000);
    const key = 'test-key';
    
    expect(limiter.isRateLimited(key)).toBe(false);
    
    limiter.recordAttempt(key);
    limiter.recordAttempt(key);
    limiter.recordAttempt(key);
    
    expect(limiter.isRateLimited(key)).toBe(true);
    expect(limiter.getRemainingAttempts(key)).toBe(0);
  });
});

describe('TokenManager', () => {
  test('should manage tokens', () => {
    const manager = new TokenManager();
    const userId = 'user123';
    
    manager.setToken(userId, {
      accessToken: 'access-token',
      refreshToken: 'refresh-token',
      expiresIn: 3600,
      scope: 'read write',
      tokenType: 'Bearer'
    });
    
    const token = manager.getToken(userId);
    expect(token?.accessToken).toBe('access-token');
    expect(token?.refreshToken).toBe('refresh-token');
    expect(token?.scope).toBe('read write');
    expect(token?.tokenType).toBe('Bearer');
  });
});

describe('OAuth2Factory', () => {
  test('should create Google client', () => {
    const client = OAuth2Factory.createClient({
      provider: 'google',
      clientId: 'test-id',
      clientSecret: 'test-secret',
      redirectUri: 'http://localhost:3000/callback',
      usePKCE: true
    });
    
    expect(client).toBeDefined();
  });

  test('should throw for unknown provider', () => {
    expect(() => {
      OAuth2Factory.createClient({
        provider: 'unknown',
        clientId: 'test-id',
        clientSecret: 'test-secret',
        redirectUri: 'http://localhost:3000/callback'
      });
    }).toThrow(ValidationError);
  });
});

describe('Error Classes', () => {
  test('OAuth2Error should have correct properties', () => {
    const error = new OAuth2Error('Test error', 'test_code', 400, 'Test description');
    expect(error.message).toBe('Test error');
    expect(error.code).toBe('test_code');
    expect(error.statusCode).toBe(400);
    expect(error.description).toBe('Test description');
  });

  test('TokenError should have errorUri', () => {
    const error = new TokenError('Token error', 'token_error', 400, 'Invalid token', 'https://example.com/error');
    expect(error.errorUri).toBe('https://example.com/error');
  });
});