import { Request } from 'express';
import { Strategy as OAuth2Strategy, StrategyOptions as BaseStrategyOptions, StrategyOptionsWithRequest as BaseStrategyOptionsWithRequest, VerifyCallback, InternalOAuthError } from 'passport-oauth2';
import axios, { AxiosError, AxiosInstance } from 'axios';
import { createHash, randomBytes, createHmac, timingSafeEqual } from 'crypto';
import { JwtPayload, sign, verify, decode, SignOptions } from 'jsonwebtoken';
import { v4 as uuidv4, v5 as uuidv5 } from 'uuid';

export class OAuth2Error extends Error {
  constructor(
    message: string,
    public code: string = 'oauth_error',
    public statusCode: number = 500,
    public description?: string
  ) {
    super(message);
    this.name = 'OAuth2Error';
  }
}

export class ValidationError extends OAuth2Error {
  constructor(message: string, public field: string, public reason: string) {
    super(message, 'validation_error', 400);
    this.name = 'ValidationError';
  }
}

export class TokenError extends OAuth2Error {
  constructor(
    message: string,
    code: string = 'token_error',
    statusCode: number = 400,
    description?: string,
    public errorUri?: string
  ) {
    super(message, code, statusCode, description);
    this.name = 'TokenError';
  }
}

export class AuthorizationError extends OAuth2Error {
  constructor(
    message: string,
    code: string = 'authorization_error',
    statusCode: number = 401,
    description?: string
  ) {
    super(message, code, statusCode, description);
    this.name = 'AuthorizationError';
  }
}

export class SecurityError extends OAuth2Error {
  constructor(
    message: string,
    code: string = 'security_error',
    statusCode: number = 403,
    description?: string
  ) {
    super(message, code, statusCode, description);
    this.name = 'SecurityError';
  }
}

export interface PKCEChallenge {
  codeVerifier: string;
  codeChallenge: string;
  method: 'S256' | 'plain';
  createdAt: Date;
}

export interface JWKSKey {
  kty: string;
  use: string;
  kid: string;
  alg: string;
  n?: string;
  e?: string;
  crv?: string;
  x?: string;
  y?: string;
}

export interface JWKS {
  keys: JWKSKey[];
}

export interface JWTValidationOptions {
  audience?: string | string[];
  issuer?: string | string[];
  subject?: string;
  jwksUri?: string;
  algorithms?: string[];
  clockTolerance?: number;
  maxAge?: number;
  requireExp?: boolean;
  requireIat?: boolean;
  requireNbf?: boolean;
}

export interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in?: number;
  refresh_token?: string;
  scope?: string;
  id_token?: string;
}

export interface UserInfo {
  sub: string;
  name?: string;
  given_name?: string;
  family_name?: string;
  middle_name?: string;
  nickname?: string;
  preferred_username?: string;
  profile?: string;
  picture?: string;
  website?: string;
  email?: string;
  email_verified?: boolean;
  gender?: string;
  birthdate?: string;
  zoneinfo?: string;
  locale?: string;
  phone_number?: string;
  phone_number_verified?: boolean;
  address?: any;
  updated_at?: number;
  [key: string]: any;
}

export interface ClientConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  authorizationEndpoint: string;
  tokenEndpoint: string;
  userInfoEndpoint?: string;
  revocationEndpoint?: string;
  jwksUri?: string;
  issuer?: string;
  usePKCE?: boolean;
  scopes?: string[];
  customParams?: Record<string, string>;
}

export interface AuthOptions {
  scope?: string[];
  state?: string;
  nonce?: string;
  responseType?: string;
  prompt?: string;
  maxAge?: number;
  uiLocales?: string[];
  claims?: any;
  codeChallenge?: string;
  codeChallengeMethod?: 'S256' | 'plain';
}

export interface TokenOptions {
  codeVerifier?: string;
  redirectUri?: string;
  grantType?: string;
}

export interface SecureState {
  state: string;
  encrypted: string;
  expiresAt: Date;
}

export class PKCE {
  static generateChallenge(length: number = 64, method: 'S256' | 'plain' = 'S256'): PKCEChallenge {
    if (length < 43 || length > 128) {
      throw new ValidationError(
        'Invalid code verifier length',
        'code_verifier',
        'length must be between 43 and 128 characters'
      );
    }

    const codeVerifier = this.generateCodeVerifier(length);
    const codeChallenge = method === 'S256' 
      ? this.generateS256Challenge(codeVerifier)
      : codeVerifier;

    return {
      codeVerifier,
      codeChallenge,
      method,
      createdAt: new Date()
    };
  }

  static validateChallenge(codeVerifier: string, codeChallenge: string, method: 'S256' | 'plain'): boolean {
    if (method === 'S256') {
      const calculatedChallenge = this.generateS256Challenge(codeVerifier);
      return timingSafeEqual(
        Buffer.from(calculatedChallenge),
        Buffer.from(codeChallenge)
      );
    }
    return timingSafeEqual(
      Buffer.from(codeVerifier),
      Buffer.from(codeChallenge)
    );
  }

  private static generateCodeVerifier(length: number): string {
    const randomBytes = crypto.getRandomValues(new Uint8Array(length));
    return Buffer.from(randomBytes)
      .toString('base64url')
      .slice(0, length);
  }

  private static generateS256Challenge(codeVerifier: string): string {
    const hash = createHash('sha256');
    hash.update(codeVerifier);
    return hash.digest('base64url');
  }
}

export class JWTValidator {
  private jwksCache: Map<string, { key: JWKSKey; expiresAt: number }> = new Map();
  private jwksUri: string;
  private options: JWTValidationOptions;
  private cacheTTL: number = 3600000;

  constructor(options: JWTValidationOptions) {
    if (!options.jwksUri) {
      throw new ValidationError('JWKS URI is required', 'jwksUri', 'missing');
    }
    this.jwksUri = options.jwksUri;
    this.options = {
      algorithms: ['RS256'],
      clockTolerance: 30,
      requireExp: true,
      requireIat: true,
      ...options
    };
  }

  async validateToken(token: string): Promise<JwtPayload> {
    const header = this.decodeHeader(token);
    const key = await this.getSigningKey(header.kid);
    const publicKey = this.jwkToPEM(key);

    try {
      const payload = verify(token, publicKey, {
        algorithms: this.options.algorithms,
        audience: this.options.audience,
        issuer: this.options.issuer,
        subject: this.options.subject,
        clockTolerance: this.options.clockTolerance,
        maxAge: this.options.maxAge,
        ignoreExpiration: !this.options.requireExp,
        ignoreNotBefore: !this.options.requireNbf
      }) as JwtPayload;

      this.validateClaims(payload);
      return payload;
    } catch (error) {
      throw new TokenError(
        'JWT validation failed',
        'jwt_validation_error',
        401,
        error instanceof Error ? error.message : 'Unknown error'
      );
    }
  }

  async getPublicKey(kid: string): Promise<string> {
    const key = await this.getSigningKey(kid);
    return this.jwkToPEM(key);
  }

  private decodeHeader(token: string): any {
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new ValidationError('Invalid JWT format', 'token', 'malformed');
    }

    try {
      const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString());
      
      if (!header.kid) {
        throw new ValidationError('JWT missing key ID', 'header.kid', 'missing');
      }

      if (!header.alg) {
        throw new ValidationError('JWT missing algorithm', 'header.alg', 'missing');
      }

      return header;
    } catch (error) {
      throw new ValidationError('Invalid JWT header', 'header', 'malformed');
    }
  }

  private async getSigningKey(kid: string): Promise<JWKSKey> {
    const cached = this.jwksCache.get(kid);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.key;
    }

    const jwks = await this.fetchJWKS();
    const key = jwks.keys.find(k => k.kid === kid);

    if (!key) {
      throw new TokenError(
        'Signing key not found',
        'key_not_found',
        401,
        `Key with kid ${kid} not found in JWKS`
      );
    }

    this.jwksCache.set(kid, {
      key,
      expiresAt: Date.now() + this.cacheTTL
    });

    return key;
  }

  private async fetchJWKS(): Promise<JWKS> {
    try {
      const response = await axios.get<JWKS>(this.jwksUri, {
        timeout: 10000,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.data.keys || !Array.isArray(response.data.keys)) {
        throw new Error('Invalid JWKS response');
      }

      return response.data;
    } catch (error) {
      throw new TokenError(
        'Failed to fetch JWKS',
        'jwks_fetch_error',
        503,
        error instanceof Error ? error.message : 'Unknown error'
      );
    }
  }

  private jwkToPEM(jwk: JWKSKey): string {
    if (jwk.kty === 'RSA') {
      return this.rsaJwkToPem(jwk);
    } else if (jwk.kty === 'EC') {
      return this.ecJwkToPem(jwk);
    }

    throw new ValidationError(
      'Unsupported key type',
      'jwk.kty',
      `Unsupported: ${jwk.kty}`
    );
  }

  private rsaJwkToPem(jwk: JWKSKey): string {
    if (!jwk.n || !jwk.e) {
      throw new ValidationError('Invalid RSA JWK', 'jwk', 'missing n or e');
    }

    const n = Buffer.from(jwk.n, 'base64url');
    const e = Buffer.from(jwk.e, 'base64url');
    
    const der = Buffer.concat([
      Buffer.from([0x30, 0x82, 0x01, 0x22, 0x30, 0x0d]),
      Buffer.from([0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01]),
      Buffer.from([0x05, 0x00]),
      Buffer.from([0x03, 0x82, 0x01, 0x0f]),
      Buffer.from([0x00]),
      Buffer.from(n),
      Buffer.from(e)
    ]);

    return `-----BEGIN PUBLIC KEY-----\n${der.toString('base64')}\n-----END PUBLIC KEY-----`;
  }

  private ecJwkToPem(jwk: JWKSKey): string {
    if (!jwk.crv || !jwk.x || !jwk.y) {
      throw new ValidationError('Invalid EC JWK', 'jwk', 'missing crv, x, or y');
    }

    const x = Buffer.from(jwk.x, 'base64url');
    const y = Buffer.from(jwk.y, 'base64url');
    
    const der = Buffer.concat([
      Buffer.from([0x30, 0x59]),
      Buffer.from([0x30, 0x13]),
      Buffer.from([0x06, 0x07, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x02, 0x01]),
      Buffer.from([0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x03, 0x01, 0x07]),
      Buffer.from([0x03, 0x42]),
      Buffer.from([0x00]),
      Buffer.from([0x04]),
      x,
      y
    ]);

    return `-----BEGIN PUBLIC KEY-----\n${der.toString('base64')}\n-----END PUBLIC KEY-----`;
  }

  private validateClaims(payload: JwtPayload): void {
    if (this.options.requireExp && !payload.exp) {
      throw new ValidationError('JWT missing expiration', 'payload.exp', 'missing');
    }

    if (this.options.requireIat && !payload.iat) {
      throw new ValidationError('JWT missing issued at', 'payload.iat', 'missing');
    }

    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000) - (this.options.clockTolerance || 0)) {
      throw new TokenError('JWT expired', 'token_expired', 401);
    }

    if (payload.nbf && payload.nbf > Math.floor(Date.now() / 1000) + (this.options.clockTolerance || 0)) {
      throw new TokenError('JWT not yet valid', 'token_not_valid_yet', 401);
    }
  }
}

export class Security {
  private static readonly STATE_SECRET = 'oauth-state-secret';
  private static readonly CSRF_SECRET = 'oauth-csrf-secret';
  private static readonly STATE_TTL = 600000;

  static generateCSRFToken(req: Request): string {
    const sessionId = req.session?.id || uuidv4();
    const timestamp = Date.now();
    const hmac = createHmac('sha256', this.CSRF_SECRET);
    hmac.update(`${sessionId}:${timestamp}`);
    const token = hmac.digest('hex');
    
    if (req.session) {
      req.session.csrfToken = token;
      req.session.csrfTokenExpiry = timestamp + 3600000;
    }
    
    return token;
  }

  static validateCSRFToken(req: Request, token: string): boolean {
    if (!req.session?.csrfToken || !req.session?.csrfTokenExpiry) {
      return false;
    }

    if (Date.now() > req.session.csrfTokenExpiry) {
      delete req.session.csrfToken;
      delete req.session.csrfTokenExpiry;
      return false;
    }

    const isValid = timingSafeEqual(
      Buffer.from(req.session.csrfToken),
      Buffer.from(token)
    );

    if (isValid) {
      delete req.session.csrfToken;
      delete req.session.csrfTokenExpiry;
    }

    return isValid;
  }

  static generateSecureState(context?: any): SecureState {
    const state = uuidv4();
    const timestamp = Date.now();
    const expiresAt = new Date(timestamp + this.STATE_TTL);
    
    const stateData = {
      state,
      timestamp,
      context: context || {},
      nonce: uuidv4()
    };

    const hmac = createHmac('sha256', this.STATE_SECRET);
    hmac.update(JSON.stringify(stateData));
    const signature = hmac.digest('hex');

    const encrypted = Buffer.from(
      JSON.stringify({ ...stateData, signature })
    ).toString('base64url');

    return { state, encrypted, expiresAt };
  }

  static validateSecureState(encrypted: string, maxAge: number = this.STATE_TTL): any {
    try {
      const decoded = Buffer.from(encrypted, 'base64url').toString();
      const stateData = JSON.parse(decoded);

      const hmac = createHmac('sha256', this.STATE_SECRET);
      hmac.update(JSON.stringify({
        state: stateData.state,
        timestamp: stateData.timestamp,
        context: stateData.context,
        nonce: stateData.nonce
      }));
      
      const calculatedSignature = hmac.digest('hex');
      
      if (!timingSafeEqual(
        Buffer.from(calculatedSignature),
        Buffer.from(stateData.signature)
      )) {
        throw new SecurityError('Invalid state signature', 'invalid_signature');
      }

      if (Date.now() - stateData.timestamp > maxAge) {
        throw new SecurityError('State expired', 'state_expired');
      }

      return stateData;
    } catch (error) {
      if (error instanceof SecurityError) {
        throw error;
      }
      throw new SecurityError('Invalid state parameter', 'invalid_state');
    }
  }
}

export class RateLimiter {
  private attempts: Map<string, { count: number; firstAttempt: number; lastAttempt: number }> = new Map();
  private maxAttempts: number;
  private windowMs: number;
  private blockDuration: number;

  constructor(maxAttempts: number = 5, windowMs: number = 900000, blockDuration: number = 1800000) {
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
    this.blockDuration = blockDuration;

    setInterval(() => this.cleanup(), 60000);
  }

  isRateLimited(key: string): boolean {
    const attempt = this.attempts.get(key);
    if (!attempt) return false;

    if (Date.now() - attempt.firstAttempt > this.windowMs) {
      this.attempts.delete(key);
      return false;
    }

    if (attempt.count >= this.maxAttempts) {
      if (Date.now() - attempt.lastAttempt > this.blockDuration) {
        this.attempts.delete(key);
        return false;
      }
      return true;
    }

    return false;
  }

  recordAttempt(key: string): void {
    const now = Date.now();
    const attempt = this.attempts.get(key);

    if (!attempt) {
      this.attempts.set(key, {
        count: 1,
        firstAttempt: now,
        lastAttempt: now
      });
    } else {
      if (now - attempt.firstAttempt > this.windowMs) {
        attempt.count = 1;
        attempt.firstAttempt = now;
        attempt.lastAttempt = now;
      } else {
        attempt.count++;
        attempt.lastAttempt = now;
      }
    }
  }

  reset(key: string): void {
    this.attempts.delete(key);
  }

  getRemainingAttempts(key: string): number {
    const attempt = this.attempts.get(key);
    if (!attempt) return this.maxAttempts;

    if (Date.now() - attempt.firstAttempt > this.windowMs) {
      this.attempts.delete(key);
      return this.maxAttempts;
    }

    return Math.max(0, this.maxAttempts - attempt.count);
  }

  private cleanup(): void {
    const now = Date.now();
    for (const [key, attempt] of this.attempts.entries()) {
      if (now - attempt.lastAttempt > this.blockDuration * 2) {
        this.attempts.delete(key);
      }
    }
  }
}

export class TokenManager {
  private tokens: Map<string, {
    accessToken: string;
    refreshToken?: string;
    expiresAt: Date;
    scope?: string;
    tokenType: string;
  }> = new Map();

  private refreshLocks: Map<string, Promise<string>> = new Map();

  setToken(
    userId: string,
    tokenData: {
      accessToken: string;
      refreshToken?: string;
      expiresIn?: number;
      scope?: string;
      tokenType?: string;
    }
  ): void {
    const expiresAt = tokenData.expiresIn
      ? new Date(Date.now() + tokenData.expiresIn * 1000)
      : new Date(Date.now() + 3600 * 1000);

    this.tokens.set(userId, {
      accessToken: tokenData.accessToken,
      refreshToken: tokenData.refreshToken,
      expiresAt,
      scope: tokenData.scope,
      tokenType: tokenData.tokenType || 'Bearer'
    });
  }

  getToken(userId: string): {
    accessToken: string;
    refreshToken?: string;
    expiresAt: Date;
    scope?: string;
    tokenType: string;
  } | null {
    const tokenData = this.tokens.get(userId);
    
    if (!tokenData) return null;
    
    if (tokenData.expiresAt < new Date()) {
      this.tokens.delete(userId);
      return null;
    }
    
    return tokenData;
  }

  async refreshAccessToken(
    userId: string,
    refreshFn: (refreshToken: string) => Promise<TokenResponse>
  ): Promise<string> {
    if (this.refreshLocks.has(userId)) {
      return this.refreshLocks.get(userId)!;
    }

    const tokenData = this.tokens.get(userId);
    if (!tokenData) {
      throw new TokenError('No token found for user', 'token_not_found');
    }

    if (!tokenData.refreshToken) {
      throw new TokenError('No refresh token available', 'no_refresh_token');
    }

    const refreshPromise = (async () => {
      try {
        const newTokens = await refreshFn(tokenData.refreshToken);
        
        this.setToken(userId, {
          accessToken: newTokens.access_token,
          refreshToken: newTokens.refresh_token,
          expiresIn: newTokens.expires_in,
          scope: newTokens.scope,
          tokenType: newTokens.token_type
        });

        return newTokens.access_token;
      } catch (error) {
        this.tokens.delete(userId);
        throw error;
      } finally {
        this.refreshLocks.delete(userId);
      }
    })();

    this.refreshLocks.set(userId, refreshPromise);
    return refreshPromise;
  }

  revokeToken(userId: string): void {
    this.tokens.delete(userId);
    this.refreshLocks.delete(userId);
  }

  cleanupExpiredTokens(): void {
    const now = new Date();
    for (const [userId, tokenData] of this.tokens.entries()) {
      if (tokenData.expiresAt < now) {
        this.tokens.delete(userId);
      }
    }
  }
}

export class OAuth2Client {
  private config: ClientConfig;
  private httpClient: AxiosInstance;
  private stateStore: Map<string, {
    state: string;
    expiresAt: Date;
    codeVerifier?: string;
    nonce?: string;
  }> = new Map();
  private rateLimiter: RateLimiter;
  private tokenManager: TokenManager;
  private jwtValidator?: JWTValidator;

  constructor(config: ClientConfig) {
    this.validateConfig(config);
    this.config = config;

    if (config.jwksUri) {
      this.jwtValidator = new JWTValidator({
        jwksUri: config.jwksUri,
        issuer: config.issuer,
        audience: config.clientId
      });
    }

    this.httpClient = axios.create({
      timeout: 30000,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'User-Agent': '@zhadevv/passport-oauth2'
      }
    });

    this.rateLimiter = new RateLimiter();
    this.tokenManager = new TokenManager();

    setInterval(() => this.cleanupExpiredStates(), 60000);
    setInterval(() => this.tokenManager.cleanupExpiredTokens(), 300000);
  }

  private validateConfig(config: ClientConfig): void {
    const errors: string[] = [];

    if (!config.clientId || typeof config.clientId !== 'string') {
      errors.push('clientId must be a non-empty string');
    }

    if (!config.clientSecret || typeof config.clientSecret !== 'string') {
      errors.push('clientSecret must be a non-empty string');
    }

    if (!config.redirectUri || typeof config.redirectUri !== 'string') {
      errors.push('redirectUri must be a non-empty string');
    }

    if (!config.authorizationEndpoint || typeof config.authorizationEndpoint !== 'string') {
      errors.push('authorizationEndpoint must be a non-empty string');
    }

    if (!config.tokenEndpoint || typeof config.tokenEndpoint !== 'string') {
      errors.push('tokenEndpoint must be a non-empty string');
    }

    if (errors.length > 0) {
      throw new ValidationError(
        'Invalid configuration',
        'config',
        errors.join(', ')
      );
    }
  }

  getAuthorizationUrl(options: AuthOptions = {}): { url: string; state: string; codeVerifier?: string } {
    const params = new URLSearchParams({
      client_id: this.config.clientId,
      redirect_uri: this.config.redirectUri,
      response_type: options.responseType || 'code',
      ...this.config.customParams
    });

    const scopes = options.scope || this.config.scopes || ['openid', 'profile', 'email'];
    if (scopes.length > 0) {
      params.append('scope', scopes.join(' '));
    }

    let state = options.state || Security.generateSecureState().state;
    let codeVerifier: string | undefined;

    if (this.config.usePKCE) {
      const challenge = PKCE.generateChallenge();
      params.append('code_challenge', challenge.codeChallenge);
      params.append('code_challenge_method', challenge.method);
      codeVerifier = challenge.codeVerifier;
    }

    if (options.nonce) {
      params.append('nonce', options.nonce);
    }

    if (options.prompt) {
      params.append('prompt', options.prompt);
    }

    if (options.maxAge) {
      params.append('max_age', options.maxAge.toString());
    }

    if (options.uiLocales) {
      params.append('ui_locales', options.uiLocales.join(' '));
    }

    if (options.claims) {
      params.append('claims', JSON.stringify(options.claims));
    }

    this.stateStore.set(state, {
      state,
      expiresAt: new Date(Date.now() + 600000),
      codeVerifier,
      nonce: options.nonce
    });

    params.append('state', state);

    return {
      url: `${this.config.authorizationEndpoint}?${params.toString()}`,
      state,
      codeVerifier
    };
  }

  async getToken(code: string, options: TokenOptions = {}): Promise<TokenResponse> {
    this.rateLimiter.recordAttempt('token:' + this.config.clientId);

    if (this.rateLimiter.isRateLimited('token:' + this.config.clientId)) {
      throw new TokenError(
        'Rate limit exceeded',
        'rate_limit_exceeded',
        429,
        'Too many token requests'
      );
    }

    const data = new URLSearchParams({
      client_id: this.config.clientId,
      client_secret: this.config.clientSecret,
      redirect_uri: options.redirectUri || this.config.redirectUri,
      code,
      grant_type: options.grantType || 'authorization_code'
    });

    if (options.codeVerifier) {
      data.append('code_verifier', options.codeVerifier);
    }

    try {
      const response = await this.httpClient.post<TokenResponse>(
        this.config.tokenEndpoint,
        data.toString()
      );

      if (!response.data.access_token) {
        throw new TokenError(
          'No access token in response',
          'no_access_token',
          response.status
        );
      }

      if (response.data.id_token && this.jwtValidator) {
        try {
          await this.jwtValidator.validateToken(response.data.id_token);
        } catch (error) {
          throw new TokenError(
            'Invalid ID token',
            'invalid_id_token',
            400,
            error instanceof Error ? error.message : undefined
          );
        }
      }

      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new TokenError(
          'Token request failed',
          'token_request_failed',
          error.response?.status || 500,
          error.response?.data?.error_description || error.message,
          error.response?.data?.error_uri
        );
      }
      throw error;
    }
  }

  async refreshToken(refreshToken: string): Promise<TokenResponse> {
    const data = new URLSearchParams({
      client_id: this.config.clientId,
      client_secret: this.config.clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token'
    });

    try {
      const response = await this.httpClient.post<TokenResponse>(
        this.config.tokenEndpoint,
        data.toString()
      );

      if (!response.data.access_token) {
        throw new TokenError(
          'No access token in refresh response',
          'no_access_token',
          response.status
        );
      }

      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new TokenError(
          'Token refresh failed',
          'token_refresh_failed',
          error.response?.status || 500,
          error.response?.data?.error_description || error.message
        );
      }
      throw error;
    }
  }

  async revokeToken(token: string, tokenType: 'access_token' | 'refresh_token' = 'access_token'): Promise<void> {
    if (!this.config.revocationEndpoint) {
      throw new ValidationError(
        'Revocation endpoint not configured',
        'revocationEndpoint',
        'missing'
      );
    }

    const data = new URLSearchParams({
      token,
      token_type_hint: tokenType,
      client_id: this.config.clientId,
      client_secret: this.config.clientSecret
    });

    try {
      await this.httpClient.post(
        this.config.revocationEndpoint,
        data.toString()
      );
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new TokenError(
          'Token revocation failed',
          'token_revocation_failed',
          error.response?.status || 500,
          error.response?.data?.error_description || error.message
        );
      }
      throw error;
    }
  }

  async getUserInfo(accessToken: string): Promise<UserInfo> {
    if (!this.config.userInfoEndpoint) {
      throw new ValidationError(
        'User info endpoint not configured',
        'userInfoEndpoint',
        'missing'
      );
    }

    try {
      const response = await axios.get<UserInfo>(
        this.config.userInfoEndpoint,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json'
          },
          timeout: 10000
        }
      );

      if (!response.data.sub) {
        throw new TokenError(
          'Invalid user info response',
          'invalid_user_info',
          response.status
        );
      }

      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new TokenError(
          'User info request failed',
          'user_info_request_failed',
          error.response?.status || 500,
          error.response?.data?.error_description || error.message
        );
      }
      throw error;
    }
  }

  async validateIdToken(idToken: string): Promise<JwtPayload> {
    if (!this.jwtValidator) {
      throw new ValidationError(
        'JWT validator not configured',
        'jwksUri',
        'missing'
      );
    }

    return this.jwtValidator.validateToken(idToken);
  }

  validateState(state: string, encryptedState?: string): boolean {
    const stateData = this.stateStore.get(state);
    
    if (!stateData) {
      return false;
    }

    if (stateData.expiresAt < new Date()) {
      this.stateStore.delete(state);
      return false;
    }

    this.stateStore.delete(state);

    if (encryptedState) {
      try {
        Security.validateSecureState(encryptedState);
        return true;
      } catch {
        return false;
      }
    }

    return true;
  }

  private cleanupExpiredStates(): void {
    const now = new Date();
    for (const [state, data] of this.stateStore.entries()) {
      if (data.expiresAt < now) {
        this.stateStore.delete(state);
      }
    }
  }
}

export interface ProviderConfig {
  name: string;
  authorizationEndpoint: string;
  tokenEndpoint: string;
  userInfoEndpoint: string;
  jwksUri?: string;
  issuer?: string;
  scopes: string[];
  usePKCE: boolean;
}

export class OAuth2Factory {
  private static readonly providers: Map<string, ProviderConfig> = new Map([
    ['google', {
      name: 'google',
      authorizationEndpoint: 'https://accounts.google.com/o/oauth2/v2/auth',
      tokenEndpoint: 'https://oauth2.googleapis.com/token',
      userInfoEndpoint: 'https://openidconnect.googleapis.com/v1/userinfo',
      jwksUri: 'https://www.googleapis.com/oauth2/v3/certs',
      issuer: 'https://accounts.google.com',
      scopes: ['openid', 'profile', 'email'],
      usePKCE: true
    }],
    ['discord', {
      name: 'discord',
      authorizationEndpoint: 'https://discord.com/api/oauth2/authorize',
      tokenEndpoint: 'https://discord.com/api/oauth2/token',
      userInfoEndpoint: 'https://discord.com/api/users/@me',
      scopes: ['identify', 'email'],
      usePKCE: true
    }],
    ['github', {
      name: 'github',
      authorizationEndpoint: 'https://github.com/login/oauth/authorize',
      tokenEndpoint: 'https://github.com/login/oauth/access_token',
      userInfoEndpoint: 'https://api.github.com/user',
      scopes: ['read:user', 'user:email'],
      usePKCE: true
    }],
    ['microsoft', {
      name: 'microsoft',
      authorizationEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
      tokenEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
      userInfoEndpoint: 'https://graph.microsoft.com/v1.0/me',
      jwksUri: 'https://login.microsoftonline.com/common/discovery/v2.0/keys',
      issuer: 'https://login.microsoftonline.com/common/v2.0',
      scopes: ['openid', 'profile', 'User.Read'],
      usePKCE: true
    }]
  ]);

  static registerProvider(name: string, config: ProviderConfig): void {
    if (this.providers.has(name)) {
      throw new ValidationError(
        'Provider already registered',
        'provider',
        'duplicate'
      );
    }
    this.providers.set(name, config);
  }

  static getProvider(name: string): ProviderConfig {
    const provider = this.providers.get(name);
    if (!provider) {
      throw new ValidationError(
        'Provider not found',
        'provider',
        'not_found'
      );
    }
    return provider;
  }

  static createClient(config: {
    provider: string;
    clientId: string;
    clientSecret: string;
    redirectUri: string;
    usePKCE?: boolean;
    scopes?: string[];
    customParams?: Record<string, string>;
  }): OAuth2Client {
    const provider = this.getProvider(config.provider);
    
    return new OAuth2Client({
      clientId: config.clientId,
      clientSecret: config.clientSecret,
      redirectUri: config.redirectUri,
      authorizationEndpoint: provider.authorizationEndpoint,
      tokenEndpoint: provider.tokenEndpoint,
      userInfoEndpoint: provider.userInfoEndpoint,
      jwksUri: provider.jwksUri,
      issuer: provider.issuer,
      usePKCE: config.usePKCE ?? provider.usePKCE,
      scopes: config.scopes ?? provider.scopes,
      customParams: config.customParams
    });
  }
}

export {
  OAuth2Error,
  ValidationError,
  TokenError,
  AuthorizationError,
  SecurityError,
  PKCE,
  JWTValidator,
  Security,
  RateLimiter,
  TokenManager
};