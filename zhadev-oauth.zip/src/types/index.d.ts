declare module '@zhadevv/passport-oauth2' {
  import { Request } from 'express';
  import { Strategy as OAuth2Strategy, VerifyCallback } from 'passport-oauth2';
  import { JwtPayload } from 'jsonwebtoken';

  export class OAuth2Error extends Error {
    code: string;
    statusCode: number;
    description?: string;
    
    constructor(message: string, code?: string, statusCode?: number, description?: string);
  }

  export class ValidationError extends OAuth2Error {
    field: string;
    reason: string;
    
    constructor(message: string, field: string, reason: string);
  }

  export class TokenError extends OAuth2Error {
    errorUri?: string;
    
    constructor(message: string, code?: string, statusCode?: number, description?: string, errorUri?: string);
  }

  export class AuthorizationError extends OAuth2Error {
    constructor(message: string, code?: string, statusCode?: number, description?: string);
  }

  export class SecurityError extends OAuth2Error {
    constructor(message: string, code?: string, statusCode?: number, description?: string);
  }

  export interface PKCEChallenge {
    codeVerifier: string;
    codeChallenge: string;
    method: 'S256' | 'plain';
    createdAt: Date;
  }

  export interface JWKSKey {
    kty: string;
    use: string;
    kid: string;
    alg: string;
    n?: string;
    e?: string;
    crv?: string;
    x?: string;
    y?: string;
  }

  export interface JWKS {
    keys: JWKSKey[];
  }

  export interface JWTValidationOptions {
    audience?: string | string[];
    issuer?: string | string[];
    subject?: string;
    jwksUri?: string;
    algorithms?: string[];
    clockTolerance?: number;
    maxAge?: number;
    requireExp?: boolean;
    requireIat?: boolean;
    requireNbf?: boolean;
  }

  export interface TokenResponse {
    access_token: string;
    token_type: string;
    expires_in?: number;
    refresh_token?: string;
    scope?: string;
    id_token?: string;
  }

  export interface UserInfo {
    sub: string;
    name?: string;
    given_name?: string;
    family_name?: string;
    middle_name?: string;
    nickname?: string;
    preferred_username?: string;
    profile?: string;
    picture?: string;
    website?: string;
    email?: string;
    email_verified?: boolean;
    gender?: string;
    birthdate?: string;
    zoneinfo?: string;
    locale?: string;
    phone_number?: string;
    phone_number_verified?: boolean;
    address?: any;
    updated_at?: number;
    [key: string]: any;
  }

  export interface ClientConfig {
    clientId: string;
    clientSecret: string;
    redirectUri: string;
    authorizationEndpoint: string;
    tokenEndpoint: string;
    userInfoEndpoint?: string;
    revocationEndpoint?: string;
    jwksUri?: string;
    issuer?: string;
    usePKCE?: boolean;
    scopes?: string[];
    customParams?: Record<string, string>;
  }

  export interface AuthOptions {
    scope?: string[];
    state?: string;
    nonce?: string;
    responseType?: string;
    prompt?: string;
    maxAge?: number;
    uiLocales?: string[];
    claims?: any;
    codeChallenge?: string;
    codeChallengeMethod?: 'S256' | 'plain';
  }

  export interface TokenOptions {
    codeVerifier?: string;
    redirectUri?: string;
    grantType?: string;
  }

  export interface SecureState {
    state: string;
    encrypted: string;
    expiresAt: Date;
  }

  export class PKCE {
    static generateChallenge(length?: number, method?: 'S256' | 'plain'): PKCEChallenge;
    static validateChallenge(codeVerifier: string, codeChallenge: string, method: 'S256' | 'plain'): boolean;
  }

  export class JWTValidator {
    constructor(options: JWTValidationOptions);
    validateToken(token: string): Promise<JwtPayload>;
    getPublicKey(kid: string): Promise<string>;
  }

  export class Security {
    static generateCSRFToken(req: Request): string;
    static validateCSRFToken(req: Request, token: string): boolean;
    static generateSecureState(context?: any): SecureState;
    static validateSecureState(encrypted: string, maxAge?: number): any;
  }

  export class RateLimiter {
    constructor(maxAttempts?: number, windowMs?: number, blockDuration?: number);
    isRateLimited(key: string): boolean;
    recordAttempt(key: string): void;
    reset(key: string): void;
    getRemainingAttempts(key: string): number;
  }

  export class TokenManager {
    setToken(userId: string, tokenData: {
      accessToken: string;
      refreshToken?: string;
      expiresIn?: number;
      scope?: string;
      tokenType?: string;
    }): void;
    
    getToken(userId: string): {
      accessToken: string;
      refreshToken?: string;
      expiresAt: Date;
      scope?: string;
      tokenType: string;
    } | null;
    
    refreshAccessToken(userId: string, refreshFn: (refreshToken: string) => Promise<TokenResponse>): Promise<string>;
    
    revokeToken(userId: string): void;
    
    cleanupExpiredTokens(): void;
  }

  export class OAuth2Client {
    constructor(config: ClientConfig);
    
    getAuthorizationUrl(options?: AuthOptions): { url: string; state: string; codeVerifier?: string };
    
    getToken(code: string, options?: TokenOptions): Promise<TokenResponse>;
    
    refreshToken(refreshToken: string): Promise<TokenResponse>;
    
    revokeToken(token: string, tokenType?: 'access_token' | 'refresh_token'): Promise<void>;
    
    getUserInfo(accessToken: string): Promise<UserInfo>;
    
    validateIdToken(idToken: string): Promise<JwtPayload>;
    
    validateState(state: string, encryptedState?: string): boolean;
  }

  export interface ProviderConfig {
    name: string;
    authorizationEndpoint: string;
    tokenEndpoint: string;
    userInfoEndpoint: string;
    jwksUri?: string;
    issuer?: string;
    scopes: string[];
    usePKCE: boolean;
  }

  export class OAuth2Factory {
    static registerProvider(name: string, config: ProviderConfig): void;
    
    static getProvider(name: string): ProviderConfig;
    
    static createClient(config: {
      provider: string;
      clientId: string;
      clientSecret: string;
      redirectUri: string;
      usePKCE?: boolean;
      scopes?: string[];
      customParams?: Record<string, string>;
    }): OAuth2Client;
  }

  export {
    OAuth2Error,
    ValidationError,
    TokenError,
    AuthorizationError,
    SecurityError,
    PKCE,
    JWTValidator,
    Security,
    RateLimiter,
    TokenManager
  };
}