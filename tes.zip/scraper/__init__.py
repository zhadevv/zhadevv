from scraper.anime import OploverzParser
from scraper.donghua import DonghuaParser
from scraper.dracin import DramaboxParser

__all__ = [
    "OploverzParser",
    "DonghuaParser", 
    "DramaboxParser"
]