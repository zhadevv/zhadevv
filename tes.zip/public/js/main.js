class ApiClient {
  constructor(baseUrl = 'https://api.zhadev.my.id') {
    this.baseUrl = baseUrl;
    this.apiKey = localStorage.getItem('zhadev_api_key') || '';
    this.theme = localStorage.getItem('zhadev_theme') || 'light';
    this.applyTheme();
  }

  setApiKey(key) {
    this.apiKey = key;
    localStorage.setItem('zhadev_api_key', key);
  }

  clearApiKey() {
    this.apiKey = '';
    localStorage.removeItem('zhadev_api_key');
  }

  toggleTheme() {
    this.theme = this.theme === 'light' ? 'dark' : 'light';
    localStorage.setItem('zhadev_theme', this.theme);
    this.applyTheme();
  }

  applyTheme() {
    document.documentElement.setAttribute('data-theme', this.theme);
  }

  async request(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;
    
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.apiKey) {
      headers['X-API-Key'] = this.apiKey;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || `HTTP ${response.status}`);
      }

      return {
        success: true,
        data: data.data,
        message: data.message,
        meta: {
          status: response.status,
          author: data.author,
          timestamp: data.timestamp,
          headers: Object.fromEntries(response.headers.entries()),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        data: null,
      };
    }
  }

  async getStatus() {
    return await this.request('/api/status');
  }

  async getHealth() {
    return await this.request('/api/v1/health');
  }

  async getDocs() {
    return await this.request('/api/v1');
  }

  async testApiKey() {
    if (!this.apiKey) {
      return { success: false, error: 'No API key set' };
    }
    return await this.request('/api/v1/health');
  }

  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      this.showToast('Copied to clipboard', 'success');
      return true;
    } catch (error) {
      this.showToast('Failed to copy', 'error');
      return false;
    }
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
      color: white;
      border-radius: 8px;
      z-index: 1000;
      animation: slideIn 0.3s ease;
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'slideOut 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  formatTime(seconds) {
    if (seconds < 60) return `${seconds.toFixed(2)}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${Math.floor(seconds % 60)}s`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  }

  formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }
}

class ApiDocsRenderer {
  constructor(apiClient) {
    this.apiClient = apiClient;
    this.endpoints = [];
  }

  async loadDocs() {
    const result = await this.apiClient.getDocs();
    if (result.success) {
      this.endpoints = result.data.endpoints;
      this.render();
    }
  }

  render() {
    const container = document.getElementById('api-docs-container');
    if (!container) return;

    container.innerHTML = '';

    Object.entries(this.endpoints).forEach(([category, endpoints]) => {
      if (typeof endpoints === 'object') {
        this.renderCategory(container, category, endpoints);
      }
    });
  }

  renderCategory(container, category, endpoints) {
    const categoryEl = document.createElement('div');
    categoryEl.className = 'category';
    categoryEl.innerHTML = `
      <h2 class="category-title">${this.formatCategoryName(category)}</h2>
      <div class="category-endpoints"></div>
    `;

    const endpointsContainer = categoryEl.querySelector('.category-endpoints');

    Object.entries(endpoints).forEach(([name, endpoint]) => {
      if (typeof endpoint === 'string') {
        this.renderEndpoint(endpointsContainer, name, endpoint);
      } else if (typeof endpoint === 'object') {
        this.renderSubCategory(endpointsContainer, name, endpoint);
      }
    });

    container.appendChild(categoryEl);
  }

  renderSubCategory(container, name, endpoints) {
    const subCategoryEl = document.createElement('div');
    subCategoryEl.className = 'sub-category';
    subCategoryEl.innerHTML = `
      <h3 class="sub-category-title">${this.formatCategoryName(name)}</h3>
    `;

    Object.entries(endpoints).forEach(([endpointName, endpointPath]) => {
      this.renderEndpoint(subCategoryEl, endpointName, endpointPath);
    });

    container.appendChild(subCategoryEl);
  }

  renderEndpoint(container, name, path) {
    const method = this.getMethodFromPath(path);
    const endpointEl = document.createElement('div');
    endpointEl.className = 'endpoint-card';
    endpointEl.innerHTML = `
      <div class="endpoint-header">
        <div class="flex items-center gap-4">
          <span class="endpoint-method method-${method.toLowerCase()}">${method}</span>
          <code class="endpoint-path">${path}</code>
        </div>
        <button class="btn btn-secondary btn-sm test-endpoint" data-path="${path}" data-method="${method}">
          Test
        </button>
      </div>
      <div class="endpoint-body">
        <div class="endpoint-description">
          <p>${this.getEndpointDescription(name, method)}</p>
        </div>
        <div class="endpoint-test hidden">
          <div class="test-controls">
            <input type="text" class="input api-key-input" placeholder="API Key (optional)" value="${this.apiClient.apiKey}">
            <button class="btn btn-primary btn-sm send-request">Send Request</button>
          </div>
          <div class="test-result hidden"></div>
        </div>
      </div>
    `;

    container.appendChild(endpointEl);

    const testBtn = endpointEl.querySelector('.test-endpoint');
    testBtn.addEventListener('click', () => {
      const testSection = endpointEl.querySelector('.endpoint-test');
      testSection.classList.toggle('hidden');
    });

    const sendBtn = endpointEl.querySelector('.send-request');
    sendBtn.addEventListener('click', async () => {
      await this.testEndpoint(endpointEl, path, method);
    });
  }

  async testEndpoint(endpointEl, path, method) {
    const resultDiv = endpointEl.querySelector('.test-result');
    const apiKeyInput = endpointEl.querySelector('.api-key-input');
    
    resultDiv.innerHTML = '<div class="loading"></div>';
    resultDiv.classList.remove('hidden');

    const testApiKey = apiKeyInput.value.trim();
    const tempClient = new ApiClient(this.apiClient.baseUrl);
    if (testApiKey) {
      tempClient.setApiKey(testApiKey);
    }

    const result = await tempClient.request(path, { method: method.toUpperCase() });

    resultDiv.innerHTML = '';
    resultDiv.classList.remove('hidden');

    if (result.success) {
      const pre = document.createElement('pre');
      pre.textContent = JSON.stringify(result.data, null, 2);
      pre.className = 'response-example';
      resultDiv.appendChild(pre);

      const meta = document.createElement('div');
      meta.className = 'response-meta';
      meta.innerHTML = `
        <div class="text-sm text-gray-600">
          Status: ${result.meta.status} | 
          Time: ${result.meta.headers['x-process-time']} | 
          Author: ${result.meta.author}
        </div>
      `;
      resultDiv.appendChild(meta);
    } else {
      resultDiv.innerHTML = `
        <div class="alert alert-error">
          <strong>Error:</strong> ${result.error}
        </div>
      `;
    }
  }

  getMethodFromPath(path) {
    if (path.includes('/admin/') || path.includes('/auth/')) {
      if (path.includes('/generate_key') || path.includes('/suspended_key') || path.includes('/moderate')) {
        return 'POST';
      }
      if (path.includes('/unsuspense_keys')) {
        return 'PUT';
      }
      if (path.includes('/remove_key')) {
        return 'DELETE';
      }
      return 'GET';
    }
    return 'GET';
  }

  getEndpointDescription(name, method) {
    const descriptions = {
      'sidebar': 'Get sidebar content including filters and latest updates',
      'home': 'Get homepage content with pagination',
      'schedule': 'Get release schedule',
      'search': 'Search content with query parameter',
      'genres': 'Get content by genre',
      'a-z': 'Browse A-Z list',
      'detail': 'Get series detail information',
      'random': 'Get random series',
      'watch': 'Get episode watch information',
      'filters': 'Advanced search with filters',
      'list-mode': 'Get advanced search in list mode',
      'ongoing': 'Get ongoing series',
      'completed': 'Get completed series',
      'channel': 'Get channel content',
      'resources': 'Get resources (English only)',
      'series': 'Get series detail',
      'health': 'Health check endpoint',
    };
    return descriptions[name] || `${method} request to ${name} endpoint`;
  }

  formatCategoryName(name) {
    return name.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  }
}

class ApiKeyManager {
  constructor(apiClient) {
    this.apiClient = apiClient;
  }

  renderKeyForm() {
    return `
      <div class="card">
        <h3 class="card-title">API Key Tester</h3>
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium mb-1">Your API Key</label>
            <input type="text" id="apiKeyInput" class="input" 
                   placeholder="Enter your API key" 
                   value="${this.apiClient.apiKey}">
          </div>
          <div class="flex gap-2">
            <button id="testKeyBtn" class="btn btn-primary">Test Key</button>
            <button id="saveKeyBtn" class="btn btn-secondary">Save Key</button>
            <button id="clearKeyBtn" class="btn btn-danger">Clear Key</button>
          </div>
          <div id="keyTestResult" class="hidden"></div>
        </div>
      </div>
    `;
  }

  bindEvents() {
    document.getElementById('testKeyBtn')?.addEventListener('click', () => this.testKey());
    document.getElementById('saveKeyBtn')?.addEventListener('click', () => this.saveKey());
    document.getElementById('clearKeyBtn')?.addEventListener('click', () => this.clearKey());
  }

  async testKey() {
    const keyInput = document.getElementById('apiKeyInput');
    const resultDiv = document.getElementById('keyTestResult');
    
    if (!keyInput.value.trim()) {
      this.showResult(resultDiv, 'Please enter an API key', 'error');
      return;
    }

    this.showResult(resultDiv, '<div class="loading"></div> Testing...', 'info');

    const tempClient = new ApiClient(this.apiClient.baseUrl);
    tempClient.setApiKey(keyInput.value.trim());
    
    const result = await tempClient.testApiKey();

    if (result.success) {
      const data = result.data;
      this.showResult(resultDiv, `
        <div class="alert alert-success">
          <strong>✓ API Key Valid</strong><br>
          Status: ${data.api.status}<br>
          Uptime: ${tempClient.formatTime(data.api.uptime)}<br>
          Redis: ${data.redis.status}
        </div>
      `, 'success');
    } else {
      this.showResult(resultDiv, `
        <div class="alert alert-error">
          <strong>✗ API Key Invalid</strong><br>
          Error: ${result.error}
        </div>
      `, 'error');
    }
  }

  saveKey() {
    const keyInput = document.getElementById('apiKeyInput');
    this.apiClient.setApiKey(keyInput.value.trim());
    this.apiClient.showToast('API key saved', 'success');
  }

  clearKey() {
    this.apiClient.clearApiKey();
    document.getElementById('apiKeyInput').value = '';
    this.apiClient.showToast('API key cleared', 'info');
  }

  showResult(container, html, type) {
    container.innerHTML = html;
    container.className = type === 'error' ? 'alert alert-error' : 
                         type === 'success' ? 'alert alert-success' : 'alert alert-info';
    container.classList.remove('hidden');
  }
}

class MobileMenu {
  constructor() {
    this.menuOpen = false;
    this.init();
  }

  init() {
    const toggleBtn = document.querySelector('.navbar-toggle');
    const menu = document.querySelector('.navbar-menu');

    if (toggleBtn && menu) {
      toggleBtn.addEventListener('click', () => this.toggleMenu(menu));
      
      document.addEventListener('click', (event) => {
        if (!menu.contains(event.target) && !toggleBtn.contains(event.target)) {
          this.closeMenu(menu);
        }
      });
    }
  }

  toggleMenu(menu) {
    this.menuOpen = !this.menuOpen;
    menu.classList.toggle('hidden');
    menu.classList.toggle('mobile-menu-open');
    
    if (this.menuOpen) {
      menu.style.cssText = `
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        padding: 1rem;
        box-shadow: var(--shadow-lg);
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      `;
    } else {
      menu.style.cssText = '';
    }
  }

  closeMenu(menu) {
    this.menuOpen = false;
    menu.classList.add('hidden');
    menu.style.cssText = '';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const apiClient = new ApiClient();
  const docsRenderer = new ApiDocsRenderer(apiClient);
  const keyManager = new ApiKeyManager(apiClient);
  const mobileMenu = new MobileMenu();

  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }
    
    .mobile-menu-open {
      display: flex !important;
    }
    
    .category {
      margin-bottom: 2rem;
    }
    
    .category-title {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 1rem;
      color: var(--gray-900);
    }
    
    .sub-category {
      margin-bottom: 1.5rem;
    }
    
    .sub-category-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 1rem;
      color: var(--gray-800);
    }
    
    .endpoint-card {
      margin-bottom: 1rem;
    }
    
    .test-controls {
      display: flex;
      gap: 0.5rem;
      margin-top: 1rem;
    }
    
    .api-key-input {
      flex: 1;
    }
    
    .response-meta {
      margin-top: 0.5rem;
      padding: 0.5rem;
      background: var(--gray-50);
      border-radius: var(--border-radius);
      font-family: var(--font-mono);
      font-size: 0.75rem;
    }
  `;
  document.head.appendChild(style);

  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => apiClient.toggleTheme());
  }

  const copyButtons = document.querySelectorAll('.copy-btn');
  copyButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const text = btn.getAttribute('data-copy');
      apiClient.copyToClipboard(text);
    });
  });

  const apiKeySection = document.getElementById('apiKeySection');
  if (apiKeySection) {
    apiKeySection.innerHTML = keyManager.renderKeyForm();
    keyManager.bindEvents();
  }

  const docsSection = document.getElementById('apiDocsSection');
  if (docsSection) {
    docsRenderer.loadDocs();
  }

  window.apiClient = apiClient;
  console.log('zhadev API Client initialized');
});