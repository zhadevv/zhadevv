import httpx
import asyncio
import time
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from urllib.parse import urlparse

from lib.system.config import settings


class CloudflareManager:
    def __init__(self):
        self.api_token = settings.cloudflare.api_token
        self.zone_id = settings.cloudflare.zone_id
        self.enabled = settings.cloudflare.enabled and bool(self.api_token and self.zone_id)
        self.cache_purge_enabled = settings.cloudflare.cache_purge_enabled
        self.cache_purge_delay = settings.cloudflare.cache_purge_delay
        
        self.base_url = "https://api.cloudflare.com/client/v4"
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }
        self.timeout = 30
    
    async def purge_cache_by_urls(self, urls: List[str]) -> Dict[str, Any]:
        if not self.enabled or not self.cache_purge_enabled:
            return {"success": False, "message": "Cloudflare cache purge is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/zones/{self.zone_id}/purge_cache",
                    headers=self.headers,
                    json={"files": urls}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "errors": result.get("errors", []),
                        "messages": result.get("messages", []),
                        "purged_urls": urls
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def purge_cache_by_prefixes(self, prefixes: List[str]) -> Dict[str, Any]:
        if not self.enabled or not self.cache_purge_enabled:
            return {"success": False, "message": "Cloudflare cache purge is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/zones/{self.zone_id}/purge_cache",
                    headers=self.headers,
                    json={"prefixes": prefixes}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "errors": result.get("errors", []),
                        "messages": result.get("messages", []),
                        "purged_prefixes": prefixes
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def purge_entire_cache(self) -> Dict[str, Any]:
        if not self.enabled or not self.cache_purge_enabled:
            return {"success": False, "message": "Cloudflare cache purge is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/zones/{self.zone_id}/purge_cache",
                    headers=self.headers,
                    json={"purge_everything": True}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "errors": result.get("errors", []),
                        "messages": result.get("messages", [])
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_zone_analytics(self, timeframe: str = "last_7_days") -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/zones/{self.zone_id}/analytics/dashboard",
                    headers=self.headers,
                    params={"since": timeframe}
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": True,
                        "data": result.get("result", {})
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_firewall_rules(self) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/zones/{self.zone_id}/firewall/rules",
                    headers=self.headers
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": True,
                        "rules": result.get("result", [])
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def create_firewall_rule(
        self,
        expression: str,
        action: str,
        description: str = ""
    ) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                rule_data = {
                    "filter": {
                        "expression": expression,
                        "paused": False
                    },
                    "action": action,
                    "description": description
                }
                
                response = await client.post(
                    f"{self.base_url}/zones/{self.zone_id}/firewall/rules",
                    headers=self.headers,
                    json=rule_data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "rule": result.get("result", {})
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def block_ip(self, ip_address: str, description: str = "") -> Dict[str, Any]:
        expression = f"(ip.src eq {ip_address})"
        return await self.create_firewall_rule(
            expression=expression,
            action="block",
            description=description or f"Block IP: {ip_address}"
        )
    
    async def unblock_ip(self, ip_address: str) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                rules_response = await self.get_firewall_rules()
                if not rules_response.get("success"):
                    return rules_response
                
                rules = rules_response.get("rules", [])
                rule_id = None
                
                for rule in rules:
                    if (rule.get("filter", {}).get("expression", "") == f"(ip.src eq {ip_address})" and
                        rule.get("action") == "block"):
                        rule_id = rule.get("id")
                        break
                
                if not rule_id:
                    return {"success": False, "message": f"No firewall rule found for IP: {ip_address}"}
                
                response = await client.delete(
                    f"{self.base_url}/zones/{self.zone_id}/firewall/rules/{rule_id}",
                    headers=self.headers
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "message": f"IP {ip_address} unblocked"
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_dns_records(self) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/zones/{self.zone_id}/dns_records",
                    headers=self.headers
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": True,
                        "records": result.get("result", [])
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def create_dns_record(
        self,
        record_type: str,
        name: str,
        content: str,
        ttl: int = 1,
        proxied: bool = True
    ) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                record_data = {
                    "type": record_type,
                    "name": name,
                    "content": content,
                    "ttl": ttl,
                    "proxied": proxied
                }
                
                response = await client.post(
                    f"{self.base_url}/zones/{self.zone_id}/dns_records",
                    headers=self.headers,
                    json=record_data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return {
                        "success": result.get("success", False),
                        "record": result.get("result", {})
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def test_connection(self) -> Dict[str, Any]:
        if not self.enabled:
            return {"success": False, "message": "Cloudflare is disabled"}
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/zones/{self.zone_id}",
                    headers=self.headers
                )
                
                if response.status_code == 200:
                    result = response.json()
                    zone_info = result.get("result", {})
                    return {
                        "success": True,
                        "zone_name": zone_info.get("name"),
                        "status": zone_info.get("status"),
                        "plan": zone_info.get("plan", {}).get("name")
                    }
                else:
                    return {
                        "success": False,
                        "status_code": response.status_code,
                        "error": response.text
                    }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def generate_api_url(self, path: str) -> str:
        parsed_url = urlparse(path)
        
        if parsed_url.netloc:
            return path
        
        base_domain = f"api.zhadev.my.id"
        if not path.startswith('/'):
            path = '/' + path
        
        return f"https://{base_domain}{path}"
    
    async def schedule_cache_purge(
        self,
        urls: List[str],
        delay_seconds: Optional[int] = None
    ) -> Dict[str, Any]:
        if not self.enabled or not self.cache_purge_enabled:
            return {"success": False, "message": "Cloudflare cache purge is disabled"}
        
        delay = delay_seconds or self.cache_purge_delay
        
        async def delayed_purge():
            await asyncio.sleep(delay)
            return await self.purge_cache_by_urls(urls)
        
        task = asyncio.create_task(delayed_purge())
        
        return {
            "success": True,
            "message": f"Cache purge scheduled in {delay} seconds",
            "task_id": id(task),
            "urls": urls
        }