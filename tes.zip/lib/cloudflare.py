#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

import httpx
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import json
from lib.system.config import config

class CloudflareManager:
    def __init__(self):
        self.api_token = config.env.CF_API_TOKEN
        self.zone_id = config.env.CF_ZONE_ID
        self.base_url = "https://api.cloudflare.com/client/v4"
        self.client = None
        self.cache = {}
        self.cache_timeout = 300
    
    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "Content-Type": "application/json"
            }
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()
    
    def _get_cache_key(self, endpoint: str, params: Dict = None) -> str:
        key = endpoint
        if params:
            key += json.dumps(params, sort_keys=True)
        return key
    
    async def _cached_request(self, method: str, endpoint: str, 
                            params: Dict = None, data: Dict = None,
                            use_cache: bool = True) -> Dict:
        if not self.api_token or not self.zone_id:
            return {"success": False, "message": "Cloudflare not configured"}
        
        cache_key = self._get_cache_key(endpoint, params)
        current_time = datetime.utcnow().timestamp()
        
        if use_cache and cache_key in self.cache:
            cached_data, cached_time = self.cache[cache_key]
            if current_time - cached_time < self.cache_timeout:
                return cached_data
        
        try:
            url = f"{self.base_url}{endpoint}"
            
            if method == "GET":
                response = await self.client.get(url, params=params)
            elif method == "POST":
                response = await self.client.post(url, json=data)
            elif method == "PUT":
                response = await self.client.put(url, json=data)
            elif method == "DELETE":
                response = await self.client.delete(url, params=params)
            else:
                return {"success": False, "message": "Invalid method"}
            
            response.raise_for_status()
            result = response.json()
            
            if result.get("success"):
                self.cache[cache_key] = (result, current_time)
            
            return result
            
        except httpx.TimeoutException:
            return {"success": False, "message": "Cloudflare API timeout"}
        except httpx.HTTPStatusError as e:
            return {"success": False, "message": f"Cloudflare API error: {e.response.status_code}"}
        except Exception as e:
            return {"success": False, "message": f"Cloudflare error: {str(e)}"}
    
    async def get_analytics(self, time_range: str = "last_7_days") -> Dict:
        endpoint = f"/zones/{self.zone_id}/analytics/dashboard"
        params = {
            "since": "-7d" if time_range == "last_7_days" else "-30d",
            "until": "0s",
            "continuous": "true"
        }
        
        return await self._cached_request("GET", endpoint, params)
    
    async def get_dns_records(self, type: str = None, name: str = None) -> Dict:
        endpoint = f"/zones/{self.zone_id}/dns_records"
        params = {}
        
        if type:
            params["type"] = type
        if name:
            params["name"] = name
        
        return await self._cached_request("GET", endpoint, params)
    
    async def create_dns_record(self, record_type: str, name: str, 
                              content: str, ttl: int = 1,
                              proxied: bool = True) -> Dict:
        endpoint = f"/zones/{self.zone_id}/dns_records"
        data = {
            "type": record_type,
            "name": name,
            "content": content,
            "ttl": ttl,
            "proxied": proxied
        }
        
        return await self._cached_request("POST", endpoint, data=data)
    
    async def update_dns_record(self, record_id: str, record_type: str, 
                              name: str, content: str, ttl: int = 1,
                              proxied: bool = True) -> Dict:
        endpoint = f"/zones/{self.zone_id}/dns_records/{record_id}"
        data = {
            "type": record_type,
            "name": name,
            "content": content,
            "ttl": ttl,
            "proxied": proxied
        }
        
        return await self._cached_request("PUT", endpoint, data=data)
    
    async def delete_dns_record(self, record_id: str) -> Dict:
        endpoint = f"/zones/{self.zone_id}/dns_records/{record_id}"
        return await self._cached_request("DELETE", endpoint)
    
    async def purge_cache(self, files: List[str] = None, 
                         tags: List[str] = None, hosts: List[str] = None) -> Dict:
        endpoint = f"/zones/{self.zone_id}/purge_cache"
        data = {}
        
        if files:
            data["files"] = files
        if tags:
            data["tags"] = tags
        if hosts:
            data["hosts"] = hosts
        
        if not data:
            data["purge_everything"] = True
        
        result = await self._cached_request("POST", endpoint, data=data)
        
        if result.get("success"):
            self.cache.clear()
        
        return result
    
    async def get_firewall_rules(self) -> Dict:
        endpoint = f"/zones/{self.zone_id}/firewall/rules"
        return await self._cached_request("GET", endpoint)
    
    async def create_firewall_rule(self, expression: str, action: str,
                                 description: str = None) -> Dict:
        endpoint = f"/zones/{self.zone_id}/firewall/rules"
        data = {
            "filter": {
                "expression": expression,
                "paused": False
            },
            "action": action,
            "description": description or f"Rule created at {datetime.utcnow().isoformat()}"
        }
        
        return await self._cached_request("POST", endpoint, data=data)
    
    async def block_ip(self, ip: str, description: str = None) -> Dict:
        expression = f"(ip.src eq {ip})"
        return await self.create_firewall_rule(
            expression, "block",
            description or f"Block IP: {ip}"
        )
    
    async def unblock_ip(self, rule_id: str) -> Dict:
        endpoint = f"/zones/{self.zone_id}/firewall/rules/{rule_id}"
        return await self._cached_request("DELETE", endpoint)
    
    async def get_security_events(self, time_range: str = "last_24_hours") -> Dict:
        endpoint = f"/zones/{self.zone_id}/security/events"
        
        since_map = {
            "last_24_hours": "-24h",
            "last_7_days": "-7d",
            "last_30_days": "-30d"
        }
        
        params = {
            "since": since_map.get(time_range, "-24h"),
            "limit": 100
        }
        
        return await self._cached_request("GET", endpoint, params)
    
    async def get_zone_settings(self) -> Dict:
        endpoint = f"/zones/{self.zone_id}/settings"
        return await self._cached_request("GET", endpoint)
    
    async def update_zone_setting(self, setting_name: str, value: Any) -> Dict:
        endpoint = f"/zones/{self.zone_id}/settings/{setting_name}"
        data = {"value": value}
        return await self._cached_request("PATCH", endpoint, data=data)
    
    async def enable_under_attack_mode(self, enable: bool = True) -> Dict:
        return await self.update_zone_setting(
            "security_level",
            "under_attack" if enable else "medium"
        )
    
    async def get_ssl_settings(self) -> Dict:
        endpoint = f"/zones/{self.zone_id}/ssl"
        return await self._cached_request("GET", endpoint)
    
    async def force_ssl(self, enable: bool = True) -> Dict:
        return await self.update_zone_setting(
            "ssl",
            "full" if enable else "off"
        )
    
    async def get_rate_limit_rules(self) -> Dict:
        endpoint = f"/zones/{self.zone_id}/rate_limit_rules"
        return await self._cached_request("GET", endpoint)
    
    async def clear_cache_by_url(self, url: str) -> Dict:
        return await self.purge_cache(files=[url])
    
    async def get_zone_details(self) -> Dict:
        endpoint = f"/zones/{self.zone_id}"
        return await self._cached_request("GET", endpoint)
    
    async def test_connection(self) -> bool:
        try:
            result = await self.get_zone_details()
            return result.get("success", False)
        except:
            return False
    
    def clear_internal_cache(self):
        self.cache.clear()


cloudflare = CloudflareManager()