import re
import ipaddress
from typing import Optional, Tuple, Dict, Any
from datetime import datetime, timedelta
from fastapi import HTTPException, Header, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
import hashlib
import hmac

class AuthValidator(HTTPBearer):
    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)
    
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        credentials = await super().__call__(request)
        
        if not credentials:
            return None
        
        if credentials.scheme.lower() != "bearer":
            raise HTTPException(
                status_code=403,
                detail="Invalid authentication scheme"
            )
        
        return credentials


class RequestValidator:
    @staticmethod
    def validate_apikey(apikey: str) -> Tuple[bool, str]:
        from lib.system.config import config
        
        if not apikey or len(apikey) < 16:
            return False, "Invalid API key format"
        
        if apikey == config.env.OWNER_APIKEY:
            return True, "owner"
        
        if apikey == config.env.DEV_APIKEY:
            return True, "developer"
        
        if apikey == config.env.ADMIN_APIKEY:
            return True, "admin"
        
        from lib.database import DatabaseManager
        db = DatabaseManager()
        
        apikey_data = db.get_apikey(apikey)
        
        if not apikey_data:
            return False, "Invalid API key"
        
        if apikey_data.get("suspended", False):
            return False, "API key suspended"
        
        if apikey_data.get("expires_at"):
            expires_at = datetime.fromisoformat(apikey_data["expires_at"])
            if datetime.utcnow() > expires_at:
                return False, "API key expired"
        
        return True, apikey_data.get("role", "guest")
    
    @staticmethod
    def validate_ip(ip: str) -> bool:
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_role(role: str) -> bool:
        valid_roles = [
            "guest", "free", "starter", "medium", 
            "highest", "enterprise", "admin", 
            "developer", "owner"
        ]
        return role in valid_roles
    
    @staticmethod
    def validate_slug(slug: str) -> bool:
        if not slug or len(slug) > 100:
            return False
        
        pattern = r'^[a-z0-9]+(?:-[a-z0-9]+)*$'
        return bool(re.match(pattern, slug))
    
    @staticmethod
    def validate_query(query: str) -> bool:
        if not query or len(query) > 200:
            return False
        
        query = query.strip()
        return len(query) >= 1
    
    @staticmethod
    def validate_page(page: int) -> bool:
        return page >= 1 and page <= 1000
    
    @staticmethod
    def validate_episode(episode: int) -> bool:
        return episode >= 1 and episode <= 10000
    
    @staticmethod
    def validate_region(region: str) -> bool:
        valid_regions = [
            "id", "en", "zh", "zhHans", "ko", 
            "ja", "tl", "th", "ar", "pt", "fr", "es"
        ]
        return region in valid_regions
    
    @staticmethod
    def validate_jwt(token: str) -> Tuple[bool, Optional[Dict]]:
        from lib.system.config import config
        
        try:
            payload = jwt.decode(
                token, 
                config.env.JWT_SECRET, 
                algorithms=["HS256"]
            )
            return True, payload
        except JWTError:
            return False, None
    
    @staticmethod
    def validate_custom_key(custom_key: str) -> bool:
        if not custom_key or len(custom_key) < 8:
            return False
        
        pattern = r'^[a-zA-Z0-9_-]+$'
        return bool(re.match(pattern, custom_key))
    
    @staticmethod
    def validate_username(username: str) -> bool:
        if not username or len(username) > 50:
            return False
        
        pattern = r'^[a-zA-Z0-9_-]+$'
        return bool(re.match(pattern, username))
    
    @staticmethod
    def generate_request_signature(
        method: str, 
        path: str, 
        timestamp: str,
        secret: str
    ) -> str:
        message = f"{method}:{path}:{timestamp}"
        signature = hmac.new(
            secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature


class ResponseValidator:
    @staticmethod
    def validate_response_structure(response: Dict) -> bool:
        required_keys = ["status", "success", "author", "data"]
        
        for key in required_keys:
            if key not in response:
                return False
        
        if response["author"] != "zhadevv":
            return False
        
        if not isinstance(response["status"], int):
            return False
        
        if not isinstance(response["success"], bool):
            return False
        
        if response["success"] and response["data"] is None:
            return False
        
        if not response["success"] and "message" not in response:
            return False
        
        return True
    
    @staticmethod
    def create_response(
        success: bool, 
        data: Any = None, 
        message: str = None,
        status_code: int = 200
    ) -> Dict:
        response = {
            "status": status_code,
            "success": success,
            "author": "zhadevv",
            "data": data if success else None,
            "message": message if not success else None
        }
        
        if not success and not message:
            response["message"] = "An error occurred"
        
        return response


validator = RequestValidator()
response_validator = ResponseValidator()
auth_validator = AuthValidator()