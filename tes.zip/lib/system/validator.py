import re
import string
import secrets
import hashlib
import hmac
import bcrypt
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from jose import jwt, JWTError
from pydantic import BaseModel, ValidationError

from lib.system.config import settings


class ApiKeyInfo(BaseModel):
    key: str
    username: str
    role: str
    rpm_limit: int
    monthly_limit: int
    active: bool
    suspended: bool = False
    created_at: datetime
    expires_at: Optional[datetime] = None
    used_count: int = 0
    last_used: Optional[datetime] = None
    allowed_versions: List[str] = ["v1"]
    custom_key: bool = False


class Validator:
    ROLE_RPM_MAP = {
        "guest": settings.rate_limit.guest_rpm,
        "free": settings.rate_limit.free_rpm,
        "starter": settings.rate_limit.starter_rpm,
        "medium": settings.rate_limit.medium_rpm,
        "highest": settings.rate_limit.highest_rpm,
        "enterprise": settings.rate_limit.enterprise_rpm,
        "admin": settings.rate_limit.admin_rpm,
        "developer": settings.rate_limit.developer_rpm,
        "owner": settings.rate_limit.owner_rpm
    }
    
    ROLE_MONTHLY_MAP = {
        "guest": settings.rate_limit.guest_monthly,
        "free": settings.rate_limit.free_monthly,
        "starter": settings.rate_limit.starter_monthly,
        "medium": settings.rate_limit.medium_monthly,
        "highest": settings.rate_limit.highest_monthly,
        "enterprise": settings.rate_limit.enterprise_monthly,
        "admin": settings.rate_limit.admin_monthly,
        "developer": settings.rate_limit.developer_monthly,
        "owner": settings.rate_limit.owner_monthly
    }
    
    @staticmethod
    def validate_api_key_format(api_key: str) -> bool:
        if not api_key or not isinstance(api_key, str):
            return False
        
        api_key = api_key.strip()
        
        if api_key == settings.security.dev_apikey:
            return True
        
        if api_key == settings.security.owner_apikey:
            return True
        
        if api_key == settings.security.admin_apikey:
            return True
        
        patterns = [
            r'^SK_zhadev-freekeys_[A-Za-z0-9]{16}$',
            r'^SK_zhadev_[A-Za-z0-9]{32}$',
            r'^SK_zhadev-admin_[A-Za-z0-9]{32}$',
            r'^SK_zhadev-dev_[A-Za-z0-9]{32}$',
            r'^SK_zhadev-owner_[A-Za-z0-9]{32}$',
        ]
        
        for pattern in patterns:
            if re.match(pattern, api_key):
                return True
        
        return False
    
    @staticmethod
    def generate_api_key(role: str, custom_key: Optional[str] = None) -> str:
        if custom_key:
            if Validator.validate_api_key_format(custom_key):
                return custom_key
            else:
                raise ValueError("Custom key format is invalid")
        
        if role == "free":
            prefix = "SK_zhadev-freekeys_"
            length = 16
        elif role in ["starter", "medium", "highest", "enterprise"]:
            prefix = "SK_zhadev_"
            length = 32
        elif role == "admin":
            prefix = "SK_zhadev-admin_"
            length = 32
        elif role == "developer":
            prefix = "SK_zhadev-dev_"
            length = 32
        elif role == "owner":
            prefix = "SK_zhadev-owner_"
            length = 32
        else:
            raise ValueError(f"Invalid role: {role}")
        
        chars = string.ascii_uppercase + string.ascii_lowercase + string.digits
        random_part = ''.join(secrets.choice(chars) for _ in range(length))
        
        return f"{prefix}{random_part}"
    
    @staticmethod
    def generate_username(prefix: str = "zhadev") -> str:
        random_part = secrets.randbelow(1000000)
        return f"{prefix}_{random_part:06d}"
    
    @staticmethod
    def validate_role(role: str) -> bool:
        valid_roles = ["free", "starter", "medium", "highest", "enterprise", "admin", "developer", "owner"]
        return role.lower() in valid_roles
    
    @staticmethod
    def validate_rpm_limit(rpm: int, role: str) -> bool:
        max_rpm = Validator.ROLE_RPM_MAP.get(role, 25)
        return 1 <= rpm <= max_rpm
    
    @staticmethod
    def validate_monthly_limit(limit: int, role: str) -> bool:
        max_monthly = Validator.ROLE_MONTHLY_MAP.get(role, 1000)
        return 100 <= limit <= max_monthly
    
    @staticmethod
    def hash_password(password: str) -> str:
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, hashed_password: str) -> bool:
        return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
    
    @staticmethod
    def create_jwt_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        to_encode = data.copy()
        
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(days=settings.jwt.access_token_expire_days)
        
        to_encode.update({"exp": expire})
        
        encoded_jwt = jwt.encode(
            to_encode, 
            settings.jwt.secret, 
            algorithm=settings.jwt.algorithm
        )
        return encoded_jwt
    
    @staticmethod
    def verify_jwt_token(token: str) -> Optional[Dict[str, Any]]:
        try:
            payload = jwt.decode(
                token,
                settings.jwt.secret,
                algorithms=[settings.jwt.algorithm]
            )
            return payload
        except JWTError:
            return None
    
    @staticmethod
    def validate_ip_address(ip: str) -> bool:
        ipv4_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        ipv6_pattern = r'^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$'
        
        if re.match(ipv4_pattern, ip) or re.match(ipv6_pattern, ip):
            return True
        return False
    
    @staticmethod
    def validate_slug(slug: str) -> bool:
        slug_pattern = r'^[a-z0-9]+(?:-[a-z0-9]+)*$'
        return bool(re.match(slug_pattern, slug))
    
    @staticmethod
    def validate_email(email: str) -> bool:
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(email_pattern, email))
    
    @staticmethod
    def sanitize_input(input_string: str, max_length: int = 255) -> str:
        if not input_string:
            return ""
        
        sanitized = input_string.strip()
        sanitized = re.sub(r'[<>"\']', '', sanitized)
        sanitized = sanitized[:max_length]
        
        return sanitized
    
    @staticmethod
    def validate_query_params(params: Dict[str, Any], allowed_params: List[str]) -> Dict[str, Any]:
        validated_params = {}
        
        for key, value in params.items():
            if key in allowed_params:
                sanitized_key = Validator.sanitize_input(key)
                if isinstance(value, str):
                    sanitized_value = Validator.sanitize_input(value)
                elif isinstance(value, list):
                    sanitized_value = [Validator.sanitize_input(str(v)) for v in value]
                else:
                    sanitized_value = value
                
                validated_params[sanitized_key] = sanitized_value
        
        return validated_params
    
    @staticmethod
    def calculate_rate_limit_headers(
        remaining: int,
        limit: int,
        reset_time: int
    ) -> Dict[str, str]:
        return {
            "X-RateLimit-Limit": str(limit),
            "X-RateLimit-Remaining": str(remaining),
            "X-RateLimit-Reset": str(reset_time)
        }
    
    @staticmethod
    def extract_api_key_from_header(authorization: Optional[str]) -> Optional[str]:
        if not authorization:
            return None
        
        if authorization.startswith("Bearer "):
            return authorization[7:].strip()
        
        return None
    
    @staticmethod
    def get_role_from_api_key(api_key: str) -> str:
        if api_key == settings.security.owner_apikey:
            return "owner"
        elif api_key == settings.security.dev_apikey:
            return "developer"
        elif api_key == settings.security.admin_apikey:
            return "admin"
        elif api_key.startswith("SK_zhadev-freekeys_"):
            return "free"
        elif api_key.startswith("SK_zhadev-admin_"):
            return "admin"
        elif api_key.startswith("SK_zhadev-dev_"):
            return "developer"
        elif api_key.startswith("SK_zhadev-owner_"):
            return "owner"
        elif api_key.startswith("SK_zhadev_"):
            key_parts = api_key.split('_')
            if len(key_parts) >= 3:
                role_part = key_parts[2].lower() if len(key_parts) > 2 else ""
                if role_part in ["starter", "medium", "highest", "enterprise"]:
                    return role_part
            
            return "starter"
        
        return "guest"
    
    @staticmethod
    def create_hmac_signature(data: str, secret: str) -> str:
        return hmac.new(
            secret.encode('utf-8'),
            data.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    @staticmethod
    def verify_hmac_signature(data: str, signature: str, secret: str) -> bool:
        expected_signature = Validator.create_hmac_signature(data, secret)
        return hmac.compare_digest(expected_signature, signature)