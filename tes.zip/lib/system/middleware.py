from typing import Dict, List, Any, Optional, Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import time
import json
import hashlib


class MiddlewareConfig:
    ENABLE_CORS = True
    ENABLE_TRUSTED_HOST = True
    ENABLE_RATE_LIMIT = True
    ENABLE_REQUEST_ID = True
    ENABLE_SECURITY_HEADERS = True
    ENABLE_GZIP = True
    ENABLE_LOGGING = True
    
    TRUSTED_HOSTS = ["*"]
    CORS_ORIGINS = ["*"]
    CORS_METHODS = ["*"]
    CORS_HEADERS = ["*"]
    
    SECURITY_HEADERS = {
        "X-Frame-Options": "DENY",
        "X-Content-Type-Options": "nosniff",
        "X-XSS-Protection": "1; mode=block",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "Content-Security-Policy": "default-src 'self'",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
    }
    
    GZIP_MIN_SIZE = 500
    REQUEST_TIMEOUT = 30
    MAX_REQUEST_SIZE = 100 * 1024 * 1024  # 100MB
    
    LOG_FORMAT = 'time:%(asctime)s | level:%(levelname)s | ip:%(client_ip)s | method:%(method)s | path:%(path)s | status:%(status_code)s | duration:%(duration).2fms'
    LOG_LEVEL = "INFO"


class RequestIDMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = self.generate_request_id(request)
        request.state.request_id = request_id
        
        response = await call_next(request)
        
        response.headers["X-Request-ID"] = request_id
        return response
    
    def generate_request_id(self, request: Request) -> str:
        timestamp = int(time.time() * 1000)
        client_ip = request.client.host if request.client else "0.0.0.0"
        user_agent = request.headers.get("user-agent", "")
        
        hash_input = f"{timestamp}{client_ip}{user_agent}"
        hash_value = hashlib.md5(hash_input.encode()).hexdigest()[:16]
        
        return f"req_{timestamp}_{hash_value}"


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        for header, value in MiddlewareConfig.SECURITY_HEADERS.items():
            if header not in response.headers:
                response.headers[header] = value
        
        response.headers["Server"] = "zhadev"
        
        if "X-Content-Type-Options" not in response.headers:
            response.headers["X-Content-Type-Options"] = "nosniff"
        
        if "X-Frame-Options" not in response.headers:
            response.headers["X-Frame-Options"] = "DENY"
        
        return response


class ProcessTimeMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        response = await call_next(request)
        
        process_time = (time.time() - start_time) * 1000
        response.headers["X-Process-Time"] = f"{process_time:.2f}ms"
        
        return response


class RequestValidationMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if request.method in ["POST", "PUT", "PATCH"]:
            content_length = request.headers.get("content-length")
            if content_length:
                try:
                    size = int(content_length)
                    if size > MiddlewareConfig.MAX_REQUEST_SIZE:
                        return Response(
                            content=json.dumps({
                                "status": 413,
                                "success": False,
                                "author": "zhadevv",
                                "data": None,
                                "message": "Request entity too large"
                            }),
                            status_code=413,
                            media_type="application/json"
                        )
                except ValueError:
                    pass
        
        request.state.validated = True
        return await call_next(request)


class CacheControlMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        path = request.url.path
        
        if "/api/" in path:
            cache_control = "no-cache, no-store, must-revalidate"
            
            if "/api/v1/" in path and request.method == "GET":
                if "/watch/" in path or "/detail/" in path:
                    cache_control = "public, max-age=3600, stale-while-revalidate=600"
                elif "/search" in path or "/filters" in path:
                    cache_control = "public, max-age=300, stale-while-revalidate=300"
                else:
                    cache_control = "public, max-age=60, stale-while-revalidate=30"
        
        else:
            cache_control = "public, max-age=3600"
        
        response.headers["Cache-Control"] = cache_control
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        
        return response


class ResponseFormatMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            response = await call_next(request)
            
            if response.status_code >= 400:
                content_type = response.headers.get("content-type", "")
                
                if "application/json" not in content_type:
                    try:
                        body = await response.body()
                        error_message = body.decode() if body else "Unknown error"
                        
                        formatted_response = {
                            "status": response.status_code,
                            "success": False,
                            "author": "zhadevv",
                            "data": None,
                            "message": error_message[:500]
                        }
                        
                        return Response(
                            content=json.dumps(formatted_response),
                            status_code=response.status_code,
                            media_type="application/json",
                            headers=dict(response.headers)
                        )
                    except:
                        pass
            
            return response
        except Exception as e:
            error_response = {
                "status": 500,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": f"Internal server error: {str(e)[:200]}"
            }
            
            return Response(
                content=json.dumps(error_response),
                status_code=500,
                media_type="application/json"
            )


class IPValidationMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        client_ip = request.client.host if request.client else "0.0.0.0"
        
        request.state.client_ip = client_ip
        request.state.forwarded_for = request.headers.get("x-forwarded-for", "")
        request.state.real_ip = request.headers.get("x-real-ip", client_ip)
        
        if not self.is_valid_ip(client_ip):
            error_response = {
                "status": 400,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": "Invalid client IP address"
            }
            
            return Response(
                content=json.dumps(error_response),
                status_code=400,
                media_type="application/json"
            )
        
        return await call_next(request)
    
    def is_valid_ip(self, ip: str) -> bool:
        import re
        
        ipv4_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        ipv6_pattern = r'^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$'
        
        return bool(re.match(ipv4_pattern, ip) or re.match(ipv6_pattern, ip))