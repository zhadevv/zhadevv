import os
import yaml
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import timedelta
from pathlib import Path


class DatabaseConfig(BaseModel):
    driver: str = "sqlite"
    database: str = "data/zhadev.db"
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30
    pool_recycle: int = 3600
    echo: bool = False


class JWTConfig(BaseModel):
    secret: str = "YourJWT"
    algorithm: str = "HS256"
    access_token_expire_days: int = 3
    refresh_token_expire_days: int = 30


class RateLimitConfig(BaseModel):
    default_rpm: int = 25
    guest_rpm: int = 25
    guest_monthly: int = 1000
    free_rpm: int = 50
    free_monthly: int = 5000
    starter_rpm: int = 100
    starter_monthly: int = 10000
    medium_rpm: int = 150
    medium_monthly: int = 50000
    highest_rpm: int = 200
    highest_monthly: int = 100000
    enterprise_rpm: int = 500
    enterprise_monthly: int = 1000000
    admin_rpm: int = 1000
    admin_monthly: int = 5000000
    developer_rpm: int = 5000
    developer_monthly: int = 10000000
    owner_rpm: int = 10000
    owner_monthly: int = 100000000


class SecurityConfig(BaseModel):
    admin_apikey: str = ""
    dev_apikey: str = "YOUR_16_CHAR"
    owner_apikey: str = "YOUR_32_CHAR"
    allowed_hosts: list = ["*"]
    cors_origins: list = ["*"]
    secure_cookies: bool = True
    hsts_enabled: bool = True
    hsts_max_age: int = 31536000
    rate_limit_enabled: bool = True


class CloudflareConfig(BaseModel):
    api_token: str = ""
    zone_id: str = ""
    enabled: bool = False
    cache_purge_enabled: bool = False
    cache_purge_delay: int = 5


class ScraperConfig(BaseModel):
    anime_base_url: str = "https://oploverz.mom"
    donghua_base_url: str = "https://anichin.cafe"
    dracin_base_url: str = "https://www.dramaboxdb.com"
    timeout: int = 30
    retries: int = 3
    max_concurrent: int = 10


class Settings(BaseModel):
    app_name: str = "zhadev"
    app_version: str = "1.0.0"
    debug: bool = False
    environment: str = "production"
    
    database: DatabaseConfig = DatabaseConfig()
    jwt: JWTConfig = JWTConfig()
    rate_limit: RateLimitConfig = RateLimitConfig()
    security: SecurityConfig = SecurityConfig()
    cloudflare: CloudflareConfig = CloudflareConfig()
    scraper: ScraperConfig = ScraperConfig()
    
    log_level: str = "INFO"
    log_file: str = "logs/zhadev.log"
    request_timeout: int = 30
    max_upload_size: int = 100 * 1024 * 1024  # 100MB
    
    class Config:
        env_file = ".env"
        env_nested_delimiter = "__"


class ConfigManager:
    _instance = None
    _settings = None
    _config_path = "config.yaml"
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._settings is None:
            self._settings = self._load_settings()
    
    def _load_settings(self) -> Settings:
        config_data = {}
        
        if os.path.exists(self._config_path):
            with open(self._config_path, 'r') as f:
                yaml_config = yaml.safe_load(f)
                if yaml_config:
                    config_data.update(yaml_config)
        
        env_config = self._load_env_vars()
        config_data.update(env_config)
        
        return Settings(**config_data)
    
    def _load_env_vars(self) -> Dict[str, Any]:
        env_config = {}
        
        env_mappings = {
            "JWT_SECRET": "jwt.secret",
            "JWT_EXPIRE": "jwt.access_token_expire_days",
            "DEFAULT_RPM": "rate_limit.default_rpm",
            "ADMIN_APIKEY": "security.admin_apikey",
            "DEV_APIKEY": "security.dev_apikey",
            "OWNER_APIKEY": "security.owner_apikey",
            "CF_API_TOKEN": "cloudflare.api_token",
            "CF_ZONE_ID": "cloudflare.zone_id",
        }
        
        for env_key, config_path in env_mappings.items():
            env_value = os.getenv(env_key)
            if env_value:
                keys = config_path.split('.')
                current = env_config
                for key in keys[:-1]:
                    if key not in current:
                        current[key] = {}
                    current = current[key]
                current[keys[-1]] = self._parse_env_value(env_value)
        
        return env_config
    
    def _parse_env_value(self, value: str) -> Any:
        if value.isdigit():
            return int(value)
        elif value.lower() in ['true', 'false']:
            return value.lower() == 'true'
        elif value.replace('.', '', 1).isdigit() and value.count('.') == 1:
            return float(value)
        return value
    
    @property
    def settings(self) -> Settings:
        return self._settings
    
    def reload(self):
        self._settings = self._load_settings()
    
    def get_database_url(self) -> str:
        db_config = self._settings.database
        if db_config.driver == "sqlite":
            return f"sqlite:///{db_config.database}"
        elif db_config.driver == "mysql":
            return f"mysql://{db_config.username}:{db_config.password}@{db_config.host}:{db_config.port}/{db_config.database}"
        elif db_config.driver == "postgresql":
            return f"postgresql://{db_config.username}:{db_config.password}@{db_config.host}:{db_config.port}/{db_config.database}"
        else:
            raise ValueError(f"Unsupported database driver: {db_config.driver}")
    
    def get_jwt_config(self) -> Dict[str, Any]:
        jwt_config = self._settings.jwt
        return {
            "secret": jwt_config.secret,
            "algorithm": jwt_config.algorithm,
            "access_token_expire": timedelta(days=jwt_config.access_token_expire_days),
            "refresh_token_expire": timedelta(days=jwt_config.refresh_token_expire_days)
        }


config_manager = ConfigManager()
settings = config_manager.settings