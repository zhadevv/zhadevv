#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

import sqlite3
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import threading
from contextlib import contextmanager
import time


class DatabaseManager:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            from .system.config import config
            self.db_path = Path("data/zhadev.db")
            self.db_path.parent.mkdir(exist_ok=True)
            self.conn = None
            self.init_database()
            self.initialized = True
    
    def get_connection(self):
        if self.conn is None:
            self.conn = sqlite3.connect(
                self.db_path, 
                check_same_thread=False,
                timeout=10.0
            )
            self.conn.row_factory = sqlite3.Row
        return self.conn
    
    @contextmanager
    def get_cursor(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cursor.close()
    
    def init_database(self):
        with self.get_cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS apikeys (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    apikey TEXT UNIQUE NOT NULL,
                    username TEXT NOT NULL,
                    role TEXT NOT NULL,
                    active BOOLEAN DEFAULT 1,
                    active_versions TEXT DEFAULT '["v1"]',
                    rpm INTEGER DEFAULT 25,
                    monthly_limit INTEGER DEFAULT 1000,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    requests_count INTEGER DEFAULT 0,
                    requests_month INTEGER DEFAULT 0,
                    last_reset TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    suspended BOOLEAN DEFAULT 0,
                    custom_key TEXT,
                    notes TEXT
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_apikey ON apikeys(apikey)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_role ON apikeys(role)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_active ON apikeys(active)
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ip_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip TEXT NOT NULL,
                    apikey TEXT,
                    endpoint TEXT NOT NULL,
                    method TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    user_agent TEXT,
                    response_time REAL,
                    status_code INTEGER
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_ip ON ip_logs(ip)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_timestamp ON ip_logs(timestamp)
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS banned_ips (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip TEXT UNIQUE NOT NULL,
                    reason TEXT NOT NULL,
                    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    banned_by TEXT NOT NULL,
                    expires_at TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_banned_ip ON banned_ips(ip)
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS rate_limits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    identifier TEXT NOT NULL,
                    request_count INTEGER DEFAULT 0,
                    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    monthly_count INTEGER DEFAULT 0,
                    month_year TEXT,
                    UNIQUE(identifier, month_year)
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_identifier ON rate_limits(identifier)
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    expires_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    total_requests INTEGER DEFAULT 0,
                    successful_requests INTEGER DEFAULT 0,
                    failed_requests INTEGER DEFAULT 0,
                    avg_response_time REAL DEFAULT 0,
                    unique_ips INTEGER DEFAULT 0,
                    active_apikeys INTEGER DEFAULT 0,
                    UNIQUE(date)
                )
            """)
    
    def get_apikey(self, apikey: str) -> Optional[Dict]:
        with self.get_cursor() as cursor:
            cursor.execute(
                "SELECT * FROM apikeys WHERE apikey = ?",
                (apikey,)
            )
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None
    
    def create_apikey(self, username: str, role: str, rpm: int, 
                     monthly_limit: int, custom_key: Optional[str] = None,
                     active_versions: List[str] = None, notes: str = None) -> str:
        from .system.config import config
        
        apikey = custom_key or config.generate_apikey(role)
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO apikeys 
                (apikey, username, role, rpm, monthly_limit, custom_key, 
                 active_versions, notes, created_at, last_reset)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                apikey,
                username,
                role,
                rpm,
                monthly_limit,
                custom_key,
                json.dumps(active_versions or ["v1"]),
                notes,
                datetime.utcnow().isoformat(),
                datetime.utcnow().isoformat()
            ))
        
        return apikey
    
    def update_apikey_stats(self, apikey: str, increment: int = 1):
        current_month = datetime.utcnow().strftime("%Y-%m")
        last_reset = datetime.utcnow() - timedelta(days=30)
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                UPDATE apikeys 
                SET requests_count = requests_count + ?,
                    requests_month = requests_month + ?
                WHERE apikey = ?
            """, (increment, increment, apikey))
            
            cursor.execute("""
                UPDATE apikeys 
                SET requests_month = 0,
                    last_reset = ?
                WHERE apikey = ? 
                AND last_reset < ?
            """, (
                datetime.utcnow().isoformat(),
                apikey,
                last_reset.isoformat()
            ))
    
    def suspend_apikey(self, apikey: str) -> bool:
        with self.get_cursor() as cursor:
            cursor.execute("""
                UPDATE apikeys 
                SET suspended = 1 
                WHERE apikey = ?
            """, (apikey,))
            return cursor.rowcount > 0
    
    def unsuspend_apikey(self, apikey: str) -> bool:
        with self.get_cursor() as cursor:
            cursor.execute("""
                UPDATE apikeys 
                SET suspended = 0 
                WHERE apikey = ?
            """, (apikey,))
            return cursor.rowcount > 0
    
    def delete_apikey(self, apikey: str) -> bool:
        with self.get_cursor() as cursor:
            cursor.execute("DELETE FROM apikeys WHERE apikey = ?", (apikey,))
            return cursor.rowcount > 0
    
    def get_all_apikeys(self, role: str = None) -> List[Dict]:
        with self.get_cursor() as cursor:
            if role:
                cursor.execute(
                    "SELECT * FROM apikeys WHERE role = ? ORDER BY created_at DESC",
                    (role,)
                )
            else:
                cursor.execute("SELECT * FROM apikeys ORDER BY created_at DESC")
            
            return [dict(row) for row in cursor.fetchall()]
    
    def log_request(self, ip: str, endpoint: str, method: str,
                   user_agent: Optional[str] = None,
                   response_time: float = 0,
                   status_code: int = 200,
                   apikey: Optional[str] = None):
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO ip_logs 
                (ip, apikey, endpoint, method, user_agent, 
                 response_time, status_code, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                ip,
                apikey,
                endpoint[:500],
                method,
                user_agent[:500] if user_agent else None,
                response_time,
                status_code,
                datetime.utcnow().isoformat()
            ))
    
    def get_ip_logs(self, ip: Optional[str] = None, 
                   limit: int = 100, offset: int = 0) -> List[Dict]:
        with self.get_cursor() as cursor:
            if ip:
                cursor.execute("""
                    SELECT * FROM ip_logs 
                    WHERE ip = ? 
                    ORDER BY timestamp DESC 
                    LIMIT ? OFFSET ?
                """, (ip, limit, offset))
            else:
                cursor.execute("""
                    SELECT * FROM ip_logs 
                    ORDER BY timestamp DESC 
                    LIMIT ? OFFSET ?
                """, (limit, offset))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def ban_ip(self, ip: str, reason: str, banned_by: str,
              expires_at: Optional[datetime] = None):
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT OR REPLACE INTO banned_ips 
                (ip, reason, banned_by, expires_at, banned_at)
                VALUES (?, ?, ?, ?, ?)
            """, (
                ip,
                reason,
                banned_by,
                expires_at.isoformat() if expires_at else None,
                datetime.utcnow().isoformat()
            ))
    
    def unban_ip(self, ip: str) -> bool:
        with self.get_cursor() as cursor:
            cursor.execute("DELETE FROM banned_ips WHERE ip = ?", (ip,))
            return cursor.rowcount > 0
    
    def is_ip_banned(self, ip: str) -> bool:
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT 1 FROM banned_ips 
                WHERE ip = ? 
                AND (expires_at IS NULL OR expires_at > ?)
            """, (ip, datetime.utcnow().isoformat()))
            return cursor.fetchone() is not None
    
    def get_banned_ips(self) -> List[Dict]:
        with self.get_cursor() as cursor:
            cursor.execute("SELECT * FROM banned_ips ORDER BY banned_at DESC")
            return [dict(row) for row in cursor.fetchall()]
    
    def update_rate_limit(self, identifier: str, increment: int = 1):
        current_month = datetime.utcnow().strftime("%Y-%m")
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT OR REPLACE INTO rate_limits 
                (identifier, request_count, window_start, monthly_count, month_year)
                VALUES (
                    ?, 
                    COALESCE((SELECT request_count FROM rate_limits 
                              WHERE identifier = ? AND month_year = ?), 0) + ?,
                    ?,
                    COALESCE((SELECT monthly_count FROM rate_limits 
                              WHERE identifier = ? AND month_year = ?), 0) + ?,
                    ?
                )
            """, (
                identifier, identifier, current_month, increment,
                datetime.utcnow().isoformat(),
                identifier, current_month, increment,
                current_month
            ))
    
    def get_rate_limit_stats(self, identifier: str) -> Dict:
        current_month = datetime.utcnow().strftime("%Y-%m")
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT request_count, monthly_count 
                FROM rate_limits 
                WHERE identifier = ? AND month_year = ?
            """, (identifier, current_month))
            
            row = cursor.fetchone()
            if row:
                return {
                    "request_count": row[0],
                    "monthly_count": row[1]
                }
            return {"request_count": 0, "monthly_count": 0}
    
    def set_cache(self, key: str, value: Any, ttl: int = 300):
        expires_at = datetime.utcnow() + timedelta(seconds=ttl)
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT OR REPLACE INTO cache 
                (key, value, expires_at, created_at)
                VALUES (?, ?, ?, ?)
            """, (
                key,
                json.dumps(value),
                expires_at.isoformat(),
                datetime.utcnow().isoformat()
            ))
    
    def get_cache(self, key: str) -> Optional[Any]:
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT value FROM cache 
                WHERE key = ? 
                AND (expires_at IS NULL OR expires_at > ?)
            """, (key, datetime.utcnow().isoformat()))
            
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
            return None
    
    def delete_cache(self, key: str):
        with self.get_cursor() as cursor:
            cursor.execute("DELETE FROM cache WHERE key = ?", (key,))
    
    def clear_expired_cache(self):
        with self.get_cursor() as cursor:
            cursor.execute("""
                DELETE FROM cache 
                WHERE expires_at IS NOT NULL 
                AND expires_at <= ?
            """, (datetime.utcnow().isoformat(),))
    
    def update_daily_stats(self):
        today = datetime.utcnow().strftime("%Y-%m-%d")
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_requests,
                    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as successful_requests,
                    SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as failed_requests,
                    AVG(response_time) as avg_response_time,
                    COUNT(DISTINCT ip) as unique_ips
                FROM ip_logs 
                WHERE DATE(timestamp) = DATE(?)
            """, (today,))
            
            stats = cursor.fetchone()
            
            cursor.execute("""
                SELECT COUNT(*) as active_apikeys 
                FROM apikeys 
                WHERE active = 1 AND suspended = 0
            """)
            
            active_apikeys = cursor.fetchone()[0]
            
            cursor.execute("""
                INSERT OR REPLACE INTO stats 
                (date, total_requests, successful_requests, failed_requests, 
                 avg_response_time, unique_ips, active_apikeys)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                today,
                stats[0] or 0,
                stats[1] or 0,
                stats[2] or 0,
                stats[3] or 0,
                stats[4] or 0,
                active_apikeys
            ))
    
    def get_stats(self, days: int = 30) -> List[Dict]:
        start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")
        
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT * FROM stats 
                WHERE date >= ? 
                ORDER BY date DESC
            """, (start_date,))
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_total_stats(self) -> Dict:
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_requests,
                    COUNT(DISTINCT ip) as total_unique_ips,
                    COUNT(DISTINCT apikey) as total_apikeys,
                    AVG(response_time) as avg_response_time
                FROM ip_logs
            """)
            
            row = cursor.fetchone()
            
            cursor.execute("SELECT COUNT(*) as total_apikeys FROM apikeys")
            total_apikeys = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) as banned_ips FROM banned_ips")
            banned_ips = cursor.fetchone()[0]
            
            return {
                "total_requests": row[0] or 0,
                "total_unique_ips": row[1] or 0,
                "total_apikeys": total_apikeys,
                "avg_response_time": row[3] or 0,
                "banned_ips": banned_ips
            }
    
    def cleanup_old_logs(self, days: int = 30):
        cutoff_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        with self.get_cursor() as cursor:
            cursor.execute("DELETE FROM ip_logs WHERE timestamp < ?", (cutoff_date,))
    
    def vacuum(self):
        with self.get_cursor() as cursor:
            cursor.execute("VACUUM")


db = DatabaseManager()