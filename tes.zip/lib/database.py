import sqlite3
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from contextlib import contextmanager
from pathlib import Path
import threading

from lib.system.config import settings


class Database:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized'):
            self.db_path = Path(settings.database.database)
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._initialized = True
            self._initialize_database()
    
    def _initialize_database(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS api_keys (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    api_key TEXT UNIQUE NOT NULL,
                    username TEXT NOT NULL,
                    role TEXT NOT NULL,
                    rpm_limit INTEGER NOT NULL,
                    monthly_limit INTEGER NOT NULL,
                    used_count INTEGER DEFAULT 0,
                    active BOOLEAN DEFAULT 1,
                    suspended BOOLEAN DEFAULT 0,
                    custom_key BOOLEAN DEFAULT 0,
                    allowed_versions TEXT DEFAULT '["v1"]',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NULL,
                    last_used TIMESTAMP NULL,
                    metadata TEXT DEFAULT '{}'
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS rate_limits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    identifier TEXT NOT NULL,
                    period TEXT NOT NULL,
                    count INTEGER DEFAULT 0,
                    reset_time INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(identifier, period)
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS request_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL,
                    api_key TEXT,
                    client_ip TEXT NOT NULL,
                    method TEXT NOT NULL,
                    path TEXT NOT NULL,
                    status_code INTEGER NOT NULL,
                    user_agent TEXT,
                    response_time REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS banned_ips (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip_address TEXT UNIQUE NOT NULL,
                    reason TEXT,
                    banned_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NULL
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ip_geolocation (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip_address TEXT UNIQUE NOT NULL,
                    country TEXT,
                    region TEXT,
                    city TEXT,
                    latitude REAL,
                    longitude REAL,
                    isp TEXT,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS api_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date DATE NOT NULL,
                    endpoint TEXT NOT NULL,
                    request_count INTEGER DEFAULT 0,
                    success_count INTEGER DEFAULT 0,
                    error_count INTEGER DEFAULT 0,
                    avg_response_time REAL DEFAULT 0,
                    UNIQUE(date, endpoint)
                )
            ''')
            
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(api_key)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_limits_identifier ON rate_limits(identifier)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_request_logs_created_at ON request_logs(created_at)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_request_logs_api_key ON request_logs(api_key)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_request_logs_client_ip ON request_logs(client_ip)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_banned_ips_ip ON banned_ips(ip_address)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache(expires_at)')
            
            conn.commit()
    
    @contextmanager
    def get_connection(self):
        conn = None
        try:
            conn = sqlite3.connect(
                str(self.db_path),
                timeout=30,
                check_same_thread=False
            )
            conn.row_factory = sqlite3.Row
            yield conn
        finally:
            if conn:
                conn.close()
    
    def add_api_key(
        self,
        api_key: str,
        username: str,
        role: str,
        rpm_limit: int,
        monthly_limit: int,
        custom_key: bool = False,
        allowed_versions: Optional[List[str]] = None,
        expires_at: Optional[datetime] = None
    ) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    allowed_versions_json = json.dumps(allowed_versions or ["v1"])
                    
                    cursor.execute('''
                        INSERT INTO api_keys 
                        (api_key, username, role, rpm_limit, monthly_limit, custom_key, allowed_versions, expires_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        api_key,
                        username,
                        role,
                        rpm_limit,
                        monthly_limit,
                        custom_key,
                        allowed_versions_json,
                        expires_at.isoformat() if expires_at else None
                    ))
                    
                    conn.commit()
                    return True
            except sqlite3.IntegrityError:
                return False
            except Exception:
                return False
    
    def get_api_key_info(self, api_key: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM api_keys 
                WHERE api_key = ? AND active = 1
            ''', (api_key,))
            
            row = cursor.fetchone()
            if row:
                result = dict(row)
                
                if result['allowed_versions']:
                    try:
                        result['allowed_versions'] = json.loads(result['allowed_versions'])
                    except:
                        result['allowed_versions'] = ["v1"]
                
                if result['metadata']:
                    try:
                        result['metadata'] = json.loads(result['metadata'])
                    except:
                        result['metadata'] = {}
                
                return result
            
            return None
    
    def update_api_key_usage(self, api_key: str) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    now = datetime.utcnow().isoformat()
                    
                    cursor.execute('''
                        UPDATE api_keys 
                        SET used_count = used_count + 1, last_used = ?
                        WHERE api_key = ?
                    ''', (now, api_key))
                    
                    conn.commit()
                    return True
            except Exception:
                return False
    
    def suspend_api_key(self, api_key: str) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                        UPDATE api_keys 
                        SET suspended = 1 
                        WHERE api_key = ?
                    ''', (api_key,))
                    
                    conn.commit()
                    return cursor.rowcount > 0
            except Exception:
                return False
    
    def unsuspend_api_key(self, api_key: str) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                        UPDATE api_keys 
                        SET suspended = 0 
                        WHERE api_key = ?
                    ''', (api_key,))
                    
                    conn.commit()
                    return cursor.rowcount > 0
            except Exception:
                return False
    
    def delete_api_key(self, api_key: str) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                        DELETE FROM api_keys 
                        WHERE api_key = ?
                    ''', (api_key,))
                    
                    conn.commit()
                    return cursor.rowcount > 0
            except Exception:
                return False
    
    def check_rate_limit(
        self,
        identifier: str,
        period: str,
        limit: int
    ) -> Tuple[bool, int, int]:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    current_time = int(time.time())
                    
                    if period == "minute":
                        reset_time = (current_time // 60 + 1) * 60
                    elif period == "hour":
                        reset_time = (current_time // 3600 + 1) * 3600
                    elif period == "day":
                        reset_time = (current_time // 86400 + 1) * 86400
                    elif period == "month":
                        now = datetime.utcnow()
                        next_month = now.replace(day=28) + timedelta(days=4)
                        reset_time = int(next_month.replace(day=1, hour=0, minute=0, second=0, microsecond=0).timestamp())
                    else:
                        reset_time = current_time + 60
                    
                    cursor.execute('''
                        SELECT count, reset_time FROM rate_limits 
                        WHERE identifier = ? AND period = ?
                    ''', (identifier, period))
                    
                    row = cursor.fetchone()
                    
                    if row:
                        count = row['count']
                        stored_reset_time = row['reset_time']
                        
                        if current_time >= stored_reset_time:
                            count = 1
                            cursor.execute('''
                                UPDATE rate_limits 
                                SET count = 1, reset_time = ?
                                WHERE identifier = ? AND period = ?
                            ''', (reset_time, identifier, period))
                        else:
                            if count >= limit:
                                return False, limit - count, stored_reset_time
                            
                            count += 1
                            cursor.execute('''
                                UPDATE rate_limits 
                                SET count = ?
                                WHERE identifier = ? AND period = ?
                            ''', (count, identifier, period))
                    else:
                        count = 1
                        cursor.execute('''
                            INSERT INTO rate_limits (identifier, period, count, reset_time)
                            VALUES (?, ?, ?, ?)
                        ''', (identifier, period, count, reset_time))
                    
                    conn.commit()
                    return True, limit - count, reset_time
            except Exception:
                return True, limit, int(time.time()) + 60
    
    def log_request(
        self,
        request_id: str,
        api_key: Optional[str],
        client_ip: str,
        method: str,
        path: str,
        status_code: int,
        user_agent: Optional[str],
        response_time: float
    ) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO request_logs 
                    (request_id, api_key, client_ip, method, path, status_code, user_agent, response_time)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    request_id,
                    api_key,
                    client_ip,
                    method,
                    path,
                    status_code,
                    user_agent,
                    response_time
                ))
                
                conn.commit()
                return True
        except Exception:
            return False
    
    def ban_ip(self, ip_address: str, reason: str = "", banned_by: str = "system", expires_at: Optional[datetime] = None) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                        INSERT OR REPLACE INTO banned_ips 
                        (ip_address, reason, banned_by, expires_at)
                        VALUES (?, ?, ?, ?)
                    ''', (
                        ip_address,
                        reason,
                        banned_by,
                        expires_at.isoformat() if expires_at else None
                    ))
                    
                    conn.commit()
                    return True
            except Exception:
                return False
    
    def unban_ip(self, ip_address: str) -> bool:
        with self._lock:
            try:
                with self.get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                        DELETE FROM banned_ips 
                        WHERE ip_address = ?
                    ''', (ip_address,))
                    
                    conn.commit()
                    return cursor.rowcount > 0
            except Exception:
                return False
    
    def is_ip_banned(self, ip_address: str) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 1 FROM banned_ips 
                    WHERE ip_address = ? 
                    AND (expires_at IS NULL OR expires_at > ?)
                ''', (ip_address, datetime.utcnow().isoformat()))
                
                return cursor.fetchone() is not None
        except Exception:
            return False
    
    def get_banned_ips(self) -> List[Dict[str, Any]]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM banned_ips 
                    ORDER BY created_at DESC
                ''')
                
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception:
            return []
    
    def update_ip_geolocation(
        self,
        ip_address: str,
        country: Optional[str] = None,
        region: Optional[str] = None,
        city: Optional[str] = None,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        isp: Optional[str] = None
    ) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT OR REPLACE INTO ip_geolocation 
                    (ip_address, country, region, city, latitude, longitude, isp, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    ip_address,
                    country,
                    region,
                    city,
                    latitude,
                    longitude,
                    isp,
                    datetime.utcnow().isoformat()
                ))
                
                conn.commit()
                return True
        except Exception:
            return False
    
    def get_ip_geolocation(self, ip_address: str) -> Optional[Dict[str, Any]]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM ip_geolocation 
                    WHERE ip_address = ?
                ''', (ip_address,))
                
                row = cursor.fetchone()
                if row:
                    return dict(row)
                return None
        except Exception:
            return None
    
    def set_cache(self, key: str, value: Any, ttl: int = 300) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                value_json = json.dumps(value)
                expires_at = datetime.utcnow() + timedelta(seconds=ttl)
                
                cursor.execute('''
                    INSERT OR REPLACE INTO cache (key, value, expires_at)
                    VALUES (?, ?, ?)
                ''', (key, value_json, expires_at.isoformat()))
                
                conn.commit()
                return True
        except Exception:
            return False
    
    def get_cache(self, key: str) -> Optional[Any]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT value FROM cache 
                    WHERE key = ? AND expires_at > ?
                ''', (key, datetime.utcnow().isoformat()))
                
                row = cursor.fetchone()
                if row:
                    try:
                        return json.loads(row['value'])
                    except:
                        return None
                return None
        except Exception:
            return None
    
    def delete_cache(self, key: str) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('DELETE FROM cache WHERE key = ?', (key,))
                
                conn.commit()
                return True
        except Exception:
            return False
    
    def clear_expired_cache(self) -> int:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    DELETE FROM cache 
                    WHERE expires_at <= ?
                ''', (datetime.utcnow().isoformat(),))
                
                deleted_count = cursor.rowcount
                conn.commit()
                return deleted_count
        except Exception:
            return 0
    
    def update_api_stats(
        self,
        endpoint: str,
        success: bool,
        response_time: float
    ) -> bool:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                today = datetime.utcnow().date().isoformat()
                
                cursor.execute('''
                    INSERT INTO api_stats (date, endpoint, request_count, success_count, error_count, avg_response_time)
                    VALUES (?, ?, 1, ?, ?, ?)
                    ON CONFLICT(date, endpoint) DO UPDATE SET
                        request_count = request_count + 1,
                        success_count = success_count + ?,
                        error_count = error_count + ?,
                        avg_response_time = (avg_response_time * (request_count - 1) + ?) / request_count
                ''', (
                    today,
                    endpoint,
                    1 if success else 0,
                    0 if success else 1,
                    response_time,
                    1 if success else 0,
                    0 if success else 1,
                    response_time
                ))
                
                conn.commit()
                return True
        except Exception:
            return False
    
    def get_api_stats(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        endpoint: Optional[str] = None
    ) -> Dict[str, Any]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                query = '''
                    SELECT 
                        COUNT(*) as total_requests,
                        SUM(success_count) as total_success,
                        SUM(error_count) as total_errors,
                        AVG(avg_response_time) as avg_response_time
                    FROM api_stats 
                    WHERE 1=1
                '''
                params = []
                
                if start_date:
                    query += " AND date >= ?"
                    params.append(start_date.date().isoformat())
                
                if end_date:
                    query += " AND date <= ?"
                    params.append(end_date.date().isoformat())
                
                if endpoint:
                    query += " AND endpoint = ?"
                    params.append(endpoint)
                
                cursor.execute(query, params)
                row = cursor.fetchone()
                
                if row:
                    stats = dict(row)
                    
                    cursor.execute('''
                        SELECT date, SUM(request_count) as daily_requests
                        FROM api_stats
                        WHERE date >= date('now', '-30 days')
                        GROUP BY date
                        ORDER BY date
                    ''')
                    
                    daily_stats = [dict(row) for row in cursor.fetchall()]
                    
                    cursor.execute('''
                        SELECT endpoint, SUM(request_count) as endpoint_requests
                        FROM api_stats
                        WHERE date >= date('now', '-7 days')
                        GROUP BY endpoint
                        ORDER BY endpoint_requests DESC
                        LIMIT 10
                    ''')
                    
                    top_endpoints = [dict(row) for row in cursor.fetchall()]
                    
                    return {
                        "summary": stats,
                        "daily_stats": daily_stats,
                        "top_endpoints": top_endpoints
                    }
                
                return {
                    "summary": {
                        "total_requests": 0,
                        "total_success": 0,
                        "total_errors": 0,
                        "avg_response_time": 0
                    },
                    "daily_stats": [],
                    "top_endpoints": []
                }
        except Exception:
            return {
                "summary": {
                    "total_requests": 0,
                    "total_success": 0,
                    "total_errors": 0,
                    "avg_response_time": 0
                },
                "daily_stats": [],
                "top_endpoints": []
            }
    
    def get_all_api_keys(self) -> List[Dict[str, Any]]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT 
                        api_key,
                        username,
                        role,
                        rpm_limit,
                        monthly_limit,
                        used_count,
                        active,
                        suspended,
                        created_at,
                        expires_at,
                        last_used
                    FROM api_keys 
                    ORDER BY created_at DESC
                ''')
                
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception:
            return []
    
    def get_request_logs(
        self,
        limit: int = 100,
        offset: int = 0,
        ip_address: Optional[str] = None,
        api_key: Optional[str] = None
    ) -> Tuple[List[Dict[str, Any]], int]:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                query = 'SELECT * FROM request_logs WHERE 1=1'
                count_query = 'SELECT COUNT(*) as total FROM request_logs WHERE 1=1'
                params = []
                
                if ip_address:
                    query += ' AND client_ip = ?'
                    count_query += ' AND client_ip = ?'
                    params.append(ip_address)
                
                if api_key:
                    query += ' AND api_key = ?'
                    count_query += ' AND api_key = ?'
                    params.append(api_key)
                
                query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
                params.extend([limit, offset])
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                cursor.execute(count_query, params[:-2] if len(params) > 2 else [])
                total_row = cursor.fetchone()
                total = total_row['total'] if total_row else 0
                
                return [dict(row) for row in rows], total
        except Exception:
            return [], 0
    
    def cleanup_old_logs(self, days: int = 30) -> int:
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cutoff_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
                
                cursor.execute('''
                    DELETE FROM request_logs 
                    WHERE created_at < ?
                ''', (cutoff_date,))
                
                deleted_count = cursor.rowcount
                conn.commit()
                
                cursor.execute('VACUUM')
                conn.commit()
                
                return deleted_count
        except Exception:
            return 0