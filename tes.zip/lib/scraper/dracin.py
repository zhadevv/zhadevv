import httpx
import asyncio
from bs4 import BeautifulSoup
import re
from typing import Dict, List, Any, Optional, Union
from urllib.parse import urljoin, urlparse, parse_qs, urlencode
import time
import json


class DramaboxParser:
    def __init__(self, base_url: str = "https://www.dramaboxdb.com", region: str = "en", timeout: int = 30, retries: int = 3):
        self.base_url = base_url.rstrip('/')
        self.region = region
        self.timeout = timeout
        self.retries = retries
        
        self.region_paths = {
            'id': '/in',
            'en': '/',
            'zh': '/zh',
            'zhHans': '/zhHans',
            'ko': '/ko',
            'ja': '/ja',
            'tl': '/tl',
            'th': '/th',
            'ar': '/ar',
            'pt': '/pt',
            'fr': '/fr',
            'es': '/es'
        }
        
        self.path = self.region_paths.get(region, '/')
        self.full_base_url = f"{self.base_url}{self.path}"
        
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': self.get_accept_language(),
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0',
            'Referer': self.full_base_url,
            'Origin': self.base_url
        }
        
        self.client = None
        self.current_url = None

    def get_accept_language(self) -> str:
        language_map = {
            'id': 'id-ID,id;q=0.9,en;q=0.8',
            'en': 'en-US,en;q=0.9',
            'zh': 'zh-CN,zh;q=0.9',
            'zhHans': 'zh-CN,zh;q=0.9',
            'ko': 'ko-KR,ko;q=0.9',
            'ja': 'ja-JP,ja;q=0.9',
            'tl': 'tl-PH,tl;q=0.9,en;q=0.8',
            'th': 'th-TH,th;q=0.9',
            'ar': 'ar-SA,ar;q=0.9',
            'pt': 'pt-BR,pt;q=0.9',
            'fr': 'fr-FR,fr;q=0.9',
            'es': 'es-ES,es;q=0.9'
        }
        return language_map.get(self.region, 'en-US,en;q=0.9')

    async def __aenter__(self):
        limits = httpx.Limits(max_keepalive_connections=5, max_connections=10)
        self.client = httpx.AsyncClient(
            timeout=self.timeout,
            limits=limits,
            headers=self.headers,
            follow_redirects=True
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    async def fetch(self, url: str) -> Optional[str]:
        full_url = urljoin(self.full_base_url, url)
        self.current_url = full_url
        
        for attempt in range(self.retries):
            try:
                response = await self.client.get(full_url)
                response.raise_for_status()
                return response.text
            except (httpx.TimeoutException, httpx.NetworkError):
                if attempt < self.retries - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise
            except httpx.HTTPStatusError as e:
                if e.response.status_code in [403, 429] and attempt < self.retries - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise

    def build_response(self, success: bool, data: Any = None, message: str = None) -> Dict:
        return {
            "status": 200,
            "success": success,
            "author": "zhadevv",
            "region": self.region,
            "path": self.path,
            "base_url": self.full_base_url,
            "data": data,
            "message": message
        }

    def extract_slug(self, url: str) -> str:
        if not url:
            return ""
        
        path = urlparse(url).path.strip('/')
        parts = [p for p in path.split('/') if p]
        return parts[-1] if parts else ""

    def extract_next_data(self, html: str) -> Optional[Dict]:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            next_data_script = soup.find('script', id='__NEXT_DATA__')
            if next_data_script:
                script_content = next_data_script.string
                if script_content:
                    return json.loads(script_content)
            return None
        except Exception:
            return None

    async def home(self) -> Dict:
        try:
            html = await self.fetch("/")
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "slider": [],
                "featured": [],
                "latest": [],
                "popular": [],
                "channels": []
            }
            
            slider_section = soup.find('div', class_='swiper-container')
            if slider_section:
                slides = slider_section.find_all('div', class_='swiper-slide')
                for slide in slides:
                    link = slide.find('a')
                    img = slide.find('img')
                    
                    if link and img:
                        data["slider"].append({
                            "title": img.get('alt', ''),
                            "image": img.get('src', ''),
                            "url": urljoin(self.full_base_url, link.get('href', ''))
                        })
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                if 'featuredDramas' in page_props:
                    for drama in page_props['featuredDramas']:
                        data["featured"].append({
                            "id": drama.get('id', ''),
                            "title": drama.get('title', ''),
                            "slug": drama.get('slug', ''),
                            "image": drama.get('poster', ''),
                            "year": drama.get('year', ''),
                            "rating": drama.get('rating', 0),
                            "episodes": drama.get('episodes', 0),
                            "url": urljoin(self.full_base_url, f"/drama/{drama.get('id', '')}/{drama.get('slug', '')}")
                        })
                
                if 'latestEpisodes' in page_props:
                    for episode in page_props['latestEpisodes']:
                        data["latest"].append({
                            "drama_id": episode.get('dramaId', ''),
                            "drama_title": episode.get('dramaTitle', ''),
                            "episode_id": episode.get('id', ''),
                            "episode_number": episode.get('episodeNumber', ''),
                            "episode_title": episode.get('title', ''),
                            "thumbnail": episode.get('thumbnail', ''),
                            "duration": episode.get('duration', ''),
                            "uploaded_at": episode.get('uploadedAt', ''),
                            "url": urljoin(self.full_base_url, f"/video/{episode.get('dramaId', '')}_{episode.get('slug', '')}/{episode.get('id', '')}_{episode.get('episodeSlug', '')}")
                        })
                
                if 'popularDramas' in page_props:
                    for drama in page_props['popularDramas']:
                        data["popular"].append({
                            "id": drama.get('id', ''),
                            "title": drama.get('title', ''),
                            "slug": drama.get('slug', ''),
                            "image": drama.get('poster', ''),
                            "year": drama.get('year', ''),
                            "rating": drama.get('rating', 0),
                            "views": drama.get('views', 0),
                            "url": urljoin(self.full_base_url, f"/drama/{drama.get('id', '')}/{drama.get('slug', '')}")
                        })
                
                if 'channels' in page_props:
                    for channel in page_props['channels']:
                        data["channels"].append({
                            "slug": channel.get('slug', ''),
                            "name": channel.get('name', ''),
                            "description": channel.get('description', ''),
                            "icon": channel.get('icon', ''),
                            "url": urljoin(self.full_base_url, f"/more/{channel.get('slug', '')}")
                        })
            
            channels_section = soup.find('div', class_='channels-section')
            if channels_section and not data["channels"]:
                channel_items = channels_section.find_all('a', class_='channel-item')
                for item in channel_items:
                    icon = item.find('i')
                    span = item.find('span')
                    
                    if span:
                        slug = self.extract_slug(item.get('href', ''))
                        data["channels"].append({
                            "slug": slug,
                            "name": span.get_text(strip=True),
                            "icon": icon.get('class', [''])[0] if icon else '',
                            "url": urljoin(self.full_base_url, item.get('href', ''))
                        })
            
            return self.build_response(True, {"home": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse home: {str(e)}")

    async def channel(self, slug: str, page: int = 1) -> Dict:
        try:
            if page == 1:
                url = f"/channel/{slug}"
            else:
                url = f"/channel/{slug}/{page}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "slug": slug,
                "page": page,
                "title": "",
                "description": "",
                "total_pages": 1,
                "total_items": 0,
                "dramas": [],
                "pagination": {}
            }
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                data["title"] = page_props.get('channelName', '')
                data["description"] = page_props.get('channelDescription', '')
                
                if 'dramas' in page_props:
                    for drama in page_props['dramas']:
                        data["dramas"].append({
                            "id": drama.get('id', ''),
                            "title": drama.get('title', ''),
                            "slug": drama.get('slug', ''),
                            "image": drama.get('poster', ''),
                            "year": drama.get('year', ''),
                            "rating": drama.get('rating', 0),
                            "episodes": drama.get('episodes', 0),
                            "duration": drama.get('duration', ''),
                            "genres": drama.get('genres', []),
                            "description": drama.get('description', ''),
                            "views": drama.get('views', 0),
                            "url": urljoin(self.full_base_url, f"/drama/{drama.get('id', '')}/{drama.get('slug', '')}")
                        })
                    data["total_items"] = len(data["dramas"])
                
                if 'pagination' in page_props:
                    pagination = page_props['pagination']
                    data["total_pages"] = pagination.get('totalPages', 1)
                    data["total_items"] = pagination.get('totalItems', 0)
            
            header_section = soup.find('div', class_='channel-header')
            if header_section:
                if not data["title"]:
                    title_h1 = header_section.find('h1')
                    if title_h1:
                        data["title"] = title_h1.get_text(strip=True)
                
                if not data["description"]:
                    desc_div = header_section.find('div', class_='channel-description')
                    if desc_div:
                        data["description"] = desc_div.get_text(strip=True)
            
            drama_grid = soup.find('div', class_='drama-grid')
            if drama_grid and not data["dramas"]:
                drama_items = drama_grid.find_all('div', class_='drama-item')
                for item in drama_items:
                    link = item.find('a')
                    img = item.find('img')
                    title = item.find('h3')
                    meta = item.find('div', class_='drama-meta')
                    
                    if link and img:
                        drama_data = {
                            "id": self.extract_slug(link.get('href', '')).split('/')[0],
                            "title": title.get_text(strip=True) if title else img.get('alt', ''),
                            "slug": self.extract_slug(link.get('href', '')),
                            "image": img.get('src', ''),
                            "url": urljoin(self.full_base_url, link.get('href', ''))
                        }
                        
                        if meta:
                            year_span = meta.find('span', class_='year')
                            rating_span = meta.find('span', class_='rating')
                            episodes_span = meta.find('span', class_='episodes')
                            
                            if year_span:
                                drama_data["year"] = year_span.get_text(strip=True)
                            if rating_span:
                                try:
                                    drama_data["rating"] = float(rating_span.get_text(strip=True).replace('★', ''))
                                except:
                                    drama_data["rating"] = 0
                            if episodes_span:
                                drama_data["episodes"] = int(episodes_span.get_text(strip=True).replace(' episodes', ''))
                        
                        data["dramas"].append(drama_data)
                data["total_items"] = len(data["dramas"])
            
            pagination_section = soup.find('div', class_='pagination')
            if pagination_section:
                page_links = pagination_section.find_all('a')
                data["pagination"]["pages"] = []
                
                for link in page_links:
                    page_text = link.get_text(strip=True)
                    if page_text.isdigit():
                        data["pagination"]["pages"].append({
                            "number": int(page_text),
                            "url": urljoin(self.full_base_url, link.get('href', '')),
                            "is_current": 'active' in link.get('class', [])
                        })
                
                if data["pagination"]["pages"]:
                    data["total_pages"] = max(p["number"] for p in data["pagination"]["pages"])
                
                prev_link = pagination_section.find('a', class_='prev')
                if prev_link:
                    data["pagination"]["prev"] = {
                        "url": urljoin(self.full_base_url, prev_link.get('href', '')),
                        "text": prev_link.get_text(strip=True)
                    }
                
                next_link = pagination_section.find('a', class_='next')
                if next_link:
                    data["pagination"]["next"] = {
                        "url": urljoin(self.full_base_url, next_link.get('href', '')),
                        "text": next_link.get_text(strip=True)
                    }
            
            return self.build_response(True, {"channel": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse channel: {str(e)}")

    async def resources(self) -> Dict:
        try:
            if self.region not in ['en']:
                return self.build_response(False, None, "Resources page only available in English region")
            
            html = await self.fetch("/resources")
            soup = BeautifulSoup(html, 'html.parser')
            
            data = {
                "categories": [],
                "latest_updates": [],
                "featured_resources": []
            }
            
            categories_section = soup.find('div', class_='resource-categories')
            if categories_section:
                category_items = categories_section.find_all('a', class_='category-item')
                for item in category_items:
                    icon = item.find('i')
                    span = item.find('span')
                    
                    data["categories"].append({
                        "name": span.get_text(strip=True) if span else '',
                        "icon": icon.get('class', [''])[0] if icon else '',
                        "url": urljoin(self.full_base_url, item.get('href', ''))
                    })
            
            latest_section = soup.find('div', class_='latest-resources')
            if latest_section:
                resource_items = latest_section.find_all('div', class_='resource-item')
                for item in resource_items:
                    link = item.find('a')
                    title = item.find('h4')
                    desc = item.find('p')
                    meta = item.find('div', class_='resource-meta')
                    
                    resource_data = {
                        "title": title.get_text(strip=True) if title else '',
                        "description": desc.get_text(strip=True) if desc else '',
                        "url": urljoin(self.full_base_url, link.get('href', '')) if link else ''
                    }
                    
                    if meta:
                        date_span = meta.find('span', class_='date')
                        author_span = meta.find('span', class_='author')
                        
                        if date_span:
                            resource_data["date"] = date_span.get_text(strip=True)
                        if author_span:
                            resource_data["author"] = author_span.get_text(strip=True)
                    
                    data["latest_updates"].append(resource_data)
            
            featured_section = soup.find('div', class_='featured-resources')
            if featured_section:
                featured_items = featured_section.find_all('div', class_='featured-item')
                for item in featured_items:
                    link = item.find('a')
                    img = item.find('img')
                    title = item.find('h3')
                    desc = item.find('p')
                    
                    featured_data = {
                        "title": title.get_text(strip=True) if title else '',
                        "description": desc.get_text(strip=True) if desc else '',
                        "image": img.get('src', '') if img else '',
                        "url": urljoin(self.full_base_url, link.get('href', '')) if link else ''
                    }
                    
                    data["featured_resources"].append(featured_data)
            
            return self.build_response(True, {"resources": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse resources: {str(e)}")

    async def browse(self, category_id: str = "0", page: int = 1) -> Dict:
        try:
            if page == 1:
                url = f"/browse/{category_id}"
            else:
                url = f"/browse/{category_id}/{page}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "category_id": category_id,
                "category_name": "All Dramas" if category_id == "0" else "",
                "page": page,
                "total_pages": 1,
                "total_items": 0,
                "dramas": [],
                "categories": [],
                "pagination": {}
            }
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                if 'category' in page_props and page_props['category']:
                    category = page_props['category']
                    data["category_name"] = category.get('name', '')
                
                if 'categories' in page_props:
                    for cat in page_props['categories']:
                        data["categories"].append({
                            "id": cat.get('id', ''),
                            "name": cat.get('name', ''),
                            "slug": cat.get('slug', ''),
                            "count": cat.get('dramaCount', 0),
                            "url": urljoin(self.full_base_url, f"/browse/{cat.get('id', '')}")
                        })
                
                if 'dramas' in page_props:
                    for drama in page_props['dramas']:
                        data["dramas"].append({
                            "id": drama.get('id', ''),
                            "title": drama.get('title', ''),
                            "slug": drama.get('slug', ''),
                            "image": drama.get('poster', ''),
                            "year": drama.get('year', ''),
                            "rating": drama.get('rating', 0),
                            "episodes": drama.get('episodes', 0),
                            "duration": drama.get('duration', ''),
                            "genres": drama.get('genres', []),
                            "views": drama.get('views', 0),
                            "url": urljoin(self.full_base_url, f"/drama/{drama.get('id', '')}/{drama.get('slug', '')}")
                        })
                    data["total_items"] = len(data["dramas"])
                
                if 'pagination' in page_props:
                    pagination = page_props['pagination']
                    data["total_pages"] = pagination.get('totalPages', 1)
                    data["total_items"] = pagination.get('totalItems', 0)
            
            category_nav = soup.find('div', class_='category-nav')
            if category_nav and not data["categories"]:
                cat_links = category_nav.find_all('a')
                for link in cat_links:
                    cat_id = self.extract_slug(link.get('href', ''))
                    data["categories"].append({
                        "id": cat_id,
                        "name": link.get_text(strip=True),
                        "url": urljoin(self.full_base_url, link.get('href', '')),
                        "active": 'active' in link.get('class', [])
                    })
                
                active_link = category_nav.find('a', class_='active')
                if active_link:
                    data["category_name"] = active_link.get_text(strip=True)
            
            drama_grid = soup.find('div', class_='drama-grid')
            if drama_grid and not data["dramas"]:
                drama_items = drama_grid.find_all('div', class_='drama-item')
                for item in drama_items:
                    link = item.find('a')
                    img = item.find('img')
                    title = item.find('h3')
                    meta = item.find('div', class_='drama-meta')
                    
                    if link and img:
                        drama_data = {
                            "id": self.extract_slug(link.get('href', '')).split('/')[0],
                            "title": title.get_text(strip=True) if title else img.get('alt', ''),
                            "slug": self.extract_slug(link.get('href', '')),
                            "image": img.get('src', ''),
                            "url": urljoin(self.full_base_url, link.get('href', ''))
                        }
                        
                        if meta:
                            year_span = meta.find('span', class_='year')
                            rating_span = meta.find('span', class_='rating')
                            episodes_span = meta.find('span', class_='episodes')
                            
                            if year_span:
                                drama_data["year"] = year_span.get_text(strip=True)
                            if rating_span:
                                try:
                                    drama_data["rating"] = float(rating_span.get_text(strip=True).replace('★', ''))
                                except:
                                    drama_data["rating"] = 0
                            if episodes_span:
                                drama_data["episodes"] = int(episodes_span.get_text(strip=True).replace(' episodes', ''))
                        
                        data["dramas"].append(drama_data)
                data["total_items"] = len(data["dramas"])
            
            pagination_section = soup.find('div', class_='pagination')
            if pagination_section:
                page_links = pagination_section.find_all('a')
                data["pagination"]["pages"] = []
                
                for link in page_links:
                    page_text = link.get_text(strip=True)
                    if page_text.isdigit():
                        data["pagination"]["pages"].append({
                            "number": int(page_text),
                            "url": urljoin(self.full_base_url, link.get('href', '')),
                            "is_current": 'active' in link.get('class', [])
                        })
                
                if data["pagination"]["pages"]:
                    data["total_pages"] = max(p["number"] for p in data["pagination"]["pages"])
                
                prev_link = pagination_section.find('a', class_='prev')
                if prev_link:
                    data["pagination"]["prev"] = {
                        "url": urljoin(self.full_base_url, prev_link.get('href', '')),
                        "text": prev_link.get_text(strip=True)
                    }
                
                next_link = pagination_section.find('a', class_='next')
                if next_link:
                    data["pagination"]["next"] = {
                        "url": urljoin(self.full_base_url, next_link.get('href', '')),
                        "text": next_link.get_text(strip=True)
                    }
            
            return self.build_response(True, {"browse": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse browse: {str(e)}")

    async def search(self, query: str, page: int = 1) -> Dict:
        try:
            encoded_query = query.replace(' ', '+')
            if page == 1:
                url = f"/search?searchValue={encoded_query}"
            else:
                url = f"/search/{page}?searchValue={encoded_query}"
            
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "query": query,
                "page": page,
                "total_pages": 1,
                "total_results": 0,
                "results": [],
                "suggestions": [],
                "pagination": {}
            }
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                if 'searchResults' in page_props:
                    for result in page_props['searchResults']:
                        data["results"].append({
                            "id": result.get('id', ''),
                            "title": result.get('title', ''),
                            "slug": result.get('slug', ''),
                            "image": result.get('poster', ''),
                            "year": result.get('year', ''),
                            "rating": result.get('rating', 0),
                            "episodes": result.get('episodes', 0),
                            "description": result.get('description', ''),
                            "genres": result.get('genres', []),
                            "url": urljoin(self.full_base_url, f"/drama/{result.get('id', '')}/{result.get('slug', '')}")
                        })
                    data["total_results"] = len(data["results"])
                
                if 'suggestions' in page_props:
                    data["suggestions"] = page_props['suggestions']
                
                if 'pagination' in page_props:
                    pagination = page_props['pagination']
                    data["total_pages"] = pagination.get('totalPages', 1)
                    data["total_results"] = pagination.get('totalResults', 0)
            
            results_section = soup.find('div', class_='search-results')
            if results_section and not data["results"]:
                result_items = results_section.find_all('div', class_='search-result-item')
                for item in result_items:
                    link = item.find('a')
                    img = item.find('img')
                    title = item.find('h3')
                    desc = item.find('p', class_='description')
                    meta = item.find('div', class_='result-meta')
                    
                    result_data = {
                        "title": title.get_text(strip=True) if title else '',
                        "description": desc.get_text(strip=True) if desc else '',
                        "image": img.get('src', '') if img else '',
                        "url": urljoin(self.full_base_url, link.get('href', '')) if link else ''
                    }
                    
                    if meta:
                        year_span = meta.find('span', class_='year')
                        rating_span = meta.find('span', class_='rating')
                        episodes_span = meta.find('span', class_='episodes')
                        
                        if year_span:
                            result_data["year"] = year_span.get_text(strip=True)
                        if rating_span:
                            try:
                                result_data["rating"] = float(rating_span.get_text(strip=True).replace('★', ''))
                            except:
                                result_data["rating"] = 0
                        if episodes_span:
                            result_data["episodes"] = int(episodes_span.get_text(strip=True).replace(' episodes', ''))
                    
                    data["results"].append(result_data)
                data["total_results"] = len(data["results"])
            
            suggestions_section = soup.find('div', class_='search-suggestions')
            if suggestions_section and not data["suggestions"]:
                suggestion_items = suggestions_section.find_all('a')
                for item in suggestion_items:
                    data["suggestions"].append({
                        "text": item.get_text(strip=True),
                        "url": urljoin(self.full_base_url, item.get('href', ''))
                    })
            
            pagination_section = soup.find('div', class_='pagination')
            if pagination_section:
                page_links = pagination_section.find_all('a')
                data["pagination"]["pages"] = []
                
                for link in page_links:
                    page_text = link.get_text(strip=True)
                    if page_text.isdigit():
                        data["pagination"]["pages"].append({
                            "number": int(page_text),
                            "url": urljoin(self.full_base_url, link.get('href', '')),
                            "is_current": 'active' in link.get('class', [])
                        })
                
                if data["pagination"]["pages"]:
                    data["total_pages"] = max(p["number"] for p in data["pagination"]["pages"])
                
                prev_link = pagination_section.find('a', class_='prev')
                if prev_link:
                    data["pagination"]["prev"] = {
                        "url": urljoin(self.full_base_url, prev_link.get('href', '')),
                        "text": prev_link.get_text(strip=True)
                    }
                
                next_link = pagination_section.find('a', class_='next')
                if next_link:
                    data["pagination"]["next"] = {
                        "url": urljoin(self.full_base_url, next_link.get('href', '')),
                        "text": next_link.get_text(strip=True)
                    }
            
            return self.build_response(True, {"search": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse search: {str(e)}")

    async def drama_detail(self, drama_id: str, slug: str) -> Dict:
        try:
            url = f"/drama/{drama_id}/{slug}"
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "id": drama_id,
                "slug": slug,
                "title": "",
                "original_title": "",
                "poster": "",
                "backdrop": "",
                "year": "",
                "rating": 0,
                "duration": "",
                "episodes": 0,
                "views": 0,
                "description": "",
                "genres": [],
                "casts": [],
                "directors": [],
                "studios": [],
                "countries": [],
                "episode_list": [],
                "recommendations": [],
                "metadata": {}
            }
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                if 'drama' in page_props:
                    drama = page_props['drama']
                    data["title"] = drama.get('title', '')
                    data["original_title"] = drama.get('originalTitle', '')
                    data["poster"] = drama.get('poster', '')
                    data["backdrop"] = drama.get('backdrop', '')
                    data["year"] = drama.get('year', '')
                    data["rating"] = drama.get('rating', 0)
                    data["duration"] = drama.get('duration', '')
                    data["episodes"] = drama.get('episodes', 0)
                    data["views"] = drama.get('views', 0)
                    data["description"] = drama.get('description', '')
                    data["genres"] = drama.get('genres', [])
                    data["countries"] = drama.get('countries', [])
                    
                    if 'metadata' in drama:
                        data["metadata"] = drama['metadata']
                
                if 'casts' in page_props:
                    for cast in page_props['casts']:
                        data["casts"].append({
                            "id": cast.get('id', ''),
                            "name": cast.get('name', ''),
                            "character": cast.get('character', ''),
                            "image": cast.get('image', '')
                        })
                
                if 'directors' in page_props:
                    for director in page_props['directors']:
                        data["directors"].append({
                            "id": director.get('id', ''),
                            "name": director.get('name', ''),
                            "role": director.get('role', '')
                        })
                
                if 'studios' in page_props:
                    data["studios"] = page_props['studios']
                
                if 'episodes' in page_props:
                    for episode in page_props['episodes']:
                        data["episode_list"].append({
                            "id": episode.get('id', ''),
                            "number": episode.get('number', ''),
                            "title": episode.get('title', ''),
                            "slug": episode.get('slug', ''),
                            "thumbnail": episode.get('thumbnail', ''),
                            "duration": episode.get('duration', ''),
                            "uploaded_at": episode.get('uploadedAt', ''),
                            "url": urljoin(self.full_base_url, f"/video/{drama_id}_{slug}/{episode.get('id', '')}_{episode.get('slug', '')}")
                        })
                
                if 'recommendations' in page_props:
                    for rec in page_props['recommendations']:
                        data["recommendations"].append({
                            "id": rec.get('id', ''),
                            "title": rec.get('title', ''),
                            "slug": rec.get('slug', ''),
                            "poster": rec.get('poster', ''),
                            "year": rec.get('year', ''),
                            "rating": rec.get('rating', 0),
                            "url": urljoin(self.full_base_url, f"/drama/{rec.get('id', '')}/{rec.get('slug', '')}")
                        })
            
            drama_header = soup.find('div', class_='drama-header')
            if drama_header:
                if not data["title"]:
                    title_h1 = drama_header.find('h1')
                    if title_h1:
                        data["title"] = title_h1.get_text(strip=True)
                
                poster_img = drama_header.find('img', class_='drama-poster')
                if poster_img and not data["poster"]:
                    data["poster"] = poster_img.get('src', '')
            
            drama_info = soup.find('div', class_='drama-info')
            if drama_info:
                if not data["description"]:
                    desc_div = drama_info.find('div', class_='drama-description')
                    if desc_div:
                        data["description"] = desc_div.get_text(strip=True)
                
                meta_div = drama_info.find('div', class_='drama-meta')
                if meta_div:
                    meta_items = meta_div.find_all('span', class_='meta-item')
                    for item in meta_items:
                        text = item.get_text(strip=True)
                        if 'Year:' in text:
                            data["year"] = text.replace('Year:', '').strip()
                        elif 'Rating:' in text:
                            try:
                                data["rating"] = float(text.replace('Rating:', '').replace('★', '').strip())
                            except:
                                pass
                        elif 'Episodes:' in text:
                            try:
                                data["episodes"] = int(text.replace('Episodes:', '').strip())
                            except:
                                pass
                        elif 'Duration:' in text:
                            data["duration"] = text.replace('Duration:', '').strip()
                        elif 'Views:' in text:
                            try:
                                data["views"] = int(text.replace('Views:', '').replace(',', '').strip())
                            except:
                                pass
                
                genres_div = drama_info.find('div', class_='drama-genres')
                if genres_div and not data["genres"]:
                    genre_links = genres_div.find_all('a')
                    for link in genre_links:
                        data["genres"].append({
                            "name": link.get_text(strip=True),
                            "url": urljoin(self.full_base_url, link.get('href', ''))
                        })
            
            cast_section = soup.find('div', class_='drama-cast')
            if cast_section and not data["casts"]:
                cast_items = cast_section.find_all('div', class_='cast-item')
                for item in cast_items:
                    img = item.find('img')
                    name_div = item.find('div', class_='cast-name')
                    character_div = item.find('div', class_='cast-character')
                    
                    cast_data = {
                        "name": name_div.get_text(strip=True) if name_div else '',
                        "character": character_div.get_text(strip=True) if character_div else '',
                        "image": img.get('src', '') if img else ''
                    }
                    
                    data["casts"].append(cast_data)
            
            episode_list = soup.find('div', class_='episode-list')
            if episode_list and not data["episode_list"]:
                episode_items = episode_list.find_all('div', class_='episode-item')
                for item in episode_items:
                    link = item.find('a')
                    thumb = item.find('img')
                    number_span = item.find('span', class_='episode-number')
                    title_div = item.find('div', class_='episode-title')
                    
                    episode_data = {
                        "number": number_span.get_text(strip=True) if number_span else '',
                        "title": title_div.get_text(strip=True) if title_div else '',
                        "thumbnail": thumb.get('src', '') if thumb else '',
                        "url": urljoin(self.full_base_url, link.get('href', '')) if link else ''
                    }
                    
                    data["episode_list"].append(episode_data)
            
            recommendations_section = soup.find('div', class_='recommendations')
            if recommendations_section and not data["recommendations"]:
                rec_items = recommendations_section.find_all('div', class_='recommendation-item')
                for item in rec_items:
                    link = item.find('a')
                    img = item.find('img')
                    title_h3 = item.find('h3')
                    
                    rec_data = {
                        "title": title_h3.get_text(strip=True) if title_h3 else '',
                        "poster": img.get('src', '') if img else '',
                        "url": urljoin(self.full_base_url, link.get('href', '')) if link else ''
                    }
                    
                    data["recommendations"].append(rec_data)
            
            return self.build_response(True, {"drama": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse drama detail: {str(e)}")

    async def watch(self, drama_id: str, drama_slug: str, episode_id: str, episode_slug: str) -> Dict:
        try:
            url = f"/video/{drama_id}_{drama_slug}/{episode_id}_{episode_slug}"
            html = await self.fetch(url)
            soup = BeautifulSoup(html, 'html.parser')
            next_data = self.extract_next_data(html)
            
            data = {
                "drama_id": drama_id,
                "drama_slug": drama_slug,
                "episode_id": episode_id,
                "episode_slug": episode_slug,
                "drama_title": "",
                "episode_title": "",
                "episode_number": "",
                "video_url": "",
                "video_sources": [],
                "subtitles": [],
                "qualities": [],
                "duration": 0,
                "thumbnail": "",
                "description": "",
                "uploaded_at": "",
                "views": 0,
                "next_episode": None,
                "prev_episode": None,
                "episode_list": []
            }
            
            if next_data and next_data.get('props', {}).get('pageProps', {}):
                page_props = next_data['props']['pageProps']
                
                if 'video' in page_props:
                    video = page_props['video']
                    data["drama_title"] = video.get('dramaTitle', '')
                    data["episode_title"] = video.get('title', '')
                    data["episode_number"] = video.get('episodeNumber', '')
                    data["video_url"] = video.get('videoUrl', '')
                    data["duration"] = video.get('duration', 0)
                    data["thumbnail"] = video.get('thumbnail', '')
                    data["description"] = video.get('description', '')
                    data["uploaded_at"] = video.get('uploadedAt', '')
                    data["views"] = video.get('views', 0)
                    
                    if 'sources' in video:
                        for source in video['sources']:
                            data["video_sources"].append({
                                "url": source.get('url', ''),
                                "type": source.get('type', ''),
                                "quality": source.get('quality', '')
                            })
                    
                    if 'subtitles' in video:
                        for sub in video['subtitles']:
                            data["subtitles"].append({
                                "language": sub.get('language', ''),
                                "url": sub.get('url', ''),
                                "format": sub.get('format', '')
                            })
                    
                    if 'qualities' in video:
                        data["qualities"] = video['qualities']
                
                if 'episodeList' in page_props:
                    for episode in page_props['episodeList']:
                        episode_data = {
                            "id": episode.get('id', ''),
                            "number": episode.get('number', ''),
                            "title": episode.get('title', ''),
                            "slug": episode.get('slug', ''),
                            "url": urljoin(self.full_base_url, f"/video/{drama_id}_{drama_slug}/{episode.get('id', '')}_{episode.get('slug', '')}"),
                            "is_current": episode.get('id', '') == episode_id
                        }
                        data["episode_list"].append(episode_data)
                        
                        if episode.get('id', '') == episode_id:
                            current_index = len(data["episode_list"]) - 1
                            
                            if current_index > 0:
                                prev_ep = data["episode_list"][current_index - 1]
                                data["prev_episode"] = prev_ep
                            
                            if current_index < len(data["episode_list"]) - 1:
                                next_ep = data["episode_list"][current_index + 1]
                                data["next_episode"] = next_ep
            
            video_section = soup.find('div', class_='video-player-section')
            if video_section:
                video_player = video_section.find('video')
                if video_player:
                    if not data["video_url"]:
                        src = video_player.get('src', '')
                        if src:
                            data["video_url"] = src
                    
                    if not data["thumbnail"]:
                        poster = video_player.get('poster', '')
                        if poster:
                            data["thumbnail"] = poster
                
                if not data["episode_title"]:
                    episode_title_div = video_section.find('div', class_='episode-title')
                    if episode_title_div:
                        data["episode_title"] = episode_title_div.get_text(strip=True)
            
            info_section = soup.find('div', class_='video-info-section')
            if info_section:
                if not data["drama_title"]:
                    drama_link = info_section.find('a', class_='drama-title-link')
                    if drama_link:
                        data["drama_title"] = drama_link.get_text(strip=True)
                
                if not data["description"]:
                    desc_div = info_section.find('div', class_='video-description')
                    if desc_div:
                        data["description"] = desc_div.get_text(strip=True)
                
                meta_div = info_section.find('div', class_='video-meta')
                if meta_div:
                    meta_items = meta_div.find_all('span', class_='meta-item')
                    for item in meta_items:
                        text = item.get_text(strip=True)
                        if 'Episode:' in text:
                            data["episode_number"] = text.replace('Episode:', '').strip()
                        elif 'Duration:' in text:
                            try:
                                data["duration"] = int(text.replace('Duration:', '').replace('min', '').strip())
                            except:
                                pass
                        elif 'Uploaded:' in text:
                            data["uploaded_at"] = text.replace('Uploaded:', '').strip()
                        elif 'Views:' in text:
                            try:
                                data["views"] = int(text.replace('Views:', '').replace(',', '').strip())
                            except:
                                pass
            
            episode_nav = soup.find('div', class_='episode-navigation')
            if episode_nav:
                prev_link = episode_nav.find('a', class_='prev-episode')
                if prev_link:
                    prev_url = prev_link.get('href', '')
                    if prev_url:
                        prev_slug = self.extract_slug(prev_url)
                        prev_parts = prev_slug.split('_')
                        if len(prev_parts) >= 2:
                            data["prev_episode"] = {
                                "id": prev_parts[0],
                                "slug": prev_parts[1],
                                "url": urljoin(self.full_base_url, prev_url)
                            }
                
                next_link = episode_nav.find('a', class_='next-episode')
                if next_link:
                    next_url = next_link.get('href', '')
                    if next_url:
                        next_slug = self.extract_slug(next_url)
                        next_parts = next_slug.split('_')
                        if len(next_parts) >= 2:
                            data["next_episode"] = {
                                "id": next_parts[0],
                                "slug": next_parts[1],
                                "url": urljoin(self.full_base_url, next_url)
                            }
            
            episode_list_section = soup.find('div', class_='video-episode-list')
            if episode_list_section and not data["episode_list"]:
                episode_links = episode_list_section.find_all('a', class_='episode-link')
                for link in episode_links:
                    href = link.get('href', '')
                    if href:
                        ep_slug = self.extract_slug(href)
                        ep_parts = ep_slug.split('_')
                        if len(ep_parts) >= 2:
                            episode_data = {
                                "id": ep_parts[0],
                                "slug": ep_parts[1],
                                "title": link.get_text(strip=True),
                                "url": urljoin(self.full_base_url, href),
                                "is_current": ep_parts[0] == episode_id
                            }
                            data["episode_list"].append(episode_data)
            
            return self.build_response(True, {"watch": data})
            
        except Exception as e:
            return self.build_response(False, None, f"Failed to parse watch: {str(e)}")