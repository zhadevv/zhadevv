#!/usr/bin/env python3
"""
zhadev API Server Startup Script
"""

import uvicorn
import sys
import os
from pathlib import Path


def check_environment():
    """Check environment and dependencies"""
    print("🔍 Checking environment...")
    
    required_dirs = ["data", "lib", "middlewares", "src"]
    for dir_name in required_dirs:
        dir_path = Path(dir_name)
        if not dir_path.exists():
            print(f"⚠️  Directory '{dir_name}' not found, creating...")
            dir_path.mkdir(exist_ok=True)
    
    db_path = Path("data/zhadev.db")
    if not db_path.exists():
        print("📦 Initializing database...")
        from lib.database import db
        db.init_database()
        print("✅ Database initialized")
    
    print("✅ Environment check completed")


def print_banner():
    """Print startup banner"""
    banner = """
╔══════════════════════════════════════════════════╗
║                zhadev API Server                 ║
║                   Version 1.0.0                  ║
╚══════════════════════════════════════════════════╝
    """
    print(banner)


def main():
    """Main entry point"""
    print_banner()
    
    try:
        check_environment()
        
        print("🚀 Starting zhadev API server...")
        print("📊 Docs: http://localhost:8000/docs")
        print("📊 Redoc: http://localhost:8000/redoc")
        print("🔌 API: http://localhost:8000/api")
        print("\nPress Ctrl+C to stop\n")
        
        uvicorn.run(
            "src.main:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info",
            access_log=True,
            workers=1
        )
        
    except KeyboardInterrupt:
        print("\n👋 Shutting down...")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()