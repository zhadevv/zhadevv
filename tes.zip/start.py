import uvicorn
import sys
import os
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from src.main import app

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    reload = os.getenv("RELOAD", "false").lower() == "true"
    
    print(f"🚀 Starting zhadev API on {host}:{port}")
    print(f"📚 API Documentation: http://{host}:{port}/docs")
    print(f"🔧 Environment: {os.getenv('ENVIRONMENT', 'production')}")
    print(f"🔄 Auto-reload: {reload}")
    
    uvicorn.run(
        "start:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )