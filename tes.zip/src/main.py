from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
import uvicorn

from src.api.router import api_router
from middlewares import (
    RequestIDMiddleware,
    SecurityHeadersMiddleware,
    ProcessTimeMiddleware,
    RequestValidationMiddleware,
    CacheControlMiddleware,
    ResponseFormatMiddleware,
    IPValidationMiddleware,
    AuthorizationMiddleware,
    ErrorHandlerMiddleware,
    ProtectorMiddleware,
    RequestLoggerMiddleware,
    RestrictMiddleware,
    RPMMiddleware,
    SecretsOnlyMiddleware
)
from middlewares.rates import (
    GuestRateMiddleware,
    FreeRateMiddleware,
    StarterRateMiddleware,
    MediumRateMiddleware,
    HighestRateMiddleware,
    EnterpriseRateMiddleware,
    AdminRateMiddleware,
    DeveloperRateMiddleware,
    OwnerRateMiddleware
)

description = """
### About
- **Github**: [Anidong](https://github.com/zhadevv/anidong-api)
- **Version**: `v1.0.0`

### Credit
- Project ini terinspirasi dari bang Sanka yang udh bnyk ngebuat Api kayak Anime, Donghua, Komik, Dll.
- Project ini dibangun atas dasar gabut aja si🗿
"""

version = "1.0.0"

tags_metadata = [
    {
        "name": "Anime",
        "description": "Anime Api Endpoint",
    },
    {
        "name": "Donghua",
        "description": "Donghua Api Endpoint",
    },
    {
        "name": "Key Management", 
        "description": "Api Key Management",
    },
]

app = FastAPI(
    title="zhadev API",
    description=description,
    version=version,
    openapi_tags=tags_metadata,
    docs_url="/docs",
    redoc_url=None,
    openapi_url="/api/v1/openapi.json",
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "docExpansion": "none",
        "filter": True,
        "showExtensions": True,
        "showCommonExtensions": True,
        "syntaxHighlight": {
            "theme": "obsidian"
        }
    }
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])

app.add_middleware(IPValidationMiddleware)
app.add_middleware(RequestIDMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(ProcessTimeMiddleware)
app.add_middleware(RequestValidationMiddleware)
app.add_middleware(CacheControlMiddleware)
app.add_middleware(ResponseFormatMiddleware)
app.add_middleware(RestrictMiddleware)
app.add_middleware(ProtectorMiddleware)
app.add_middleware(AuthorizationMiddleware)
app.add_middleware(SecretsOnlyMiddleware)

app.add_middleware(GuestRateMiddleware)
app.add_middleware(FreeRateMiddleware)
app.add_middleware(StarterRateMiddleware)
app.add_middleware(MediumRateMiddleware)
app.add_middleware(HighestRateMiddleware)
app.add_middleware(EnterpriseRateMiddleware)
app.add_middleware(AdminRateMiddleware)
app.add_middleware(DeveloperRateMiddleware)
app.add_middleware(OwnerRateMiddleware)

app.add_middleware(RPMMiddleware)
app.add_middleware(RequestLoggerMiddleware)
app.add_middleware(ErrorHandlerMiddleware)

app.include_router(api_router)

@app.get("/")
async def root():
    return {
        "status": 200,
        "success": True,
        "author": "zhadevv",
        "data": {
            "app": "zhadev API",
            "version": version,
            "docs": "/docs",
            "api_v1": "/api/v1",
            "health": "/api/health",
            "stats": "/api/stats"
        },
        "message": None
    }

@app.get("/api/health")
async def health_check():
    return {
        "status": 200,
        "success": True,
        "author": "zhadevv",
        "data": {
            "status": "healthy",
            "timestamp": "2024-01-01T00:00:00Z"
        },
        "message": None
    }

if __name__ == "__main__":
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )