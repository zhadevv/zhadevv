from fastapi import FastAPI, Request
from starlette.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from lib.system.middleware import (
    RequestIDMiddleware,
    TimingMiddleware,
    SecurityHeadersMiddleware,
    IPBlockMiddleware,
    LoggingMiddleware,
    CompressionMiddleware,
    CacheMiddleware
)
from middlewares import (
    ErrorHandlerMiddleware,
    RequestProtectorMiddleware,
    SizeLimitMiddleware,
    MethodFilterMiddleware,
    RPMMiddleware
)
from src.api.router import router as api_router
import uvicorn
from contextlib import asynccontextmanager
import time
from datetime import datetime
from lib.system.config import config


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 Starting zhadev API server...")
    print(f"📊 Default RPM: {config.env.DEFAULT_RPM}")
    print(f"🔐 JWT Expire: {config.env.JWT_EXPIRE} days")
    
    yield
    
    print("👋 Shutting down zhadev API server...")


description = f"""
### About
- **API**: zhadev RESTful API
- **Author**: zhadevv
- **Version**: `v1.0.0`
- **Environment**: Production
- **Server**: VPS Localstorage

### API Structure
- **Public APIs**: Available under `/api/v1/` with API key authentication
- **Private APIs**: Admin endpoints under `/api/admin/` (not in docs)
- **Health & Stats**: Available under `/api/health` and `/api/stats`

### Rate Limits
- **Guest**: {config.rate_limits.guest.rpm} RPM, {config.rate_limits.guest.monthly_limit} monthly
- **Free**: {config.rate_limits.free.rpm} RPM, {config.rate_limits.free.monthly_limit} monthly
- **Starter**: {config.rate_limits.starter.rpm} RPM, {config.rate_limits.starter.monthly_limit} monthly
- **Medium**: {config.rate_limits.medium.rpm} RPM, {config.rate_limits.medium.monthly_limit} monthly
- **Highest**: {config.rate_limits.highest.rpm} RPM, {config.rate_limits.highest.monthly_limit} monthly
- **Admin/Dev/Owner**: Higher limits with special permissions

### Authentication
All endpoints require `Authorization: Bearer {apikey}` header except health check.

### Note
- This API is built for educational and personal use
- Respect the rate limits and terms of service
- Report issues to the maintainer
"""

tags_metadata = [
    {
        "name": "Health",
        "description": "Health check and server statistics"
    },
    {
        "name": "Anime",
        "description": "Anime content from Oploverz"
    },
    {
        "name": "Donghua",
        "description": "Donghua content from Anichin"
    },
    {
        "name": "Dracin",
        "description": "Drama content from DramaboxDB"
    },
    {
        "name": "API Management",
        "description": "API key management and validation"
    }
]

app = FastAPI(
    title="zhadev API",
    description=description,
    version="1.0.0",
    openapi_tags=tags_metadata,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "docExpansion": "none",
        "filter": True,
        "showExtensions": True,
        "showCommonExtensions": True,
        "syntaxHighlight": {
            "theme": "obsidian"
        },
        "persistAuthorization": True
    }
)


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
        tags=app.openapi_tags
    )
    
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "API Key",
            "description": "Enter your API key with 'Bearer ' prefix"
        }
    }
    
    for path in openapi_schema["paths"].values():
        for method in path.values():
            if method.get("tags") and method["tags"][0] != "Health":
                method["security"] = [{"BearerAuth": []}]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


app.add_middleware(CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Process-Time", "X-Rate-Limit-*", "X-Monthly-*"]
)

app.add_middleware(RequestIDMiddleware)
app.add_middleware(TimingMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(IPBlockMiddleware)
app.add_middleware(LoggingMiddleware)
app.add_middleware(CompressionMiddleware)
app.add_middleware(CacheMiddleware)
app.add_middleware(ErrorHandlerMiddleware, debug=False)
app.add_middleware(RequestProtectorMiddleware)
app.add_middleware(SizeLimitMiddleware, max_size=10*1024*1024)
app.add_middleware(MethodFilterMiddleware)
app.add_middleware(RPMMiddleware)


app.include_router(api_router, prefix="/api")


@app.get("/", include_in_schema=False)
async def root():
    return {
        "status": 200,
        "success": True,
        "author": "zhadevv",
        "data": {
            "message": "Welcome to zhadev API",
            "docs": "/docs",
            "version": "1.0.0",
            "timestamp": datetime.utcnow().isoformat()
        },
        "message": None
    }


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = f"{process_time:.3f}"
    return response


if __name__ == "__main__":
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
        access_log=True
    )