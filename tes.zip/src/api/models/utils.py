from typing import Optional, List
from pydantic import BaseModel, Field, validator


class PaginationParams(BaseModel):
    page: int = Field(1, ge=1, description="Page number")
    limit: int = Field(20, ge=1, le=100, description="Items per page")
    
    @validator('limit')
    def validate_limit(cls, v):
        if v > 100:
            raise ValueError('Limit cannot exceed 100')
        return v


class SearchParams(BaseModel):
    q: str = Field(..., min_length=1, max_length=100, description="Search query")
    page: int = Field(1, ge=1, description="Page number")
    limit: int = Field(20, ge=1, le=50, description="Results per page")
    
    @validator('q')
    def sanitize_query(cls, v):
        v = v.strip()
        if len(v) < 1:
            raise ValueError('Search query cannot be empty')
        return v


class FilterParams(BaseModel):
    status: Optional[str] = Field(None, description="Filter by status")
    type: Optional[str] = Field(None, description="Filter by type")
    order: Optional[str] = Field(None, description="Sort order")
    genres: Optional[List[str]] = Field(None, description="Filter by genres")
    studios: Optional[List[str]] = Field(None, description="Filter by studios")
    seasons: Optional[List[str]] = Field(None, description="Filter by seasons")
    page: int = Field(1, ge=1, description="Page number")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "ongoing",
                "type": "tv",
                "order": "popular",
                "genres": ["action", "adventure"],
                "studios": ["studio1"],
                "seasons": ["2023"],
                "page": 1
            }
        }


class AnimeParams(BaseModel):
    slug: str = Field(..., description="Anime slug")
    episode: Optional[int] = Field(None, ge=1, description="Episode number")
    page: Optional[int] = Field(1, ge=1, description="Page number")


class DonghuaParams(BaseModel):
    slug: str = Field(..., description="Donghua slug")
    episode: Optional[int] = Field(None, ge=1, description="Episode number")
    page: Optional[int] = Field(1, ge=1, description="Page number")
    letter: Optional[str] = Field(None, min_length=1, max_length=1, description="Letter for A-Z list")
    show: Optional[str] = Field(None, min_length=1, max_length=1, description="Show specific letter")


class DracinParams(BaseModel):
    region: str = Field(..., description="Region code (en, id, zh, etc.)")
    slug: str = Field(..., description="Drama slug")
    id: Optional[str] = Field(None, description="Genre/Channel ID")
    episode: Optional[str] = Field(None, description="Episode slug")
    page: Optional[int] = Field(1, ge=1, description="Page number")