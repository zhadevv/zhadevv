from typing import Optional, Dict, Any
from fastapi import HTTPException


class APIException(HTTPException):
    def __init__(
        self,
        status_code: int = 400,
        detail: str = "An error occurred",
        headers: Optional[Dict[str, Any]] = None
    ):
        super().__init__(status_code=status_code, detail=detail, headers=headers)


class RateLimitException(APIException):
    def __init__(
        self,
        detail: str = "Rate limit exceeded",
        retry_after: Optional[int] = None
    ):
        headers = {"Retry-After": str(retry_after)} if retry_after else None
        super().__init__(status_code=429, detail=detail, headers=headers)


class AuthorizationException(APIException):
    def __init__(
        self,
        detail: str = "Unauthorized"
    ):
        super().__init__(status_code=401, detail=detail)


class ValidationException(APIException):
    def __init__(
        self,
        detail: str = "Validation error",
        errors: Optional[list] = None
    ):
        if errors:
            detail = f"{detail}: {', '.join(errors)}"
        super().__init__(status_code=422, detail=detail)


class NotFoundException(APIException):
    def __init__(
        self,
        detail: str = "Resource not found"
    ):
        super().__init__(status_code=404, detail=detail)


class InternalServerException(APIException):
    def __init__(
        self,
        detail: str = "Internal server error"
    ):
        super().__init__(status_code=500, detail=detail)