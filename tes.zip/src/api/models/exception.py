from fastapi import HTTPException
from typing import Any, Dict, Optional


class APIException(HTTPException):
    def __init__(
        self,
        status_code: int = 400,
        detail: str = "An error occurred",
        headers: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None
    ):
        super().__init__(status_code=status_code, detail=detail, headers=headers)
        self.error_code = error_code


class ValidationException(APIException):
    def __init__(
        self,
        detail: str = "Validation error",
        errors: Optional[Dict[str, Any]] = None
    ):
        super().__init__(status_code=422, detail=detail)
        self.errors = errors


class AuthenticationException(APIException):
    def __init__(self, detail: str = "Authentication failed"):
        super().__init__(status_code=401, detail=detail)


class AuthorizationException(APIException):
    def __init__(self, detail: str = "Authorization failed"):
        super().__init__(status_code=403, detail=detail)


class RateLimitException(APIException):
    def __init__(
        self,
        detail: str = "Rate limit exceeded",
        retry_after: Optional[int] = None
    ):
        headers = {}
        if retry_after:
            headers["Retry-After"] = str(retry_after)
            headers["X-RateLimit-Reset"] = str(retry_after)
        
        super().__init__(status_code=429, detail=detail, headers=headers)


class NotFoundException(APIException):
    def __init__(self, detail: str = "Resource not found"):
        super().__init__(status_code=404, detail=detail)


class InternalServerException(APIException):
    def __init__(self, detail: str = "Internal server error"):
        super().__init__(status_code=500, detail=detail)


class ServiceUnavailableException(APIException):
    def __init__(self, detail: str = "Service temporarily unavailable"):
        super().__init__(status_code=503, detail=detail)


class BadRequestException(APIException):
    def __init__(self, detail: str = "Bad request"):
        super().__init__(status_code=400, detail=detail)


class ConflictException(APIException):
    def __init__(self, detail: str = "Resource conflict"):
        super().__init__(status_code=409, detail=detail)


class ScraperException(APIException):
    def __init__(self, detail: str = "Scraper error"):
        super().__init__(status_code=502, detail=detail)


class CloudflareException(APIException):
    def __init__(self, detail: str = "Cloudflare error"):
        super().__init__(status_code=502, detail=detail)


class DatabaseException(APIException):
    def __init__(self, detail: str = "Database error"):
        super().__init__(status_code=500, detail=detail)