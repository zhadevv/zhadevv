from typing import Generic, TypeVar, Optional
from pydantic import BaseModel, Field

T = TypeVar('T')

class BaseResponse(BaseModel, Generic[T]):
    status: int = Field(..., description="Kode Status HTTP")
    success: bool = Field(..., description="Pesan Sukses")
    author: str = Field("zhadevv", description="my Gwej Name")
    data: Optional[T] = Field(None, description="Data ada jika Fetch Berhasil.")
    message: Optional[str] = Field(None, description="Pesan Error jika Data tidak ada.")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": 200,
                "success": True,
                "author": "zhadevv",
                "data": {"example": "data"},
                "message": None
            }
        }

class ErrorResponse(BaseModel):
    status: int = Field(..., description="Kode Status HTTP")
    success: bool = Field(..., description="Pesan Sukses")
    author: str = Field("zhadevv", description="my Gwej Name")
    data: None = Field(None, description="Data selalu null untuk error")
    message: str = Field(..., description="Pesan Error")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": 400,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": "Bad Request"
            }
        }

class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    pages: int
    has_next: bool
    has_prev: bool
    
    class Config:
        json_schema_extra = {
            "example": {
                "items": [{"id": 1, "name": "Item 1"}],
                "total": 100,
                "page": 1,
                "pages": 10,
                "has_next": True,
                "has_prev": False
            }
        }