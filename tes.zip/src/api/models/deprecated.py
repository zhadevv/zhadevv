from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class DeprecatedEndpoint(BaseModel):
    endpoint: str = Field(..., description="Deprecated endpoint")
    deprecated_since: datetime = Field(..., description="Deprecation date")
    alternative: Optional[str] = Field(default=None, description="Alternative endpoint")
    removal_date: Optional[datetime] = Field(default=None, description="Planned removal date")
    message: str = Field(..., description="Deprecation message")


class DeprecatedResponse(BaseModel):
    status: int = Field(..., description="HTTP status code")
    success: bool = Field(default=False, description="Request success status")
    author: str = Field(default="zhadevv", description="API author")
    data: Optional[Dict[str, Any]] = Field(default=None, description="Deprecation info")
    message: str = Field(..., description="Deprecation message")

    class Config:
        json_schema_extra = {
            "example": {
                "status": 410,
                "success": False,
                "author": "zhadevv",
                "data": {
                    "endpoint": "/api/v1/old",
                    "deprecated_since": "2024-01-01T00:00:00Z",
                    "alternative": "/api/v2/new",
                    "removal_date": "2024-07-01T00:00:00Z"
                },
                "message": "This endpoint is deprecated. Please use the alternative endpoint."
            }
        }


DEPRECATED_ENDPOINTS = {
    "/api/v1/anime/old": DeprecatedEndpoint(
        endpoint="/api/v1/anime/old",
        deprecated_since=datetime(2024, 1, 1),
        alternative="/api/v1/anime/new",
        removal_date=datetime(2024, 7, 1),
        message="This endpoint is deprecated. Use /api/v1/anime/new instead."
    )
}