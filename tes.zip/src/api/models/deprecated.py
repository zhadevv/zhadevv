from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class DeprecatedEndpoint(BaseModel):
    deprecated: bool = Field(True, description="Endpoint is deprecated")
    message: str = Field(..., description="Deprecation message")
    alternative: Optional[str] = Field(None, description="Alternative endpoint")
    sunset_date: Optional[datetime] = Field(None, description="Date when endpoint will be removed")
    
    class Config:
        json_schema_extra = {
            "example": {
                "deprecated": True,
                "message": "This endpoint is deprecated and will be removed in future versions",
                "alternative": "/api/v2/new-endpoint",
                "sunset_date": "2024-06-01T00:00:00Z"
            }
        }