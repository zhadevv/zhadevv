from fastapi import APIRouter
from src.api.endpoints.main import router as main_router
from src.api.endpoints.v1.anime import router as anime_router
from src.api.endpoints.v1.donghua import router as donghua_router
from src.api.endpoints.v1.dracin import router as dracin_router
from src.api.endpoints.admin import router as admin_router

router = APIRouter()

router.include_router(main_router, prefix="")
router.include_router(anime_router, prefix="")
router.include_router(donghua_router, prefix="")
router.include_router(dracin_router, prefix="")
router.include_router(admin_router, prefix="")

@router.get("/api", include_in_schema=False)
async def api_root():
    return {
        "status": 200,
        "success": True,
        "author": "zhadevv",
        "data": {
            "message": "zhadev API Root",
            "versions": {
                "v1": {
                    "anime": "/api/v1/anime/...",
                    "donghua": "/api/v1/donghua/...",
                    "dracin": "/api/v1/dracin/..."
                }
            },
            "endpoints": {
                "health": "/api/health",
                "stats": "/api/stats",
                "check": "/api/check?apikey=",
                "me": "/api/@me"
            },
            "documentation": "/docs",
            "openapi": "/openapi.json"
        },
        "message": None
    }

@router.get("/api/v1", include_in_schema=False)
async def api_v1_root():
    return {
        "status": 200,
        "success": True,
        "author": "zhadevv",
        "data": {
            "version": "v1",
            "endpoints": {
                "anime": {
                    "sidebar": "/api/v1/anime/sidebar",
                    "schedule": "/api/v1/anime/schedule",
                    "home": "/api/v1/anime/home",
                    "search": "/api/v1/anime/search",
                    "genres": "/api/v1/anime/genres/{slug}",
                    "detail": "/api/v1/anime/detail/{slug}",
                    "watch": "/api/v1/anime/watch/{slug}",
                    "filters": "/api/v1/anime/filters",
                    "random": "/api/v1/anime/random"
                },
                "donghua": {
                    "sidebar": "/api/v1/donghua/sidebar",
                    "schedule": "/api/v1/donghua/schedule",
                    "home": "/api/v1/donghua/home",
                    "search": "/api/v1/donghua/search",
                    "ongoing": "/api/v1/donghua/ongoing",
                    "completed": "/api/v1/donghua/completed",
                    "az_list": "/api/v1/donghua/az_list",
                    "genres": "/api/v1/donghua/genres/{slug}",
                    "seasons": "/api/v1/donghua/seasons/{slug}",
                    "detail": "/api/v1/donghua/detail/{slug}",
                    "watch": "/api/v1/donghua/watch/{slug}",
                    "filters": "/api/v1/donghua/filters",
                    "random": "/api/v1/donghua/random"
                },
                "dracin": {
                    "sidecontent": "/api/v1/dracin/{region}/sidecontent",
                    "home": "/api/v1/dracin/{region}/home",
                    "channel": "/api/v1/dracin/{region}/channel/{slug}",
                    "genres": "/api/v1/dracin/{region}/genres",
                    "genres_id": "/api/v1/dracin/{region}/genres/{id}",
                    "search": "/api/v1/dracin/{region}/search",
                    "detail": "/api/v1/dracin/{region}/detail/{slug}",
                    "watch": "/api/v1/dracin/{region}/watch/{slug}",
                    "resources": "/api/v1/dracin/en/resources"
                }
            },
            "authentication": "Requires Authorization: Bearer {apikey} header",
            "rate_limits": "See documentation for rate limits by role"
        },
        "message": None
    }