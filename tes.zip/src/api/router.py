from fastapi import APIRouter

from src.api.endpoints import v1 as v1_endpoints
from src.api.endpoints import admin as admin_endpoints
from src.api.endpoints import main as main_endpoints

api_router = APIRouter()

api_router.include_router(main_endpoints.router, prefix="/api", tags=["Main"])
api_router.include_router(v1_endpoints.router, prefix="/api/v1", tags=["v1"])
api_router.include_router(admin_endpoints.router, prefix="/api/admin", tags=["Admin"])