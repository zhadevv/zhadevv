from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from typing import Dict, Any
import time
from datetime import datetime, timedelta
from lib.system.validator import response_validator
from src.api.models.response_model import (
    BaseResponse,
    HealthResponse,
    StatsResponse,
    IPInfoResponse,
    CheckKeyResponse
)
from src.api.models.exception import APIException
from lib.system.config import config
from lib.global import db
from middlewares import GuestRateLimiter
import psutil
import socket


router = APIRouter(tags=["Health"])


start_time = time.time()


@router.get(
    "/health",
    response_model=BaseResponse[HealthResponse],
    summary="Health Check",
    description="Check API health and server status",
    dependencies=[Depends(GuestRateLimiter())]
)
async def health_check(request: Request):
    try:
        current_time = time.time()
        uptime = current_time - start_time
        
        db_status = "healthy"
        try:
            with db.get_cursor() as cursor:
                cursor.execute("SELECT 1")
        except:
            db_status = "unhealthy"
        
        cache_status = "healthy"
        
        total_requests = db.get_total_stats()["total_requests"]
        
        today = datetime.utcnow().strftime("%Y-%m-%d")
        today_stats = next(
            (stat for stat in db.get_stats(1) if stat["date"] == today),
            {"total_requests": 0}
        )
        
        requests_today = today_stats.get("total_requests", 0)
        
        active_apikeys = db.get_total_stats()["total_apikeys"]
        
        health_data = {
            "status": "healthy",
            "version": "1.0.0",
            "timestamp": datetime.utcnow(),
            "uptime": uptime,
            "database": db_status,
            "cache": cache_status,
            "requests_total": total_requests,
            "requests_today": requests_today,
            "active_apikeys": active_apikeys
        }
        
        return response_validator.create_response(
            success=True,
            data=health_data,
            status_code=200
        )
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Health check failed: {str(e)}",
            status_code=500
        )


@router.get(
    "/stats",
    response_model=BaseResponse[StatsResponse],
    summary="Server Statistics",
    description="Get server statistics and usage data",
    dependencies=[Depends(GuestRateLimiter())]
)
async def get_stats(request: Request):
    try:
        total_stats = db.get_total_stats()
        
        daily_stats = db.get_stats(30)
        
        for stat in daily_stats:
            stat["date"] = stat["date"]
            stat["success_rate"] = (
                (stat["successful_requests"] / stat["total_requests"] * 100)
                if stat["total_requests"] > 0 else 0
            )
        
        stats_data = {
            "total_requests": total_stats["total_requests"],
            "total_unique_ips": total_stats["total_unique_ips"],
            "total_apikeys": total_stats["total_apikeys"],
            "avg_response_time": total_stats["avg_response_time"],
            "banned_ips": total_stats["banned_ips"],
            "daily_stats": daily_stats
        }
        
        return response_validator.create_response(
            success=True,
            data=stats_data,
            status_code=200
        )
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get statistics: {str(e)}",
            status_code=500
        )


@router.get(
    "/check",
    response_model=BaseResponse[CheckKeyResponse],
    summary="Check API Key",
    description="Check API key validity and usage statistics",
    dependencies=[Depends(GuestRateLimiter())]
)
async def check_apikey(request: Request, apikey: str):
    try:
        from lib.system.validator import validator
        
        valid, role = validator.validate_apikey(apikey)
        
        if not valid:
            return response_validator.create_response(
                success=False,
                message="Invalid API key",
                status_code=400
            )
        
        apikey_data = db.get_apikey(apikey)
        
        if not apikey_data:
            return response_validator.create_response(
                success=False,
                message="API key not found",
                status_code=404
            )
        
        monthly_limit = config.get_rate_limit(role).monthly_limit
        monthly_used = apikey_data.get("requests_month", 0)
        remaining_monthly = max(0, monthly_limit - monthly_used)
        
        active_versions = apikey_data.get("active_versions", ["v1"])
        if isinstance(active_versions, str):
            import json
            try:
                active_versions = json.loads(active_versions)
            except:
                active_versions = ["v1"]
        
        check_data = {
            "valid": True,
            "role": role,
            "username": apikey_data.get("username", ""),
            "active": bool(apikey_data.get("active", True)),
            "suspended": bool(apikey_data.get("suspended", False)),
            "requests_count": apikey_data.get("requests_count", 0),
            "requests_month": monthly_used,
            "monthly_limit": monthly_limit,
            "remaining_monthly": remaining_monthly,
            "created_at": datetime.fromisoformat(apikey_data.get("created_at", datetime.utcnow().isoformat())),
            "expires_at": (
                datetime.fromisoformat(apikey_data["expires_at"])
                if apikey_data.get("expires_at") else None
            ),
            "active_versions": active_versions
        }
        
        return response_validator.create_response(
            success=True,
            data=check_data,
            status_code=200
        )
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to check API key: {str(e)}",
            status_code=500
        )


@router.get(
    "/@me",
    response_model=BaseResponse[IPInfoResponse],
    summary="Get IP Information",
    description="Get information about your IP address",
    dependencies=[Depends(GuestRateLimiter())]
)
async def get_ip_info(request: Request):
    try:
        client_ip = request.client.host
        
        ip_info = {
            "ip": client_ip,
            "country": None,
            "region": None,
            "city": None,
            "isp": None,
            "latitude": None,
            "longitude": None,
            "timezone": None,
            "asn": None,
            "is_hosting": False,
            "is_proxy": False,
            "is_tor": False,
            "threat_level": "low"
        }
        
        try:
            import socket
            hostname = socket.gethostbyaddr(client_ip)[0] if client_ip != "127.0.0.1" else "localhost"
            ip_info["hostname"] = hostname
        except:
            ip_info["hostname"] = None
        
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            ip_info["forwarded_for"] = forwarded_for
        
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            ip_info["real_ip"] = real_ip
        
        user_agent = request.headers.get("user-agent", "")
        ip_info["user_agent"] = user_agent[:200] if user_agent else None
        
        return response_validator.create_response(
            success=True,
            data=ip_info,
            status_code=200
        )
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get IP info: {str(e)}",
            status_code=500
        )


@router.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return JSONResponse(content=None, status_code=204)


@router.get("/robots.txt", include_in_schema=False)
async def robots():
    robots_txt = """User-agent: *
Disallow: /api/admin/
Disallow: /api/private/
Allow: /api/v1/
Allow: /api/health
Allow: /api/stats
Allow: /api/check
Allow: /api/@me

Sitemap: https://api.zhadev.my.id/sitemap.xml
"""
    return Response(content=robots_txt, media_type="text/plain")