from fastapi import APIRouter, Request, Query
from typing import Optional
import time
import json

from src.api.models.response_model import BaseResponse
from lib.database import Database
from lib.cloudflare import CloudflareManager

router = APIRouter()
db = Database()
cf = CloudflareManager()

@router.get(
    "/health",
    response_model=BaseResponse,
    summary="API Health Check",
    description="Check API health status"
)
async def health():
    return BaseResponse(
        status=200,
        success=True,
        author="zhadevv",
        data={
            "status": "healthy",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "database": "connected",
            "cache": "enabled"
        },
        message=None
    )


@router.get(
    "/stats",
    response_model=BaseResponse,
    summary="API Statistics",
    description="Get API usage statistics"
)
async def stats():
    stats_data = db.get_api_stats()
    
    total_keys = len(db.get_all_api_keys())
    banned_ips = len(db.get_banned_ips())
    
    stats_data["key_stats"] = {
        "total_keys": total_keys,
        "banned_ips": banned_ips,
        "cache_size": 0
    }
    
    return BaseResponse(
        status=200,
        success=True,
        author="zhadevv",
        data=stats_data,
        message=None
    )


@router.get(
    "/check",
    response_model=BaseResponse,
    summary="Check API Key",
    description="Check your API key information"
)
async def check_key(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    if not apikey:
        return BaseResponse(
            status=400,
            success=False,
            author="zhadevv",
            data=None,
            message="API key is required"
        )
    
    from lib.system.validator import Validator
    from lib.system.config import settings
    
    if not Validator.validate_api_key_format(apikey):
        return BaseResponse(
            status=400,
            success=False,
            author="zhadevv",
            data=None,
            message="Invalid API key format"
        )
    
    if apikey in [settings.security.owner_apikey, 
                  settings.security.dev_apikey,
                  settings.security.admin_apikey]:
        role = "owner" if apikey == settings.security.owner_apikey else \
               "developer" if apikey == settings.security.dev_apikey else "admin"
        
        key_info = {
            "role": role,
            "active": True,
            "suspended": False,
            "custom_key": True,
            "rpm_limit": 10000 if role == "owner" else 5000 if role == "developer" else 1000,
            "monthly_limit": 100000000 if role == "owner" else 10000000 if role == "developer" else 5000000,
            "allowed_versions": ["v1", "v2", "admin"]
        }
    else:
        key_info = db.get_api_key_info(apikey)
        if not key_info:
            return BaseResponse(
                status=404,
                success=False,
                author="zhadevv",
                data=None,
                message="API key not found"
            )
    
    return BaseResponse(
        status=200,
        success=True,
        author="zhadevv",
        data=key_info,
        message=None
    )


@router.get(
    "/@me",
    response_model=BaseResponse,
    summary="My Information",
    description="Get information about your current request"
)
async def my_info(request: Request):
    client_ip = request.state.get("client_ip", "0.0.0.0")
    api_key = request.state.get("api_key")
    request_id = getattr(request.state, "request_id", None)
    role = request.state.get("role", "guest")
    
    geo_info = db.get_ip_geolocation(client_ip)
    
    info = {
        "ip": client_ip,
        "role": role,
        "request_id": request_id,
        "user_agent": request.headers.get("user-agent"),
        "method": request.method,
        "path": request.url.path,
        "geolocation": geo_info or {},
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    }
    
    if api_key:
        info["api_key"] = f"{api_key[:8]}...{api_key[-4:]}"
    
    return BaseResponse(
        status=200,
        success=True,
        author="zhadevv",
        data=info,
        message=None
    )