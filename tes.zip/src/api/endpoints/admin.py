from fastapi import APIRouter, Request, Query, Depends, HTTPException
from typing import Optional, List
from datetime import datetime, timedelta
from pydantic import BaseModel
import json

from src.api.models.response_model import BaseResponse
from lib.database import Database
from lib.system.validator import Validator
from lib.system.config import settings

router = APIRouter()
db = Database()


def verify_admin_key(apikey: str = Query(..., description="Admin API key")):
    if apikey not in [settings.security.admin_apikey, 
                      settings.security.dev_apikey,
                      settings.security.owner_apikey]:
        if not apikey.startswith("SK_zhadev-admin_"):
            raise HTTPException(status_code=403, detail="Admin access required")
        
        key_info = db.get_api_key_info(apikey)
        if not key_info or key_info.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Admin access required")
    
    return apikey


class GenerateKeyResponse(BaseModel):
    api_key: str
    username: str
    role: str
    rpm_limit: int
    monthly_limit: int
    expires_at: Optional[str]
    message: str


@router.post(
    "/generate_key",
    response_model=BaseResponse[GenerateKeyResponse],
    summary="Generate API Key",
    description="Generate a new API key (Admin/Dev/Owner only)",
    include_in_schema=False
)
async def generate_key(
    request: Request,
    admin_key: str = Depends(verify_admin_key),
    username: Optional[str] = Query(None, description="Username for the key"),
    role: str = Query(..., description="Role (free, starter, medium, highest, enterprise, admin, dev)"),
    custom_key: Optional[str] = Query(None, description="Custom API key (optional)"),
    rpm: Optional[int] = Query(None, description="Custom RPM limit"),
    monthly_limit: Optional[int] = Query(None, description="Custom monthly limit"),
    expires_days: Optional[int] = Query(None, description="Expiration in days"),
    active: Optional[str] = Query("all", description="Active for versions (all, v1, v2, etc)")
):
    if not Validator.validate_role(role):
        raise HTTPException(status_code=400, detail="Invalid role")
    
    if not username:
        username = Validator.generate_username()
    
    if custom_key:
        api_key = custom_key
        if not Validator.validate_api_key_format(api_key):
            raise HTTPException(status_code=400, detail="Invalid custom key format")
    else:
        api_key = Validator.generate_api_key(role)
    
    role_limits = {
        "free": (settings.rate_limit.free_rpm, settings.rate_limit.free_monthly),
        "starter": (settings.rate_limit.starter_rpm, settings.rate_limit.starter_monthly),
        "medium": (settings.rate_limit.medium_rpm, settings.rate_limit.medium_monthly),
        "highest": (settings.rate_limit.highest_rpm, settings.rate_limit.highest_monthly),
        "enterprise": (settings.rate_limit.enterprise_rpm, settings.rate_limit.enterprise_monthly),
        "admin": (settings.rate_limit.admin_rpm, settings.rate_limit.admin_monthly),
        "dev": (settings.rate_limit.developer_rpm, settings.rate_limit.developer_monthly)
    }
    
    default_rpm, default_monthly = role_limits.get(role, (25, 1000))
    
    rpm_limit = rpm if rpm is not None else default_rpm
    monthly_limit_val = monthly_limit if monthly_limit is not None else default_monthly
    
    if not Validator.validate_rpm_limit(rpm_limit, role):
        raise HTTPException(status_code=400, detail=f"Invalid RPM limit for role {role}")
    
    if not Validator.validate_monthly_limit(monthly_limit_val, role):
        raise HTTPException(status_code=400, detail=f"Invalid monthly limit for role {role}")
    
    expires_at = None
    if expires_days:
        expires_at = datetime.utcnow() + timedelta(days=expires_days)
    
    allowed_versions = ["v1"]
    if active != "all":
        allowed_versions = [v.strip() for v in active.split(",") if v.strip()]
    
    success = db.add_api_key(
        api_key=api_key,
        username=username,
        role=role,
        rpm_limit=rpm_limit,
        monthly_limit=monthly_limit_val,
        custom_key=bool(custom_key),
        allowed_versions=allowed_versions,
        expires_at=expires_at
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Failed to generate API key (possibly duplicate)")
    
    return BaseResponse[GenerateKeyResponse](
        status=200,
        success=True,
        author="zhadevv",
        data=GenerateKeyResponse(
            api_key=api_key,
            username=username,
            role=role,
            rpm_limit=rpm_limit,
            monthly_limit=monthly_limit_val,
            expires_at=expires_at.isoformat() if expires_at else None,
            message="API key generated successfully"
        ),
        message=None
    )


@router.post(
    "/suspended_key",
    response_model=BaseResponse[dict],
    summary="Suspend API Key",
    description="Suspend an API key (Admin only)",
    include_in_schema=False
)
async def suspend_key(
    request: Request,
    admin_key: str = Depends(verify_admin_key),
    keys: str = Query(..., description="API key to suspend")
):
    success = db.suspend_api_key(keys)
    
    if not success:
        raise HTTPException(status_code=404, detail="API key not found")
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data={"message": "API key suspended successfully"},
        message=None
    )


@router.put(
    "/unsuspense_keys",
    response_model=BaseResponse[dict],
    summary="Unsuspend API Key",
    description="Unsuspend an API key (Admin only)",
    include_in_schema=False
)
async def unsuspend_key(
    request: Request,
    admin_key: str = Depends(verify_admin_key),
    keys: str = Query(..., description="API key to unsuspend")
):
    success = db.unsuspend_api_key(keys)
    
    if not success:
        raise HTTPException(status_code=404, detail="API key not found")
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data={"message": "API key unsuspended successfully"},
        message=None
    )


@router.delete(
    "/remove_key",
    response_model=BaseResponse[dict],
    summary="Remove API Key",
    description="Remove an API key (Owner only)",
    include_in_schema=False
)
async def remove_key(
    request: Request,
    keys: str = Query(..., description="API key to remove"),
    apikey: str = Query(..., description="Owner API key")
):
    if apikey != settings.security.owner_apikey:
        raise HTTPException(status_code=403, detail="Owner access required")
    
    success = db.delete_api_key(keys)
    
    if not success:
        raise HTTPException(status_code=404, detail="API key not found")
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data={"message": "API key removed successfully"},
        message=None
    )


@router.get(
    "/stats",
    response_model=BaseResponse[dict],
    summary="Admin Statistics",
    description="Get detailed API statistics (Admin only)",
    include_in_schema=False
)
async def admin_stats(
    request: Request,
    admin_key: str = Depends(verify_admin_key)
):
    stats = db.get_api_stats()
    
    all_keys = db.get_all_api_keys()
    banned_ips = db.get_banned_ips()
    
    total_requests = sum(key.get("used_count", 0) for key in all_keys)
    active_keys = sum(1 for key in all_keys if key.get("active", True) and not key.get("suspended", False))
    suspended_keys = sum(1 for key in all_keys if key.get("suspended", False))
    
    detailed_stats = {
        **stats,
        "key_stats": {
            "total_keys": len(all_keys),
            "active_keys": active_keys,
            "suspended_keys": suspended_keys,
            "total_requests": total_requests,
            "keys_by_role": {},
            "banned_ips": len(banned_ips)
        },
        "recent_activity": {}
    }
    
    for key in all_keys:
        role = key.get("role", "unknown")
        if role not in detailed_stats["key_stats"]["keys_by_role"]:
            detailed_stats["key_stats"]["keys_by_role"][role] = 0
        detailed_stats["key_stats"]["keys_by_role"][role] += 1
    
    logs, total = db.get_request_logs(limit=10)
    detailed_stats["recent_activity"]["latest_requests"] = logs
    detailed_stats["recent_activity"]["total_logs"] = total
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data=detailed_stats,
        message=None
    )


@router.get(
    "/ip_logs",
    response_model=BaseResponse[dict],
    summary="IP Logs",
    description="Get request logs by IP (Admin only)",
    include_in_schema=False
)
async def ip_logs(
    request: Request,
    admin_key: str = Depends(verify_admin_key),
    ip: Optional[str] = Query(None, description="Filter by IP address"),
    limit: int = Query(100, ge=1, le=1000, description="Number of logs"),
    offset: int = Query(0, ge=0, description="Offset for pagination")
):
    logs, total = db.get_request_logs(limit=limit, offset=offset, ip_address=ip)
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data={
            "logs": logs,
            "total": total,
            "page": offset // limit + 1,
            "pages": (total + limit - 1) // limit if limit > 0 else 1
        },
        message=None
    )


@router.post(
    "/moderate",
    response_model=BaseResponse[dict],
    summary="Moderate IP",
    description="Ban or unban an IP address (Admin only)",
    include_in_schema=False
)
async def moderate_ip(
    request: Request,
    admin_key: str = Depends(verify_admin_key),
    ban: Optional[str] = Query(None, description="IP to ban"),
    unban: Optional[str] = Query(None, description="IP to unban"),
    reason: Optional[str] = Query("", description="Reason for ban")
):
    if ban and unban:
        raise HTTPException(status_code=400, detail="Cannot both ban and unban")
    
    if ban:
        if not Validator.validate_ip_address(ban):
            raise HTTPException(status_code=400, detail="Invalid IP address")
        
        success = db.ban_ip(ban, reason, "admin")
        if not success:
            raise HTTPException(status_code=500, detail="Failed to ban IP")
        
        message = f"IP {ban} banned successfully"
    
    elif unban:
        if not Validator.validate_ip_address(unban):
            raise HTTPException(status_code=400, detail="Invalid IP address")
        
        success = db.unban_ip(unban)
        if not success:
            raise HTTPException(status_code=404, detail="IP not found in ban list")
        
        message = f"IP {unban} unbanned successfully"
    
    else:
        raise HTTPException(status_code=400, detail="Either ban or unban parameter is required")
    
    return BaseResponse[dict](
        status=200,
        success=True,
        author="zhadevv",
        data={"message": message},
        message=None
    )


@router.get(
    "/moderate/{path}",
    response_model=BaseResponse[dict],
    summary="Moderation Data",
    description="Get moderation data (Admin only)",
    include_in_schema=False
)
async def moderation_data(
    request: Request,
    path: str,
    admin_key: str = Depends(verify_admin_key)
):
    if path == "banned-ips":
        banned_ips = db.get_banned_ips()
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data={"banned_ips": banned_ips},
            message=None
        )
    
    elif path == "total_keys":
        all_keys = db.get_all_api_keys()
        
        stats = {
            "total": len(all_keys),
            "by_role": {},
            "active": sum(1 for k in all_keys if k.get("active", True)),
            "suspended": sum(1 for k in all_keys if k.get("suspended", False)),
            "total_requests": sum(k.get("used_count", 0) for k in all_keys)
        }
        
        for key in all_keys:
            role = key.get("role", "unknown")
            if role not in stats["by_role"]:
                stats["by_role"][role] = 0
            stats["by_role"][role] += 1
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=stats,
            message=None
        )
    
    else:
        raise HTTPException(status_code=404, detail="Path not found")