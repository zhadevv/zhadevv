from fastapi import APIRouter

from src.api.endpoints.v1 import anime, donghua, dracin

router = APIRouter()

router.include_router(anime.router, prefix="/anime", tags=["Anime"])
router.include_router(donghua.router, prefix="/donghua", tags=["Donghua"])
router.include_router(dracin.router, prefix="/dracin", tags=["Dracin"])