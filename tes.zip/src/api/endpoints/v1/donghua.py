from fastapi import APIRouter, Depends, Request, Query, Path
from typing import Optional, Dict, Any, List
from lib.scraper.donghua import DonghuaParser
from src.api.models.response_model import (
    BaseResponse,
    AnimeSearchResponse,
    AnimeDetailResponse,
    WatchResponse,
    ScheduleResponse,
    SidebarResponse,
    HomeResponse,
    FiltersResponse,
    DonghuaAZResponse
)
from lib.system.validator import response_validator
from middlewares import FreeRateLimiter
from src.api.models.exception import ScraperException
import asyncio


router = APIRouter(
    prefix="/v1/donghua",
    tags=["Donghua"],
    dependencies=[Depends(FreeRateLimiter())]
)


@router.get(
    "/sidebar",
    response_model=BaseResponse[SidebarResponse],
    summary="Get Donghua Sidebar",
    description="Get sidebar content including filters, ongoing series, etc."
)
async def get_donghua_sidebar(request: Request):
    try:
        async with DonghuaParser() as parser:
            result = await parser.sidebar()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get sidebar: {str(e)}",
            status_code=500
        )


@router.get(
    "/schedule",
    response_model=BaseResponse[ScheduleResponse],
    summary="Get Donghua Schedule",
    description="Get donghua release schedule by day"
)
async def get_donghua_schedule(request: Request):
    try:
        async with DonghuaParser() as parser:
            result = await parser.schedule()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get schedule: {str(e)}",
            status_code=500
        )


@router.get(
    "/home",
    response_model=BaseResponse[HomeResponse],
    summary="Get Donghua Home",
    description="Get home page content with slider, popular, latest, etc."
)
async def get_donghua_home(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.home(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get home page: {str(e)}",
            status_code=500
        )


@router.get(
    "/search",
    response_model=BaseResponse[AnimeSearchResponse],
    summary="Search Donghua",
    description="Search donghua by query"
)
async def search_donghua(
    request: Request,
    q: str = Query(..., min_length=1, max_length=200, description="Search query"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.search(query=q, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to search donghua: {str(e)}",
            status_code=500
        )


@router.get(
    "/ongoing",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Ongoing Donghua",
    description="Get ongoing donghua series"
)
async def get_ongoing_donghua(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.ongoing(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get ongoing donghua: {str(e)}",
            status_code=500
        )


@router.get(
    "/completed",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Completed Donghua",
    description="Get completed donghua series"
)
async def get_completed_donghua(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.completed(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get completed donghua: {str(e)}",
            status_code=500
        )


@router.get(
    "/az_list",
    response_model=BaseResponse[DonghuaAZResponse],
    summary="Get Donghua A-Z List",
    description="Get donghua list alphabetically"
)
async def get_donghua_az_list(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number"),
    show: Optional[str] = Query(None, description="Show specific letter")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.az_list(page=page, letter=show)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get A-Z list: {str(e)}",
            status_code=500
        )


@router.get(
    "/genres/{slug}",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Donghua by Genre",
    description="Get donghua list by genre slug"
)
async def get_donghua_by_genre(
    request: Request,
    slug: str = Path(..., description="Genre slug"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.genres(slug=slug, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get donghua by genre: {str(e)}",
            status_code=500
        )


@router.get(
    "/seasons/{slug}",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Donghua by Season",
    description="Get donghua list by season slug"
)
async def get_donghua_by_season(
    request: Request,
    slug: str = Path(..., description="Season slug")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seasons(slug=slug)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get donghua by season: {str(e)}",
            status_code=500
        )


@router.get(
    "/detail/{slug}",
    response_model=BaseResponse[AnimeDetailResponse],
    summary="Get Donghua Detail",
    description="Get detailed information about a donghua"
)
async def get_donghua_detail(
    request: Request,
    slug: str = Path(..., description="Donghua slug")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seri_detail(slug=slug)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get donghua detail: {str(e)}",
            status_code=500
        )


@router.get(
    "/watch/{slug}",
    response_model=BaseResponse[WatchResponse],
    summary="Watch Donghua Episode",
    description="Get donghua episode streaming information"
)
async def watch_donghua(
    request: Request,
    slug: str = Path(..., description="Donghua slug"),
    episode: int = Query(..., ge=1, le=10000, description="Episode number")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.watch(slug=slug, ep_num=episode)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get episode: {str(e)}",
            status_code=500
        )


@router.get(
    "/filters/list-mode",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Donghua List Mode",
    description="Get donghua list in text mode with alphabet navigation"
)
async def get_donghua_list_mode(request: Request):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seri_advanced_search(mode="text")
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get list mode: {str(e)}",
            status_code=500
        )


@router.get(
    "/filters",
    response_model=BaseResponse[FiltersResponse],
    summary="Filter Donghua",
    description="Advanced donghua filtering with multiple parameters"
)
async def filter_donghua(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number"),
    status: Optional[str] = Query(None, description="Donghua status"),
    type: Optional[str] = Query(None, description="Donghua type"),
    order: Optional[str] = Query(None, description="Sort order"),
    sub: Optional[str] = Query(None, description="Subtitle language"),
    genres: Optional[str] = Query(None, description="Genres (comma separated)"),
    studios: Optional[str] = Query(None, description="Studios (comma separated)"),
    seasons: Optional[str] = Query(None, description="Seasons (comma separated)")
):
    try:
        filters = {}
        
        if status:
            filters["status"] = status
        if type:
            filters["type"] = type
        if order:
            filters["order"] = order
        if sub:
            filters["sub"] = sub
        if genres:
            filters["genre"] = genres.split(',')
        if studios:
            filters["studio"] = studios.split(',')
        if seasons:
            filters["season"] = seasons.split(',')
        
        async with DonghuaParser() as parser:
            if filters:
                result = await parser.seri_advanced_search(page=page, filters=filters)
            else:
                result = await parser.seri_advanced_search(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to filter donghua: {str(e)}",
            status_code=500
        )


@router.get(
    "/random",
    response_model=BaseResponse[AnimeDetailResponse],
    summary="Get Random Donghua",
    description="Get random donghua detail"
)
async def get_random_donghua(request: Request):
    try:
        import random
        
        async with DonghuaParser() as parser:
            list_mode = await parser.seri_advanced_search(mode="text")
            
            if not list_mode["success"]:
                raise ScraperException(list_mode["message"])
            
            all_donghua = []
            for letter_data in list_mode["data"]["filters"]["text_mode"].values():
                all_donghua.extend(letter_data)
            
            if not all_donghua:
                return response_validator.create_response(
                    success=False,
                    message="No donghua found",
                    status_code=404
                )
            
            random_donghua = random.choice(all_donghua)
            slug = random_donghua["slug"]
            
            detail = await parser.seri_detail(slug=slug)
            
            if not detail["success"]:
                raise ScraperException(detail["message"])
            
            return detail
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get random donghua: {str(e)}",
            status_code=500
        )