from fastapi import APIRouter, Request, Query, HTTPException
from typing import Optional, List
import asyncio

from src.api.models.response_model import BaseResponse
from scraper import DonghuaParser

router = APIRouter()


@router.get(
    "/sidebar",
    response_model=BaseResponse[dict],
    summary="Donghua Sidebar",
    description="Get donghua sidebar content"
)
async def donghua_sidebar(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.sidebar()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch sidebar"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch sidebar: {str(e)}")


@router.get(
    "/schedule",
    response_model=BaseResponse[dict],
    summary="Donghua Schedule",
    description="Get donghua release schedule"
)
async def donghua_schedule(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.schedule()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch schedule"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch schedule: {str(e)}")


@router.get(
    "/home",
    response_model=BaseResponse[dict],
    summary="Donghua Home",
    description="Get donghua home page content"
)
async def donghua_home(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.home(page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch home"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch home: {str(e)}")


@router.get(
    "/search",
    response_model=BaseResponse[dict],
    summary="Search Donghua",
    description="Search for donghua"
)
async def search_donghua(
    request: Request,
    q: str = Query(..., description="Search query"),
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.search(query=q, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Search failed"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@router.get(
    "/ongoing",
    response_model=BaseResponse[dict],
    summary="Ongoing Donghua",
    description="Get ongoing donghua"
)
async def ongoing_donghua(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.ongoing(page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch ongoing"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch ongoing: {str(e)}")


@router.get(
    "/completed",
    response_model=BaseResponse[dict],
    summary="Completed Donghua",
    description="Get completed donghua"
)
async def completed_donghua(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.completed(page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch completed"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch completed: {str(e)}")


@router.get(
    "/az_list",
    response_model=BaseResponse[dict],
    summary="Donghua A-Z List",
    description="Get donghua A-Z list"
)
async def donghua_az_list(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    show: Optional[str] = Query(None, description="Show specific letter"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.az_list(page=page, letter=show)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch A-Z list"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch A-Z list: {str(e)}")


@router.get(
    "/genres/{slug}",
    response_model=BaseResponse[dict],
    summary="Donghua by Genre",
    description="Get donghua by genre"
)
async def donghua_by_genre(
    request: Request,
    slug: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.genres(slug=slug, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Genre not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch genre: {str(e)}")


@router.get(
    "/seasons/{slug}",
    response_model=BaseResponse[dict],
    summary="Donghua by Season",
    description="Get donghua by season"
)
async def donghua_by_season(
    request: Request,
    slug: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seasons(slug=slug)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Season not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch season: {str(e)}")


@router.get(
    "/detail/{slug}",
    response_model=BaseResponse[dict],
    summary="Donghua Detail",
    description="Get donghua details"
)
async def donghua_detail(
    request: Request,
    slug: str,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seri_detail(slug=slug)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Donghua not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch donghua detail: {str(e)}")


@router.get(
    "/watch/{slug}",
    response_model=BaseResponse[dict],
    summary="Watch Donghua",
    description="Watch donghua episode"
)
async def watch_donghua(
    request: Request,
    slug: str,
    episode: int = Query(..., ge=1, description="Episode number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.watch(slug=slug, ep_num=episode)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Episode not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch episode: {str(e)}")


@router.get(
    "/filters/list-mode",
    response_model=BaseResponse[dict],
    summary="Donghua List Mode",
    description="Get donghua in list mode for filters"
)
async def donghua_list_mode(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            result = await parser.seri_advanced_search(mode="text")
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch list"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch list: {str(e)}")


@router.get(
    "/filters",
    response_model=BaseResponse[dict],
    summary="Donghua Filters",
    description="Filter donghua with advanced options"
)
async def donghua_filters(
    request: Request,
    status: Optional[str] = Query(None, description="Filter by status"),
    type: Optional[str] = Query(None, description="Filter by type"),
    order: Optional[str] = Query(None, description="Sort order"),
    sub: Optional[str] = Query(None, description="Filter by subtitle"),
    genres: Optional[List[str]] = Query(None, description="Filter by genres"),
    studios: Optional[List[str]] = Query(None, description="Filter by studios"),
    seasons: Optional[List[str]] = Query(None, description="Filter by seasons"),
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        filters = {}
        if status:
            filters["status"] = status
        if type:
            filters["type"] = type
        if order:
            filters["order"] = order
        if sub:
            filters["sub"] = sub
        if genres:
            filters["genres"] = genres
        if studios:
            filters["studios"] = studios
        if seasons:
            filters["seasons"] = seasons
        
        async with DonghuaParser() as parser:
            if not filters and page == 1:
                result = await parser.seri_advanced_search(page=page)
            else:
                result = await parser.seri_advanced_search(page=page, filters=filters)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to apply filters"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to apply filters: {str(e)}")


@router.get(
    "/random",
    response_model=BaseResponse[dict],
    summary="Random Donghua",
    description="Get random donghua"
)
async def random_donghua(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DonghuaParser() as parser:
            list_result = await parser.seri_advanced_search(mode="text")
        
        if not list_result.get("success"):
            raise HTTPException(status_code=500, detail="Failed to fetch donghua list")
        
        all_donghua = []
        data = list_result.get("data", {}).get("filters", {}).get("text_mode", {})
        
        for letter, items in data.items():
            all_donghua.extend(items)
        
        if not all_donghua:
            raise HTTPException(status_code=404, detail="No donghua found")
        
        import random
        random_donghua = random.choice(all_donghua)
        slug = random_donghua.get("slug")
        
        if not slug:
            raise HTTPException(status_code=404, detail="Failed to get random donghua")
        
        async with DonghuaParser() as parser:
            detail_result = await parser.seri_detail(slug=slug)
        
        if not detail_result.get("success"):
            raise HTTPException(status_code=500, detail="Failed to fetch random donghua detail")
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data={
                "random": detail_result.get("data", {}),
                "list_info": random_donghua
            },
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get random donghua: {str(e)}")