from fastapi import APIRouter, Request, Query, HTTPException
from typing import Optional
import asyncio

from src.api.models.response_model import BaseResponse
from scraper import DramaboxParser

router = APIRouter()


@router.get(
    "/{region}/sidecontent",
    response_model=BaseResponse[dict],
    summary="Dracin Side Content",
    description="Get dracin side content by region"
)
async def dracin_sidecontent(
    request: Request,
    region: str,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.home()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch side content"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch side content: {str(e)}")


@router.get(
    "/{region}/home",
    response_model=BaseResponse[dict],
    summary="Dracin Home",
    description="Get dracin home page by region"
)
async def dracin_home(
    request: Request,
    region: str,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.home()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch home"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch home: {str(e)}")


@router.get(
    "/{region}/channel/{slug}",
    response_model=BaseResponse[dict],
    summary="Dracin Channel",
    description="Get dracin channel content"
)
async def dracin_channel(
    request: Request,
    region: str,
    slug: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.channel(slug=slug, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Channel not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch channel: {str(e)}")


@router.get(
    "/{region}/genres",
    response_model=BaseResponse[dict],
    summary="Dracin Genres",
    description="Get dracin genres list"
)
async def dracin_genres(
    request: Request,
    region: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.browse(category_id="0", page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch genres"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch genres: {str(e)}")


@router.get(
    "/{region}/genres/{id}",
    response_model=BaseResponse[dict],
    summary="Dracin by Genre",
    description="Get dracin by genre ID"
)
async def dracin_by_genre(
    request: Request,
    region: str,
    id: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.browse(category_id=id, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Genre not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch genre: {str(e)}")


@router.get(
    "/{region}/search",
    response_model=BaseResponse[dict],
    summary="Search Dracin",
    description="Search for dracin content"
)
async def search_dracin(
    request: Request,
    region: str,
    q: str = Query(..., description="Search query"),
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.search(query=q, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Search failed"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@router.get(
    "/{region}/detail/{slug}",
    response_model=BaseResponse[dict],
    summary="Dracin Detail",
    description="Get dracin details"
)
async def dracin_detail(
    request: Request,
    region: str,
    slug: str,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        drama_id, drama_slug = slug.split("_", 1) if "_" in slug else (slug, slug)
        
        async with DramaboxParser(region=region) as parser:
            result = await parser.drama_detail(drama_id=drama_id, slug=drama_slug)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Drama not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch drama detail: {str(e)}")


@router.get(
    "/{region}/watch/{slug}",
    response_model=BaseResponse[dict],
    summary="Watch Dracin",
    description="Watch dracin episode"
)
async def watch_dracin(
    request: Request,
    region: str,
    slug: str,
    episode: str = Query(..., description="Episode slug"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        drama_slug, episode_slug = slug, episode
        
        if "_" in slug:
            drama_parts = slug.split("_")
            if len(drama_parts) >= 2:
                drama_id = drama_parts[0]
                drama_slug = "_".join(drama_parts[1:])
        
        if "_" in episode:
            episode_parts = episode.split("_")
            if len(episode_parts) >= 2:
                episode_id = episode_parts[0]
                episode_slug = "_".join(episode_parts[1:])
        
        async with DramaboxParser(region=region) as parser:
            result = await parser.watch(
                drama_id=drama_id,
                drama_slug=drama_slug,
                episode_id=episode_id,
                episode_slug=episode_slug
            )
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Episode not found"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch episode: {str(e)}")


@router.get(
    "/en/resources",
    response_model=BaseResponse[dict],
    summary="Dracin Resources",
    description="Get dracin resources (English region only)"
)
async def dracin_resources(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        if request.url.path.split("/")[3] != "en":
            raise HTTPException(status_code=400, detail="Resources only available for English region")
        
        async with DramaboxParser(region="en") as parser:
            result = await parser.resources()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch resources"))
        
        return BaseResponse[dict](
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch resources: {str(e)}")