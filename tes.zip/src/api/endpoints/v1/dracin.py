from fastapi import APIRouter, Depends, Request, Query, Path
from typing import Optional, Dict, Any, List
from lib.scraper.dracin import DramaboxParser
from src.api.models.response_model import (
    BaseResponse,
    DracinHomeResponse,
    DracinChannelResponse,
    DracinBrowseResponse,
    DracinDramaResponse,
    DracinWatchResponse,
    ResourcesResponse,
    AnimeSearchResponse
)
from lib.system.validator import response_validator
from middlewares import GuestRateLimiter
from src.api.models.exception import ScraperException
import asyncio


router = APIRouter(
    prefix="/v1/dracin",
    tags=["Dracin"],
    dependencies=[Depends(GuestRateLimiter())]
)


@router.get(
    "/{region}/sidecontent",
    response_model=BaseResponse[DracinHomeResponse],
    summary="Get Dracin Side Content",
    description="Get side content for specific region"
)
async def get_dracin_sidecontent(
    request: Request,
    region: str = Path(..., description="Region code (id, en, zh, etc)")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.home()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get side content: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/home",
    response_model=BaseResponse[DracinHomeResponse],
    summary="Get Dracin Home",
    description="Get home page content for specific region"
)
async def get_dracin_home(
    request: Request,
    region: str = Path(..., description="Region code (id, en, zh, etc)")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.home()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get home page: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/channel/{slug}",
    response_model=BaseResponse[DracinChannelResponse],
    summary="Get Dracin Channel",
    description="Get channel content for specific region"
)
async def get_dracin_channel(
    request: Request,
    region: str = Path(..., description="Region code"),
    slug: str = Path(..., description="Channel slug"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.channel(slug=slug, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get channel: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/genres",
    response_model=BaseResponse[DracinBrowseResponse],
    summary="Browse Dracin by Category",
    description="Browse dramas by category for specific region"
)
async def browse_dracin_genres(
    request: Request,
    region: str = Path(..., description="Region code"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.browse(category_id="0", page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to browse genres: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/genres/{id}",
    response_model=BaseResponse[DracinBrowseResponse],
    summary="Get Dracin by Genre ID",
    description="Get dramas by specific genre ID for region"
)
async def get_dracin_by_genre(
    request: Request,
    region: str = Path(..., description="Region code"),
    id: str = Path(..., description="Genre ID"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.browse(category_id=id, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get dramas by genre: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/search",
    response_model=BaseResponse[AnimeSearchResponse],
    summary="Search Dracin",
    description="Search dramas in specific region"
)
async def search_dracin(
    request: Request,
    region: str = Path(..., description="Region code"),
    q: str = Query(..., min_length=1, max_length=200, description="Search query"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with DramaboxParser(region=region) as parser:
            result = await parser.search(query=q, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to search dramas: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/detail/{slug}",
    response_model=BaseResponse[DracinDramaResponse],
    summary="Get Dracin Drama Detail",
    description="Get detailed information about a drama"
)
async def get_dracin_detail(
    request: Request,
    region: str = Path(..., description="Region code"),
    slug: str = Path(..., description="Drama slug")
):
    try:
        parts = slug.split('_')
        if len(parts) >= 2:
            drama_id = parts[0]
            drama_slug = '_'.join(parts[1:])
        else:
            drama_id = slug
            drama_slug = slug
        
        async with DramaboxParser(region=region) as parser:
            result = await parser.drama_detail(drama_id=drama_id, slug=drama_slug)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get drama detail: {str(e)}",
            status_code=500
        )


@router.get(
    "/{region}/watch/{slug}",
    response_model=BaseResponse[DracinWatchResponse],
    summary="Watch Dracin Episode",
    description="Get drama episode streaming information"
)
async def watch_dracin(
    request: Request,
    region: str = Path(..., description="Region code"),
    slug: str = Path(..., description="Episode slug"),
    episode: Optional[str] = Query(None, description="Episode ID (optional)")
):
    try:
        slug_parts = slug.split('_')
        
        if len(slug_parts) >= 4:
            drama_id = slug_parts[0]
            drama_slug = slug_parts[1]
            episode_id = slug_parts[2]
            episode_slug = slug_parts[3]
        elif episode:
            drama_id = slug_parts[0] if len(slug_parts) > 0 else slug
            drama_slug = slug_parts[1] if len(slug_parts) > 1 else slug
            episode_id = episode
            episode_slug = episode
        else:
            return response_validator.create_response(
                success=False,
                message="Invalid episode slug format",
                status_code=400
            )
        
        async with DramaboxParser(region=region) as parser:
            result = await parser.watch(
                drama_id=drama_id,
                drama_slug=drama_slug,
                episode_id=episode_id,
                episode_slug=episode_slug
            )
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get episode: {str(e)}",
            status_code=500
        )


@router.get(
    "/en/resources",
    response_model=BaseResponse[ResourcesResponse],
    summary="Get English Resources",
    description="Get resources for English region (only available in en region)",
    dependencies=[Depends(FreeRateLimiter())]
)
async def get_english_resources(request: Request):
    try:
        async with DramaboxParser(region="en") as parser:
            result = await parser.resources()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get resources: {str(e)}",
            status_code=500
        )