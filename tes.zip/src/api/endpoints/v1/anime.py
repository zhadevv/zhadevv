from fastapi import APIRouter, Request, Query, HTTPException
from typing import Optional, List
import asyncio

from src.api.models.response_model import BaseResponse
from scraper import OploverzParser

router = APIRouter()


@router.get(
    "/sidebar",
    response_model=BaseResponse,
    summary="Anime Sidebar",
    description="Get anime sidebar content"
)
async def anime_sidebar(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.sidebar()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch sidebar"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch sidebar: {str(e)}")


@router.get(
    "/schedule",
    response_model=BaseResponse,
    summary="Anime Schedule",
    description="Get anime release schedule"
)
async def anime_schedule(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.schedule()
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch schedule"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch schedule: {str(e)}")


@router.get(
    "/home",
    response_model=BaseResponse,
    summary="Anime Home",
    description="Get anime home page content"
)
async def anime_home(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.home(page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch home"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch home: {str(e)}")


@router.get(
    "/search",
    response_model=BaseResponse,
    summary="Search Anime",
    description="Search for anime"
)
async def search_anime(
    request: Request,
    q: str = Query(..., description="Search query"),
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.search(query=q, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Search failed"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@router.get(
    "/genres/{slug}",
    response_model=BaseResponse,
    summary="Anime by Genre",
    description="Get anime by genre"
)
async def anime_by_genre(
    request: Request,
    slug: str,
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.genres(slug=slug, page=page)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Genre not found"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result,
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch genre: {str(e)}")


@router.get(
    "/detail/{slug}",
    response_model=BaseResponse,
    summary="Anime Detail",
    description="Get anime details"
)
async def anime_detail(
    request: Request,
    slug: str,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.anime_detail(slug=slug)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Anime not found"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch anime detail: {str(e)}")


@router.get(
    "/watch/{slug}",
    response_model=BaseResponse,
    summary="Watch Anime",
    description="Watch anime episode"
)
async def watch_anime(
    request: Request,
    slug: str,
    episode: int = Query(..., ge=1, description="Episode number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.watch(slug=slug, ep_num=episode)
        
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("message", "Episode not found"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch episode: {str(e)}")


@router.get(
    "/filters/list-mode",
    response_model=BaseResponse,
    summary="Anime List Mode",
    description="Get anime in list mode for filters"
)
async def anime_list_mode(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.advanced_search(mode="text")
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to fetch list"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch list: {str(e)}")


@router.get(
    "/filters",
    response_model=BaseResponse,
    summary="Anime Filters",
    description="Filter anime with advanced options"
)
async def anime_filters(
    request: Request,
    status: Optional[str] = Query(None, description="Filter by status"),
    type: Optional[str] = Query(None, description="Filter by type"),
    order: Optional[str] = Query(None, description="Sort order"),
    genres: Optional[List[str]] = Query(None, description="Filter by genres"),
    studios: Optional[List[str]] = Query(None, description="Filter by studios"),
    seasons: Optional[List[str]] = Query(None, description="Filter by seasons"),
    page: int = Query(1, ge=1, description="Page number"),
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        filters = {}
        if status:
            filters["status"] = status
        if type:
            filters["type"] = type
        if order:
            filters["order"] = order
        if genres:
            filters["genres"] = genres
        if studios:
            filters["studios"] = studios
        if seasons:
            filters["seasons"] = seasons
        
        async with OploverzParser() as parser:
            if not filters and page == 1:
                result = await parser.advanced_search(page=page)
            else:
                result = await parser.advanced_search(page=page, filters=filters)
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("message", "Failed to apply filters"))
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data=result.get("data"),
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to apply filters: {str(e)}")


@router.get(
    "/random",
    response_model=BaseResponse,
    summary="Random Anime",
    description="Get random anime"
)
async def random_anime(
    request: Request,
    apikey: Optional[str] = Query(None, description="Your API key")
):
    try:
        async with OploverzParser() as parser:
            list_result = await parser.advanced_search(mode="text")
        
        if not list_result.get("success"):
            raise HTTPException(status_code=500, detail="Failed to fetch anime list")
        
        all_anime = []
        data = list_result.get("data", {}).get("filters", {}).get("text_mode", {})
        
        for letter, items in data.items():
            all_anime.extend(items)
        
        if not all_anime:
            raise HTTPException(status_code=404, detail="No anime found")
        
        import random
        random_anime = random.choice(all_anime)
        slug = random_anime.get("slug")
        
        if not slug:
            raise HTTPException(status_code=404, detail="Failed to get random anime")
        
        async with OploverzParser() as parser:
            detail_result = await parser.anime_detail(slug=slug)
        
        if not detail_result.get("success"):
            raise HTTPException(status_code=500, detail="Failed to fetch random anime detail")
        
        return BaseResponse(
            status=200,
            success=True,
            author="zhadevv",
            data={
                "random": detail_result.get("data", {}),
                "list_info": random_anime
            },
            message=None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get random anime: {str(e)}")