from fastapi import APIRouter, Depends, Request, Query, Path
from typing import Optional, Dict, Any, List
from lib.scraper.anime import OploverzParser
from src.api.models.response_model import (
    BaseResponse,
    AnimeSearchResponse,
    AnimeDetailResponse,
    WatchResponse,
    ScheduleResponse,
    SidebarResponse,
    HomeResponse,
    FiltersResponse
)
from lib.system.validator import response_validator
from middlewares import GuestRateLimiter
from src.api.models.exception import ScraperException
import asyncio


router = APIRouter(
    prefix="/v1/anime",
    tags=["Anime"],
    dependencies=[Depends(GuestRateLimiter())]
)


@router.get(
    "/sidebar",
    response_model=BaseResponse[SidebarResponse],
    summary="Get Anime Sidebar",
    description="Get sidebar content including filters, new movies, etc."
)
async def get_anime_sidebar(request: Request):
    try:
        async with OploverzParser() as parser:
            result = await parser.sidebar()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get sidebar: {str(e)}",
            status_code=500
        )


@router.get(
    "/schedule",
    response_model=BaseResponse[ScheduleResponse],
    summary="Get Anime Schedule",
    description="Get anime release schedule by day"
)
async def get_anime_schedule(request: Request):
    try:
        async with OploverzParser() as parser:
            result = await parser.schedule()
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get schedule: {str(e)}",
            status_code=500
        )


@router.get(
    "/home",
    response_model=BaseResponse[HomeResponse],
    summary="Get Anime Home",
    description="Get home page content with slider, popular, latest, etc."
)
async def get_anime_home(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.home(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get home page: {str(e)}",
            status_code=500
        )


@router.get(
    "/search",
    response_model=BaseResponse[AnimeSearchResponse],
    summary="Search Anime",
    description="Search anime by query"
)
async def search_anime(
    request: Request,
    q: str = Query(..., min_length=1, max_length=200, description="Search query"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.search(query=q, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to search anime: {str(e)}",
            status_code=500
        )


@router.get(
    "/genres/{slug}",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Anime by Genre",
    description="Get anime list by genre slug"
)
async def get_anime_by_genre(
    request: Request,
    slug: str = Path(..., description="Genre slug"),
    page: int = Query(1, ge=1, le=100, description="Page number")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.genres(slug=slug, page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get anime by genre: {str(e)}",
            status_code=500
        )


@router.get(
    "/detail/{slug}",
    response_model=BaseResponse[AnimeDetailResponse],
    summary="Get Anime Detail",
    description="Get detailed information about an anime"
)
async def get_anime_detail(
    request: Request,
    slug: str = Path(..., description="Anime slug")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.anime_detail(slug=slug)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get anime detail: {str(e)}",
            status_code=500
        )


@router.get(
    "/watch/{slug}",
    response_model=BaseResponse[WatchResponse],
    summary="Watch Anime Episode",
    description="Get anime episode streaming information"
)
async def watch_anime(
    request: Request,
    slug: str = Path(..., description="Anime slug"),
    episode: int = Query(..., ge=1, le=10000, description="Episode number")
):
    try:
        async with OploverzParser() as parser:
            result = await parser.watch(slug=slug, ep_num=episode)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get episode: {str(e)}",
            status_code=500
        )


@router.get(
    "/filters/list-mode",
    response_model=BaseResponse[FiltersResponse],
    summary="Get Anime List Mode",
    description="Get anime list in text mode with alphabet navigation"
)
async def get_anime_list_mode(request: Request):
    try:
        async with OploverzParser() as parser:
            result = await parser.advanced_search(mode="text")
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get list mode: {str(e)}",
            status_code=500
        )


@router.get(
    "/filters",
    response_model=BaseResponse[FiltersResponse],
    summary="Filter Anime",
    description="Advanced anime filtering with multiple parameters"
)
async def filter_anime(
    request: Request,
    page: int = Query(1, ge=1, le=100, description="Page number"),
    status: Optional[str] = Query(None, description="Anime status"),
    type: Optional[str] = Query(None, description="Anime type"),
    order: Optional[str] = Query(None, description="Sort order"),
    genres: Optional[str] = Query(None, description="Genres (comma separated)"),
    studios: Optional[str] = Query(None, description="Studios (comma separated)"),
    seasons: Optional[str] = Query(None, description="Seasons (comma separated)")
):
    try:
        filters = {}
        
        if status:
            filters["status"] = status
        if type:
            filters["type"] = type
        if order:
            filters["order"] = order
        if genres:
            filters["genre"] = genres.split(',')
        if studios:
            filters["studio"] = studios.split(',')
        if seasons:
            filters["season"] = seasons.split(',')
        
        async with OploverzParser() as parser:
            if filters:
                result = await parser.advanced_search(page=page, filters=filters)
            else:
                if page == 1:
                    result = await parser.advanced_search(page=page)
                else:
                    result = await parser.advanced_search(page=page)
            
            if not result["success"]:
                raise ScraperException(result["message"])
            
            return result
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to filter anime: {str(e)}",
            status_code=500
        )


@router.get(
    "/random",
    response_model=BaseResponse[AnimeDetailResponse],
    summary="Get Random Anime",
    description="Get random anime detail"
)
async def get_random_anime(request: Request):
    try:
        import random
        
        async with OploverzParser() as parser:
            list_mode = await parser.advanced_search(mode="text")
            
            if not list_mode["success"]:
                raise ScraperException(list_mode["message"])
            
            all_anime = []
            for letter_data in list_mode["data"]["filters"]["text_mode"].values():
                all_anime.extend(letter_data)
            
            if not all_anime:
                return response_validator.create_response(
                    success=False,
                    message="No anime found",
                    status_code=404
                )
            
            random_anime = random.choice(all_anime)
            slug = random_anime["slug"]
            
            detail = await parser.anime_detail(slug=slug)
            
            if not detail["success"]:
                raise ScraperException(detail["message"])
            
            return detail
        
    except Exception as e:
        return response_validator.create_response(
            success=False,
            message=f"Failed to get random anime: {str(e)}",
            status_code=500
        )