from src.api.endpoints import v1, admin, main

__all__ = ["v1", "admin", "main"]