export default function Main({ children, sidebar, className = '' }) {
  return (
    <main className={`main-content ${className}`}>
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {sidebar && (
            <aside className="lg:col-span-1">
              <div className="sticky top-24">
                {sidebar}
              </div>
            </aside>
          )}
          
          <div className={sidebar ? 'lg:col-span-3' : 'col-span-full'}>
            {children}
          </div>
        </div>
      </div>
    </main>
  );
}