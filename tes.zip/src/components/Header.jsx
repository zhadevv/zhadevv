export default function Header({ title, subtitle, action }) {
  return (
    <header className="py-8 border-b border-gray-200">
      <div className="container">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {title}
            </h1>
            {subtitle && (
              <p className="mt-2 text-lg text-gray-600">
                {subtitle}
              </p>
            )}
          </div>
          {action && (
            <div>
              {action}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}