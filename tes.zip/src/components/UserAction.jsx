import { useState } from 'react';

export default function UserAction({ 
  actionType = 'info', 
  title, 
  message, 
  confirmText = 'Confirm', 
  cancelText = 'Cancel',
  onConfirm,
  onCancel,
  children 
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleConfirm = async () => {
    setLoading(true);
    try {
      await onConfirm?.();
      setIsOpen(false);
    } catch (error) {
      console.error('Action failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    onCancel?.();
    setIsOpen(false);
  };

  const getActionStyle = () => {
    switch (actionType) {
      case 'danger':
        return 'btn-danger';
      case 'warning':
        return 'btn-warning';
      case 'success':
        return 'btn-success';
      default:
        return 'btn-primary';
    }
  };

  return (
    <>
      <button
        className={`btn ${getActionStyle()}`}
        onClick={() => setIsOpen(true)}
      >
        {children || title}
      </button>

      {isOpen && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="text-lg font-semibold">{title}</h3>
            </div>
            
            <div className="modal-body">
              {message && (
                <p className="text-gray-700 mb-4">{message}</p>
              )}
            </div>
            
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                onClick={handleCancel}
                disabled={loading}
              >
                {cancelText}
              </button>
              
              <button
                className={`btn ${getActionStyle()}`}
                onClick={handleConfirm}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <div className="loading mr-2"></div>
                    Processing...
                  </>
                ) : (
                  confirmText
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}