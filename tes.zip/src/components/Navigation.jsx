import { useState } from 'react';
import Link from 'next/link';

export default function Navigation({ user }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link href="/" className="navbar-brand">
          zhadev API
        </Link>

        <button 
          className="navbar-toggle md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {mobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>

        <div className={`navbar-menu ${mobileMenuOpen ? 'md:flex' : 'hidden md:flex'}`}>
          <Link href="/docs" className="navbar-link">
            Documentation
          </Link>
          <Link href="/about" className="navbar-link">
            About
          </Link>
          <Link href="/donate" className="navbar-link">
            Donate
          </Link>
          
          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">
                {user.username}
              </span>
              <Link href="/admin-panel" className="btn btn-primary btn-sm">
                Dashboard
              </Link>
              <Link href="/api/auth/signout" className="btn btn-secondary btn-sm">
                Logout
              </Link>
            </div>
          ) : (
            <Link href="/auth/signin" className="btn btn-primary btn-sm">
              Admin Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}