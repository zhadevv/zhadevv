import { useState } from 'react';

export default function Endpoint({ 
  method, 
  path, 
  description, 
  parameters = [], 
  response 
}) {
  const [showDetails, setShowDetails] = useState(false);
  const [copied, setCopied] = useState(false);

  const getMethodColor = () => {
    switch (method.toLowerCase()) {
      case 'get':
        return 'method-get';
      case 'post':
        return 'method-post';
      case 'put':
        return 'method-put';
      case 'delete':
        return 'method-delete';
      default:
        return 'method-get';
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="endpoint-card">
      <div className="endpoint-header">
        <div className="flex items-center gap-4">
          <span className={`endpoint-method ${getMethodColor()}`}>
            {method}
          </span>
          <code className="endpoint-path">
            {path}
          </code>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? 'Hide Details' : 'Show Details'}
          </button>
          
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => copyToClipboard(path)}
            title="Copy endpoint"
          >
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>
      </div>
      
      <div className="endpoint-body">
        <p className="text-gray-700 mb-4">{description}</p>
        
        {showDetails && (
          <div className="space-y-6">
            {parameters.length > 0 && (
              <div className="endpoint-params">
                <h4 className="font-semibold text-gray-900 mb-3">Parameters</h4>
                <div className="table-container">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Required</th>
                        <th>Description</th>
                      </tr>
                    </thead>
                    <tbody>
                      {parameters.map((param, index) => (
                        <tr key={index}>
                          <td className="font-mono text-sm">{param.name}</td>
                          <td>
                            <span className="badge badge-info">
                              {param.type}
                            </span>
                          </td>
                          <td>
                            {param.required ? (
                              <span className="badge badge-danger">Required</span>
                            ) : (
                              <span className="badge badge-success">Optional</span>
                            )}
                          </td>
                          <td className="text-sm text-gray-600">
                            {param.description}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {response && (
              <div className="endpoint-response">
                <h4 className="font-semibold text-gray-900 mb-3">Response</h4>
                <div className="response-example">
                  <pre className="text-sm">
                    {JSON.stringify(response, null, 2)}
                  </pre>
                </div>
              </div>
            )}
            
            <div className="endpoint-example">
              <h4 className="font-semibold text-gray-900 mb-3">Example Request</h4>
              <div className="bg-gray-900 text-gray-300 rounded p-4 font-mono text-sm">
                <code>
                  <span className="text-blue-400">curl</span>{' '}
                  <span className="text-green-400">-X</span>{' '}
                  <span className="text-yellow-400">{method}</span>{' '}
                  <span className="text-purple-400">"https://api.zhadev.my.id{path}"</span>
                </code>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}