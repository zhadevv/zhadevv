import { useState } from 'react';
import Endpoint from './Endpoint.jsx';

export default function Category({ 
  category, 
  endpoints, 
  expanded = false,
  onToggle 
}) {
  const [isExpanded, setIsExpanded] = useState(expanded);

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
    onToggle?.(!isExpanded);
  };

  return (
    <div className="category">
      <div 
        className="category-header cursor-pointer p-4 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100"
        onClick={toggleExpand}
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {category.name}
            </h3>
            {category.description && (
              <p className="text-sm text-gray-600 mt-1">
                {category.description}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="badge badge-info">
              {endpoints.length} endpoints
            </span>
            <svg 
              className={`w-5 h-5 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`}
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>

      {isExpanded && (
        <div className="mt-4 space-y-4">
          {endpoints.map((endpoint, index) => (
            <Endpoint
              key={index}
              method={endpoint.method}
              path={endpoint.path}
              description={endpoint.description}
              parameters={endpoint.parameters}
              response={endpoint.response}
            />
          ))}
        </div>
      )}
    </div>
  );
}