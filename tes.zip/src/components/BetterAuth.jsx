'use client';

import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';

export default function BetterAuth({ children, requireAuth = false }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    checkAuth();
  }, [pathname]);

  async function checkAuth() {
    // Skip auth check for public pages
    if (pathname === '/' || 
        pathname.startsWith('/about') || 
        pathname.startsWith('/donate') || 
        pathname.startsWith('/contact') || 
        pathname.startsWith('/docs') ||
        pathname.startsWith('/auth/signin')) {
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include',
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setUser(data.data.user);
          
          // Redirect non-admin away from admin pages
          if (pathname.startsWith('/admin-panel') && data.data.user.role !== 'owner') {
            router.push('/');
          }
        } else {
          setUser(null);
          if (requireAuth || pathname.startsWith('/admin-panel')) {
            router.push('/auth/signin');
          }
        }
      } else {
        setUser(null);
        if (requireAuth || pathname.startsWith('/admin-panel')) {
          router.push('/auth/signin');
        }
      }
    } catch (err) {
      setUser(null);
      if (requireAuth || pathname.startsWith('/admin-panel')) {
        router.push('/auth/signin');
      }
    } finally {
      setLoading(false);
    }
  }

  if (loading && (requireAuth || pathname.startsWith('/admin-panel'))) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="loading"></div>
      </div>
    );
  }

  if (requireAuth && !user) {
    return null;
  }

  return children;
}