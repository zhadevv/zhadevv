import { FaGithub, FaTwitter, FaDiscord, FaEnvelope } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function getApiStatus() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/status`, {
      next: { revalidate: 60 },
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch API status');
    }
    
    const data = await response.json();
    return data.success ? data.data : null;
  } catch (error) {
    console.error('Error fetching API status:', error);
    return null;
  }
}

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  
  return parts.join(' ') || 'Just started';
}

function formatMemory(bytes) {
  const gb = bytes / 1024 / 1024 / 1024;
  return `${gb.toFixed(2)} GB`;
}

export default async function AboutPage() {
  const apiStatus = await getApiStatus();
  
  const team = [
    {
      name: 'zhadevv',
      role: 'Founder & Lead Developer',
      description: 'Full-stack developer with passion for building scalable APIs',
    },
  ];

  const stats = [
    { 
      label: 'API Endpoints', 
      value: '30+',
      description: 'Total available endpoints'
    },
    { 
      label: 'Uptime', 
      value: apiStatus ? formatUptime(apiStatus.server.uptime) : 'Loading...',
      description: 'Current server uptime'
    },
    { 
      label: 'Memory Usage', 
      value: apiStatus ? `${((apiStatus.server.memory.used.heapUsed / apiStatus.server.memory.total) * 100).toFixed(1)}%` : 'Loading...',
      description: 'Current memory utilization'
    },
    { 
      label: 'Redis Status', 
      value: apiStatus ? apiStatus.redis.status.charAt(0).toUpperCase() + apiStatus.redis.status.slice(1) : 'Loading...',
      description: 'Cache database status'
    },
  ];

  return (
    <>
      <Header 
        title="About zhadev API" 
        subtitle="Learn more about our mission and team"
      />
      
      <Main>
        <section className="py-8">
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                zhadev API was born out of a passion for anime, donghua, and dracin content 
                and the need for a reliable, high-performance API service for developers.
              </p>
              <p>
                Our mission is to provide developers with the tools they need to build 
                amazing applications without worrying about infrastructure, rate limits, 
                or data quality.
              </p>
              <p>
                We believe in complete transparency. Below you can see real-time statistics 
                about our API infrastructure.
              </p>
            </div>
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6">Live API Status</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-primary-color mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">
                    {stat.label}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {stat.description}
                  </div>
                </div>
              ))}
            </div>
            
            {apiStatus && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="font-semibold mb-3">Detailed System Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-600">Node Version:</span>
                      <span className="font-mono">{apiStatus.server.node_version}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-600">Platform:</span>
                      <span className="font-mono">{apiStatus.server.platform}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-600">CPU Cores:</span>
                      <span>{apiStatus.server.cpu.cores}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-600">Total Memory:</span>
                      <span>{formatMemory(apiStatus.server.memory.total)}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-gray-100">
                      <span className="text-gray-600">Free Memory:</span>
                      <span>{formatMemory(apiStatus.server.memory.free)}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-gray-600">API Environment:</span>
                      <span className="badge badge-info">{apiStatus.api.environment}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6">Our Team</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {team.map((member, index) => (
                <div key={index} className="p-6 border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-2xl font-bold text-gray-700">
                        {member.name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{member.name}</h3>
                      <p className="text-sm text-gray-600">{member.role}</p>
                    </div>
                  </div>
                  <p className="text-gray-700">{member.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h2 className="text-2xl font-bold mb-6">Connect With Us</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <a
                href="https://github.com/zhadevv"
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FaGithub className="w-8 h-8 mb-2" />
                <span className="font-medium">GitHub</span>
              </a>
              
              <a
                href="https://twitter.com/zhadevv"
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FaTwitter className="w-8 h-8 mb-2" />
                <span className="font-medium">Twitter</span>
              </a>
              
              <a
                href="https://discord.gg/zhadev"
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FaDiscord className="w-8 h-8 mb-2" />
                <span className="font-medium">Discord</span>
              </a>
              
              <a
                href="mailto:contact@zhadev.my.id"
                className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FaEnvelope className="w-8 h-8 mb-2" />
                <span className="font-medium">Email</span>
              </a>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}