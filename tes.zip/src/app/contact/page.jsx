import { FaEnvelope, FaWhatsapp, FaClock, FaMapMarkerAlt } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';
import ContactForm from '@/components/form/ContactForm';

export default function ContactPage() {
  const contactInfo = [
    {
      icon: <FaEnvelope className="w-6 h-6" />,
      title: 'Email',
      details: 'contact@zhadev.my.id',
      link: 'mailto:contact@zhadev.my.id',
    },
    {
      icon: <FaWhatsapp className="w-6 h-6" />,
      title: 'WhatsApp',
      details: '+62 856-5955-8652',
      link: 'https://wa.me/6285659558652',
    },
    {
      icon: <FaClock className="w-6 h-6" />,
      title: 'Response Time',
      details: '24-48 hours',
    },
    {
      icon: <FaMapMarkerAlt className="w-6 h-6" />,
      title: 'Based In',
      details: 'Indonesia',
    },
  ];

  const faqs = [
    {
      question: 'How do I get an API key?',
      answer: 'API keys are optional for basic usage. For premium keys with higher limits, please visit the Donate page.',
    },
    {
      question: 'Is there a free tier?',
      answer: 'Yes, you can use the API without an API key with 25 requests per minute limit.',
    },
    {
      question: 'How can I report a bug or issue?',
      answer: 'Please use the contact form or email us directly with details about the issue.',
    },
    {
      question: 'Can I request a new feature?',
      answer: 'Yes, we welcome feature requests. Premium users get priority consideration.',
    },
  ];

  return (
    <>
      <Header 
        title="Contact Us" 
        subtitle="Get in touch with our team"
      />
      
      <Main>
        <section className="py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <ContactForm />
            </div>
            
            <div className="space-y-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                <div className="space-y-4">
                  {contactInfo.map((info, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="text-primary-color mt-1">
                        {info.icon}
                      </div>
                      <div>
                        <h4 className="font-medium">{info.title}</h4>
                        {info.link ? (
                          <a
                            href={info.link}
                            target={info.link.includes('mailto:') ? undefined : '_blank'}
                            rel="noopener noreferrer"
                            className="text-sm text-gray-600 hover:text-primary-color transition-colors"
                          >
                            {info.details}
                          </a>
                        ) : (
                          <p className="text-sm text-gray-600">{info.details}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <h3 className="text-lg font-semibold mb-4">FAQ</h3>
                <div className="space-y-4">
                  {faqs.map((faq, index) => (
                    <details key={index} className="border-b border-gray-200 pb-4 last:border-0 last:pb-0">
                      <summary className="cursor-pointer font-medium">
                        {faq.question}
                      </summary>
                      <p className="mt-2 text-sm text-gray-600">
                        {faq.answer}
                      </p>
                    </details>
                  ))}
                </div>
              </div>

              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Support Hours</h3>
                <div className="space-y-2 text-sm">
                  <p className="flex justify-between">
                    <span className="text-gray-600">Monday - Friday</span>
                    <span className="font-medium">9:00 AM - 6:00 PM WIB</span>
                  </p>
                  <p className="flex justify-between">
                    <span className="text-gray-600">Saturday</span>
                    <span className="font-medium">10:00 AM - 4:00 PM WIB</span>
                  </p>
                  <p className="flex justify-between">
                    <span className="text-gray-600">Sunday</span>
                    <span className="font-medium">Emergency Only</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}