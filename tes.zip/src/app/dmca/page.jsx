import Header from '@/components/Header';
import Main from '@/components/Main';

export default function DMCAPage() {
  return (
    <>
      <Header 
        title="DMCA & Copyright" 
        subtitle="Digital Millennium Copyright Act Policy"
      />
      
      <Main>
        <section className="py-8">
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">DMCA Policy</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                zhadev API ("we", "our", or "us") respects the intellectual property rights 
                of others and expects its users to do the same. In accordance with the 
                Digital Millennium Copyright Act of 1998, the text of which may be found 
                on the U.S. Copyright Office website at http://www.copyright.gov/legislation/dmca.pdf, 
                we will respond expeditiously to claims of copyright infringement committed 
                using our service.
              </p>
              
              <p>
                If you are a copyright owner, authorized to act on behalf of one, or 
                authorized to act under any exclusive right under copyright, please report 
                alleged copyright infringements taking place on or through our services 
                by completing the following DMCA Notice of Alleged Infringement and 
                delivering it to our Designated Copyright Agent.
              </p>
            </div>
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">DMCA Notice Requirements</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                Upon receipt of Notice as described below, we will take whatever action, 
                in its sole discretion, it deems appropriate, including removal of the 
                challenged content from the services.
              </p>
              
              <h3 className="text-lg font-semibold mt-6 mb-3">To file a DMCA notice, you must provide:</h3>
              
              <ol className="list-decimal list-inside space-y-3 ml-4">
                <li>
                  <strong>Identification of the copyrighted work:</strong> A physical or 
                  electronic signature of a person authorized to act on behalf of the owner 
                  of an exclusive right that is allegedly infringed.
                </li>
                <li>
                  <strong>Identification of the infringing material:</strong> Identification 
                  of the copyrighted work claimed to have been infringed, or, if multiple 
                  copyrighted works at a single online site are covered by a single notification, 
                  a representative list of such works at that site.
                </li>
                <li>
                  <strong>Contact information:</strong> Identification of the material that is 
                  claimed to be infringing or to be the subject of infringing activity and that 
                  is to be removed or access to which is to be disabled, and information 
                  reasonably sufficient to permit us to locate the material.
                </li>
                <li>
                  <strong>Statement of good faith:</strong> Information reasonably sufficient 
                  to permit us to contact the complaining party, such as an address, telephone 
                  number, and, if available, an email address at which the complaining party 
                  may be contacted.
                </li>
                <li>
                  <strong>Statement under penalty of perjury:</strong> A statement that the 
                  complaining party has a good faith belief that use of the material in the 
                  manner complained of is not authorized by the copyright owner, its agent, 
                  or the law.
                </li>
                <li>
                  <strong>Authority statement:</strong> A statement that the information in 
                  the notification is accurate, and under penalty of perjury, that the 
                  complaining party is authorized to act on behalf of the owner of an exclusive 
                  right that is allegedly infringed.
                </li>
              </ol>
            </div>
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">Submit DMCA Notice</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                Please send your DMCA notice to our designated copyright agent at:
              </p>
              
              <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-lg mb-3">Copyright Agent</h3>
                <div className="space-y-2">
                  <p>
                    <strong>Name:</strong> zhadev DMCA Agent
                  </p>
                  <p>
                    <strong>Email:</strong> dmca@zhadev.my.id
                  </p>
                  <p>
                    <strong>Physical Address:</strong><br />
                    [Your Physical Address Here]<br />
                    [City, State, ZIP Code]<br />
                    Indonesia
                  </p>
                  <p>
                    <strong>Phone:</strong> +62 856-5955-8652
                  </p>
                </div>
              </div>
              
              <p className="mt-4">
                <strong>Note:</strong> Only DMCA notices should go to the Copyright Agent. 
                Any other feedback, comments, requests for technical support, and other 
                communications should be directed to our general contact at contact@zhadev.my.id.
              </p>
            </div>
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">Counter-Notification</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                If you believe that your content was removed or disabled by mistake or 
                misidentification, you may file a counter-notification with us by providing 
                the following information to our Copyright Agent:
              </p>
              
              <ol className="list-decimal list-inside space-y-3 ml-4">
                <li>Your physical or electronic signature</li>
                <li>Identification of the material that has been removed or to which access has been disabled</li>
                <li>A statement under penalty of perjury that you have a good faith belief that the material was removed or disabled as a result of mistake or misidentification</li>
                <li>Your name, address, and telephone number</li>
                <li>A statement that you consent to the jurisdiction of the Federal District Court for the judicial district in which your address is located</li>
              </ol>
              
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mt-6">
                <p className="text-sm text-yellow-800">
                  <strong>Warning:</strong> Knowingly materially misrepresenting that material 
                  or activity was removed or disabled by mistake or misidentification may be 
                  subject to liability for damages.
                </p>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-2xl font-bold mb-4">Repeat Infringers</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                It is our policy in appropriate circumstances to disable and/or terminate 
                the accounts of users who are repeat infringers of intellectual property rights.
              </p>
              
              <p>
                We reserve the right to terminate accounts that we determine, in our sole 
                discretion, are repeat infringers. A repeat infringer is a user who has been 
                notified of infringing activity more than twice and/or has had content removed 
                from the service more than twice.
              </p>
              
              <p>
                This policy is intended to protect the rights of copyright owners and to 
                provide a positive experience for all users of our service.
              </p>
              
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Last Updated:</strong> {new Date().toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  This DMCA policy may be updated from time to time. Please check this page 
                  regularly for updates.
                </p>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}