import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaCog, FaSave, FaUndo, FaShieldAlt, FaBell } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

export default async function SettingsPage() {
  const user = await validateAdmin();

  const settingsSections = [
    {
      title: 'General Settings',
      icon: <FaCog className="w-5 h-5" />,
      settings: [
        { name: 'site_title', label: 'Site Title', value: 'zhadev API', type: 'text' },
        { name: 'site_description', label: 'Site Description', value: 'Powerful REST API for anime, donghua, and dracin content', type: 'textarea' },
        { name: 'contact_email', label: 'Contact Email', value: 'contact@zhadev.my.id', type: 'email' },
        { name: 'maintenance_mode', label: 'Maintenance Mode', value: false, type: 'checkbox' },
      ],
    },
    {
      title: 'Security Settings',
      icon: <FaShieldAlt className="w-5 h-5" />,
      settings: [
        { name: 'rate_limit_guest', label: 'Guest Rate Limit', value: '25', type: 'number', suffix: 'requests/minute' },
        { name: 'rate_limit_free', label: 'Free User Rate Limit', value: '50', type: 'number', suffix: 'requests/minute' },
        { name: 'auto_ban_attempts', label: 'Auto-ban Failed Attempts', value: '10', type: 'number', suffix: 'attempts' },
        { name: 'session_timeout', label: 'Session Timeout', value: '24', type: 'number', suffix: 'hours' },
      ],
    },
    {
      title: 'Notification Settings',
      icon: <FaBell className="w-5 h-5" />,
      settings: [
        { name: 'email_notifications', label: 'Email Notifications', value: true, type: 'checkbox' },
        { name: 'webhook_url', label: 'Webhook URL', value: '', type: 'text', placeholder: 'https://webhook.example.com' },
        { name: 'alert_threshold', label: 'Alert Threshold', value: '1000', type: 'number', suffix: 'requests/hour' },
      ],
    },
  ];

  return (
    <>
      <Header 
        title="System Settings" 
        subtitle="Configure API settings and preferences"
        action={
          <div className="flex items-center gap-3">
            <Link href="/admin-panel" className="btn btn-secondary btn-sm">
              Back to Dashboard
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <form className="space-y-8">
            {settingsSections.map((section, sectionIndex) => (
              <div key={sectionIndex} className="card">
                <div className="flex items-center gap-3 mb-6">
                  <div className="text-primary-color">
                    {section.icon}
                  </div>
                  <h3 className="text-xl font-semibold">{section.title}</h3>
                </div>
                
                <div className="space-y-4">
                  {section.settings.map((setting, settingIndex) => (
                    <div key={settingIndex} className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className="md:w-1/3">
                        <label className="block text-sm font-medium mb-1">
                          {setting.label}
                        </label>
                        {setting.description && (
                          <p className="text-xs text-gray-600">{setting.description}</p>
                        )}
                      </div>
                      
                      <div className="md:w-2/3">
                        {setting.type === 'checkbox' ? (
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              name={setting.name}
                              defaultChecked={setting.value}
                              className="w-4 h-4 text-primary-color rounded"
                            />
                            <label className="ml-2 text-sm">
                              Enable {setting.label.toLowerCase()}
                            </label>
                          </div>
                        ) : setting.type === 'textarea' ? (
                          <textarea
                            name={setting.name}
                            defaultValue={setting.value}
                            className="input min-h-[100px]"
                            placeholder={setting.placeholder}
                          />
                        ) : (
                          <div className="flex gap-3">
                            <input
                              type={setting.type}
                              name={setting.name}
                              defaultValue={setting.value}
                              className="input flex-1"
                              placeholder={setting.placeholder}
                            />
                            {setting.suffix && (
                              <span className="text-sm text-gray-600 whitespace-nowrap">
                                {setting.suffix}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            <div className="card">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Save Changes</h3>
                  <p className="text-sm text-gray-600">
                    Changes will take effect immediately after saving.
                  </p>
                </div>
                
                <div className="flex gap-3">
                  <button type="reset" className="btn btn-secondary">
                    <FaUndo className="inline mr-2" />
                    Reset
                  </button>
                  <button type="submit" className="btn btn-primary">
                    <FaSave className="inline mr-2" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </form>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Danger Zone</h3>
              <div className="space-y-4">
                <button
                  type="button"
                  className="w-full btn btn-danger"
                  onClick={() => {
                    if (confirm('Are you sure you want to clear all API cache? This will affect performance temporarily.')) {
                      // Clear cache action
                    }
                  }}
                >
                  Clear All Cache
                </button>
                
                <button
                  type="button"
                  className="w-full btn btn-danger"
                  onClick={() => {
                    if (confirm('This will delete all user API keys. Are you sure?')) {
                      // Delete all keys action
                    }
                  }}
                >
                  Delete All API Keys
                </button>
                
                <button
                  type="button"
                  className="w-full btn btn-danger"
                  onClick={() => {
                    if (confirm('This will purge all logs. This action cannot be undone.')) {
                      // Purge logs action
                    }
                  }}
                >
                  Purge All Logs
                </button>
              </div>
            </div>
            
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">System Information</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Current User:</span>
                  <span className="font-medium">{user.username}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">User Role:</span>
                  <span className="badge badge-info capitalize">{user.role}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Last Login:</span>
                  <span>Just now</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Session Expires:</span>
                  <span>24 hours</span>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <Link
                  href="/auth/signout"
                  className="w-full btn btn-secondary"
                >
                  Logout All Sessions
                </Link>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}