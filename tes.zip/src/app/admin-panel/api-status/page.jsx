import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaCheckCircle, FaTimesCircle, FaExclamationTriangle } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getApiStatus() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/status`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch API status');
    }
    
    const data = await response.json();
    return data.success ? data.data : null;
  } catch (error) {
    return null;
  }
}

function getStatusIcon(status) {
  if (status === 'connected' || status === 'healthy') {
    return <FaCheckCircle className="w-5 h-5 text-green-500" />;
  } else if (status === 'disconnected' || status === 'unhealthy') {
    return <FaTimesCircle className="w-5 h-5 text-red-500" />;
  } else {
    return <FaExclamationTriangle className="w-5 h-5 text-yellow-500" />;
  }
}

export default async function ApiStatusPage() {
  const user = await validateAdmin();
  const status = await getApiStatus();

  const services = [
    {
      name: 'API Server',
      status: status ? 'healthy' : 'unhealthy',
      description: 'Main API application server',
    },
    {
      name: 'Redis Cache',
      status: status?.redis.status || 'unknown',
      description: 'In-memory data store for caching',
    },
    {
      name: 'Database',
      status: 'connected',
      description: 'Primary MySQL database',
    },
    {
      name: 'Rate Limiting',
      status: 'active',
      description: 'Request rate limiting system',
    },
  ];

  return (
    <>
      <Header 
        title="API Status" 
        subtitle="Monitor system health and services"
        action={
          <div className="flex items-center gap-3">
            <span className="text-sm">
              Last Updated: <span className="font-bold">
                {status ? new Date(status.timestamp).toLocaleTimeString() : 'Unknown'}
              </span>
            </span>
            <Link href="/admin-panel" className="btn btn-secondary btn-sm">
              Back to Dashboard
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Service Status</h3>
              <div className="space-y-4">
                {services.map((service, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div>
                      <h4 className="font-semibold">{service.name}</h4>
                      <p className="text-sm text-gray-600">{service.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(service.status)}
                      <span className={`font-medium ${
                        service.status === 'healthy' || service.status === 'connected' || service.status === 'active'
                          ? 'text-green-600'
                          : service.status === 'unhealthy' || service.status === 'disconnected'
                          ? 'text-red-600'
                          : 'text-yellow-600'
                      }`}>
                        {service.status.charAt(0).toUpperCase() + service.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full btn btn-primary">
                  Clear API Cache
                </button>
                <button className="w-full btn btn-secondary">
                  Restart Services
                </button>
                <button className="w-full btn btn-danger">
                  Emergency Shutdown
                </button>
              </div>
              
              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">
                  <FaExclamationTriangle className="inline mr-2" />
                  Maintenance Mode
                </h4>
                <p className="text-sm text-yellow-700">
                  Enable maintenance mode to temporarily disable API access for users.
                </p>
                <button className="mt-3 w-full btn btn-warning btn-sm">
                  Enable Maintenance Mode
                </button>
              </div>
            </div>
          </div>
          
          {status && (
            <div className="mt-8">
              <div className="card">
                <h3 className="text-xl font-semibold mb-4">Detailed System Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3">Server Details</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Node Version:</span>
                        <code>{status.server.node_version}</code>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Platform:</span>
                        <code>{status.server.platform}</code>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Uptime:</span>
                        <span>{Math.floor(status.server.uptime / 3600)} hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">CPU Cores:</span>
                        <span>{status.server.cpu.cores}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-3">Memory Usage</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Memory:</span>
                        <span>{(status.server.memory.total / 1024 / 1024 / 1024).toFixed(2)} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Free Memory:</span>
                        <span>{(status.server.memory.free / 1024 / 1024 / 1024).toFixed(2)} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Used Heap:</span>
                        <span>{(status.server.memory.used.heapUsed / 1024 / 1024).toFixed(2)} MB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Heap:</span>
                        <span>{(status.server.memory.used.heapTotal / 1024 / 1024).toFixed(2)} MB</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-3">Load Average</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">1 minute:</span>
                        <span>{status.server.cpu.loadavg[0].toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">5 minutes:</span>
                        <span>{status.server.cpu.loadavg[1].toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">15 minutes:</span>
                        <span>{status.server.cpu.loadavg[2].toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Environment:</span>
                        <span className="badge badge-info">{status.api.environment}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </Main>
    </>
  );
}