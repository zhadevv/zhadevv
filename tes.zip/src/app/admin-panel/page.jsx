import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { 
  FaTachometerAlt, 
  FaKey, 
  FaUsers, 
  FaShieldAlt, 
  FaChartBar,
  FaCog,
  FaHistory,
  FaServer
} from 'react-icons/fa';
import Link from 'next/link';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function getAdminData() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getStats() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/admin/stats`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      return null;
    }
    
    const data = await response.json();
    return data.success ? data.data : null;
  } catch (error) {
    return null;
  }
}

export default async function AdminPanelPage() {
  const user = await getAdminData();
  const stats = await getStats();
  
  const adminCards = [
    {
      icon: <FaKey className="w-6 h-6" />,
      title: 'API Keys',
      description: 'Manage user API keys',
      count: stats?.keys?.total || 0,
      color: 'bg-blue-100 text-blue-800',
      href: '/admin-panel/keys',
    },
    {
      icon: <FaUsers className="w-6 h-6" />,
      title: 'Users',
      description: 'View active users',
      count: stats?.requests?.byRole?.free + stats?.requests?.byRole?.premium || 0,
      color: 'bg-green-100 text-green-800',
      href: '#',
    },
    {
      icon: <FaShieldAlt className="w-6 h-6" />,
      title: 'Moderation',
      description: 'IP bans and moderation',
      count: stats?.keys?.suspended || 0,
      color: 'bg-red-100 text-red-800',
      href: '/admin-panel/moderate',
    },
    {
      icon: <FaChartBar className="w-6 h-6" />,
      title: 'Analytics',
      description: 'Usage statistics',
      count: stats?.requests?.total || 0,
      color: 'bg-purple-100 text-purple-800',
      href: '/admin-panel/monitoring',
    },
    {
      icon: <FaHistory className="w-6 h-6" />,
      title: 'Activity Logs',
      description: 'Request history',
      count: 'Recent',
      color: 'bg-yellow-100 text-yellow-800',
      href: '/admin-panel/activity',
    },
    {
      icon: <FaServer className="w-6 h-6" />,
      title: 'API Status',
      description: 'System health',
      count: 'Live',
      color: 'bg-teal-100 text-teal-800',
      href: '/admin-panel/api-status',
    },
    {
      icon: <FaCog className="w-6 h-6" />,
      title: 'Settings',
      description: 'System configuration',
      count: 'Config',
      color: 'bg-gray-100 text-gray-800',
      href: '/admin-panel/settings',
    },
  ];
  
  const recentActivity = [
    { action: 'User logged in', time: '2 minutes ago', user: 'admin' },
    { action: 'API key generated', time: '15 minutes ago', user: 'premium_user' },
    { action: 'Request blocked', time: '1 hour ago', user: '192.168.1.1' },
    { action: 'System updated', time: '3 hours ago', user: 'system' },
  ];

  return (
    <>
      <Header 
        title="Admin Dashboard" 
        subtitle={`Welcome back, ${user.username}`}
        action={
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600">
              Role: <span className="font-semibold capitalize">{user.role}</span>
            </span>
            <Link href="/auth/signout" className="btn btn-danger btn-sm">
              Logout
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
            {adminCards.map((card, index) => (
              <Link
                key={index}
                href={card.href}
                className="card hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${card.color}`}>
                    {card.icon}
                  </div>
                  <span className="text-2xl font-bold">{card.count}</span>
                </div>
                <h3 className="font-semibold text-lg mb-1">{card.title}</h3>
                <p className="text-sm text-gray-600">{card.description}</p>
              </Link>
            ))}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link
                  href="/admin-panel/keys?action=generate"
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <FaKey className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Generate API Key</h4>
                      <p className="text-sm text-gray-600">Create new user API key</p>
                    </div>
                  </div>
                  <span className="text-blue-600">→</span>
                </Link>
                
                <Link
                  href="/admin-panel/moderate"
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-100 rounded-lg">
                      <FaShieldAlt className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Manage Bans</h4>
                      <p className="text-sm text-gray-600">View and manage IP bans</p>
                    </div>
                  </div>
                  <span className="text-red-600">→</span>
                </Link>
                
                <Link
                  href="/admin-panel/docs/create"
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <FaCog className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-medium">Create Documentation</h4>
                      <p className="text-sm text-gray-600">Add new API documentation</p>
                    </div>
                  </div>
                  <span className="text-purple-600">→</span>
                </Link>
              </div>
            </div>
            
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border-b border-gray-100 last:border-0">
                    <div>
                      <h4 className="font-medium">{activity.action}</h4>
                      <p className="text-sm text-gray-600">by {activity.user}</p>
                    </div>
                    <span className="text-sm text-gray-500">{activity.time}</span>
                  </div>
                ))}
              </div>
              
              <Link
                href="/admin-panel/activity"
                className="mt-4 btn btn-secondary w-full"
              >
                View All Activity
              </Link>
            </div>
          </div>
          
          {stats && (
            <div className="mt-8 card">
              <h3 className="text-xl font-semibold mb-4">System Overview</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="text-2xl font-bold mb-1">{stats.keys?.total || 0}</div>
                  <div className="text-sm text-gray-600">Total API Keys</div>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="text-2xl font-bold mb-1">{stats.keys?.active || 0}</div>
                  <div className="text-sm text-gray-600">Active Keys</div>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="text-2xl font-bold mb-1">{stats.requests?.today || 0}</div>
                  <div className="text-sm text-gray-600">Today's Requests</div>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <div className="text-2xl font-bold mb-1">{stats.requests?.total || 0}</div>
                  <div className="text-sm text-gray-600">Total Requests</div>
                </div>
              </div>
            </div>
          )}
        </section>
      </Main>
    </>
  );
}