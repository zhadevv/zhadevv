import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaChartLine, FaServer, FaDatabase, FaNetworkWired } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getMonitoringStats() {
  try {
    const [statsResponse, statusResponse] = await Promise.all([
      fetch(`${process.env.NEXT_URL}/api/admin/stats`, { cache: 'no-store' }),
      fetch(`${process.env.NEXT_URL}/api/status`, { cache: 'no-store' }),
    ]);
    
    const stats = statsResponse.ok ? await statsResponse.json() : null;
    const status = statusResponse.ok ? await statusResponse.json() : null;
    
    return {
      stats: stats?.success ? stats.data : null,
      status: status?.success ? status.data : null,
    };
  } catch (error) {
    return { stats: null, status: null };
  }
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export default async function MonitoringPage() {
  const user = await validateAdmin();
  const { stats, status } = await getMonitoringStats();
  
  const monitoringCards = [
    {
      icon: <FaServer className="w-6 h-6" />,
      title: 'Server Uptime',
      value: status ? Math.floor(status.server.uptime / 3600) + ' hours' : 'Loading...',
      description: 'System uptime',
      color: 'bg-blue-100 text-blue-800',
    },
    {
      icon: <FaChartLine className="w-6 h-6" />,
      title: 'Today\'s Requests',
      value: stats?.requests?.today || 0,
      description: 'Requests in last 24h',
      color: 'bg-green-100 text-green-800',
    },
    {
      icon: <FaDatabase className="w-6 h-6" />,
      title: 'Memory Usage',
      value: status ? formatBytes(status.server.memory.used.heapUsed) : 'Loading...',
      description: 'Current memory usage',
      color: 'bg-purple-100 text-purple-800',
    },
    {
      icon: <FaNetworkWired className="w-6 h-6" />,
      title: 'Redis Status',
      value: status ? status.redis.status.charAt(0).toUpperCase() + status.redis.status.slice(1) : 'Loading...',
      description: 'Cache database status',
      color: status?.redis.status === 'connected' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800',
    },
  ];

  return (
    <>
      <Header 
        title="System Monitoring" 
        subtitle="Real-time system statistics and analytics"
        action={
          <Link href="/admin-panel" className="btn btn-secondary btn-sm">
            Back to Dashboard
          </Link>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {monitoringCards.map((card, index) => (
              <div key={index} className="card">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${card.color}`}>
                    {card.icon}
                  </div>
                </div>
                <div className="text-2xl font-bold mb-1">{card.value}</div>
                <h3 className="font-semibold text-lg mb-1">{card.title}</h3>
                <p className="text-sm text-gray-600">{card.description}</p>
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Request Statistics</h3>
              {stats?.requests?.byRole ? (
                <div className="space-y-4">
                  {Object.entries(stats.requests.byRole).map(([role, count]) => (
                    <div key={role} className="flex items-center justify-between">
                      <span className="capitalize">{role}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ 
                              width: `${(count / stats.requests.total * 100) || 0}%` 
                            }}
                          ></div>
                        </div>
                        <span className="font-semibold">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600">No request data available</p>
              )}
            </div>
            
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">API Key Statistics</h3>
              {stats?.keys ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Total Keys</span>
                    <span className="font-semibold">{stats.keys.total}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Active Keys</span>
                    <span className="font-semibold">{stats.keys.active}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Suspended Keys</span>
                    <span className="font-semibold">{stats.keys.suspended}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Free Users</span>
                    <span className="font-semibold">{stats.keys.free}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Premium Users</span>
                    <span className="font-semibold">{stats.keys.premium}</span>
                  </div>
                </div>
              ) : (
                <p className="text-gray-600">No key data available</p>
              )}
            </div>
          </div>
          
          {status && (
            <div className="mt-8 card">
              <h3 className="text-xl font-semibold mb-4">System Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Server Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Node Version:</span>
                      <code>{status.server.node_version}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Platform:</span>
                      <code>{status.server.platform}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Architecture:</span>
                      <code>{status.server.arch}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">CPU Cores:</span>
                      <span>{status.server.cpu.cores}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Memory Usage</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Memory:</span>
                      <span>{formatBytes(status.server.memory.total)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Free Memory:</span>
                      <span>{formatBytes(status.server.memory.free)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Heap Used:</span>
                      <span>{formatBytes(status.server.memory.used.heapUsed)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Heap Total:</span>
                      <span>{formatBytes(status.server.memory.used.heapTotal)}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">API Information</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Environment:</span>
                      <span className="badge badge-info">
                        {status.api.environment}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Version:</span>
                      <code>{status.api.version}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Base URL:</span>
                      <code className="truncate max-w-[150px]">
                        {status.api.base_url}
                      </code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Timestamp:</span>
                      <span className="text-xs">
                        {new Date(status.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </Main>
    </>
  );
}