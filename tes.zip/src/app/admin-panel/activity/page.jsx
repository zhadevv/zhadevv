import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaHistory, FaSearch, FaFilter, FaDownload } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getActivityLogs() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/admin/ip_logs`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      return { logs: [], total: 0 };
    }
    
    const data = await response.json();
    return data.success ? data.data : { logs: [], total: 0 };
  } catch (error) {
    return { logs: [], total: 0 };
  }
}

export default async function ActivityPage() {
  const user = await validateAdmin();
  const { logs, total, ip } = await getActivityLogs();

  return (
    <>
      <Header 
        title="Activity Logs" 
        subtitle="View API request history and logs"
        action={
          <div className="flex items-center gap-3">
            <span className="text-sm">
              Showing: <span className="font-bold">{logs.length}</span> logs
            </span>
            <Link href="/admin-panel" className="btn btn-secondary btn-sm">
              Back to Dashboard
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="card mb-8">
            <h3 className="text-xl font-semibold mb-4">
              <FaSearch className="inline mr-2" />
              Search Logs
            </h3>
            <form action="/api/admin/ip_logs" method="GET" className="space-y-4">
              <div className="flex gap-3">
                <input
                  type="text"
                  name="ip"
                  className="input flex-1"
                  placeholder="Filter by IP address (optional)"
                  defaultValue={ip !== 'all' ? ip : ''}
                />
                <input
                  type="hidden"
                  name="apikey"
                  value={process.env.ADMIN_API_KEY}
                />
                <button type="submit" className="btn btn-primary">
                  <FaFilter className="inline mr-2" />
                  Filter Logs
                </button>
              </div>
              
              {ip && ip !== 'all' && (
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">
                    Showing logs for IP: <code className="font-bold">{ip}</code>
                    <a
                      href="/admin-panel/activity"
                      className="ml-3 text-blue-600 hover:underline"
                    >
                      Clear filter
                    </a>
                  </p>
                </div>
              )}
            </form>
          </div>
          
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">
                <FaHistory className="inline mr-2" />
                Recent Activity
              </h3>
              <div className="flex gap-2">
                <button className="btn btn-secondary btn-sm">
                  <FaDownload className="inline mr-1" />
                  Export
                </button>
              </div>
            </div>
            
            {logs.length === 0 ? (
              <div className="text-center py-8">
                <FaHistory className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">No Activity Logs</h4>
                <p className="text-gray-600">
                  {ip && ip !== 'all' 
                    ? `No logs found for IP: ${ip}`
                    : 'No activity logs available yet.'
                  }
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {logs.map((log, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <code className="font-mono text-sm">{log.ip}</code>
                          <span className="text-xs px-2 py-1 rounded bg-gray-100">
                            {log.role}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {new Date(log.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className={`badge ${
                          log.statusCode >= 400 ? 'badge-danger' : 'badge-success'
                        }`}>
                          {log.method} {log.statusCode}
                        </span>
                        <p className="text-xs text-gray-600 mt-1">
                          {log.responseTime}ms
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-sm">
                      <div className="flex items-start gap-2">
                        <span className="font-medium">Endpoint:</span>
                        <code className="text-gray-700 truncate">{log.endpoint}</code>
                      </div>
                      
                      {log.userAgent && (
                        <div className="mt-2">
                          <span className="font-medium">User Agent:</span>
                          <p className="text-gray-600 text-xs truncate">
                            {log.userAgent}
                          </p>
                        </div>
                      )}
                      
                      {log.query && Object.keys(log.query).length > 0 && (
                        <div className="mt-2">
                          <span className="font-medium">Query Params:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {Object.entries(log.query).map(([key, value], i) => (
                              <span key={i} className="text-xs px-2 py-1 bg-gray-100 rounded">
                                {key}: {value}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Request ID: {log.id}</span>
                        <span>API Key: {log.apiKey === 'none' ? 'None' : 'Present'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {logs.length > 0 && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <p className="text-sm text-gray-600">
                      Showing {Math.min(logs.length, 100)} of {total} total logs
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Logs are kept for 30 days and limited to 10,000 entries
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button className="btn btn-secondary btn-sm">
                      Load More
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </Main>
    </>
  );
}