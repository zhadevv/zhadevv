import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaKey, FaUser, FaCalendar, FaBan, FaCheck, FaTimes } from 'react-icons/fa';
import Link from 'next/link';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getApiKeys() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/admin/moderate/total_keys`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      return { keys: [], total: 0 };
    }
    
    const data = await response.json();
    return data.success ? data.data : { keys: [], total: 0 };
  } catch (error) {
    return { keys: [], total: 0 };
  }
}

export default async function KeysPage() {
  const user = await validateAdmin();
  const { keys, total } = await getApiKeys();
  
  const generateForm = (
    <div className="card mb-8">
      <h3 className="text-xl font-semibold mb-4">Generate New API Key</h3>
      <form action="/api/admin/generate_key" method="POST" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              <FaUser className="inline mr-2" />
              Username (Optional)
            </label>
            <input
              type="text"
              name="username"
              className="input"
              placeholder="Leave empty for auto-generate"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">
              <FaKey className="inline mr-2" />
              Role
            </label>
            <select name="role" className="input" required>
              <option value="free">Free (50 requests/minute)</option>
              <option value="premium">Premium (100-200 requests/minute)</option>
            </select>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              Custom Key (Optional)
            </label>
            <input
              type="text"
              name="keys"
              className="input"
              placeholder="Leave empty for auto-generate"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">
              <FaCalendar className="inline mr-2" />
              Active For (Optional)
            </label>
            <input
              type="text"
              name="active"
              className="input"
              placeholder="v1, v2, or leave empty for all"
            />
          </div>
        </div>
        
        <input
          type="hidden"
          name="apikey"
          value={process.env.ADMIN_API_KEY}
        />
        
        <div className="flex gap-3">
          <button type="submit" className="btn btn-primary">
            Generate Key
          </button>
          <button type="reset" className="btn btn-secondary">
            Clear Form
          </button>
        </div>
      </form>
    </div>
  );

  return (
    <>
      <Header 
        title="API Key Management" 
        subtitle="Generate and manage user API keys"
        action={
          <div className="flex items-center gap-3">
            <span className="text-sm">
              Total Keys: <span className="font-bold">{total}</span>
            </span>
            <Link href="/admin-panel" className="btn btn-secondary btn-sm">
              Back to Dashboard
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          {generateForm}
          
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">All API Keys</h3>
              <div className="flex gap-2">
                <button className="btn btn-secondary btn-sm">
                  Refresh
                </button>
              </div>
            </div>
            
            {keys.length === 0 ? (
              <div className="text-center py-8">
                <FaKey className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold mb-2">No API Keys Found</h4>
                <p className="text-gray-600 mb-4">
                  Generate your first API key using the form above.
                </p>
              </div>
            ) : (
              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Key</th>
                      <th>Username</th>
                      <th>Role</th>
                      <th>Status</th>
                      <th>Created</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {keys.slice(0, 10).map((key, index) => (
                      <tr key={index}>
                        <td>
                          <code className="text-xs font-mono">
                            {key.key.substring(0, 16)}...
                          </code>
                        </td>
                        <td>{key.username}</td>
                        <td>
                          <span className={`badge ${
                            key.role === 'premium' ? 'badge-warning' : 'badge-info'
                          }`}>
                            {key.role}
                          </span>
                        </td>
                        <td>
                          {key.suspended ? (
                            <span className="badge badge-danger">
                              <FaBan className="inline mr-1" />
                              Suspended
                            </span>
                          ) : (
                            <span className="badge badge-success">
                              <FaCheck className="inline mr-1" />
                              Active
                            </span>
                          )}
                        </td>
                        <td>
                          <span className="text-sm text-gray-600">
                            {new Date(key.createdAt).toLocaleDateString()}
                          </span>
                        </td>
                        <td>
                          <div className="flex gap-2">
                            {key.suspended ? (
                              <form action="/api/admin/unsuspense_keys" method="POST" className="inline">
                                <input type="hidden" name="keys" value={key.key} />
                                <input type="hidden" name="apikey" value={process.env.ADMIN_API_KEY} />
                                <button
                                  type="submit"
                                  className="btn btn-success btn-xs"
                                >
                                  Unsuspend
                                </button>
                              </form>
                            ) : (
                              <form action="/api/admin/suspended_key" method="POST" className="inline">
                                <input type="hidden" name="keys" value={key.key} />
                                <input type="hidden" name="apikey" value={process.env.ADMIN_API_KEY} />
                                <button
                                  type="submit"
                                  className="btn btn-warning btn-xs"
                                >
                                  Suspend
                                </button>
                              </form>
                            )}
                            
                            {user.role === 'owner' && (
                              <form action="/api/admin/remove_key" method="POST" className="inline">
                                <input type="hidden" name="keys" value={key.key} />
                                <input type="hidden" name="apikey" value={process.env.ADMIN_API_KEY} />
                                <button
                                  type="submit"
                                  className="btn btn-danger btn-xs"
                                  onClick={(e) => {
                                    if (!confirm('Are you sure you want to permanently delete this API key?')) {
                                      e.preventDefault();
                                    }
                                  }}
                                >
                                  <FaTimes className="inline" />
                                </button>
                              </form>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            
            {keys.length > 10 && (
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-600">
                  Showing 10 of {keys.length} keys
                </p>
                <Link
                  href="/admin-panel/keys?page=2"
                  className="mt-2 btn btn-secondary btn-sm"
                >
                  Load More
                </Link>
              </div>
            )}
          </div>
        </section>
      </Main>
    </>
  );
}