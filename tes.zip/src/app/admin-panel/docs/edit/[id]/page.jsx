'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FaSave, FaTimes, FaTrash } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

export default function EditDocsPage() {
  const router = useRouter();
  const params = useParams();
  const { id } = params;
  const [endpointId, setEndpointId] = useState(null);
  
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    content: '',
    published: true,
    parameters: [],
    examples: [],
  });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    fetchDocumentation();
  }, [id]);

  const fetchDocumentation = async () => {
    try {
      const response = await fetch(`/api/admin/pages/${id}`);
      const data = await response.json();
      
      if (data.success) {
        setFormData(data.data);
      } else {
        setError('Failed to load documentation');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    
    try {
      const response = await fetch(`/api/admin/pages/edit/${id}${endpointId ? `/${endpointId}` : ''}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setSuccess(true);
        setTimeout(() => {
          router.push('/admin-panel/docs');
        }, 2000);
      } else {
        setError(data.message || 'Failed to update documentation');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this documentation? This action cannot be undone.')) {
      return;
    }
    
    try {
      const response = await fetch(`/api/admin/pages/delete/${id}${endpointId ? `/${endpointId}` : ''}`, {
        method: 'DELETE',
      });
      
      const data = await response.json();
      
      if (data.success) {
        router.push('/admin-panel/docs');
      } else {
        setError(data.message || 'Failed to delete documentation');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    }
  };

  if (loading) {
    return (
      <>
        <Header title="Edit Documentation" />
        <Main>
          <div className="text-center py-12">
            <div className="loading mx-auto mb-4"></div>
            <p>Loading documentation...</p>
          </div>
        </Main>
      </>
    );
  }

  return (
    <>
      <Header 
        title="Edit Documentation"
        subtitle="Update documentation content"
        action={
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleDelete}
              className="btn btn-danger btn-sm"
            >
              <FaTrash className="inline mr-2" />
              Delete
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="btn btn-secondary btn-sm"
            >
              <FaTimes className="inline mr-2" />
              Cancel
            </button>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="card">
            {error && (
              <div className="alert alert-error mb-6">
                {error}
              </div>
            )}
            
            {success && (
              <div className="alert alert-success mb-6">
                Documentation updated successfully! Redirecting...
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="input"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Slug
                    </label>
                    <input
                      type="text"
                      name="slug"
                      value={formData.slug}
                      onChange={handleChange}
                      className="input"
                      required
                    />
                    <p className="mt-1 text-xs text-gray-600">
                      URL: /docs/{formData.slug}
                    </p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    className="input"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Content
                  </label>
                  <textarea
                    name="content"
                    value={formData.content}
                    onChange={handleChange}
                    className="input min-h-[300px]"
                    required
                  />
                </div>
                
                <div className="flex items-center gap-3">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="published"
                      checked={formData.published}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <span>Published</span>
                  </label>
                </div>
                
                <div className="flex gap-3 pt-6 border-t border-gray-200">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={saving}
                  >
                    {saving ? (
                      <>
                        <div className="loading mr-2"></div>
                        Saving...
                      </>
                    ) : (
                      <>
                        <FaSave className="inline mr-2" />
                        Save Changes
                      </>
                    )}
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => router.back()}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </form>
          </div>
        </section>
      </Main>
    </>
  );
}