import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaFolder, FaFile, FaPlus, FaEdit, FaTrash, FaSearch } from 'react-icons/fa';
import Link from 'next/link';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getDocsCategories() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/admin/pages`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      return { categories: [], total: 0 };
    }
    
    const data = await response.json();
    return data.success ? data.data : { categories: [], total: 0 };
  } catch (error) {
    return { categories: [], total: 0 };
  }
}

export default async function DocsManagementPage() {
  const user = await validateAdmin();
  const { categories, total } = await getDocsCategories();

  return (
    <>
      <Header 
        title="Documentation Management" 
        subtitle="Create and manage API documentation"
        action={
          <div className="flex items-center gap-3">
            <Link href="/admin-panel/docs/create" className="btn btn-primary">
              <FaPlus className="inline mr-2" />
              Create New
            </Link>
            <Link href="/admin-panel" className="btn btn-secondary btn-sm">
              Back to Dashboard
            </Link>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="card mb-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold">Documentation Categories</h3>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search docs..."
                        className="input pl-10"
                      />
                      <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    </div>
                  </div>
                </div>
                
                {categories.length === 0 ? (
                  <div className="text-center py-8">
                    <FaFolder className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h4 className="text-lg font-semibold mb-2">No Documentation Categories</h4>
                    <p className="text-gray-600 mb-4">
                      Create your first documentation category to get started.
                    </p>
                    <Link href="/admin-panel/docs/create" className="btn btn-primary">
                      <FaPlus className="inline mr-2" />
                      Create Category
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {categories.map((category, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg">
                        <div className="p-4 bg-gray-50 border-b border-gray-200">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <FaFolder className="w-5 h-5 text-blue-500" />
                              <div>
                                <h4 className="font-semibold">{category.name}</h4>
                                <p className="text-sm text-gray-600">
                                  {category.endpoints?.length || 0} endpoints
                                </p>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Link
                                href={`/admin-panel/docs/edit/${category.id}`}
                                className="btn btn-secondary btn-xs"
                              >
                                <FaEdit className="inline mr-1" />
                                Edit
                              </Link>
                              <button
                                className="btn btn-danger btn-xs"
                                onClick={() => {
                                  if (confirm(`Delete category "${category.name}" and all its endpoints?`)) {
                                    // Delete action
                                  }
                                }}
                              >
                                <FaTrash className="inline mr-1" />
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                        
                        {category.endpoints && category.endpoints.length > 0 && (
                          <div className="p-4">
                            <div className="space-y-2">
                              {category.endpoints.map((endpoint, epIndex) => (
                                <div key={epIndex} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                                  <div className="flex items-center gap-3">
                                    <FaFile className="w-4 h-4 text-gray-400" />
                                    <div>
                                      <h5 className="font-medium">{endpoint.name}</h5>
                                      <p className="text-xs text-gray-600">
                                        /docs/{category.slug}/{endpoint.slug}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex gap-2">
                                    <Link
                                      href={`/admin-panel/docs/edit/${category.id}/${endpoint.id}`}
                                      className="btn btn-secondary btn-xs"
                                    >
                                      Edit
                                    </Link>
                                    <button
                                      className="btn btn-danger btn-xs"
                                      onClick={() => {
                                        if (confirm(`Delete endpoint "${endpoint.name}"?`)) {
                                          // Delete action
                                        }
                                      }}
                                    >
                                      <FaTrash />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            
                            <div className="mt-4 text-center">
                              <Link
                                href={`/admin-panel/docs/create?category=${category.id}`}
                                className="btn btn-primary btn-sm"
                              >
                                <FaPlus className="inline mr-1" />
                                Add Endpoint
                              </Link>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <span className="font-medium">Total Categories</span>
                      <p className="text-sm text-gray-600">Documentation groups</p>
                    </div>
                    <span className="text-2xl font-bold">{total}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <span className="font-medium">Total Endpoints</span>
                      <p className="text-sm text-gray-600">Documentation pages</p>
                    </div>
                    <span className="text-2xl font-bold">
                      {categories.reduce((sum, cat) => sum + (cat.endpoints?.length || 0), 0)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <span className="font-medium">Live Pages</span>
                      <p className="text-sm text-gray-600">Publicly accessible</p>
                    </div>
                    <span className="text-2xl font-bold">
                      {categories.reduce((sum, cat) => sum + (cat.endpoints?.filter(e => e.published)?.length || 0), 0)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Link
                    href="/admin-panel/docs/create?type=category"
                    className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <FaFolder className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Create Category</h4>
                        <p className="text-sm text-gray-600">New documentation group</p>
                      </div>
                    </div>
                    <span className="text-blue-600">→</span>
                  </Link>
                  
                  <Link
                    href="/admin-panel/docs/create?type=endpoint"
                    className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <FaFile className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Create Endpoint</h4>
                        <p className="text-sm text-gray-600">New documentation page</p>
                      </div>
                    </div>
                    <span className="text-green-600">→</span>
                  </Link>
                  
                  <Link
                    href="/docs"
                    target="_blank"
                    className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <FaSearch className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">View Live Docs</h4>
                        <p className="text-sm text-gray-600">Preview documentation</p>
                      </div>
                    </div>
                    <span className="text-purple-600">→</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}