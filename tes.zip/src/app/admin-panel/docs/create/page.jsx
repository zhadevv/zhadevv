'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { FaSave, FaTimes, FaCode, FaList, FaInfoCircle } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

export default function CreateDocsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const type = searchParams.get('type') || 'endpoint';
  const categoryId = searchParams.get('category');
  
  const [formData, setFormData] = useState({
    type: type,
    categoryId: categoryId || '',
    name: '',
    slug: '',
    description: '',
    content: '',
    published: true,
    parameters: [{ name: '', type: 'string', required: true, description: '' }],
    examples: [{ title: '', code: '', description: '' }],
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleArrayChange = (field, index, key, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => 
        i === index ? { ...item, [key]: value } : item
      ),
    }));
  };

  const addArrayItem = (field, template) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], template],
    }));
  };

  const removeArrayItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index),
    }));
  };

  const generateSlug = (text) => {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const handleNameChange = (e) => {
    const name = e.target.value;
    setFormData(prev => ({
      ...prev,
      name: name,
      slug: generateSlug(name),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const apiUrl = formData.type === 'category' 
        ? '/api/admin/pages/create/category'
        : `/api/admin/pages/create/${formData.categoryId}/endpoint`;
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const data = await response.json();
      
      if (data.success) {
        setSuccess(true);
        setTimeout(() => {
          router.push('/admin-panel/docs');
        }, 2000);
      } else {
        setError(data.message || 'Failed to create documentation');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header 
        title={`Create ${formData.type === 'category' ? 'Category' : 'Endpoint'}`}
        subtitle="Add new documentation"
        action={
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => router.back()}
              className="btn btn-secondary btn-sm"
            >
              <FaTimes className="inline mr-2" />
              Cancel
            </button>
          </div>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="card">
            {error && (
              <div className="alert alert-error mb-6">
                {error}
              </div>
            )}
            
            {success && (
              <div className="alert alert-success mb-6">
                Documentation created successfully! Redirecting...
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Type
                    </label>
                    <div className="flex gap-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="type"
                          value="category"
                          checked={formData.type === 'category'}
                          onChange={handleChange}
                          className="mr-2"
                        />
                        <span>Category</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="type"
                          value="endpoint"
                          checked={formData.type === 'endpoint'}
                          onChange={handleChange}
                          className="mr-2"
                        />
                        <span>Endpoint</span>
                      </label>
                    </div>
                  </div>
                  
                  {formData.type === 'endpoint' && (
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Category ID
                      </label>
                      <input
                        type="text"
                        name="categoryId"
                        value={formData.categoryId}
                        onChange={handleChange}
                        className="input"
                        required
                        placeholder="Enter category ID"
                      />
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleNameChange}
                      className="input"
                      required
                      placeholder="e.g., Getting Started"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Slug
                    </label>
                    <input
                      type="text"
                      name="slug"
                      value={formData.slug}
                      onChange={handleChange}
                      className="input"
                      required
                      placeholder="e.g., getting-started"
                    />
                    <p className="mt-1 text-xs text-gray-600">
                      This will be used in the URL: /docs/{formData.slug}
                    </p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    className="input"
                    placeholder="Brief description"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Content
                  </label>
                  <textarea
                    name="content"
                    value={formData.content}
                    onChange={handleChange}
                    className="input min-h-[200px]"
                    required
                    placeholder="Documentation content (Markdown supported)"
                  />
                </div>
                
                {formData.type === 'endpoint' && (
                  <>
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">
                          <FaList className="inline mr-2" />
                          Parameters
                        </h3>
                        <button
                          type="button"
                          onClick={() => addArrayItem('parameters', { name: '', type: 'string', required: true, description: '' })}
                          className="btn btn-secondary btn-sm"
                        >
                          Add Parameter
                        </button>
                      </div>
                      
                      <div className="space-y-4">
                        {formData.parameters.map((param, index) => (
                          <div key={index} className="p-4 border border-gray-200 rounded-lg">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-3">
                              <div>
                                <label className="block text-xs font-medium mb-1">
                                  Name
                                </label>
                                <input
                                  type="text"
                                  value={param.name}
                                  onChange={(e) => handleArrayChange('parameters', index, 'name', e.target.value)}
                                  className="input"
                                  placeholder="e.g., apikey"
                                />
                              </div>
                              
                              <div>
                                <label className="block text-xs font-medium mb-1">
                                  Type
                                </label>
                                <select
                                  value={param.type}
                                  onChange={(e) => handleArrayChange('parameters', index, 'type', e.target.value)}
                                  className="input"
                                >
                                  <option value="string">String</option>
                                  <option value="number">Number</option>
                                  <option value="boolean">Boolean</option>
                                  <option value="array">Array</option>
                                  <option value="object">Object</option>
                                </select>
                              </div>
                              
                              <div>
                                <label className="block text-xs font-medium mb-1">
                                  Required
                                </label>
                                <select
                                  value={param.required}
                                  onChange={(e) => handleArrayChange('parameters', index, 'required', e.target.value === 'true')}
                                  className="input"
                                >
                                  <option value="true">Required</option>
                                  <option value="false">Optional</option>
                                </select>
                              </div>
                              
                              <div className="flex items-end">
                                <button
                                  type="button"
                                  onClick={() => removeArrayItem('parameters', index)}
                                  className="btn btn-danger btn-sm"
                                >
                                  Remove
                                </button>
                              </div>
                            </div>
                            
                            <div>
                              <label className="block text-xs font-medium mb-1">
                                Description
                              </label>
                              <input
                                type="text"
                                value={param.description}
                                onChange={(e) => handleArrayChange('parameters', index, 'description', e.target.value)}
                                className="input"
                                placeholder="Parameter description"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">
                          <FaCode className="inline mr-2" />
                          Examples
                        </h3>
                        <button
                          type="button"
                          onClick={() => addArrayItem('examples', { title: '', code: '', description: '' })}
                          className="btn btn-secondary btn-sm"
                        >
                          Add Example
                        </button>
                      </div>
                      
                      <div className="space-y-4">
                        {formData.examples.map((example, index) => (
                          <div key={index} className="p-4 border border-gray-200 rounded-lg">
                            <div className="mb-3">
                              <label className="block text-xs font-medium mb-1">
                                Title
                              </label>
                              <input
                                type="text"
                                value={example.title}
                                onChange={(e) => handleArrayChange('examples', index, 'title', e.target.value)}
                                className="input"
                                placeholder="e.g., JavaScript Example"
                              />
                            </div>
                            
                            <div className="mb-3">
                              <label className="block text-xs font-medium mb-1">
                                Code
                              </label>
                              <textarea
                                value={example.code}
                                onChange={(e) => handleArrayChange('examples', index, 'code', e.target.value)}
                                className="input min-h-[100px] font-mono text-sm"
                                placeholder="Code example"
                              />
                            </div>
                            
                            <div className="mb-3">
                              <label className="block text-xs font-medium mb-1">
                                Description
                              </label>
                              <input
                                type="text"
                                value={example.description}
                                onChange={(e) => handleArrayChange('examples', index, 'description', e.target.value)}
                                className="input"
                                placeholder="Example description"
                              />
                            </div>
                            
                            <div className="text-right">
                              <button
                                type="button"
                                onClick={() => removeArrayItem('examples', index)}
                                className="btn btn-danger btn-sm"
                              >
                                Remove Example
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
                
                <div className="flex items-center gap-3">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="published"
                      checked={formData.published}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <span>Publish immediately</span>
                  </label>
                </div>
                
                <div className="flex gap-3 pt-6 border-t border-gray-200">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <div className="loading mr-2"></div>
                        Creating...
                      </>
                    ) : (
                      <>
                        <FaSave className="inline mr-2" />
                        Create {formData.type === 'category' ? 'Category' : 'Endpoint'}
                      </>
                    )}
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => router.back()}
                    className="btn btn-secondary"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </form>
          </div>
        </section>
      </Main>
    </>
  );
}