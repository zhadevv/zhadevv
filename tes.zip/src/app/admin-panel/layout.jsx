import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import BetterAuth from '@/components/BetterAuth';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return true;
  } catch (error) {
    redirect('/auth/signin');
  }
}

export default async function AdminLayout({ children }) {
  await validateAdmin();
  
  return (
    <BetterAuth requireAuth>
      {children}
    </BetterAuth>
  );
}