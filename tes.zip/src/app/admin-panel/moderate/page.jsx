import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { FaBan, FaCheck, FaEye, FaTrash } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function validateAdmin() {
  const cookieStore = await cookies();
  const token = cookieStore.get('auth_token')?.value;
  
  if (!token) {
    redirect('/auth/signin');
  }
  
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/auth/me`, {
      headers: {
        'Cookie': `auth_token=${token}`,
      },
      cache: 'no-store',
    });
    
    if (!response.ok) {
      redirect('/auth/signin');
    }
    
    const data = await response.json();
    
    if (!data.success || data.data.user.role !== 'owner') {
      redirect('/');
    }
    
    return data.data.user;
  } catch (error) {
    redirect('/auth/signin');
  }
}

async function getBannedIps() {
  try {
    const response = await fetch(`${process.env.NEXT_URL}/api/admin/moderate/banned-ips`, {
      cache: 'no-store',
    });
    
    if (!response.ok) {
      return { bannedIps: [], total: 0 };
    }
    
    const data = await response.json();
    return data.success ? data.data : { bannedIps: [], total: 0 };
  } catch (error) {
    return { bannedIps: [], total: 0 };
  }
}

export default async function ModeratePage() {
  const user = await validateAdmin();
  const { bannedIps, total } = await getBannedIps();

  return (
    <>
      <Header 
        title="Moderation Panel" 
        subtitle="Manage IP bans and user moderation"
        action={
          <Link href="/admin-panel" className="btn btn-secondary btn-sm">
            Back to Dashboard
          </Link>
        }
      />
      
      <Main>
        <section className="py-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Ban IP Address</h3>
              <form action="/api/admin/moderate" method="POST" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    IP Address
                  </label>
                  <input
                    type="text"
                    name="ban"
                    className="input"
                    placeholder="e.g., 192.168.1.1"
                    required
                  />
                  <p className="mt-1 text-sm text-gray-600">
                    Enter the IP address to ban
                  </p>
                </div>
                
                <input
                  type="hidden"
                  name="apikey"
                  value={process.env.ADMIN_API_KEY}
                />
                
                <button type="submit" className="btn btn-danger w-full">
                  <FaBan className="inline mr-2" />
                  Ban IP Address
                </button>
              </form>
              
              <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">
                  <FaBan className="inline mr-2" />
                  Warning
                </h4>
                <p className="text-sm text-red-700">
                  Banned IPs will be blocked from accessing the API for 7 days.
                  Use this feature carefully.
                </p>
              </div>
            </div>
            
            <div className="card">
              <h3 className="text-xl font-semibold mb-4">Unban IP Address</h3>
              <form action="/api/admin/moderate" method="POST" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    IP Address
                  </label>
                  <input
                    type="text"
                    name="unban"
                    className="input"
                    placeholder="e.g., 192.168.1.1"
                    required
                  />
                  <p className="mt-1 text-sm text-gray-600">
                    Enter the IP address to unban
                  </p>
                </div>
                
                <input
                  type="hidden"
                  name="apikey"
                  value={process.env.ADMIN_API_KEY}
                />
                
                <button type="submit" className="btn btn-success w-full">
                  <FaCheck className="inline mr-2" />
                  Unban IP Address
                </button>
              </form>
              
              <div className="mt-6">
                <h4 className="font-semibold mb-3">Currently Banned IPs</h4>
                {bannedIps.length === 0 ? (
                  <p className="text-gray-600 text-sm">
                    No IP addresses are currently banned.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {bannedIps.slice(0, 5).map((ban, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                          <code className="font-mono">{ban.ip}</code>
                          <p className="text-xs text-gray-600">
                            Banned {new Date(ban.data.bannedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <form action="/api/admin/moderate" method="POST" className="inline">
                          <input type="hidden" name="unban" value={ban.ip} />
                          <input type="hidden" name="apikey" value={process.env.ADMIN_API_KEY} />
                          <button
                            type="submit"
                            className="btn btn-success btn-xs"
                            title="Unban IP"
                          >
                            <FaCheck />
                          </button>
                        </form>
                      </div>
                    ))}
                    
                    {bannedIps.length > 5 && (
                      <p className="text-sm text-gray-600 text-center">
                        ... and {bannedIps.length - 5} more banned IPs
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-8 card">
            <h3 className="text-xl font-semibold mb-4">IP Logs</h3>
            <form action="/api/admin/ip_logs" method="GET" className="mb-6">
              <div className="flex gap-3">
                <input
                  type="text"
                  name="ip"
                  className="input flex-1"
                  placeholder="Search by IP address (optional)"
                />
                <input
                  type="hidden"
                  name="apikey"
                  value={process.env.ADMIN_API_KEY}
                />
                <button type="submit" className="btn btn-primary">
                  <FaEye className="inline mr-2" />
                  Search Logs
                </button>
              </div>
            </form>
            
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>Note:</strong> IP logs show the last 10,000 requests made to the API.
                Logs are refreshed every 5 minutes.
              </p>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}