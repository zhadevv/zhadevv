import { FaCreditCard, FaPaypal, FaMoneyBillWave, FaBuilding, FaGlobe } from 'react-icons/fa';
import { SiGopay, SiDana, SiOvo } from 'react-icons/si';
import Header from '@/components/Header';
import Main from '@/components/Main';

export default function DonatePage() {
  const donationMethods = [
    {
      name: 'Dana',
      icon: <SiDana className="w-8 h-8" />,
      details: '0888-8888-8888',
      color: 'bg-blue-100 text-blue-800',
    },
    {
      name: 'OVO',
      icon: <SiOvo className="w-8 h-8" />,
      details: '0888-8888-8888',
      color: 'bg-purple-100 text-purple-800',
    },
    {
      name: 'GoPay',
      icon: <SiGopay className="w-8 h-8" />,
      details: '0888-8888-8888',
      color: 'bg-green-100 text-green-800',
    },
    {
      name: 'Saweria',
      icon: <FaMoneyBillWave className="w-8 h-8" />,
      details: 'saweria.co/zhadevv',
      color: 'bg-yellow-100 text-yellow-800',
      link: 'https://saweria.co/zhadevv',
    },
    {
      name: 'Trakteer',
      icon: <FaCreditCard className="w-8 h-8" />,
      details: 'trakteer.id/zhadevv',
      color: 'bg-red-100 text-red-800',
      link: 'https://trakteer.id/zhadevv',
    },
    {
      name: 'Bank BCA',
      icon: <FaBuilding className="w-8 h-8" />,
      details: '888-888-8888',
      subdetails: 'a/n zhadevv',
      color: 'bg-indigo-100 text-indigo-800',
    },
    {
      name: 'Wise',
      icon: <FaGlobe className="w-8 h-8" />,
      details: 'International Transfer',
      subdetails: 'contact@zhadev.my.id',
      color: 'bg-teal-100 text-teal-800',
    },
    {
      name: 'PayPal',
      icon: <FaPaypal className="w-8 h-8" />,
      details: 'paypal.me/zhadevv',
      color: 'bg-blue-100 text-blue-800',
      link: 'https://paypal.me/zhadevv',
    },
  ];

  const benefits = [
    'Premium API Key with higher rate limits',
    'Priority support and feature requests',
    'Access to beta features',
    'Your name in the supporters list',
    'Custom API endpoints (on request)',
  ];

  return (
    <>
      <Header 
        title="Support zhadev API" 
        subtitle="Help us maintain and improve the API"
      />
      
      <Main>
        <section className="py-8">
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">Why Donate?</h2>
            <div className="space-y-4 text-gray-700">
              <p>
                zhadev API is maintained by a single developer with a passion for 
                creating useful tools for the community. Your donations help cover:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Server and hosting costs</li>
                <li>Domain and SSL certificates</li>
                <li>Development and maintenance time</li>
                <li>API monitoring and uptime services</li>
                <li>Future feature development</li>
              </ul>
              <p>
                Every donation, no matter the size, helps ensure the API remains 
                available and continues to improve.
              </p>
            </div>
          </div>

          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-6">Donation Methods</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {donationMethods.map((method, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`p-2 rounded-lg ${method.color}`}>
                      {method.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{method.name}</h3>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <p className="font-mono text-sm">{method.details}</p>
                    {method.subdetails && (
                      <p className="text-sm text-gray-600">{method.subdetails}</p>
                    )}
                  </div>
                  
                  {method.link && (
                    <a
                      href={method.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-3 btn btn-primary btn-sm w-full"
                    >
                      Donate via {method.name}
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h2 className="text-2xl font-bold mb-6">Donor Benefits</h2>
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="text-green-500 mt-1">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> After making a donation, please contact us via email 
                or WhatsApp to receive your premium API key and benefits.
              </p>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}