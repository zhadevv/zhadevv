import { Inter } from 'next/font/google';
import './globals.css';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import BetterAuth from '@/components/BetterAuth';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'zhadev API - Powerful Content API',
  description: 'REST API for anime, donghua, and dracin content with comprehensive features',
  keywords: ['API', 'anime', 'donghua', 'dracin', 'REST', 'zhadev'],
  authors: [{ name: 'zhadevv' }],
  openGraph: {
    title: 'zhadev API',
    description: 'Powerful REST API for anime, donghua, and dracin content',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'zhadev API',
    description: 'Powerful REST API for anime, donghua, and dracin content',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="stylesheet" href="/css/style.css" />
        <link rel="stylesheet" href="/css/style-dark.css" />
        <script src="/js/main.js" defer></script>
        <link rel="icon" href="/zhadev/assets/16x16.png" sizes="16x16" />
        <link rel="icon" href="/zhadev/assets/32x32.png" sizes="32x32" />
        <link rel="icon" href="/zhadev/assets/64x64.png" sizes="64x64" />
        <link rel="icon" href="/zhadev/assets/128x128.png" sizes="128x128" />
        <link rel="icon" href="/zhadev/assets/256x256.png" sizes="256x256" />
        <link rel="icon" href="/zhadev/assets/512x512.png" sizes="512x512" />
        <link rel="apple-touch-icon" href="/zhadev/assets/1080x1080.png" />
        <meta name="theme-color" content="#2563eb" />
      </head>
      <body className={`${inter.className} min-h-screen flex flex-col`}>
        <Navigation />
        <div className="flex-grow">
          {children}
        </div>
        <Footer />
      </body>
    </html>
  );
}