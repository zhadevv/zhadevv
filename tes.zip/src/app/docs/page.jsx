import { notFound } from 'next/navigation';
import { FaBook, FaCode, FaQuestionCircle, FaExternalLinkAlt } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

async function getPageContent(category, endpoint) {
  try {
    const response = await fetch(
      `${process.env.NEXT_URL}/api/admin/pages/${category}/${endpoint}`,
      { cache: 'no-store' }
    );
    
    if (!response.ok) {
      return null;
    }
    
    return await response.json();
  } catch (error) {
    return null;
  }
}

async function getDefaultDocs() {
  const defaultCategories = {
    'introduction': {
      title: 'Introduction to zhadev API',
      content: `
        <h2>Welcome to zhadev API</h2>
        <p>zhadev API provides programmatic access to anime, donghua, and dracin content through a simple REST interface.</p>
        
        <h3>Features</h3>
        <ul>
          <li><strong>Comprehensive Coverage:</strong> Access to thousands of anime, donghua, and dracin series</li>
          <li><strong>High Performance:</strong> Optimized for speed with Redis caching and CDN support</li>
          <li><strong>Developer Friendly:</strong> Clean REST API with consistent response format</li>
          <li><strong>Rate Limiting:</strong> Flexible rate limits for different user tiers</li>
          <li><strong>Real-time Updates:</strong> Latest episodes and series updates</li>
        </ul>
        
        <h3>Getting Started</h3>
        <p>To start using the API, you don't need an API key for basic usage. However, getting an API key provides higher rate limits and access to premium features.</p>
        
        <div class="alert alert-info">
          <strong>Note:</strong> The API is free to use with rate limits. For higher limits and premium features, consider getting a premium API key.
        </div>
      `,
      parameters: [
        { name: 'apikey', type: 'string', required: false, description: 'Your API key (optional for basic usage)' },
        { name: 'page', type: 'integer', required: false, description: 'Page number for paginated endpoints' },
      ],
      examples: [
        {
          title: 'Basic Request',
          code: `curl -X GET "https://api.zhadev.my.id/api/v1/health"`,
          description: 'Check API health status'
        },
        {
          title: 'With API Key',
          code: `curl -X GET "https://api.zhadev.my.id/api/v1/anime/home" \\
  -H "X-API-Key: YOUR_API_KEY"`,
          description: 'Get anime homepage with API key authentication'
        }
      ]
    },
    'authentication': {
      title: 'API Authentication',
      content: `
        <h2>Authentication Methods</h2>
        <p>zhadev API supports multiple authentication methods depending on your use case.</p>
        
        <h3>API Key Authentication</h3>
        <p>API keys are the primary authentication method. You can include your API key in requests using:</p>
        
        <h4>As a Header</h4>
        <pre><code>X-API-Key: YOUR_API_KEY</code></pre>
        
        <h4>As a Query Parameter</h4>
        <pre><code>?apikey=YOUR_API_KEY</code></pre>
        
        <h3>Rate Limits by Key Type</h3>
        <table class="table">
          <thead>
            <tr>
              <th>Key Type</th>
              <th>Requests/Minute</th>
              <th>Requests/Month</th>
              <th>Features</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Guest (No Key)</td>
              <td>25</td>
              <td>1000</td>
              <td>Basic access only</td>
            </tr>
            <tr>
              <td>Free Key</td>
              <td>50</td>
              <td>5000</td>
              <td>Standard features</td>
            </tr>
            <tr>
              <td>Premium Key</td>
              <td>100-200</td>
              <td>Unlimited</td>
              <td>All features + priority</td>
            </tr>
          </tbody>
        </table>
        
        <div class="alert alert-warning">
          <strong>Important:</strong> Keep your API keys secure. Do not expose them in client-side code or public repositories.
        </div>
      `,
      examples: [
        {
          title: 'JavaScript Fetch with API Key',
          code: `const response = await fetch('https://api.zhadev.my.id/api/v1/anime/home', {
  headers: {
    'X-API-Key': 'YOUR_API_KEY'
  }
});
const data = await response.json();`,
          description: 'Example using Fetch API with headers'
        }
      ]
    },
    'anime-api': {
      title: 'Anime API Endpoints',
      content: `
        <h2>Anime API Documentation</h2>
        <p>Access anime content from various sources with comprehensive metadata.</p>
        
        <h3>Available Endpoints</h3>
        
        <h4>1. Get Anime Homepage</h4>
        <pre><code>GET /api/v1/anime/home</code></pre>
        <p>Returns the anime homepage with latest releases, popular series, and recommendations.</p>
        
        <h4>2. Search Anime</h4>
        <pre><code>GET /api/v1/anime/search?s=query</code></pre>
        <p>Search for anime series by title.</p>
        
        <h4>3. Get Anime Details</h4>
        <pre><code>GET /api/v1/anime/detail/:slug</code></pre>
        <p>Get detailed information about a specific anime series.</p>
        
        <h4>4. Watch Episode</h4>
        <pre><code>GET /api/v1/anime/watch/:slug/:episode</code></pre>
        <p>Get streaming information for a specific episode.</p>
        
        <h3>Response Format</h3>
        <p>All endpoints return a consistent JSON response format:</p>
        <pre><code>{
  "status": 200,
  "success": true,
  "author": "zhadevv",
  "data": {
    // Endpoint-specific data
  },
  "message": null
}</code></pre>
      `,
      parameters: [
        { name: 's', type: 'string', required: true, description: 'Search query for search endpoint' },
        { name: 'slug', type: 'string', required: true, description: 'Anime series slug' },
        { name: 'episode', type: 'string', required: true, description: 'Episode number' },
        { name: 'page', type: 'integer', required: false, description: 'Page number for paginated results' },
      ],
      examples: [
        {
          title: 'Get Anime Details',
          code: `curl -X GET "https://api.zhadev.my.id/api/v1/anime/detail/jujutsu-kaisen"`,
          description: 'Get details for Jujutsu Kaisen anime'
        },
        {
          title: 'Search Anime',
          code: `curl -X GET "https://api.zhadev.my.id/api/v1/anime/search?s=naruto"`,
          description: 'Search for Naruto anime series'
        }
      ]
    },
    'donghua-api': {
      title: 'Donghua API Endpoints',
      content: `
        <h2>Donghua (Chinese Anime) API</h2>
        <p>Access Chinese anime (donghua) content with similar structure to the Anime API.</p>
        
        <h3>Key Differences</h3>
        <ul>
          <li>Focused on Chinese animation content</li>
          <li>Additional metadata specific to donghua</li>
          <li>Chinese language support</li>
          <li>Regional content categorization</li>
        </ul>
        
        <h3>Available Endpoints</h3>
        <pre><code>GET /api/v1/donghua/home          # Donghua homepage
GET /api/v1/donghua/search       # Search donghua
GET /api/v1/donghua/detail/:slug # Donghua details
GET /api/v1/donghua/watch/:slug/:episode # Watch donghua episode</code></pre>
      `
    },
    'dracin-api': {
      title: 'Dracin API Endpoints',
      content: `
        <h2>Dracin (Chinese Drama) API</h2>
        <p>Access Chinese drama content with multi-language support.</p>
        
        <h3>Language Support</h3>
        <p>The Dracin API supports multiple languages through region codes:</p>
        <ul>
          <li><code>id</code> - Indonesian</li>
          <li><code>en</code> - English</li>
          <li><code>zh</code> - Chinese</li>
          <li><code>ko</code> - Korean</li>
          <li><code>ja</code> - Japanese</li>
          <li>And more...</li>
        </ul>
        
        <h3>Endpoint Structure</h3>
        <pre><code>GET /api/v1/dracin/{region}/home     # Homepage for region
GET /api/v1/dracin/{region}/search  # Search in region
GET /api/v1/dracin/{region}/series/:slug # Series details
GET /api/v1/dracin/{region}/watch/:slug  # Watch episode</code></pre>
      `
    }
  };
  
  return defaultCategories;
}

export default async function DynamicDocsPage({ params }) {
  const { docs } = await params;
  const [category, endpoint] = docs || [];
  
  if (!category) {
    notFound();
  }

  const defaultDocs = await getDefaultDocs();
  const pageData = endpoint 
    ? await getPageContent(category, endpoint)
    : defaultDocs[category] || null;

  if (!pageData) {
    notFound();
  }

  const { title, content, parameters = [], examples = [] } = pageData;

  const sidebarItems = [
    { id: 'introduction', name: 'Introduction', icon: <FaBook /> },
    { id: 'authentication', name: 'Authentication', icon: <FaBook /> },
    { id: 'anime-api', name: 'Anime API', icon: <FaCode /> },
    { id: 'donghua-api', name: 'Donghua API', icon: <FaCode /> },
    { id: 'dracin-api', name: 'Dracin API', icon: <FaCode /> },
  ];

  return (
    <>
      <Header 
        title={title || 'API Documentation'}
        subtitle="Complete API reference and guides"
      />
      
      <Main sidebar={
        <div className="card">
          <nav className="space-y-2">
            {sidebarItems.map((item) => (
              <a
                key={item.id}
                href={`/docs/${item.id}`}
                className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  category === item.id 
                    ? 'bg-primary-color text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {item.icon}
                <span>{item.name}</span>
              </a>
            ))}
            
            <div className="pt-4 mt-4 border-t border-gray-200">
              <a
                href="/donate"
                className="flex items-center gap-3 p-3 text-green-700 hover:bg-green-50 rounded-lg transition-colors"
              >
                <FaExternalLinkAlt />
                <span>Get Premium API Key</span>
              </a>
              
              <a
                href="/contact"
                className="flex items-center gap-3 p-3 text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <FaQuestionCircle />
                <span>Need Help?</span>
              </a>
            </div>
          </nav>
        </div>
      }>
        <div className="space-y-8">
          <div className="card">
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: content }} />
          </div>

          {parameters.length > 0 && (
            <div className="card">
              <h2 className="text-2xl font-bold mb-4">Parameters</h2>
              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Type</th>
                      <th>Required</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parameters.map((param, index) => (
                      <tr key={index}>
                        <td className="font-mono text-sm">{param.name}</td>
                        <td>
                          <span className="badge badge-info">
                            {param.type}
                          </span>
                        </td>
                        <td>
                          {param.required ? (
                            <span className="badge badge-danger">Required</span>
                          ) : (
                            <span className="badge badge-success">Optional</span>
                          )}
                        </td>
                        <td className="text-sm text-gray-600">
                          {param.description}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {examples.length > 0 && (
            <div className="card">
              <h2 className="text-2xl font-bold mb-4">Examples</h2>
              <div className="space-y-4">
                {examples.map((example, index) => (
                  <details key={index} className="border border-gray-200 rounded-lg" open={index === 0}>
                    <summary className="p-4 cursor-pointer font-medium flex items-center justify-between">
                      <span>{example.title}</span>
                      <span className="text-sm text-gray-500">Click to {index === 0 ? 'collapse' : 'expand'}</span>
                    </summary>
                    <div className="p-4 border-t border-gray-200">
                      <div className="bg-gray-900 text-gray-300 rounded p-4 font-mono text-sm overflow-x-auto">
                        <pre className="whitespace-pre-wrap">{example.code}</pre>
                      </div>
                      {example.description && (
                        <p className="mt-3 text-sm text-gray-600">
                          {example.description}
                        </p>
                      )}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          )}

          <div className="card">
            <div className="text-center p-6">
              <h3 className="text-lg font-semibold mb-3">Ready to Start Building?</h3>
              <p className="text-gray-600 mb-4">
                Start using the API today. No registration required for basic usage.
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <a
                  href="/docs/introduction"
                  className="btn btn-primary"
                >
                  Get Started Guide
                </a>
                <a
                  href="/donate"
                  className="btn btn-success"
                >
                  Get Premium Key
                </a>
                <a
                  href="/contact"
                  className="btn btn-secondary"
                >
                  Contact Support
                </a>
              </div>
            </div>
          </div>
        </div>
      </Main>
    </>
  );
}