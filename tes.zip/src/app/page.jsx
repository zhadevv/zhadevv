import Link from 'next/link';
import { FaBolt, FaShieldAlt, FaRocket, FaCode, FaServer, FaChartLine } from 'react-icons/fa';
import Header from '@/components/Header';
import Main from '@/components/Main';

export default function HomePage() {
  const features = [
    {
      icon: <FaBolt className="w-8 h-8" />,
      title: 'High Performance',
      description: 'Built with Node.js and optimized for speed with Redis caching',
    },
    {
      icon: <FaShieldAlt className="w-8 h-8" />,
      title: 'Secure & Reliable',
      description: 'Rate limiting, API key authentication, and comprehensive logging',
    },
    {
      icon: <FaRocket className="w-8 h-8" />,
      title: 'Scalable',
      description: 'Handles thousands of requests per second with ease',
    },
    {
      icon: <FaCode className="w-8 h-8" />,
      title: 'Developer Friendly',
      description: 'Clean REST API with comprehensive documentation',
    },
    {
      icon: <FaServer className="w-8 h-8" />,
      title: 'Multiple Sources',
      description: 'Anime, Donghua, and Dracin content from various sources',
    },
    {
      icon: <FaChartLine className="w-8 h-8" />,
      title: 'Analytics',
      description: 'Detailed request analytics and usage statistics',
    },
  ];

  const endpoints = [
    {
      category: 'Anime',
      count: '12+ endpoints',
      color: 'bg-blue-100 text-blue-800',
    },
    {
      category: 'Donghua',
      count: '12+ endpoints',
      color: 'bg-purple-100 text-purple-800',
    },
    {
      category: 'Dracin',
      count: '7+ endpoints',
      color: 'bg-green-100 text-green-800',
    },
    {
      category: 'Health',
      count: '2+ endpoints',
      color: 'bg-yellow-100 text-yellow-800',
    },
  ];

  return (
    <>
      <Header 
        title="zhadev API" 
        subtitle="Powerful REST API for anime, donghua, and dracin content"
        action={
          <Link href="/docs" className="btn btn-primary">
            Get Started
          </Link>
        }
      />
      
      <Main>
        <section className="py-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose zhadev API?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              A comprehensive API solution for developers building anime, donghua, 
              and dracin-related applications with enterprise-grade features.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {features.map((feature, index) => (
              <div key={index} className="card">
                <div className="flex items-start gap-4">
                  <div className="text-primary-color">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="card">
            <h3 className="text-xl font-semibold mb-6">Available Endpoints</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {endpoints.map((endpoint, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-semibold mb-2">{endpoint.category}</h4>
                  <span className={`badge ${endpoint.color}`}>
                    {endpoint.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="card">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">Get Started in Minutes</h3>
                <p className="text-gray-600 mb-6">
                  Start using our API with just a few lines of code. No registration 
                  required for basic usage.
                </p>
                
                <div className="bg-gray-900 text-gray-300 rounded-lg p-4 font-mono text-sm">
                  <pre>
                    <code>
                      <span className="text-blue-400">curl</span>{' '}
                      <span className="text-green-400">-X</span>{' '}
                      <span className="text-yellow-400">GET</span>{' '}
                      <span className="text-purple-400">"https://api.zhadev.my.id/api/v1/health"</span>
                    </code>
                  </pre>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4">Need More Power?</h3>
                <p className="text-gray-600 mb-6">
                  Get premium API keys for higher rate limits and advanced features.
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <span className="font-semibold">Free Tier</span>
                      <p className="text-sm text-gray-600">50 requests/minute</p>
                    </div>
                    <span className="badge badge-success">Free</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <span className="font-semibold">Premium Tier</span>
                      <p className="text-sm text-gray-600">Up to 200 requests/minute</p>
                    </div>
                    <Link href="/donate" className="btn btn-primary btn-sm">
                      Get Premium
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Start Building?</h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Join thousands of developers using zhadev API to power their applications.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/docs" className="btn btn-primary">
                View Documentation
              </Link>
              <Link href="/about" className="btn btn-secondary">
                Learn More
              </Link>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}