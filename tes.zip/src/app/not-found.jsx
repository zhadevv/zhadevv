import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header';

export default function NotFound() {
  return (
    <>
      <Header title="Page Not Found" />
      
      <main className="container py-12">
        <div className="text-center">
          <div className="mb-8">
            <Image
              src="/zhadev/assets/404.png"
              alt="404 Not Found"
              width={300}
              height={300}
              className="mx-auto"
            />
          </div>
          
          <h1 className="text-4xl font-bold mb-4">404 - Page Not Found</h1>
          <p className="text-lg text-gray-600 mb-8 max-w-md mx-auto">
            The page you are looking for might have been removed, had its name changed, 
            or is temporarily unavailable.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/" className="btn btn-primary">
              Go Home
            </Link>
            <Link href="/docs" className="btn btn-secondary">
              View Documentation
            </Link>
          </div>
        </div>
      </main>
    </>
  );
}