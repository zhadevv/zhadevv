import Header from '@/components/Header';
import Main from '@/components/Main';

export default function PrivacyPage() {
  return (
    <>
      <Header 
        title="Privacy Policy" 
        subtitle="How we handle your data"
      />
      
      <Main>
        <section className="py-8">
          <div className="card">
            <div className="prose max-w-none">
              <h2>Privacy Policy for zhadev API</h2>
              <p className="text-sm text-gray-600 mb-6">
                Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </p>
              
              <h3>1. Information We Collect</h3>
              <p>
                When you use zhadev API, we may collect the following information:
              </p>
              <ul>
                <li><strong>API Usage Data:</strong> IP addresses, request timestamps, endpoints accessed, and response times</li>
                <li><strong>Account Information:</strong> For premium users, we collect email addresses for communication</li>
                <li><strong>Technical Information:</strong> Browser type, operating system, and device information</li>
                <li><strong>Cookies:</strong> We use cookies for authentication and session management</li>
              </ul>
              
              <h3>2. How We Use Your Information</h3>
              <p>We use collected information for:</p>
              <ul>
                <li>Providing and maintaining the API service</li>
                <li>Monitoring API usage and preventing abuse</li>
                <li>Improving API performance and reliability</li>
                <li>Communicating with users about service updates</li>
                <li>Enforcing our Terms of Service</li>
              </ul>
              
              <h3>3. Data Storage and Security</h3>
              <p>
                We implement appropriate security measures to protect your information:
              </p>
              <ul>
                <li>Encryption of sensitive data in transit (SSL/TLS)</li>
                <li>Secure storage of API keys using hashing</li>
                <li>Regular security audits and updates</li>
                <li>Limited access to personal information</li>
              </ul>
              
              <h3>4. Third-Party Services</h3>
              <p>
                We may use third-party services for:
              </p>
              <ul>
                <li><strong>Analytics:</strong> Google Analytics for usage statistics</li>
                <li><strong>Hosting:</strong> Cloud infrastructure providers</li>
                <li><strong>Payment Processing:</strong> For premium subscriptions</li>
                <li><strong>Email Services:</strong> For communication with users</li>
              </ul>
              
              <h3>5. API Key Security</h3>
              <p>
                Your API keys are stored securely using hashing algorithms. We recommend:
              </p>
              <ul>
                <li>Keeping your API keys confidential</li>
                <li>Not exposing API keys in client-side code</li>
                <li>Rotating keys periodically</li>
                <li>Reporting compromised keys immediately</li>
              </ul>
              
              <h3>6. Data Retention</h3>
              <p>We retain data for different periods:</p>
              <ul>
                <li><strong>API Request Logs:</strong> 30 days for debugging and analytics</li>
                <li><strong>User Accounts:</strong> Until account deletion request</li>
                <li><strong>Error Logs:</strong> 90 days for service improvement</li>
                <li><strong>Backup Data:</strong> Encrypted backups retained for 6 months</li>
              </ul>
              
              <h3>7. Your Rights</h3>
              <p>You have the right to:</p>
              <ul>
                <li>Access personal information we hold about you</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your personal data</li>
                <li>Opt-out of non-essential communications</li>
                <li>Export your data in a machine-readable format</li>
              </ul>
              
              <h3>8. Children's Privacy</h3>
              <p>
                Our service is not intended for users under 13 years of age. We do not 
                knowingly collect personal information from children under 13.
              </p>
              
              <h3>9. Changes to This Policy</h3>
              <p>
                We may update this Privacy Policy from time to time. We will notify 
                users of any material changes via email or website announcement.
              </p>
              
              <h3>10. Contact Us</h3>
              <p>
                If you have questions about this Privacy Policy, please contact us:
              </p>
              <ul>
                <li>Email: privacy@zhadev.my.id</li>
                <li>Contact Form: <a href="/contact">/contact</a></li>
              </ul>
              
              <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Note:</strong> This Privacy Policy applies only to zhadev API services 
                  and not to any third-party websites or services that may be linked from our API.
                </p>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}