'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FaExclamationTriangle, FaLock, FaUser } from 'react-icons/fa';
import Header from '@/components/Header';

export default function SignInPage() {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [captcha, setCaptcha] = useState('');
  const [userCaptcha, setUserCaptcha] = useState('');
  const router = useRouter();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
          router.push('/admin-panel');
        }
      } catch (error) {
        // Not authenticated
      }
    };
    
    checkAuth();
    
    if (attempts >= 3) {
      generateCaptcha();
      setShowCaptcha(true);
    }
  }, [attempts, router]);

  const generateCaptcha = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptcha(result);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (attempts >= 3 && userCaptcha !== captcha) {
      setError('Invalid CAPTCHA code');
      setLoading(false);
      generateCaptcha();
      setUserCaptcha('');
      return;
    }

    try {
      const response = await fetch('/api/auth/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        setAttempts(0);
        router.push('/admin-panel');
        router.refresh();
      } else {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        
        if (newAttempts >= 10) {
          try {
            await fetch('/api/admin/moderate?ban=' + getClientIp() + '&apikey=' + process.env.NEXT_PUBLIC_ADMIN_KEY, {
              method: 'POST',
            });
            setError('Too many failed attempts. Your IP has been banned.');
            setTimeout(() => {
              router.push('/');
            }, 3000);
            return;
          } catch {
            setError('Account locked. Please contact administrator.');
          }
        } else if (newAttempts >= 3) {
          setError(`Invalid credentials (${newAttempts}/10 attempts)`);
          setShowCaptcha(true);
          generateCaptcha();
        } else {
          setError(`Invalid credentials (${newAttempts}/10 attempts)`);
        }
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getClientIp = () => {
    return 'unknown';
  };

  return (
    <>
      <Header 
        title="Admin Sign In" 
        subtitle="Access the admin dashboard"
      />
      
      <main className="container py-12">
        <div className="max-w-md mx-auto">
          <div className="card">
            <h2 className="text-2xl font-bold mb-6 text-center">Admin Login</h2>
            
            {attempts >= 3 && (
              <div className="alert alert-warning mb-4">
                <FaExclamationTriangle className="inline mr-2" />
                <strong>Security Alert:</strong> Multiple failed attempts detected
              </div>
            )}
            
            {attempts >= 7 && (
              <div className="alert alert-danger mb-4">
                <FaLock className="inline mr-2" />
                <strong>Warning:</strong> {10 - attempts} attempts remaining before IP ban
              </div>
            )}

            {error && (
              <div className="alert alert-error mb-4">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    <FaUser className="inline mr-2" />
                    Username
                  </label>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    className="input"
                    required
                    disabled={loading || attempts >= 10}
                    placeholder="Enter admin username"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">
                    <FaLock className="inline mr-2" />
                    Password
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="input"
                    required
                    disabled={loading || attempts >= 10}
                    placeholder="Enter admin password"
                  />
                </div>

                {showCaptcha && attempts >= 3 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block text-sm font-medium">
                        Security CAPTCHA
                      </label>
                      <button
                        type="button"
                        onClick={generateCaptcha}
                        className="text-sm text-primary-color hover:underline"
                      >
                        Refresh
                      </button>
                    </div>
                    
                    <div className="bg-gray-100 p-4 rounded-lg text-center">
                      <div className="text-2xl font-mono tracking-widest bg-white p-3 rounded inline-block">
                        {captcha}
                      </div>
                    </div>
                    
                    <input
                      type="text"
                      value={userCaptcha}
                      onChange={(e) => setUserCaptcha(e.target.value.toUpperCase())}
                      className="input text-center font-mono tracking-widest"
                      placeholder="Enter the code above"
                      required
                      maxLength={6}
                    />
                  </div>
                )}

                <button
                  type="submit"
                  className="btn btn-primary w-full"
                  disabled={loading || attempts >= 10}
                >
                  {loading ? (
                    <>
                      <div className="loading mr-2"></div>
                      Authenticating...
                    </>
                  ) : attempts >= 10 ? (
                    'Account Locked'
                  ) : (
                    'Sign In'
                  )}
                </button>
              </div>
            </form>

            {attempts >= 5 && (
              <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">
                  <FaExclamationTriangle className="inline mr-2" />
                  Multiple Failed Attempts Detected
                </h4>
                <p className="text-sm text-red-700">
                  If you continue to enter incorrect credentials, your IP address 
                  will be temporarily banned from accessing the admin panel.
                </p>
              </div>
            )}
          </div>

          <div className="mt-8 text-center text-sm text-gray-600">
            <p>
              This page is for administrators only. Regular users do not need 
              to login to use the API.
            </p>
            <p className="mt-2">
              <strong>Security Note:</strong> 3 failed attempts will trigger CAPTCHA.
              10 failed attempts will result in IP ban.
            </p>
            <p className="mt-2">
              If you're locked out, contact: contact@zhadev.my.id
            </p>
          </div>
        </div>
      </main>
    </>
  );
}