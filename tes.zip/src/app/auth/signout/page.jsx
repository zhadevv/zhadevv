'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

export default function SignOutPage() {
  const router = useRouter();

  useEffect(() => {
    const logout = async () => {
      try {
        await fetch('/api/auth/signout', {
          method: 'DELETE',
          credentials: 'include',
        });
        
        setTimeout(() => {
          router.push('/');
        }, 2000);
      } catch (error) {
        router.push('/');
      }
    };
    
    logout();
  }, [router]);

  return (
    <>
      <Header title="Signing Out..." />
      
      <main className="container py-12">
        <div className="max-w-md mx-auto text-center">
          <div className="loading mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold mb-2">Signing you out...</h2>
          <p className="text-gray-600">
            You will be redirected to the homepage shortly.
          </p>
        </div>
      </main>
    </>
  );
}