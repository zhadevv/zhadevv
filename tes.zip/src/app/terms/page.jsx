import Header from '@/components/Header';
import Main from '@/components/Main';

export default function TermsPage() {
  return (
    <>
      <Header 
        title="Terms of Service" 
        subtitle="Rules and guidelines for using zhadev API"
      />
      
      <Main>
        <section className="py-8">
          <div className="card">
            <div className="prose max-w-none">
              <h2>Terms of Service for zhadev API</h2>
              <p className="text-sm text-gray-600 mb-6">
                Effective Date: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </p>
              
              <h3>1. Acceptance of Terms</h3>
              <p>
                By accessing or using zhadev API, you agree to be bound by these Terms of Service. 
                If you disagree with any part of the terms, you may not access the service.
              </p>
              
              <h3>2. Description of Service</h3>
              <p>
                zhadev API provides programmatic access to anime, donghua, and dracin content 
                through RESTful endpoints. The service includes:
              </p>
              <ul>
                <li>Free tier with limited rate limits</li>
                <li>Premium tier with enhanced rate limits</li>
                <li>API documentation and support</li>
                <li>Regular updates and maintenance</li>
              </ul>
              
              <h3>3. User Accounts and API Keys</h3>
              <p>When using zhadev API:</p>
              <ul>
                <li>You are responsible for keeping your API keys secure</li>
                <li>You may not share API keys with unauthorized users</li>
                <li>We reserve the right to revoke API keys for violations</li>
                <li>Premium API keys are non-transferable</li>
              </ul>
              
              <h3>4. Acceptable Use</h3>
              <p>You agree not to use the service to:</p>
              <ul>
                <li>Violate any laws or regulations</li>
                <li>Infringe upon intellectual property rights</li>
                <li>Distribute malware or harmful code</li>
                <li>Overload or attempt to disrupt the service</li>
                <li>Scrape or collect data beyond reasonable limits</li>
                <li>Use the service for illegal streaming or piracy</li>
              </ul>
              
              <h3>5. Rate Limits and Fair Use</h3>
              <p>
                We implement rate limits to ensure fair usage:
              </p>
              <ul>
                <li><strong>Guest Users:</strong> 25 requests per minute</li>
                <li><strong>Free Tier:</strong> 50 requests per minute</li>
                <li><strong>Premium Tier:</strong> 100-200 requests per minute</li>
                <li><strong>Excessive usage</strong> may result in temporary restrictions</li>
              </ul>
              
              <h3>6. Intellectual Property</h3>
              <p>
                zhadev API and its original content, features, and functionality are owned 
                by zhadev and are protected by international copyright, trademark, patent, 
                trade secret, and other intellectual property laws.
              </p>
              
              <h3>7. Termination</h3>
              <p>
                We may terminate or suspend your access to the service immediately, without 
                prior notice or liability, for any reason, including breach of the Terms.
              </p>
              
              <h3>8. Limitation of Liability</h3>
              <p>
                In no event shall zhadev, nor its directors, employees, partners, agents, 
                suppliers, or affiliates, be liable for any indirect, incidental, special, 
                consequential or punitive damages, including without limitation, loss of 
                profits, data, use, goodwill, or other intangible losses.
              </p>
              
              <h3>9. Service Availability</h3>
              <p>
                We strive to maintain 99.9% uptime but do not guarantee uninterrupted service. 
                We may temporarily suspend access for maintenance, upgrades, or emergency repairs.
              </p>
              
              <h3>10. Changes to Terms</h3>
              <p>
                We reserve the right to modify or replace these Terms at any time. 
                Continued use of the service after changes constitutes acceptance of new terms.
              </p>
              
              <h3>11. Governing Law</h3>
              <p>
                These Terms shall be governed by and construed in accordance with the laws 
                of Indonesia, without regard to its conflict of law provisions.
              </p>
              
              <h3>12. Contact Information</h3>
              <p>
                For questions about these Terms, please contact:
              </p>
              <ul>
                <li>Email: legal@zhadev.my.id</li>
                <li>Contact Form: <a href="/contact">/contact</a></li>
              </ul>
              
              <div className="mt-8 p-4 bg-red-50 border border-red-200 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-2">Prohibited Activities</h4>
                <p className="text-sm text-red-700">
                  The following activities will result in immediate termination of API access:
                </p>
                <ul className="text-sm text-red-700 mt-2 list-disc list-inside">
                  <li>Attempting to bypass rate limits</li>
                  <li>Using the API for commercial streaming services without permission</li>
                  <li>Redistributing API data as a competing service</li>
                  <li>Abusing the service through automated attacks</li>
                  <li>Violating copyright or intellectual property rights</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </Main>
    </>
  );
}