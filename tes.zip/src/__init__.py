from src.main import app

__all__ = ["app"]