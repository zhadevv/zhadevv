import { NextResponse } from 'next/server';
import rateLimit from 'express-rate-limit';
import Redis from 'redis';
import { createClient } from 'redis';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
  ],
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple(),
  }));
}

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    get: async () => null,
    set: async () => 'OK',
    incr: async () => 1,
    del: async () => 0,
    exists: async () => 0,
  };
}

const RATE_LIMITS = {
  guest: parseInt(process.env.GUEST_LIMIT) || 25,
  free: parseInt(process.env.FREE_LIMIT) || 50,
  prem_1: parseInt(process.env.PREM_1_LIMIT) || 100,
  prem_2: parseInt(process.env.PREM_2_LIMIT) || 150,
  prem_3: parseInt(process.env.PREM_3_LIMIT) || 200,
  admin: parseInt(process.env.ADMIN_LIMIT) || 300,
  dev: parseInt(process.env.DEV_LIMIT) || 1000,
  owner: Infinity,
};

const validateAdminCredentials = (credentials) => {
  try {
    const creds = JSON.parse(credentials);
    return Array.isArray(creds) ? creds : [];
  } catch {
    return [];
  }
};

const ADMIN_CREDENTIALS = validateAdminCredentials(
  Buffer.from(process.env.CREDENTIAL_ACC || 'W10=', 'base64').toString()
);

const createRateLimiter = (limit, windowMs = 60000) => {
  return async (req, res, next) => {
    const ip = req.ip || req.headers.get('x-forwarded-for') || 'unknown';
    const key = `rate_limit:${ip}:${Date.now() / windowMs | 0}`;
    
    try {
      const current = await redisClient.incr(key);
      if (current === 1) {
        await redisClient.expire(key, Math.ceil(windowMs / 1000));
      }
      
      if (current > limit) {
        return NextResponse.json(
          {
            status: 429,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Rate limit exceeded',
          },
          { status: 429 }
        );
      }
      
      res.headers.set('X-RateLimit-Limit', limit.toString());
      res.headers.set('X-RateLimit-Remaining', Math.max(0, limit - current).toString());
      return next();
    } catch (error) {
      logger.error('Rate limiter error:', error);
      return next();
    }
  };
};

const authenticateApiKey = async (apiKey) => {
  if (!apiKey) return { role: 'guest', valid: true };
  
  const keys = [
    process.env.ADM_KEY,
    process.env.DEV_KEY,
    process.env.OWN_KEY,
  ];
  
  if (keys.includes(apiKey)) {
    if (apiKey === process.env.OWN_KEY) return { role: 'owner', valid: true };
    if (apiKey === process.env.DEV_KEY) return { role: 'dev', valid: true };
    if (apiKey === process.env.ADM_KEY) return { role: 'admin', valid: true };
  }
  
  const storedKey = await redisClient.get(`apikey:${apiKey}`);
  if (storedKey) {
    const keyData = JSON.parse(storedKey);
    if (keyData.suspended) {
      return { role: 'suspended', valid: false, message: 'Key suspended' };
    }
    return { role: keyData.role, valid: true, keyData };
  }
  
  return { role: 'invalid', valid: false, message: 'Invalid API key' };
};

const getIpInfo = async (ip) => {
  try {
    const response = await fetch(`http://ip-api.com/json/${ip}`);
    const data = await response.json();
    return {
      country: data.country,
      region: data.regionName,
      city: data.city,
      isp: data.isp,
    };
  } catch {
    return {};
  }
};

const logRequest = async (req, auth, ip) => {
  const requestId = uuidv4();
  const timestamp = new Date().toISOString();
  const url = req.url;
  const method = req.method;
  const userAgent = req.headers.get('user-agent') || 'unknown';
  
  const logEntry = {
    requestId,
    timestamp,
    ip,
    method,
    url,
    userAgent,
    role: auth.role,
    apiKey: req.headers.get('x-api-key') || 'none',
  };
  
  await redisClient.lpush('request_logs', JSON.stringify(logEntry));
  await redisClient.ltrim('request_logs', 0, 9999);
  
  req.headers.set('X-Request-ID', requestId);
  return requestId;
};

const checkBannedIp = async (ip) => {
  const banned = await redisClient.get(`banned:${ip}`);
  return !!banned;
};

const verifyJWT = (token) => {
  try {
    const decoded = jwt.verify(token, process.env.NEXT_JWT);
    return decoded;
  } catch {
    return null;
  }
};

export async function middleware(req) {
  const startTime = Date.now();
  const url = new URL(req.url);
  const path = url.pathname;
  
  const ip = req.headers.get('x-forwarded-for') || req.ip || 'unknown';
  
  const isBanned = await checkBannedIp(ip);
  if (isBanned) {
    return NextResponse.json(
      {
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'IP banned',
      },
      { status: 403 }
    );
  }
  
  const apiKey = req.headers.get('x-api-key') || url.searchParams.get('apikey');
  const auth = await authenticateApiKey(apiKey);
  
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message || 'Unauthorized',
      },
      { status: 401 }
    );
  }
  
  if (path.startsWith('/api/admin') || path.startsWith('/api/auth')) {
    const token = req.cookies.get('auth_token')?.value || 
                  req.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Authentication required',
        },
        { status: 401 }
      );
    }
    
    const decoded = verifyJWT(token);
    if (!decoded) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Invalid token',
        },
        { status: 401 }
      );
    }
    
    const userCred = ADMIN_CREDENTIALS.find(c => c.user === decoded.user);
    if (!userCred) {
      return NextResponse.json(
        {
          status: 403,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Access denied',
        },
        { status: 403 }
      );
    }
    
    req.headers.set('X-User-Role', userCred.role);
    req.headers.set('X-User-Id', userCred.id.toString());
  }
  
  const requestId = await logRequest(req, auth, ip);
  
  let rateLimitValue = RATE_LIMITS[auth.role] || RATE_LIMITS.guest;
  if (auth.role === 'owner') rateLimitValue = Infinity;
  
  const rateLimiter = createRateLimiter(rateLimitValue);
  const rateLimitResponse = await new Promise((resolve) => {
    const mockRes = {
      headers: new Headers(),
      set: (key, value) => mockRes.headers.set(key, value),
    };
    
    rateLimiter(req, mockRes, () => resolve(null));
  });
  
  if (rateLimitResponse) {
    return rateLimitResponse;
  }
  
  const response = NextResponse.next();
  
  const endTime = Date.now();
  const processTime = endTime - startTime;
  
  response.headers.set('X-Request-ID', requestId);
  response.headers.set('X-Process-Time', `${processTime}ms`);
  response.headers.set('X-Rate-Limit', rateLimitValue.toString());
  response.headers.set('X-Api-Key', apiKey || 'none');
  response.headers.set('Content-Type', 'application/json');
  response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  response.headers.set('Server', 'zhadev-api');
  response.headers.set('Date', new Date().toUTCString());
  
  return response;
}

export const config = {
  matcher: [
    '/api/:path*',
    '/admin-panel/:path*',
  ],
};