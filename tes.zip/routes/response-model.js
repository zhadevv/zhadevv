export class ApiResponse {
  constructor(status = 200, success = true, data = null, message = null) {
    this.status = status;
    this.success = success;
    this.author = 'zhadevv';
    this.data = data;
    this.message = message;
    this.timestamp = new Date().toISOString();
  }

  static success(data, message = null) {
    return new ApiResponse(200, true, data, message);
  }

  static error(status = 500, message = 'Internal Server Error') {
    return new ApiResponse(status, false, null, message);
  }

  static notFound(message = 'Resource not found') {
    return new ApiResponse(404, false, null, message);
  }

  static unauthorized(message = 'Unauthorized') {
    return new ApiResponse(401, false, null, message);
  }

  static forbidden(message = 'Forbidden') {
    return new ApiResponse(403, false, null, message);
  }

  static badRequest(message = 'Bad Request') {
    return new ApiResponse(400, false, null, message);
  }

  static rateLimitExceeded(message = 'Rate limit exceeded') {
    return new ApiResponse(429, false, null, message);
  }

  toJSON() {
    return {
      status: this.status,
      success: this.success,
      author: this.author,
      data: this.data,
      message: this.message,
      timestamp: this.timestamp,
    };
  }
}