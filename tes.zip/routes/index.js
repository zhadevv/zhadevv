import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { errorMiddleware } from '../middlewares/error.js';
import { requestIdMiddleware } from '../middlewares/requests-id.js';
import { protectMiddleware } from '../middlewares/protector.js';

const router = express.Router();

router.use(cors({
  origin: process.env.NEXT_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'X-Request-ID'],
}));

router.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

router.use(express.json({ limit: '10mb' }));
router.use(express.urlencoded({ extended: true, limit: '10mb' }));
router.use(cookieParser());
router.use(requestIdMiddleware);
router.use(protectMiddleware);

router.get('/', (req, res) => {
  res.json({
    status: 200,
    success: true,
    author: 'zhadevv',
    data: {
      name: 'zhadev API',
      version: '1.0.0',
      documentation: `${process.env.NEXT_URL}/docs`,
      endpoints: {
        v1: '/api/v1',
        admin: '/api/admin',
        auth: '/api/auth',
        status: '/api/status',
      },
    },
    message: null,
  });
});

router.get('/health', (req, res) => {
  res.json({
    status: 200,
    success: true,
    author: 'zhadevv',
    data: {
      status: 'healthy',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      memory: process.memoryUsage(),
    },
    message: null,
  });
});

router.use(errorMiddleware);

export default router;