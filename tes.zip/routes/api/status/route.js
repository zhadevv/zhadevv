import { NextResponse } from 'next/server';
import os from 'os';
import Redis from 'redis';
import { createClient } from 'redis';

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    ping: async () => 'PONG',
  };
}

export async function GET() {
  const startTime = Date.now();

  try {
    const redisStatus = await redisClient.ping().then(() => 'connected').catch(() => 'disconnected');
    
    const stats = {
      server: {
        node_version: process.version,
        platform: process.platform,
        arch: process.arch,
        uptime: process.uptime(),
        memory: {
          total: os.totalmem(),
          free: os.freemem(),
          used: process.memoryUsage(),
        },
        cpu: {
          cores: os.cpus().length,
          loadavg: os.loadavg(),
        },
      },
      redis: {
        status: redisStatus,
      },
      api: {
        version: '1.0.0',
        environment: process.env.NODE_ENV,
        base_url: process.env.NEXT_URL,
      },
      timestamp: new Date().toISOString(),
    };

    const processTime = Date.now() - startTime;

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: stats,
        message: null,
      },
      {
        headers: {
          'X-Process-Time': `${processTime}ms`,
          'Cache-Control': 'no-cache, no-store, must-revalidate',
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Failed to get status',
      },
      { status: 500 }
    );
  }
}