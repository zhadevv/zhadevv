import { NextResponse } from 'next/server';
import Redis from 'redis';
import { createClient } from 'redis';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { cookies } from 'next/headers';

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    get: async () => null,
    set: async () => 'OK',
    del: async () => 0,
    exists: async () => 0,
    keys: async () => [],
    hgetall: async () => ({}),
    hset: async () => 0,
    hdel: async () => 0,
    lrange: async () => [],
  };
}

const ADMIN_CREDENTIALS = JSON.parse(
  Buffer.from(process.env.CREDENTIAL_ACC || 'W10=', 'base64').toString()
);

const verifyAdmin = async (request) => {
  const apiKey = request.headers.get('x-api-key') || new URL(request.url).searchParams.get('apikey');
  
  if (!apiKey) {
    return { valid: false, role: null, message: 'API key required' };
  }

  const validKeys = [process.env.ADM_KEY, process.env.DEV_KEY, process.env.OWN_KEY];
  if (!validKeys.includes(apiKey)) {
    return { valid: false, role: null, message: 'Invalid admin API key' };
  }

  const role = apiKey === process.env.OWN_KEY ? 'owner' 
              : apiKey === process.env.DEV_KEY ? 'dev' 
              : 'admin';

  return { valid: true, role, apiKey };
};

export async function POST(request) {
  try {
    const { pathname } = new URL(request.url);
    
    if (pathname.includes('/generate_key')) {
      return await generateApiKey(request);
    }
    if (pathname.includes('/suspended_key')) {
      return await suspendApiKey(request);
    }
    if (pathname.includes('/moderate')) {
      return await moderateAction(request);
    }
    
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Endpoint not found',
      },
      { status: 404 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Internal server error',
      },
      { status: 500 }
    );
  }
}

export async function GET(request) {
  try {
    const { pathname } = new URL(request.url);
    
    if (pathname.includes('/stats')) {
      return await getStats(request);
    }
    if (pathname.includes('/ip_logs')) {
      return await getIpLogs(request);
    }
    if (pathname.includes('/moderate/')) {
      return await getModerationData(request);
    }
    
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Endpoint not found',
      },
      { status: 404 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Internal server error',
      },
      { status: 500 }
    );
  }
}

export async function PUT(request) {
  try {
    const { pathname } = new URL(request.url);
    
    if (pathname.includes('/unsuspense_keys')) {
      return await unsuspendApiKey(request);
    }
    
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Endpoint not found',
      },
      { status: 404 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Internal server error',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request) {
  try {
    const { pathname } = new URL(request.url);
    
    if (pathname.includes('/remove_key')) {
      return await removeApiKey(request);
    }
    
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Endpoint not found',
      },
      { status: 404 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Internal server error',
      },
      { status: 500 }
    );
  }
}

async function generateApiKey(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const url = new URL(request.url);
  const username = url.searchParams.get('username');
  const role = url.searchParams.get('role');
  const customKey = url.searchParams.get('keys');
  const activeFor = url.searchParams.get('active');

  if (!role || !['free', 'premium'].includes(role)) {
    return NextResponse.json(
      {
        status: 400,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Valid role required (free or premium)',
      },
      { status: 400 }
    );
  }

  const apiKey = customKey || generateRandomKey(role);
  const keyId = `key:${uuidv4()}`;
  
  const keyData = {
    id: keyId,
    key: apiKey,
    username: username || `zhadev_${Math.random().toString(36).substr(2, 6)}`,
    role: role,
    activeFor: activeFor || 'all',
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    requestCount: 0,
    monthlyLimit: role === 'free' ? 5000 : 0,
    monthlyUsed: 0,
    suspended: false,
  };

  await redisClient.set(`apikey:${apiKey}`, JSON.stringify(keyData));
  await redisClient.hset('api_keys', apiKey, keyId);

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: {
        apiKey: apiKey,
        details: keyData,
      },
      message: 'API key generated successfully',
    }
  );
}

async function suspendApiKey(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const url = new URL(request.url);
  const key = url.searchParams.get('keys');

  if (!key) {
    return NextResponse.json(
      {
        status: 400,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Key parameter required',
      },
      { status: 400 }
    );
  }

  const keyData = await redisClient.get(`apikey:${key}`);
  if (!keyData) {
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'API key not found',
      },
      { status: 404 }
    );
  }

  const parsedData = JSON.parse(keyData);
  parsedData.suspended = true;
  parsedData.suspendedAt = new Date().toISOString();

  await redisClient.set(`apikey:${key}`, JSON.stringify(parsedData));

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: {
        key: key,
        suspended: true,
        suspendedAt: parsedData.suspendedAt,
      },
      message: 'API key suspended successfully',
    }
  );
}

async function unsuspendApiKey(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const url = new URL(request.url);
  const key = url.searchParams.get('keys');

  if (!key) {
    return NextResponse.json(
      {
        status: 400,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Key parameter required',
      },
      { status: 400 }
    );
  }

  const keyData = await redisClient.get(`apikey:${key}`);
  if (!keyData) {
    return NextResponse.json(
      {
        status: 404,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'API key not found',
      },
      { status: 404 }
    );
  }

  const parsedData = JSON.parse(keyData);
  parsedData.suspended = false;
  delete parsedData.suspendedAt;

  await redisClient.set(`apikey:${key}`, JSON.stringify(parsedData));

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: {
        key: key,
        suspended: false,
      },
      message: 'API key unsuspended successfully',
    }
  );
}

async function removeApiKey(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid || auth.role !== 'owner') {
    return NextResponse.json(
      {
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Only owner can remove API keys',
      },
      { status: 403 }
    );
  }

  const url = new URL(request.url);
  const key = url.searchParams.get('keys');

  if (!key) {
    return NextResponse.json(
      {
        status: 400,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Key parameter required',
      },
      { status: 400 }
    );
  }

  await redisClient.del(`apikey:${key}`);
  await redisClient.hdel('api_keys', key);

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: null,
      message: 'API key removed successfully',
    }
  );
}

async function getStats(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const allKeys = await redisClient.hgetall('api_keys');
  const keys = Object.keys(allKeys || {});
  
  const keyStats = {
    total: keys.length,
    free: 0,
    premium: 0,
    suspended: 0,
    active: 0,
  };

  for (const key of keys) {
    const keyData = await redisClient.get(`apikey:${key}`);
    if (keyData) {
      const parsed = JSON.parse(keyData);
      keyStats[parsed.role]++;
      if (parsed.suspended) keyStats.suspended++;
      else keyStats.active++;
    }
  }

  const requestLogs = await redisClient.lrange('request_logs', 0, -1);
  const logs = requestLogs.map(log => JSON.parse(log));

  const today = new Date().toISOString().split('T')[0];
  const todayRequests = logs.filter(log => log.timestamp.startsWith(today)).length;

  const stats = {
    keys: keyStats,
    requests: {
      total: logs.length,
      today: todayRequests,
      byRole: {
        guest: logs.filter(l => l.role === 'guest').length,
        free: logs.filter(l => l.role === 'free').length,
        premium: logs.filter(l => l.role === 'premium').length,
        admin: logs.filter(l => l.role === 'admin').length,
        dev: logs.filter(l => l.role === 'dev').length,
        owner: logs.filter(l => l.role === 'owner').length,
      },
    },
    system: {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      timestamp: new Date().toISOString(),
    },
  };

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: stats,
      message: null,
    }
  );
}

async function getIpLogs(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const url = new URL(request.url);
  const ip = url.searchParams.get('ip');

  const requestLogs = await redisClient.lrange('request_logs', 0, -1);
  const logs = requestLogs.map(log => JSON.parse(log));

  let filteredLogs = logs;
  if (ip) {
    filteredLogs = logs.filter(log => log.ip === ip);
  }

  filteredLogs = filteredLogs.slice(0, 100);

  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: {
        logs: filteredLogs,
        total: filteredLogs.length,
        ip: ip || 'all',
      },
      message: null,
    }
  );
}

async function moderateAction(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const url = new URL(request.url);
  const banIp = url.searchParams.get('ban');
  const unbanIp = url.searchParams.get('unban');

  if (banIp) {
    await redisClient.set(`banned:${banIp}`, JSON.stringify({
      bannedAt: new Date().toISOString(),
      bannedBy: auth.role,
      reason: 'Admin moderation',
    }));
    await redisClient.expire(`banned:${banIp}`, 7 * 24 * 60 * 60);

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          ip: banIp,
          action: 'banned',
          duration: '7 days',
        },
        message: 'IP banned successfully',
      }
    );
  }

  if (unbanIp) {
    await redisClient.del(`banned:${unbanIp}`);

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          ip: unbanIp,
          action: 'unbanned',
        },
        message: 'IP unbanned successfully',
      }
    );
  }

  return NextResponse.json(
    {
      status: 400,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Action parameter required (ban or unban)',
    },
    { status: 400 }
  );
}

async function getModerationData(request) {
  const auth = await verifyAdmin(request);
  if (!auth.valid) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: auth.message,
      },
      { status: 401 }
    );
  }

  const { pathname } = new URL(request.url);
  
  if (pathname.includes('/banned-ips')) {
    const keys = await redisClient.keys('banned:*');
    const bannedIps = [];
    
    for (const key of keys) {
      const ip = key.replace('banned:', '');
      const data = await redisClient.get(key);
      bannedIps.push({
        ip: ip,
        data: JSON.parse(data || '{}'),
      });
    }

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          bannedIps: bannedIps,
          total: bannedIps.length,
        },
        message: null,
      }
    );
  }

  if (pathname.includes('/total_keys')) {
    const allKeys = await redisClient.hgetall('api_keys');
    const keys = Object.keys(allKeys || {});
    
    const keyDetails = [];
    for (const key of keys.slice(0, 50)) {
      const data = await redisClient.get(`apikey:${key}`);
      if (data) {
        keyDetails.push(JSON.parse(data));
      }
    }

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          keys: keyDetails,
          total: keys.length,
        },
        message: null,
      }
    );
  }

  return NextResponse.json(
    {
      status: 404,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Moderation endpoint not found',
    },
    { status: 404 }
  );
}

function generateRandomKey(role) {
  const prefix = role === 'free' ? 'SK_zhadev-freekeys_' : 'SK_zhadev_prem_';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  
  for (let i = 0; i < 16; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return prefix + result;
}