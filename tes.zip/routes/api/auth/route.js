import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';

const ADMIN_CREDENTIALS = JSON.parse(
  Buffer.from(process.env.CREDENTIAL_ACC || 'W10=', 'base64').toString()
);

export async function POST(request) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        {
          status: 400,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Username and password required',
        },
        { status: 400 }
      );
    }

    const user = ADMIN_CREDENTIALS.find(u => u.user === username);
    if (!user) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Invalid credentials',
        },
        { status: 401 }
      );
    }

    const decodedPassword = Buffer.from(user.pass, 'base64').toString();
    const isValid = await bcrypt.compare(password, decodedPassword);

    if (!isValid) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Invalid credentials',
        },
        { status: 401 }
      );
    }

    const token = jwt.sign(
      {
        id: user.id,
        user: user.user,
        role: user.role,
        email: user.email,
      },
      process.env.NEXT_JWT,
      { expiresIn: '24h' }
    );

    const cookieStore = await cookies();
    cookieStore.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60,
      path: '/',
    });

    cookieStore.set('auth_session', 'active', {
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60,
      path: '/',
    });

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          user: {
            id: user.id,
            username: user.user,
            role: user.role,
            email: user.email,
          },
          token: token,
          expires_in: 24 * 60 * 60,
        },
        message: 'Login successful',
      },
      {
        headers: {
          'Set-Cookie': cookieStore.toString(),
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Login failed',
      },
      { status: 500 }
    );
  }
}

export async function GET(request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('auth_token')?.value;

    if (!token) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Not authenticated',
        },
        { status: 401 }
      );
    }

    const decoded = jwt.verify(token, process.env.NEXT_JWT);
    const user = ADMIN_CREDENTIALS.find(u => u.id === decoded.id);

    if (!user) {
      return NextResponse.json(
        {
          status: 401,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Invalid session',
        },
        { status: 401 }
      );
    }

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: {
          user: {
            id: user.id,
            username: user.user,
            role: user.role,
            email: user.email,
          },
          token: token,
          expires_in: decoded.exp - Math.floor(Date.now() / 1000),
        },
        message: null,
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Invalid token',
      },
      { status: 401 }
    );
  }
}

export async function DELETE() {
  try {
    const cookieStore = await cookies();
    
    cookieStore.delete('auth_token');
    cookieStore.delete('auth_session');

    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: null,
        message: 'Logout successful',
      },
      {
        headers: {
          'Set-Cookie': 'auth_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Strict',
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Logout failed',
      },
      { status: 500 }
    );
  }
}