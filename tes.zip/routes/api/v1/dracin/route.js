import { NextResponse } from 'next/server';
import DramaboxParser from '../../../../src/lib/scraper/Dracin.js';

const parserCache = new Map();

function getParser(region) {
  if (!parserCache.has(region)) {
    parserCache.set(region, new DramaboxParser({ region }));
  }
  return parserCache.get(region);
}

export async function GET(request) {
  const startTime = Date.now();
  
  try {
    const url = new URL(request.url);
    const pathSegments = url.pathname.split('/').filter(Boolean);
    
    const regionIndex = pathSegments.indexOf('dracin') + 1;
    if (regionIndex >= pathSegments.length) {
      return NextResponse.json(
        {
          status: 400,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Region parameter required',
        },
        { status: 400 }
      );
    }
    
    const region = pathSegments[regionIndex];
    const action = pathSegments[regionIndex + 1];
    const slug = pathSegments[regionIndex + 2];
    
    const validRegions = ['id', 'en', 'zh', 'zhHans', 'ko', 'ja', 'tl', 'th', 'ar', 'pt', 'fr', 'es'];
    if (!validRegions.includes(region)) {
      return NextResponse.json(
        {
          status: 400,
          success: false,
          author: 'zhadevv',
          data: null,
          message: `Invalid region. Valid regions: ${validRegions.join(', ')}`,
        },
        { status: 400 }
      );
    }
    
    const parser = getParser(region);
    let result;
    
    switch(action) {
      case 'home':
        const homeResponse = await parser.fetchWithRetry('');
        result = await parser.parse_home(homeResponse.data);
        break;
        
      case 'channel':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Channel slug required',
            },
            { status: 400 }
          );
        }
        const channelPage = url.searchParams.get('page') || '1';
        const channelResponse = await parser.fetchWithRetry(`/channel/${slug}?page=${channelPage}`);
        result = await parser.parse_channel(channelResponse.data);
        break;
        
      case 'genres':
        const genresPage = url.searchParams.get('page') || '1';
        if (slug && slug !== '0') {
          const genresResponse = await parser.fetchWithRetry(`/genres?typeTwoId=${slug}&page=${genresPage}`);
          result = await parser.parse_genres(genresResponse.data);
        } else {
          const genresResponse = await parser.fetchWithRetry(`/genres?page=${genresPage}`);
          result = await parser.parse_genres(genresResponse.data);
        }
        break;
        
      case 'resources':
        if (region !== 'en') {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Resources only available for English region',
            },
            { status: 400 }
          );
        }
        const resourcesResponse = await parser.fetchWithRetry('/resources');
        result = await parser.parse_resources(resourcesResponse.data);
        break;
        
      case 'search':
        const query = url.searchParams.get('s') || '';
        const searchPage = url.searchParams.get('page') || '1';
        if (!query) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Search query (s) parameter required',
            },
            { status: 400 }
          );
        }
        const searchResponse = await parser.fetchWithRetry(`/search?s=${encodeURIComponent(query)}&page=${searchPage}`);
        result = await parser.parse_search(searchResponse.data);
        break;
        
      case 'series':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug required',
            },
            { status: 400 }
          );
        }
        const seriesResponse = await parser.fetchWithRetry(`/movie/${slug}`);
        result = await parser.parse_detail(seriesResponse.data);
        break;
        
      case 'watch':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug required',
            },
            { status: 400 }
          );
        }
        const episode = url.searchParams.get('episode');
        if (!episode) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Episode parameter required',
            },
            { status: 400 }
          );
        }
        const watchResponse = await parser.fetchWithRetry(`/ep/${slug}/${episode}`);
        result = await parser.parse_watch(watchResponse.data);
        break;
        
      default:
        return NextResponse.json(
          {
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Endpoint not found',
          },
          { status: 404 }
        );
    }
    
    const processTime = Date.now() - startTime;
    
    const response = NextResponse.json(result, {
      headers: {
        'X-Process-Time': `${processTime}ms`,
        'Cache-Control': 'public, max-age=300, s-maxage=600',
        'Content-Type': 'application/json',
      },
    });
    
    return response;
    
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `Failed to process request: ${error.message}`,
      },
      { status: 500 }
    );
  }
}