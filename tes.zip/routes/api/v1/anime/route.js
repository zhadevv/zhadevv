import { NextResponse } from 'next/server';
import AnimeParser from '../../../../src/lib/scraper/Anime.js';

const animeParser = new AnimeParser({
  baseUrl: 'https://oploverz.mom',
  timeout: 30000,
  retryCount: 3,
});

export async function GET(request) {
  const startTime = Date.now();
  
  try {
    const url = new URL(request.url);
    const pathSegments = url.pathname.split('/').filter(Boolean);
    const action = pathSegments[pathSegments.length - 1];
    const slug = pathSegments[pathSegments.length - 2];
    
    let result;
    
    switch(action) {
      case 'sidebar':
        const sidebarResponse = await animeParser.fetchWithRetry('');
        result = await animeParser.parse_sidebar(sidebarResponse.data);
        break;
        
      case 'home':
        const page = url.searchParams.get('page') || '1';
        const homeResponse = await animeParser.fetchWithRetry(`/page/${page}/`);
        result = await animeParser.parse_home(homeResponse.data);
        break;
        
      case 'schedule':
        const scheduleResponse = await animeParser.fetchWithRetry('/jadwal-rilis-anime/');
        result = await animeParser.parse_schedule(scheduleResponse.data);
        break;
        
      case 'search':
        const query = url.searchParams.get('s') || '';
        const searchPage = url.searchParams.get('page') || '1';
        if (!query) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Search query (s) parameter required',
            },
            { status: 400 }
          );
        }
        const searchResponse = await animeParser.fetchWithRetry(`/page/${searchPage}/?s=${encodeURIComponent(query)}`);
        result = await animeParser.parse_search(searchResponse.data);
        break;
        
      case 'genres':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Genre slug required',
            },
            { status: 400 }
          );
        }
        const genrePage = url.searchParams.get('page') || '1';
        const genreResponse = await animeParser.fetchWithRetry(`/genres/${slug}/page/${genrePage}/`);
        result = await animeParser.parse_genres(genreResponse.data, slug);
        break;
        
      case 'a-z':
        const azPage = url.searchParams.get('page') || '1';
        const azResponse = await animeParser.fetchWithRetry(`/az-list/page/${azPage}/`);
        result = await animeParser.parse_az_list(azResponse.data);
        break;
        
      case 'detail':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug required',
            },
            { status: 400 }
          );
        }
        const detailResponse = await animeParser.fetchWithRetry(`/anime/${slug}/`);
        result = await animeParser.parse_detail(detailResponse.data);
        break;
        
      case 'random':
        const randomResponse = await animeParser.fetchWithRetry('/az-list/');
        const randomData = await animeParser.parse_az_list(randomResponse.data);
        if (randomData.success && randomData.data.lists.length > 0) {
          const randomItem = randomData.data.lists[Math.floor(Math.random() * randomData.data.lists.length)];
          const randomDetailResponse = await animeParser.fetchWithRetry(randomItem.url);
          result = await animeParser.parse_detail(randomDetailResponse.data);
        } else {
          result = randomData;
        }
        break;
        
      case 'watch':
        const episodeSlug = pathSegments[pathSegments.length - 3];
        if (!episodeSlug || !slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug and episode number required',
            },
            { status: 400 }
          );
        }
        const watchResponse = await animeParser.fetchWithRetry(`/${episodeSlug}-episode-${slug}/`);
        result = await animeParser.parse_watch(watchResponse.data);
        break;
        
      case 'list-mode':
        const listModeResponse = await animeParser.fetchWithRetry('/advanced-search/');
        result = await animeParser.parse_advanced_search_text_mode(listModeResponse.data);
        break;
        
      case 'filters':
        const filterPage = url.searchParams.get('page') || '1';
        const params = new URLSearchParams();
        
        const filterParams = ['status', 'order', 'type', 'genre[]', 'studio[]', 'season[]'];
        filterParams.forEach(param => {
          const value = url.searchParams.get(param);
          if (value) params.append(param, value);
        });
        
        const filterUrl = `/advanced-search/page/${filterPage}/?${params.toString()}`;
        const filterResponse = await animeParser.fetchWithRetry(filterUrl);
        result = await animeParser.parse_advance_search(filterResponse.data);
        break;
        
      default:
        return NextResponse.json(
          {
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Endpoint not found',
          },
          { status: 404 }
        );
    }
    
    const processTime = Date.now() - startTime;
    
    const response = NextResponse.json(result, {
      headers: {
        'X-Process-Time': `${processTime}ms`,
        'Cache-Control': 'public, max-age=300, s-maxage=600',
        'Content-Type': 'application/json',
      },
    });
    
    return response;
    
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `Failed to process request: ${error.message}`,
      },
      { status: 500 }
    );
  }
}