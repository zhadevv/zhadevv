import { NextResponse } from 'next/server';
import Redis from 'redis';
import { createClient } from 'redis';

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    ping: async () => 'PONG',
  };
}

export async function GET() {
  const startTime = Date.now();
  
  try {
    const healthChecks = {
      api: {
        status: 'healthy',
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
      },
      redis: {
        status: 'checking',
      },
      scraper: {
        anime: 'available',
        donghua: 'available',
        dracin: 'available',
      },
    };
    
    try {
      const redisPing = await redisClient.ping();
      healthChecks.redis.status = redisPing === 'PONG' ? 'healthy' : 'unhealthy';
    } catch (redisError) {
      healthChecks.redis.status = 'unreachable';
      healthChecks.redis.error = redisError.message;
    }
    
    const processTime = Date.now() - startTime;
    healthChecks.api.response_time = `${processTime}ms`;
    
    return NextResponse.json(
      {
        status: 200,
        success: true,
        author: 'zhadevv',
        data: healthChecks,
        message: null,
      },
      {
        headers: {
          'X-Process-Time': `${processTime}ms`,
          'Cache-Control': 'no-cache, no-store, must-revalidate',
        },
      }
    );
    
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Health check failed',
      },
      { status: 500 }
    );
  }
}