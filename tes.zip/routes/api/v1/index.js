import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json(
    {
      status: 200,
      success: true,
      author: 'zhadevv',
      data: {
        version: 'v1',
        endpoints: {
          anime: {
            sidebar: '/api/v1/anime/sidebar/',
            home: '/api/v1/anime/home/',
            schedule: '/api/v1/anime/schedule/',
            search: '/api/v1/anime/search/',
            genres: '/api/v1/anime/genres/:slug/',
            az_list: '/api/v1/anime/a-z/',
            detail: '/api/v1/anime/detail/:slug/',
            random: '/api/v1/anime/random/',
            watch: '/api/v1/anime/watch/:slug/:episode/',
            filters: {
              list_mode: '/api/v1/anime/filters/list-mode/',
              search: '/api/v1/anime/filters/',
            },
          },
          donghua: {
            sidebar: '/api/v1/donghua/sidebar/',
            home: '/api/v1/donghua/home/',
            schedule: '/api/v1/donghua/schedule/',
            search: '/api/v1/donghua/search/',
            ongoing: '/api/v1/donghua/ongoing/',
            completed: '/api/v1/donghua/completed/',
            genres: '/api/v1/donghua/genres/:slug/',
            az_list: '/api/v1/donghua/a-z/',
            detail: '/api/v1/donghua/detail/:slug/',
            random: '/api/v1/donghua/random/',
            watch: '/api/v1/donghua/watch/:slug/:episode/',
            filters: {
              list_mode: '/api/v1/donghua/filters/list-mode/',
              search: '/api/v1/donghua/filters/',
            },
          },
          dracin: {
            home: '/api/v1/dracin/{region}/home/',
            channel: '/api/v1/dracin/{region}/channel/:slug/',
            genres: '/api/v1/dracin/{region}/genres/',
            resources: '/api/v1/dracin/en/resources/',
            search: '/api/v1/dracin/{region}/search/',
            series: '/api/v1/dracin/{region}/series/:slug/',
            watch: '/api/v1/dracin/{region}/watch/:slug/',
          },
          health: '/api/v1/health/',
        },
        parameters: {
          apikey: 'optional',
          page: 'optional for paginated endpoints',
        },
        rate_limits: {
          guest: '25 requests/minute',
          free: '50 requests/minute',
          premium_1: '100 requests/minute',
          premium_2: '150 requests/minute',
          premium_3: '200 requests/minute',
          admin: '300 requests/minute',
          developer: '1000 requests/minute',
          owner: 'unlimited',
        },
      },
      message: null,
    }
  );
}