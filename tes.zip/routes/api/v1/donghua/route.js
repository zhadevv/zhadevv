import { NextResponse } from 'next/server';
import DonghuaParser from '../../../../src/lib/scraper/Donghua.js';

const donghuaParser = new DonghuaParser({
  baseUrl: 'https://anichin.cafe',
  timeout: 30000,
  retryCount: 3,
});

export async function GET(request) {
  const startTime = Date.now();
  
  try {
    const url = new URL(request.url);
    const pathSegments = url.pathname.split('/').filter(Boolean);
    const action = pathSegments[pathSegments.length - 1];
    const slug = pathSegments[pathSegments.length - 2];
    
    let result;
    
    switch(action) {
      case 'sidebar':
        const sidebarResponse = await donghuaParser.fetchWithRetry('');
        result = await donghuaParser.parse_sidebar(sidebarResponse.data);
        break;
        
      case 'home':
        const page = url.searchParams.get('page') || '1';
        const homeResponse = await donghuaParser.fetchWithRetry(`/page/${page}/`);
        result = await donghuaParser.parse_home(homeResponse.data);
        break;
        
      case 'schedule':
        const scheduleResponse = await donghuaParser.fetchWithRetry('/jadwal-rilis-donghua/');
        result = await donghuaParser.parse_schedule(scheduleResponse.data);
        break;
        
      case 'search':
        const query = url.searchParams.get('s') || '';
        const searchPage = url.searchParams.get('page') || '1';
        if (!query) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Search query (s) parameter required',
            },
            { status: 400 }
          );
        }
        const searchResponse = await donghuaParser.fetchWithRetry(`/page/${searchPage}/?s=${encodeURIComponent(query)}`);
        result = await donghuaParser.parse_search(searchResponse.data);
        break;
        
      case 'ongoing':
        const ongoingPage = url.searchParams.get('page') || '1';
        const ongoingResponse = await donghuaParser.fetchWithRetry(`/ongoing/page/${ongoingPage}/`);
        result = await donghuaParser.parse_ongoing(ongoingResponse.data);
        break;
        
      case 'completed':
        const completedPage = url.searchParams.get('page') || '1';
        const completedResponse = await donghuaParser.fetchWithRetry(`/completed/page/${completedPage}/`);
        result = await donghuaParser.parse_completed(completedResponse.data);
        break;
        
      case 'genres':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Genre slug required',
            },
            { status: 400 }
          );
        }
        const genrePage = url.searchParams.get('page') || '1';
        const genreResponse = await donghuaParser.fetchWithRetry(`/genres/${slug}/page/${genrePage}/`);
        result = await donghuaParser.parse_genres(genreResponse.data, slug);
        break;
        
      case 'a-z':
        const showLetter = url.searchParams.get('show');
        const azPage = url.searchParams.get('page') || '1';
        
        if (showLetter) {
          const azResponse = await donghuaParser.fetchWithRetry(`/az-list/page/${azPage}/?show=${showLetter}`);
          result = await donghuaParser.parse_az_list_with_show(azResponse.data, showLetter);
        } else {
          const azResponse = await donghuaParser.fetchWithRetry(`/az-list/page/${azPage}/`);
          result = await donghuaParser.parse_az_list(azResponse.data);
        }
        break;
        
      case 'detail':
        if (!slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug required',
            },
            { status: 400 }
          );
        }
        const detailResponse = await donghuaParser.fetchWithRetry(`/donghua/${slug}/`);
        result = await donghuaParser.parse_detail(detailResponse.data);
        break;
        
      case 'random':
        const randomResponse = await donghuaParser.fetchWithRetry('/az-list/');
        const randomData = await donghuaParser.parse_az_list(randomResponse.data);
        if (randomData.success && randomData.data.lists.length > 0) {
          const randomItem = randomData.data.lists[Math.floor(Math.random() * randomData.data.lists.length)];
          const randomDetailResponse = await donghuaParser.fetchWithRetry(randomItem.url);
          result = await donghuaParser.parse_detail(randomDetailResponse.data);
        } else {
          result = randomData;
        }
        break;
        
      case 'watch':
        const episodeSlug = pathSegments[pathSegments.length - 3];
        if (!episodeSlug || !slug) {
          return NextResponse.json(
            {
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Series slug and episode number required',
            },
            { status: 400 }
          );
        }
        const watchResponse = await donghuaParser.fetchWithRetry(`/${episodeSlug}-episode-${slug}/`);
        result = await donghuaParser.parse_watch(watchResponse.data);
        break;
        
      case 'list-mode':
        const listModeResponse = await donghuaParser.fetchWithRetry('/advanced-search/');
        result = await donghuaParser.parse_advanced_search_text_mode(listModeResponse.data);
        break;
        
      case 'filters':
        const filterPage = url.searchParams.get('page') || '1';
        const params = new URLSearchParams();
        
        const filterParams = ['status', 'order', 'type', 'sub', 'genre[]', 'studio[]', 'season[]'];
        filterParams.forEach(param => {
          const value = url.searchParams.get(param);
          if (value) params.append(param, value);
        });
        
        const filterUrl = `/advanced-search/page/${filterPage}/?${params.toString()}`;
        const filterResponse = await donghuaParser.fetchWithRetry(filterUrl);
        result = await donghuaParser.parse_advance_search(filterResponse.data);
        break;
        
      default:
        return NextResponse.json(
          {
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Endpoint not found',
          },
          { status: 404 }
        );
    }
    
    const processTime = Date.now() - startTime;
    
    const response = NextResponse.json(result, {
      headers: {
        'X-Process-Time': `${processTime}ms`,
        'Cache-Control': 'public, max-age=300, s-maxage=600',
        'Content-Type': 'application/json',
      },
    });
    
    return response;
    
  } catch (error) {
    return NextResponse.json(
      {
        status: 500,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `Failed to process request: ${error.message}`,
      },
      { status: 500 }
    );
  }
}