#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
from pathlib import Path
import argparse

def setup_project():
    print("🔧 Setting up zhadev API project...")
    
    current_dir = Path(__file__).parent.parent
    data_dir = current_dir / "data"
    logs_dir = current_dir / "logs"
    
    print(f"📁 Project directory: {current_dir}")
    
    data_dir.mkdir(exist_ok=True)
    logs_dir.mkdir(exist_ok=True)
    
    print("✅ Created directories: data/, logs/")
    
    env_file = current_dir / ".env"
    if not env_file.exists():
        env_content = """# JWT Configuration
JWT_SECRET=YourJWTSecretKey123!
JWT_EXPIRE=3

# Rate Limiting
DEFAULT_RPM=25

# API Keys
ADMIN_APIKEY=
DEV_APIKEY=YOUR_16_CHAR_DEV_KEY
OWNER_APIKEY=YOUR_32_CHAR_OWNER_KEY

# Cloudflare
CF_API_TOKEN=
CF_ZONE_ID=

# Server
PORT=8000
HOST=0.0.0.0
ENVIRONMENT=development
RELOAD=true
"""
        with open(env_file, "w") as f:
            f.write(env_content)
        print("✅ Created .env file with default values")
    
    config_file = current_dir / "config.yaml"
    if not config_file.exists():
        shutil.copy(current_dir / "config.yaml.example", config_file)
        print("✅ Created config.yaml from example")
    
    requirements_file = current_dir / "requirements.txt"
    if requirements_file.exists():
        print("📦 Installing dependencies...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(requirements_file)], 
                         check=True)
            print("✅ Dependencies installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install dependencies: {e}")
    
    print("\n🎉 Setup completed!")
    print("\n📋 Next steps:")
    print("1. Edit .env file with your configuration")
    print("2. Edit config.yaml if needed")
    print("3. Run the API: python start.py")
    print("4. Visit: http://localhost:8000/docs")

def create_admin_key():
    from lib.system.validator import Validator
    from lib.database import Database
    
    print("🔑 Creating admin API key...")
    
    api_key = Validator.generate_api_key("admin")
    username = "admin_user"
    
    db = Database()
    success = db.add_api_key(
        api_key=api_key,
        username=username,
        role="admin",
        rpm_limit=1000,
        monthly_limit=5000000,
        custom_key=False
    )
    
    if success:
        print(f"✅ Admin API key created:")
        print(f"   Key: {api_key}")
        print(f"   Username: {username}")
        print(f"   Role: admin")
        print(f"   RPM Limit: 1000")
        print(f"   Monthly Limit: 5,000,000")
    else:
        print("❌ Failed to create admin API key")

def init_database():
    from lib.database import Database
    
    print("🗄️ Initializing database...")
    
    db = Database()
    
    print("✅ Database initialized successfully")
    print(f"📁 Database file: data/zhadev.db")

def main():
    parser = argparse.ArgumentParser(description="zhadev API Setup Tool")
    parser.add_argument("--setup", action="store_true", help="Setup project structure")
    parser.add_argument("--create-admin", action="store_true", help="Create admin API key")
    parser.add_argument("--init-db", action="store_true", help="Initialize database")
    parser.add_argument("--all", action="store_true", help="Run all setup steps")
    
    args = parser.parse_args()
    
    if args.all:
        args.setup = True
        args.init_db = True
        args.create_admin = True
    
    if args.setup:
        setup_project()
    
    if args.init_db:
        init_database()
    
    if args.create_admin:
        create_admin_key()
    
    if not any([args.setup, args.create_admin, args.init_db, args.all]):
        parser.print_help()

if __name__ == "__main__":
    main()