#!/usr/bin/env python3
import asyncio
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

async def test_scraper():
    print("🧪 Testing scrapers...")
    
    try:
        from scraper import OploverzParser, DonghuaParser, DramaboxParser
        
        print("\n1. Testing Anime Scraper (Oploverz)...")
        try:
            async with OploverzParser() as parser:
                print("   📍 Testing sidebar...")
                result = await parser.sidebar()
                if result.get("success"):
                    print("   ✅ Sidebar test passed")
                else:
                    print(f"   ❌ Sidebar test failed: {result.get('message')}")
                
                print("   📍 Testing home page...")
                result = await parser.home(page=1)
                if result.get("success"):
                    print("   ✅ Home page test passed")
                else:
                    print(f"   ❌ Home page test failed: {result.get('message')}")
                
                print("   📍 Testing search...")
                result = await parser.search(query="naruto", page=1)
                if result.get("success"):
                    print("   ✅ Search test passed")
                else:
                    print(f"   ❌ Search test failed: {result.get('message')}")
        except Exception as e:
            print(f"   ❌ Anime scraper test failed: {str(e)}")
        
        print("\n2. Testing Donghua Scraper (Anichin)...")
        try:
            async with DonghuaParser() as parser:
                print("   📍 Testing sidebar...")
                result = await parser.sidebar()
                if result.get("success"):
                    print("   ✅ Sidebar test passed")
                else:
                    print(f"   ❌ Sidebar test failed: {result.get('message')}")
                
                print("   📍 Testing home page...")
                result = await parser.home(page=1)
                if result.get("success"):
                    print("   ✅ Home page test passed")
                else:
                    print(f"   ❌ Home page test failed: {result.get('message')}")
                
                print("   📍 Testing search...")
                result = await parser.search(query="donghua", page=1)
                if result.get("success"):
                    print("   ✅ Search test passed")
                else:
                    print(f"   ❌ Search test failed: {result.get('message')}")
        except Exception as e:
            print(f"   ❌ Donghua scraper test failed: {str(e)}")
        
        print("\n3. Testing Dracin Scraper (Dramabox)...")
        try:
            async with DramaboxParser(region="en") as parser:
                print("   📍 Testing home page...")
                result = await parser.home()
                if result.get("success"):
                    print("   ✅ Home page test passed")
                else:
                    print(f"   ❌ Home page test failed: {result.get('message')}")
                
                print("   📍 Testing browse...")
                result = await parser.browse(category_id="0", page=1)
                if result.get("success"):
                    print("   ✅ Browse test passed")
                else:
                    print(f"   ❌ Browse test failed: {result.get('message')}")
        except Exception as e:
            print(f"   ❌ Dracin scraper test failed: {str(e)}")
    
    except ImportError as e:
        print(f"❌ Failed to import scrapers: {str(e)}")
        return
    
    print("\n🎉 All scraper tests completed!")

async def test_api():
    print("\n🔗 Testing API endpoints...")
    
    try:
        import httpx
        import time
        
        base_url = "http://localhost:8000"
        
        print(f"   📍 Testing health endpoint...")
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(f"{base_url}/api/health")
                if response.status_code == 200:
                    print("   ✅ Health endpoint test passed")
                else:
                    print(f"   ❌ Health endpoint test failed: {response.status_code}")
        except Exception as e:
            print(f"   ❌ Health endpoint test failed: {str(e)}")
        
        print(f"   📍 Testing stats endpoint...")
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(f"{base_url}/api/stats")
                if response.status_code == 200:
                    print("   ✅ Stats endpoint test passed")
                else:
                    print(f"   ❌ Stats endpoint test failed: {response.status_code}")
        except Exception as e:
            print(f"   ❌ Stats endpoint test failed: {str(e)}")
        
        print(f"   📍 Testing anime endpoint (public)...")
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.get(f"{base_url}/api/v1/anime/sidebar")
                if response.status_code == 200:
                    print("   ✅ Anime endpoint test passed")
                else:
                    print(f"   ❌ Anime endpoint test failed: {response.status_code}")
        except Exception as e:
            print(f"   ❌ Anime endpoint test failed: {str(e)}")
    
    except ImportError as e:
        print(f"❌ Failed to import httpx: {str(e)}")
        return
    
    print("\n🎉 API tests completed!")

async def test_database():
    print("\n🗄️ Testing database...")
    
    try:
        from lib.database import Database
        
        db = Database()
        
        print("   📍 Testing API key operations...")
        test_key = "TEST_KEY_123"
        
        success = db.add_api_key(
            api_key=test_key,
            username="test_user",
            role="free",
            rpm_limit=50,
            monthly_limit=5000
        )
        
        if success:
            print("   ✅ API key creation test passed")
            
            key_info = db.get_api_key_info(test_key)
            if key_info:
                print("   ✅ API key retrieval test passed")
            else:
                print("   ❌ API key retrieval test failed")
            
            db.delete_api_key(test_key)
            print("   ✅ API key deletion test passed")
        else:
            print("   ❌ API key creation test failed")
        
        print("   📍 Testing rate limiting...")
        allowed, remaining, reset = db.check_rate_limit(
            identifier="test_ip_127.0.0.1",
            period="minute",
            limit=10
        )
        if allowed:
            print("   ✅ Rate limiting test passed")
        else:
            print("   ❌ Rate limiting test failed")
        
        print("   📍 Testing cache operations...")
        cache_key = "test_cache"
        cache_value = {"test": "data"}
        
        db.set_cache(cache_key, cache_value, ttl=60)
        retrieved = db.get_cache(cache_key)
        
        if retrieved == cache_value:
            print("   ✅ Cache operations test passed")
        else:
            print("   ❌ Cache operations test failed")
        
        db.delete_cache(cache_key)
    
    except Exception as e:
        print(f"❌ Database test failed: {str(e)}")
        return
    
    print("\n🎉 Database tests completed!")

async def run_all_tests():
    print("🚀 Running comprehensive tests for zhadev API")
    print("=" * 50)
    
    await test_scraper()
    await test_database()
    await test_api()
    
    print("\n" + "=" * 50)
    print("🎊 All tests completed successfully!")

if __name__ == "__main__":
    asyncio.run(run_all_tests())