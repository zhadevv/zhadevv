#!/usr/bin/env python3
import os
import secrets
import string
import argparse
from pathlib import Path

def generate_random_string(length: int, use_special: bool = False) -> str:
    if use_special:
        chars = string.ascii_letters + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"
    else:
        chars = string.ascii_letters + string.digits
    
    return ''.join(secrets.choice(chars) for _ in range(length))

def generate_env_file(force: bool = False, output_file: str = ".env"):
    env_path = Path(output_file)
    
    if env_path.exists() and not force:
        print(f"⚠️  {output_file} already exists. Use --force to overwrite.")
        return
    
    print(f"🔧 Generating {output_file}...")
    
    env_content = f"""# ========================================
# zhadev API Environment Configuration
# ========================================

# JWT Configuration
JWT_SECRET={generate_random_string(32, True)}
JWT_EXPIRE=3

# Rate Limiting Configuration
DEFAULT_RPM=25

# API Keys Configuration
# Note: These keys should be kept secret!
ADMIN_APIKEY={generate_random_string(32)}
DEV_APIKEY={generate_random_string(16)}
OWNER_APIKEY={generate_random_string(32)}

# Cloudflare Configuration (Optional)
CF_API_TOKEN=
CF_ZONE_ID=

# Server Configuration
PORT=8000
HOST=0.0.0.0
ENVIRONMENT=development
RELOAD=true

# Database Configuration (SQLite by default)
# For MySQL/PostgreSQL, uncomment and configure:
# DB_DRIVER=mysql
# DB_HOST=localhost
# DB_PORT=3306
# DB_NAME=zhadev
# DB_USER=root
# DB_PASSWORD=password

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=logs/zhadev.log

# Security Configuration
ALLOWED_HOSTS=*
CORS_ORIGINS=*
SECURE_COOKIES=true
HSTS_ENABLED=true

# Scraper Configuration
ANIME_BASE_URL=https://oploverz.mom
DONGHUA_BASE_URL=https://anichin.cafe
DRACIN_BASE_URL=https://www.dramaboxdb.com
SCRAPER_TIMEOUT=30
SCRAPER_RETRIES=3

# Cache Configuration
CACHE_ENABLED=true
CACHE_TTL=300
CACHE_MAX_SIZE=1000

# Rate Limit Configuration
GUEST_RPM=25
GUEST_MONTHLY=1000
FREE_RPM=50
FREE_MONTHLY=5000
STARTER_RPM=100
STARTER_MONTHLY=10000
MEDIUM_RPM=150
MEDIUM_MONTHLY=50000
HIGHEST_RPM=200
HIGHEST_MONTHLY=100000
ENTERPRISE_RPM=500
ENTERPRISE_MONTHLY=1000000
ADMIN_RPM=1000
ADMIN_MONTHLY=5000000
DEVELOPER_RPM=5000
DEVELOPER_MONTHLY=10000000
OWNER_RPM=10000
OWNER_MONTHLY=100000000
"""

    with open(env_path, "w") as f:
        f.write(env_content)
    
    print(f"✅ {output_file} generated successfully!")
    print("\n⚠️  IMPORTANT: Keep this file secure!")
    print("   Do not commit it to version control.")
    
    if ".gitignore" not in output_file:
        print("\n📋 Add to .gitignore:")
        print(f"   echo '{output_file}' >> .gitignore")

def generate_docker_env():
    print("🐳 Generating Docker environment files...")
    
    docker_env = """# Docker Environment Variables
COMPOSE_PROJECT_NAME=zhadev-api
API_PORT=8000
DB_PORT=5432
REDIS_PORT=6379
"""
    
    with open(".env.docker", "w") as f:
        f.write(docker_env)
    
    print("✅ .env.docker generated successfully!")

def generate_production_env():
    print("🚀 Generating production environment file...")
    
    prod_env = f"""# Production Environment
JWT_SECRET={generate_random_string(64, True)}
JWT_EXPIRE=1

ADMIN_APIKEY={generate_random_string(64)}
DEV_APIKEY={generate_random_string(32)}
OWNER_APIKEY={generate_random_string(64)}

PORT=8000
HOST=0.0.0.0
ENVIRONMENT=production
RELOAD=false

LOG_LEVEL=WARNING
SECURE_COOKIES=true
HSTS_ENABLED=true

# Production database (example for PostgreSQL)
DB_DRIVER=postgresql
DB_HOST=localhost
DB_PORT=5432
DB_NAME=zhadev_prod
DB_USER=zhadev_user
DB_PASSWORD={generate_random_string(32)}

# Redis for cache and rate limiting
REDIS_URL=redis://localhost:6379/0
CACHE_ENABLED=true
"""
    
    with open(".env.production", "w") as f:
        f.write(prod_env)
    
    print("✅ .env.production generated successfully!")
    print("⚠️  Remember to configure database and Redis in production!")

def generate_example_env():
    print("📝 Generating example environment file...")
    
    example_env = """# zhadev API - Example Environment Configuration
# Copy this file to .env and fill in the values

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRE=3

# Rate Limiting
DEFAULT_RPM=25

# API Keys
ADMIN_APIKEY=your_admin_apikey_here
DEV_APIKEY=your_dev_apikey_here
OWNER_APIKEY=your_owner_apikey_here

# Cloudflare (Optional)
CF_API_TOKEN=
CF_ZONE_ID=

# Server
PORT=8000
HOST=0.0.0.0
ENVIRONMENT=development
RELOAD=true

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/zhadev.log
"""

    with open(".env.example", "w") as f:
        f.write(example_env)
    
    print("✅ .env.example generated successfully!")

def main():
    parser = argparse.ArgumentParser(description="zhadev API Environment Generator")
    parser.add_argument("--force", "-f", action="store_true", help="Force overwrite existing files")
    parser.add_argument("--output", "-o", default=".env", help="Output file name (default: .env)")
    parser.add_argument("--docker", action="store_true", help="Generate Docker environment files")
    parser.add_argument("--production", action="store_true", help="Generate production environment")
    parser.add_argument("--example", action="store_true", help="Generate example environment file")
    parser.add_argument("--all", action="store_true", help="Generate all environment files")
    
    args = parser.parse_args()
    
    if args.all:
        args.docker = True
        args.production = True
        args.example = True
    
    generate_env_file(force=args.force, output_file=args.output)
    
    if args.docker:
        generate_docker_env()
    
    if args.production:
        generate_production_env()
    
    if args.example:
        generate_example_env()
    
    if not any([args.docker, args.production, args.example, args.all]):
        print("\n📋 Usage tips:")
        print("   python scripts/env_generate.py --all        # Generate all files")
        print("   python scripts/env_generate.py --docker     # Generate Docker files")
        print("   python scripts/env_generate.py --production # Generate production env")
        print("   python scripts/env_generate.py --example    # Generate example file")
        print("   python scripts/env_generate.py --force      # Overwrite existing .env")

if __name__ == "__main__":
    main()