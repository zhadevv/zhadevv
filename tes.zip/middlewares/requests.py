from fastapi import Request
from typing import Dict, Any
import time
import json
from datetime import datetime


class RequestLoggerMiddleware:
    async def __call__(self, request: Request, call_next):
        start_time = time.time()
        
        request_info = {
            "method": request.method,
            "url": str(request.url),
            "client_ip": request.client.host,
            "user_agent": request.headers.get("user-agent", ""),
            "content_type": request.headers.get("content-type"),
            "accept": request.headers.get("accept"),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        auth_header = request.headers.get("authorization")
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            request_info["apikey"] = apikey[:8] + "..." if len(apikey) > 8 else apikey
        
        request.state.request_info = request_info
        
        response = await call_next(request)
        
        process_time = time.time() - start_time
        request_info["response_time"] = process_time
        request_info["status_code"] = response.status_code
        
        self._log_request(request_info)
        
        response.headers["X-Request-Time"] = f"{process_time:.3f}"
        response.headers["X-Request-ID"] = request.state.get("request_id", "")
        
        return response
    
    def _log_request(self, request_info: Dict[str, Any]):
        try:
            log_entry = {
                "type": "request",
                "timestamp": request_info["timestamp"],
                "method": request_info["method"],
                "url": request_info["url"],
                "client_ip": request_info["client_ip"],
                "status_code": request_info.get("status_code", 0),
                "response_time": request_info.get("response_time", 0),
                "user_agent": request_info.get("user_agent", "")[:200]
            }
            
            if "apikey" in request_info:
                log_entry["apikey"] = request_info["apikey"]
            
            print(f"[REQUEST] {json.dumps(log_entry)}")
        except:
            pass


class RequestValidatorMiddleware:
    async def __call__(self, request: Request, call_next):
        if request.method in ["POST", "PUT", "PATCH"]:
            content_type = request.headers.get("content-type", "")
            
            if content_type and "application/json" in content_type:
                try:
                    body = await request.body()
                    
                    if body:
                        body_str = body.decode('utf-8')
                        
                        try:
                            json.loads(body_str)
                        except json.JSONDecodeError:
                            from fastapi import HTTPException
                            raise HTTPException(
                                status_code=400,
                                detail="Invalid JSON format"
                            )
                except:
                    pass
        
        return await call_next(request)


class RequestEnricherMiddleware:
    async def __call__(self, request: Request, call_next):
        request_id = request.state.get("request_id", "")
        
        if not request_id:
            import hashlib
            request_id = hashlib.sha256(
                f"{request.client.host}:{time.time()}".encode()
            ).hexdigest()[:16]
            request.state.request_id = request_id
        
        request.state.start_time = time.time()
        
        geo_data = self._get_geo_data(request.client.host)
        if geo_data:
            request.state.geo_data = geo_data
        
        response = await call_next(request)
        
        if hasattr(request.state, "geo_data"):
            response.headers["X-Geo-Country"] = request.state.geo_data.get("country", "")
            response.headers["X-Geo-Region"] = request.state.geo_data.get("region", "")
            response.headers["X-Geo-City"] = request.state.geo_data.get("city", "")
        
        return response
    
    def _get_geo_data(self, ip: str) -> Dict[str, str]:
        return {}


class RequestMetricsMiddleware:
    def __init__(self):
        self.metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "avg_response_time": 0,
            "endpoints": {},
            "methods": {}
        }
    
    async def __call__(self, request: Request, call_next):
        self.metrics["total_requests"] += 1
        
        endpoint = str(request.url.path)
        method = request.method
        
        if endpoint not in self.metrics["endpoints"]:
            self.metrics["endpoints"][endpoint] = {
                "count": 0,
                "avg_time": 0,
                "errors": 0
            }
        
        self.metrics["endpoints"][endpoint]["count"] += 1
        
        if method not in self.metrics["methods"]:
            self.metrics["methods"][method] = 0
        
        self.metrics["methods"][method] += 1
        
        start_time = time.time()
        
        try:
            response = await call_next(request)
            
            process_time = time.time() - start_time
            
            if 200 <= response.status_code < 400:
                self.metrics["successful_requests"] += 1
            else:
                self.metrics["failed_requests"] += 1
                self.metrics["endpoints"][endpoint]["errors"] += 1
            
            current_avg = self.metrics["avg_response_time"]
            total_req = self.metrics["total_requests"]
            
            self.metrics["avg_response_time"] = (
                (current_avg * (total_req - 1)) + process_time
            ) / total_req
            
            endpoint_avg = self.metrics["endpoints"][endpoint]["avg_time"]
            endpoint_count = self.metrics["endpoints"][endpoint]["count"]
            
            self.metrics["endpoints"][endpoint]["avg_time"] = (
                (endpoint_avg * (endpoint_count - 1)) + process_time
            ) / endpoint_count
            
            response.headers["X-Metrics-Total"] = str(self.metrics["total_requests"])
            response.headers["X-Metrics-Avg-Time"] = f"{self.metrics['avg_response_time']:.3f}"
            
            return response
            
        except Exception as e:
            self.metrics["failed_requests"] += 1
            self.metrics["endpoints"][endpoint]["errors"] += 1
            raise
    
    def get_metrics(self) -> Dict[str, Any]:
        return self.metrics.copy()