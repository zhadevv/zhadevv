from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import time
import json
import logging

from lib.database import Database


class RequestLoggerMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
        self.logger = logging.getLogger(__name__)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        try:
            response = await call_next(request)
            
            process_time = (time.time() - start_time) * 1000
            
            await self._log_request(request, response, process_time)
            
            return response
        
        except Exception as exc:
            process_time = (time.time() - start_time) * 1000
            
            error_response = Response(
                content=json.dumps({
                    "status": 500,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Internal server error"
                }),
                status_code=500,
                media_type="application/json"
            )
            
            await self._log_request(request, error_response, process_time, error=str(exc))
            
            raise
    
    async def _log_request(self, request: Request, response: Response, 
                          process_time: float, error: str = None):
        try:
            request_id = getattr(request.state, "request_id", None)
            client_ip = request.state.get("client_ip", "0.0.0.0")
            api_key = request.state.get("api_key")
            
            user_agent = request.headers.get("user-agent")
            
            log_data = {
                "timestamp": time.time(),
                "request_id": request_id,
                "client_ip": client_ip,
                "api_key": api_key,
                "method": request.method,
                "path": request.url.path,
                "query_params": dict(request.query_params),
                "status_code": response.status_code,
                "response_time_ms": round(process_time, 2),
                "user_agent": user_agent,
                "content_length": response.headers.get("content-length", 0),
                "error": error
            }
            
            if api_key:
                self.db.update_api_stats(
                    endpoint=request.url.path,
                    success=response.status_code < 400,
                    response_time=process_time
                )
            
            self.db.log_request(
                request_id=request_id or "unknown",
                api_key=api_key,
                client_ip=client_ip,
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                user_agent=user_agent,
                response_time=process_time
            )
            
            log_level = "INFO" if response.status_code < 400 else "WARNING"
            if response.status_code >= 500:
                log_level = "ERROR"
            
            log_message = (
                f"{log_level}: {request.method} {request.url.path} "
                f"{response.status_code} {process_time:.2f}ms"
            )
            
            if log_level == "INFO":
                self.logger.info(log_message)
            elif log_level == "WARNING":
                self.logger.warning(log_message)
            else:
                self.logger.error(log_message)
            
        except Exception as log_exc:
            self.logger.error(f"Failed to log request: {str(log_exc)}")
    
    def _should_log_request(self, path: str) -> bool:
        exclude_paths = [
            '/health',
            '/favicon.ico',
            '/robots.txt',
        ]
        
        for exclude in exclude_paths:
            if path.startswith(exclude):
                return False
        
        return True