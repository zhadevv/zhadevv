import winston from 'winston';

const logger = winston.createLogger({
  level: 'error',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log' }),
  ],
});

export function errorMiddleware(err, req, res, next) {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  
  logger.error({
    timestamp: new Date().toISOString(),
    requestId: req.requestId,
    method: req.method,
    url: req.url,
    ip: req.ip,
    error: err.message,
    stack: err.stack,
  });
  
  res.status(statusCode).json({
    status: statusCode,
    success: false,
    author: 'zhadevv',
    data: null,
    message: process.env.NODE_ENV === 'production' ? 'Internal server error' : message,
  });
}