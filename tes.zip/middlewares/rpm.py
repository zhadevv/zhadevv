from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import json
import time

from lib.database import Database
from lib.system.validator import Validator


class RPMMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        api_key = request.state.get("api_key")
        client_ip = request.state.get("client_ip", "0.0.0.0")
        
        if api_key:
            api_info = request.state.get("api_info")
            
            if api_info:
                role = api_info.get("role", "guest")
                rpm_limit = api_info.get("rpm_limit", 25)
                
                if role in ["owner", "developer", "admin"] and api_key in [
                    getattr(settings.security, f"{role}_apikey", "") for role in ["owner", "developer", "admin"]
                ]:
                    return await call_next(request)
                
                identifier = f"api_key_{api_key}"
            else:
                role = "guest"
                rpm_limit = 25
                identifier = f"ip_{client_ip}"
        else:
            role = "guest"
            rpm_limit = 25
            identifier = f"ip_{client_ip}"
        
        allowed, remaining, reset_time = self.db.check_rate_limit(
            identifier, "minute", rpm_limit
        )
        
        if not allowed:
            headers = Validator.calculate_rate_limit_headers(
                remaining,
                rpm_limit,
                reset_time
            )
            
            return Response(
                content=json.dumps({
                    "status": 429,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Requests per minute limit exceeded"
                }),
                status_code=429,
                media_type="application/json",
                headers=headers
            )
        
        request.state.rpm_info = {
            "limit": rpm_limit,
            "remaining": remaining,
            "reset": reset_time,
            "role": role
        }
        
        response = await call_next(request)
        
        if hasattr(request.state, "rpm_info"):
            response.headers["X-RateLimit-Limit"] = str(rpm_limit)
            response.headers["X-RateLimit-Remaining"] = str(remaining)
            response.headers["X-RateLimit-Reset"] = str(reset_time)
        
        return response