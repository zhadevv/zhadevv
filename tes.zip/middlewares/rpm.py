from fastapi import HTTPException, Request
from lib.system.config import config
from lib.system.middleware import rate_limiter
from lib.system.validator import validator
from typing import Optional, Dict
import time

class RPMCalculator:
    def __init__(self):
        self.requests_log = {}
    
    def calculate_rpm(self, identifier: str) -> float:
        current_time = time.time()
        window_start = current_time - 60
        
        if identifier not in self.requests_log:
            return 0
        
        recent_requests = [
            req_time for req_time in self.requests_log[identifier]
            if req_time > window_start
        ]
        
        self.requests_log[identifier] = recent_requests
        
        return len(recent_requests)
    
    def add_request(self, identifier: str):
        current_time = time.time()
        
        if identifier not in self.requests_log:
            self.requests_log[identifier] = []
        
        self.requests_log[identifier].append(current_time)
        
        if len(self.requests_log[identifier]) > 1000:
            self.requests_log[identifier] = self.requests_log[identifier][-500:]


class RPMMiddleware:
    def __init__(self, default_rpm: int = None):
        self.default_rpm = default_rpm or config.env.DEFAULT_RPM
        self.calculator = RPMCalculator()
        self.custom_limits = {}
    
    async def __call__(self, request: Request, call_next):
        identifier = self._get_identifier(request)
        
        current_rpm = self.calculator.calculate_rpm(identifier)
        limit_rpm = self._get_limit_for_identifier(identifier)
        
        if current_rpm >= limit_rpm:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: {current_rpm}/{limit_rpm} RPM"
            )
        
        self.calculator.add_request(identifier)
        
        response = await call_next(request)
        
        response.headers["X-RPM-Current"] = str(current_rpm + 1)
        response.headers["X-RPM-Limit"] = str(limit_rpm)
        response.headers["X-RPM-Remaining"] = str(max(0, limit_rpm - (current_rpm + 1)))
        response.headers["X-RPM-Reset"] = str(int(time.time() + 60))
        
        return response
    
    def _get_identifier(self, request: Request) -> str:
        auth_header = request.headers.get("authorization")
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            valid, role = validator.validate_apikey(apikey)
            
            if valid:
                if role == "guest":
                    return f"guest:{request.client.host}"
                else:
                    return f"{role}:{apikey}"
        
        return f"guest:{request.client.host}"
    
    def _get_limit_for_identifier(self, identifier: str) -> int:
        if identifier in self.custom_limits:
            return self.custom_limits[identifier]
        
        if identifier.startswith("guest:"):
            return config.get_rate_limit("guest").rpm
        
        parts = identifier.split(":", 1)
        if len(parts) == 2:
            role = parts[0]
            if hasattr(config.rate_limits, role):
                return getattr(config.rate_limits, role).rpm
        
        return self.default_rpm
    
    def set_custom_limit(self, identifier: str, rpm: int):
        self.custom_limits[identifier] = max(1, rpm)
    
    def remove_custom_limit(self, identifier: str):
        if identifier in self.custom_limits:
            del self.custom_limits[identifier]


class MonthlyLimitMiddleware:
    def __init__(self):
        self.monthly_counts = {}
    
    async def __call__(self, request: Request, call_next):
        auth_header = request.headers.get("authorization")
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            valid, role = validator.validate_apikey(apikey)
            
            if valid and role not in ["guest", "admin", "developer", "owner"]:
                from lib.global import db
                apikey_data = db.get_apikey(apikey)
                
                if apikey_data:
                    monthly_limit = config.get_rate_limit(role).monthly_limit
                    monthly_used = apikey_data.get("requests_month", 0)
                    
                    if monthly_used >= monthly_limit:
                        raise HTTPException(
                            status_code=429,
                            detail=f"Monthly limit exceeded: {monthly_used}/{monthly_limit}"
                        )
        
        response = await call_next(request)
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            valid, role = validator.validate_apikey(apikey)
            
            if valid and role not in ["guest", "admin", "developer", "owner"]:
                monthly_limit = config.get_rate_limit(role).monthly_limit
                
                from lib.global import db
                apikey_data = db.get_apikey(apikey)
                
                if apikey_data:
                    monthly_used = apikey_data.get("requests_month", 0)
                    remaining = max(0, monthly_limit - (monthly_used + 1))
                    
                    response.headers["X-Monthly-Used"] = str(monthly_used + 1)
                    response.headers["X-Monthly-Limit"] = str(monthly_limit)
                    response.headers["X-Monthly-Remaining"] = str(remaining)
        
        return response


class AdaptiveRPMMiddleware:
    def __init__(self, base_rpm: int = 25, max_rpm: int = 1000):
        self.base_rpm = base_rpm
        self.max_rpm = max_rpm
        self.performance_history = {}
    
    async def __call__(self, request: Request, call_next):
        identifier = self._get_identifier(request)
        
        current_rpm = self._get_current_rpm(identifier)
        adaptive_limit = self._calculate_adaptive_limit(identifier)
        
        if current_rpm >= adaptive_limit:
            raise HTTPException(
                status_code=429,
                detail=f"Adaptive rate limit exceeded: {current_rpm}/{adaptive_limit} RPM"
            )
        
        start_time = time.time()
        
        response = await call_next(request)
        
        process_time = time.time() - start_time
        
        self._update_performance_history(identifier, process_time, response.status_code)
        
        response.headers["X-RPM-Adaptive-Limit"] = str(adaptive_limit)
        response.headers["X-RPM-Adaptive-Current"] = str(current_rpm + 1)
        
        return response
    
    def _get_identifier(self, request: Request) -> str:
        auth_header = request.headers.get("authorization")
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            return f"apikey:{apikey}"
        
        return f"ip:{request.client.host}"
    
    def _get_current_rpm(self, identifier: str) -> int:
        current_time = time.time()
        window_start = current_time - 60
        
        if identifier not in self.performance_history:
            return 0
        
        history = self.performance_history[identifier]
        recent_requests = [
            req for req in history.get("requests", [])
            if req["timestamp"] > window_start
        ]
        
        return len(recent_requests)
    
    def _calculate_adaptive_limit(self, identifier: str) -> int:
        if identifier not in self.performance_history:
            return self.base_rpm
        
        history = self.performance_history[identifier]
        
        avg_response_time = history.get("avg_response_time", 0)
        error_rate = history.get("error_rate", 0)
        
        if error_rate > 0.1:
            return max(self.base_rpm // 2, 5)
        
        if avg_response_time > 5.0:
            return max(self.base_rpm // 2, 10)
        
        if avg_response_time < 1.0:
            return min(self.base_rpm * 2, self.max_rpm)
        
        return self.base_rpm
    
    def _update_performance_history(self, identifier: str, response_time: float, status_code: int):
        if identifier not in self.performance_history:
            self.performance_history[identifier] = {
                "requests": [],
                "total_response_time": 0,
                "error_count": 0,
                "request_count": 0
            }
        
        history = self.performance_history[identifier]
        
        history["requests"].append({
            "timestamp": time.time(),
            "response_time": response_time,
            "status_code": status_code
        })
        
        if len(history["requests"]) > 100:
            history["requests"] = history["requests"][-50:]
        
        history["total_response_time"] += response_time
        history["request_count"] += 1
        
        if status_code >= 400:
            history["error_count"] += 1
        
        if history["request_count"] > 0:
            history["avg_response_time"] = history["total_response_time"] / history["request_count"]
            history["error_rate"] = history["error_count"] / history["request_count"]