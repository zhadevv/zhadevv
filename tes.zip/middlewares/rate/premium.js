export function ownerRateLimit(req, res, next) {
  res.setHeader('X-RateLimit-Limit', 'infinity');
  res.setHeader('X-RateLimit-Remaining', 'infinity');
  next();
}