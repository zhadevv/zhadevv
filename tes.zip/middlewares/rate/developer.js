import { rpmMiddleware } from '../rpm.js';

const DEV_LIMIT = parseInt(process.env.DEV_LIMIT) || 1000;

export const developerRateLimit = rpmMiddleware(DEV_LIMIT);