import { rpmMiddleware } from '../rpm.js';

const FREE_LIMIT = parseInt(process.env.FREE_LIMIT) || 50;

export const freeRateLimit = rpmMiddleware(FREE_LIMIT);