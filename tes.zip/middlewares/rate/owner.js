const ownerRateLimiter = (req, res, next) => {
    next()
}

export default ownerRateLimiter