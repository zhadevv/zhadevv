import { rpmMiddleware } from '../rpm.js';

const GUEST_LIMIT = parseInt(process.env.GUEST_LIMIT) || 25;

export const guestRateLimit = rpmMiddleware(GUEST_LIMIT);