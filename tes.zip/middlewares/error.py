#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import traceback
import json
from typing import Dict, Any
from datetime import datetime

class ErrorHandlerMiddleware:
    def __init__(self, debug: bool = False):
        self.debug = debug
    
    async def __call__(self, request: Request, call_next):
        try:
            response = await call_next(request)
            return response
            
        except HTTPException as exc:
            return self._handle_http_exception(exc, request)
            
        except RequestValidationError as exc:
            return self._handle_validation_error(exc, request)
            
        except StarletteHTTPException as exc:
            return self._handle_starlette_exception(exc, request)
            
        except Exception as exc:
            return self._handle_unexpected_error(exc, request)
    
    def _handle_http_exception(self, exc: HTTPException, request: Request) -> JSONResponse:
        error_response = {
            "status": exc.status_code,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": exc.detail
        }
        
        self._log_error(request, exc.status_code, str(exc.detail))
        
        return JSONResponse(
            status_code=exc.status_code,
            content=error_response,
            headers=self._get_error_headers()
        )
    
    def _handle_validation_error(self, exc: RequestValidationError, request: Request) -> JSONResponse:
        errors = []
        for error in exc.errors():
            errors.append({
                "loc": error.get("loc", []),
                "msg": error.get("msg", ""),
                "type": error.get("type", "")
            })
        
        error_response = {
            "status": 422,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": "Validation error",
            "errors": errors
        }
        
        self._log_error(request, 422, f"Validation error: {errors}")
        
        return JSONResponse(
            status_code=422,
            content=error_response,
            headers=self._get_error_headers()
        )
    
    def _handle_starlette_exception(self, exc: StarletteHTTPException, request: Request) -> JSONResponse:
        error_response = {
            "status": exc.status_code,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": exc.detail
        }
        
        self._log_error(request, exc.status_code, str(exc.detail))
        
        return JSONResponse(
            status_code=exc.status_code,
            content=error_response,
            headers=self._get_error_headers()
        )
    
    def _handle_unexpected_error(self, exc: Exception, request: Request) -> JSONResponse:
        error_id = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        
        error_details = {
            "error_id": error_id,
            "type": type(exc).__name__,
            "message": str(exc)
        }
        
        if self.debug:
            error_details["traceback"] = traceback.format_exc()
        
        error_response = {
            "status": 500,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": "Internal server error",
            "error_id": error_id
        }
        
        if self.debug:
            error_response["details"] = error_details
        
        self._log_error(request, 500, f"Internal error [{error_id}]: {str(exc)}", traceback.format_exc())
        
        return JSONResponse(
            status_code=500,
            content=error_response,
            headers=self._get_error_headers()
        )
    
    def _log_error(self, request: Request, status_code: int, message: str, traceback_str: str = None):
        from lib.database import db
        
        log_data = {
            "ip": request.client.host,
            "endpoint": str(request.url),
            "method": request.method,
            "user_agent": request.headers.get("user-agent", "")[:500],
            "response_time": 0,
            "status_code": status_code,
            "timestamp": datetime.utcnow().isoformat(),
            "error_message": message[:1000]
        }
        
        if traceback_str:
            log_data["traceback"] = traceback_str[:2000]
        
        auth_header = request.headers.get("authorization")
        if auth_header and auth_header.startswith("Bearer "):
            log_data["apikey"] = auth_header[7:]
        
        try:
            db.log_request(**log_data)
        except:
            pass
    
    def _get_error_headers(self) -> Dict[str, str]:
        return {
            "X-Error-Handled": "true",
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"
        }


class TimeoutMiddleware:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
    
    async def __call__(self, request: Request, call_next):
        import asyncio
        
        try:
            response = await asyncio.wait_for(call_next(request), timeout=self.timeout)
            return response
        except asyncio.TimeoutError:
            error_response = {
                "status": 504,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": f"Request timeout after {self.timeout} seconds"
            }
            
            return JSONResponse(
                status_code=504,
                content=error_response,
                headers={"X-Timeout": str(self.timeout)}
            )