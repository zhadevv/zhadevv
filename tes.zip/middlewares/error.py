from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from starlette.exceptions import HTTPException
from typing import Callable
import json
import traceback
import logging

from lib.database import Database


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
        self.logger = logging.getLogger(__name__)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            response = await call_next(request)
            return response
        
        except HTTPException as http_exc:
            return self._handle_http_exception(http_exc, request)
        
        except Exception as exc:
            return self._handle_unexpected_exception(exc, request)
    
    def _handle_http_exception(self, exc: HTTPException, request: Request) -> Response:
        error_response = {
            "status": exc.status_code,
            "success": False,
            "author": "zhadevv",
            "data": None,
            "message": exc.detail
        }
        
        self._log_error(request, exc.status_code, str(exc.detail))
        
        return Response(
            content=json.dumps(error_response),
            status_code=exc.status_code,
            media_type="application/json"
        )
    
    def _handle_unexpected_exception(self, exc: Exception, request: Request) -> Response:
        error_id = self._generate_error_id()
        error_trace = traceback.format_exc()
        
        self.logger.error(
            f"Error ID: {error_id}\n"
            f"Path: {request.url.path}\n"
            f"Method: {request.method}\n"
            f"Error: {str(exc)}\n"
            f"Traceback:\n{error_trace}"
        )
        
        if hasattr(request.state, "request_id"):
            error_response = {
                "status": 500,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": f"Internal server error. Error ID: {error_id}"
            }
        else:
            error_response = {
                "status": 500,
                "success": False,
                "author": "zhadevv",
                "data": None,
                "message": "Internal server error"
            }
        
        self._log_error(request, 500, str(exc), error_id, error_trace)
        
        return Response(
            content=json.dumps(error_response),
            status_code=500,
            media_type="application/json"
        )
    
    def _log_error(self, request: Request, status_code: int, error_message: str, 
                  error_id: str = None, traceback: str = None):
        try:
            client_ip = request.state.get("client_ip", "0.0.0.0")
            api_key = request.state.get("api_key")
            request_id = getattr(request.state, "request_id", None)
            
            log_data = {
                "error_id": error_id,
                "request_id": request_id,
                "client_ip": client_ip,
                "api_key": api_key,
                "method": request.method,
                "path": request.url.path,
                "status_code": status_code,
                "error_message": error_message[:500],
                "user_agent": request.headers.get("user-agent"),
                "query_params": dict(request.query_params),
                "traceback": traceback[:1000] if traceback else None
            }
            
            self.logger.error(json.dumps(log_data, default=str))
            
        except Exception as log_exc:
            self.logger.error(f"Failed to log error: {str(log_exc)}")
    
    def _generate_error_id(self) -> str:
        import time
        import hashlib
        import secrets
        
        timestamp = int(time.time() * 1000)
        random_part = secrets.token_hex(4)
        
        hash_input = f"{timestamp}{random_part}"
        hash_value = hashlib.md5(hash_input.encode()).hexdigest()[:8]
        
        return f"err_{timestamp}_{hash_value}"