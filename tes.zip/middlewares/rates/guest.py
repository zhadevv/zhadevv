from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from typing import Callable
import json
import time

from lib.database import Database
from lib.system.config import settings
from lib.system.validator import Validator


class GuestRateMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
        self.rpm_limit = settings.rate_limit.guest_rpm
        self.monthly_limit = settings.rate_limit.guest_monthly
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        api_key = request.state.get("api_key")
        
        if api_key:
            return await call_next(request)
        
        client_ip = request.state.get("client_ip", "0.0.0.0")
        
        identifier_minute = f"guest_ip_{client_ip}_minute"
        identifier_month = f"guest_ip_{client_ip}_month"
        
        allowed_minute, remaining_minute, reset_minute = self.db.check_rate_limit(
            identifier_minute, "minute", self.rpm_limit
        )
        
        allowed_month, remaining_month, reset_month = self.db.check_rate_limit(
            identifier_month, "month", self.monthly_limit
        )
        
        if not allowed_minute or not allowed_month:
            headers = Validator.calculate_rate_limit_headers(
                min(remaining_minute, remaining_month),
                min(self.rpm_limit, self.monthly_limit),
                min(reset_minute, reset_month)
            )
            
            error_message = "Rate limit exceeded"
            if not allowed_minute:
                error_message = "Requests per minute limit exceeded"
            elif not allowed_month:
                error_message = "Monthly request limit exceeded"
            
            return Response(
                content=json.dumps({
                    "status": 429,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": error_message
                }),
                status_code=429,
                media_type="application/json",
                headers=headers
            )
        
        request.state.rate_limit_info = {
            "limit_minute": self.rpm_limit,
            "remaining_minute": remaining_minute,
            "reset_minute": reset_minute,
            "limit_month": self.monthly_limit,
            "remaining_month": remaining_month,
            "reset_month": reset_month,
            "role": "guest"
        }
        
        response = await call_next(request)
        
        if hasattr(request.state, "rate_limit_info"):
            response.headers["X-RateLimit-Limit-Minute"] = str(self.rpm_limit)
            response.headers["X-RateLimit-Remaining-Minute"] = str(remaining_minute)
            response.headers["X-RateLimit-Reset-Minute"] = str(reset_minute)
            response.headers["X-RateLimit-Limit-Month"] = str(self.monthly_limit)
            response.headers["X-RateLimit-Remaining-Month"] = str(remaining_month)
            response.headers["X-RateLimit-Reset-Month"] = str(reset_month)
        
        return response