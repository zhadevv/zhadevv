from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import json
import time

from lib.database import Database
from lib.system.config import settings
from lib.system.validator import Validator


class AdminRateMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
        self.rpm_limit = settings.rate_limit.admin_rpm
        self.monthly_limit = settings.rate_limit.admin_monthly
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        api_key = request.state.get("api_key")
        
        is_admin_key = (
            api_key == settings.security.admin_apikey or
            (api_key and api_key.startswith("SK_zhadev-admin_"))
        )
        
        if not api_key or not is_admin_key:
            return await call_next(request)
        
        if api_key == settings.security.admin_apikey:
            api_info = {
                "role": "admin",
                "rpm_limit": self.rpm_limit,
                "monthly_limit": self.monthly_limit,
                "used_count": 0,
                "suspended": False
            }
        else:
            api_info = self.db.get_api_key_info(api_key)
            if not api_info or api_info.get("role") != "admin":
                return await call_next(request)
        
        if api_info.get("suspended"):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key is suspended"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        rpm_limit = api_info.get("rpm_limit", self.rpm_limit)
        identifier_minute = f"admin_key_{api_key}_minute"
        
        allowed_minute, remaining_minute, reset_minute = self.db.check_rate_limit(
            identifier_minute, "minute", rpm_limit
        )
        
        if not allowed_minute:
            headers = Validator.calculate_rate_limit_headers(
                remaining_minute,
                rpm_limit,
                reset_minute
            )
            
            return Response(
                content=json.dumps({
                    "status": 429,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Requests per minute limit exceeded"
                }),
                status_code=429,
                media_type="application/json",
                headers=headers
            )
        
        if api_key != settings.security.admin_apikey:
            self.db.update_api_key_usage(api_key)
        
        request.state.rate_limit_info = {
            "limit_minute": rpm_limit,
            "remaining_minute": remaining_minute,
            "reset_minute": reset_minute,
            "limit_month": api_info.get("monthly_limit", self.monthly_limit),
            "role": "admin",
            "api_key": api_key
        }
        
        response = await call_next(request)
        
        if hasattr(request.state, "rate_limit_info"):
            response.headers["X-RateLimit-Limit-Minute"] = str(rpm_limit)
            response.headers["X-RateLimit-Remaining-Minute"] = str(remaining_minute)
            response.headers["X-RateLimit-Reset-Minute"] = str(reset_minute)
            response.headers["X-RateLimit-Limit-Month"] = str(api_info.get("monthly_limit", self.monthly_limit))
        
        return response