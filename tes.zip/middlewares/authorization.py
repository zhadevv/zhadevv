#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import HTTPException, Request
from lib.system.validator import validator
from typing import Optional, List, Dict

class AuthorizationMiddleware:
    def __init__(self, allowed_roles: Optional[List[str]] = None, 
                 require_apikey: bool = True):
        self.allowed_roles = allowed_roles or []
        self.require_apikey = require_apikey
    
    async def __call__(self, request: Request, call_next):
        if request.method == "OPTIONS":
            return await call_next(request)
        
        auth_header = request.headers.get("authorization")
        
        if self.require_apikey and (not auth_header or not auth_header.startswith("Bearer ")):
            raise HTTPException(
                status_code=401,
                detail="Authorization header required"
            )
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            valid, role = validator.validate_apikey(apikey)
            
            if not valid:
                raise HTTPException(
                    status_code=403,
                    detail="Invalid API key"
                )
            
            if self.allowed_roles and role not in self.allowed_roles:
                raise HTTPException(
                    status_code=403,
                    detail=f"Access denied. Required roles: {self.allowed_roles}"
                )
            
            request.state.apikey = apikey
            request.state.role = role
        
        response = await call_next(request)
        
        if auth_header and auth_header.startswith("Bearer "):
            response.headers["X-Api-Key-Valid"] = "true"
            response.headers["X-User-Role"] = role
        
        return response


class VersionAuthorizationMiddleware:
    def __init__(self, allowed_versions: List[str] = None):
        self.allowed_versions = allowed_versions or ["v1"]
    
    async def __call__(self, request: Request, call_next):
        if request.method == "OPTIONS":
            return await call_next(request)
        
        auth_header = request.headers.get("authorization")
        
        if auth_header and auth_header.startswith("Bearer "):
            apikey = auth_header[7:]
            valid, role = validator.validate_apikey(apikey)
            
            if valid and role not in ["admin", "developer", "owner"]:
                from lib.database import db
                apikey_data = db.get_apikey(apikey)
                
                if apikey_data:
                    active_versions = apikey_data.get("active_versions", ["v1"])
                    
                    if isinstance(active_versions, str):
                        import json
                        try:
                            active_versions = json.loads(active_versions)
                        except:
                            active_versions = ["v1"]
                    
                    request_path = str(request.url.path)
                    
                    version_allowed = False
                    for version in self.allowed_versions:
                        if version in active_versions and f"/api/{version}" in request_path:
                            version_allowed = True
                            break
                    
                    if not version_allowed:
                        raise HTTPException(
                            status_code=403,
                            detail=f"API key not authorized for this version. Allowed: {active_versions}"
                        )
        
        return await call_next(request)