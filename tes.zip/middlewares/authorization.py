from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from typing import Callable
import json
import re

from lib.database import Database
from lib.system.config import settings
from lib.system.validator import Validator


class AuthorizationMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        
        if self._is_public_path(path):
            return await call_next(request)
        
        api_key = self._extract_api_key(request)
        
        if not api_key:
            return Response(
                content=json.dumps({
                    "status": 401,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key is required"
                }),
                status_code=401,
                media_type="application/json"
            )
        
        if not Validator.validate_api_key_format(api_key):
            return Response(
                content=json.dumps({
                    "status": 400,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Invalid API key format"
                }),
                status_code=400,
                media_type="application/json"
            )
        
        api_info = self._get_api_key_info(api_key)
        
        if not api_info:
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Invalid API key"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if not api_info.get("active", True):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key is inactive"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if api_info.get("suspended", False):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key is suspended"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if self._is_expired(api_info):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key has expired"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if not self._check_version_access(api_info, path):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "API key not authorized for this API version"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if self._requires_admin_access(path) and not self._is_admin_key(api_key, api_info):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Admin access required"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        request.state.api_key = api_key
        request.state.api_info = api_info
        request.state.role = api_info.get("role", "guest")
        
        return await call_next(request)
    
    def _is_public_path(self, path: str) -> bool:
        public_paths = [
            r'^/$',
            r'^/api/health$',
            r'^/api/stats$',
            r'^/docs$',
            r'^/redoc$',
            r'^/openapi.json$',
        ]
        
        for pattern in public_paths:
            if re.match(pattern, path):
                return True
        
        return False
    
    def _extract_api_key(self, request: Request) -> Optional[str]:
        authorization = request.headers.get("authorization")
        
        if authorization:
            return Validator.extract_api_key_from_header(authorization)
        
        api_key_param = request.query_params.get("apikey")
        if api_key_param:
            return api_key_param.strip()
        
        return None
    
    def _get_api_key_info(self, api_key: str) -> Optional[dict]:
        if api_key in [settings.security.owner_apikey, 
                       settings.security.dev_apikey,
                       settings.security.admin_apikey]:
            role = "owner" if api_key == settings.security.owner_apikey else \
                   "developer" if api_key == settings.security.dev_apikey else "admin"
            
            return {
                "role": role,
                "active": True,
                "suspended": False,
                "allowed_versions": ["v1", "v2", "admin"],
                "rpm_limit": 10000 if role == "owner" else 5000 if role == "developer" else 1000,
                "monthly_limit": 100000000 if role == "owner" else 10000000 if role == "developer" else 5000000,
                "custom_key": True
            }
        
        return self.db.get_api_key_info(api_key)
    
    def _is_expired(self, api_info: dict) -> bool:
        expires_at = api_info.get("expires_at")
        if not expires_at:
            return False
        
        from datetime import datetime
        try:
            expires_dt = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
            return datetime.utcnow() > expires_dt
        except:
            return False
    
    def _check_version_access(self, api_info: dict, path: str) -> bool:
        allowed_versions = api_info.get("allowed_versions", ["v1"])
        
        if "all" in allowed_versions or "*" in allowed_versions:
            return True
        
        if "/api/v1/" in path and "v1" in allowed_versions:
            return True
        
        if "/api/v2/" in path and "v2" in allowed_versions:
            return True
        
        if "/api/admin/" in path and "admin" in allowed_versions:
            return True
        
        if not any(f"/api/{version}/" in path for version in allowed_versions):
            return "/api/v1/" not in path and "/api/v2/" not in path and "/api/admin/" not in path
        
        return True
    
    def _requires_admin_access(self, path: str) -> bool:
        admin_patterns = [
            r'^/api/admin/',
        ]
        
        for pattern in admin_patterns:
            if re.match(pattern, path):
                return True
        
        return False
    
    def _is_admin_key(self, api_key: str, api_info: dict) -> bool:
        if api_key in [settings.security.owner_apikey, 
                       settings.security.dev_apikey,
                       settings.security.admin_apikey]:
            return True
        
        role = api_info.get("role", "")
        return role in ["admin", "developer", "owner"]