import jwt from 'jsonwebtoken';

export function authorizeMiddleware(requiredRoles = []) {
  return function(req, res, next) {
    const token = req.cookies.get('auth_token')?.value || 
                  req.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Authentication required',
      });
    }
    
    try {
      const decoded = jwt.verify(token, process.env.NEXT_JWT);
      req.user = decoded;
      
      if (requiredRoles.length > 0 && !requiredRoles.includes(decoded.role)) {
        return res.status(403).json({
          status: 403,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Insufficient permissions',
        });
      }
      
      next();
    } catch (error) {
      return res.status(401).json({
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Invalid token',
      });
    }
  };
}