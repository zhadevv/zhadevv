import Redis from 'redis';
import { createClient } from 'redis';

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    get: async () => null,
  };
}

export async function protectMiddleware(req, res, next) {
  const ip = req.ip || req.headers.get('x-forwarded-for') || 'unknown';
  
  const isBanned = await redisClient.get(`banned:${ip}`);
  if (isBanned) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'IP banned',
    });
  }
  
  const blockedPaths = await redisClient.get('blocked_paths');
  if (blockedPaths) {
    const paths = JSON.parse(blockedPaths);
    if (paths.includes(req.path)) {
      return res.status(403).json({
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Path blocked',
      });
    }
  }
  
  next();
}