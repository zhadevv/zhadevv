#
#             Zhadevv Project
#             --MIT License--
#
# Feed Me Starnya Bang:>
# Project 100% Open Source
# Bebas Recode, Deploy Production. KECUALI
# Diperjual-Belikan.
#
# Project ini Sepenuhnya Gratis, Makannua ksih Bintang Dong anj:>
# *bercanda ajahh
#
# Regards
# Zhadevv
#

from fastapi import HTTPException, Request
from typing import List, Set, Optional, Dict
import re
from datetime import datetime, time
import ipaddress

class IPRestrictionMiddleware:
    def __init__(self, allowed_ips: List[str] = None, blocked_ips: List[str] = None):
        self.allowed_ips = set(allowed_ips or [])
        self.blocked_ips = set(blocked_ips or [])
    
    async def __call__(self, request: Request, call_next):
        client_ip = request.client.host
        
        if client_ip in self.blocked_ips:
            raise HTTPException(
                status_code=403,
                detail="IP address blocked"
            )
        
        if self.allowed_ips and client_ip not in self.allowed_ips:
            raise HTTPException(
                status_code=403,
                detail="IP address not allowed"
            )
        
        return await call_next(request)
    
    def allow_ip(self, ip: str):
        self.allowed_ips.add(ip)
        self.blocked_ips.discard(ip)
    
    def block_ip(self, ip: str):
        self.blocked_ips.add(ip)
        self.allowed_ips.discard(ip)


class TimeRestrictionMiddleware:
    def __init__(self, start_time: time = time(0, 0), end_time: time = time(23, 59)):
        self.start_time = start_time
        self.end_time = end_time
    
    async def __call__(self, request: Request, call_next):
        current_time = datetime.now().time()
        
        if not (self.start_time <= current_time <= self.end_time):
            raise HTTPException(
                status_code=403,
                detail=f"Access allowed only between {self.start_time} and {self.end_time}"
            )
        
        return await call_next(request)


class ReferrerRestrictionMiddleware:
    def __init__(self, allowed_referrers: List[str] = None, 
                 blocked_referrers: List[str] = None):
        self.allowed_referrers = allowed_referrers or []
        self.blocked_referrers = blocked_referrers or []
    
    async def __call__(self, request: Request, call_next):
        referrer = request.headers.get("referer") or request.headers.get("referrer")
        
        if referrer:
            if self.blocked_referrers:
                for blocked in self.blocked_referrers:
                    if blocked in referrer:
                        raise HTTPException(
                            status_code=403,
                            detail="Referrer not allowed"
                        )
            
            if self.allowed_referrers:
                allowed = False
                for allowed_ref in self.allowed_referrers:
                    if allowed_ref in referrer:
                        allowed = True
                        break
                
                if not allowed:
                    raise HTTPException(
                        status_code=403,
                        detail="Referrer not allowed"
                    )
        
        return await call_next(request)


class UserAgentRestrictionMiddleware:
    def __init__(self, allowed_agents: List[str] = None, 
                 blocked_agents: List[str] = None):
        self.allowed_agents = allowed_agents or []
        self.blocked_agents = blocked_agents or []
    
    async def __call__(self, request: Request, call_next):
        user_agent = request.headers.get("user-agent", "")
        
        if user_agent:
            if self.blocked_agents:
                for blocked in self.blocked_agents:
                    if blocked.lower() in user_agent.lower():
                        raise HTTPException(
                            status_code=403,
                            detail="User agent not allowed"
                        )
            
            if self.allowed_agents:
                allowed = False
                for allowed_ua in self.allowed_agents:
                    if allowed_ua.lower() in user_agent.lower():
                        allowed = True
                        break
                
                if not allowed:
                    raise HTTPException(
                        status_code=403,
                        detail="User agent not allowed"
                    )
        
        return await call_next(request)


class PathRestrictionMiddleware:
    def __init__(self, blocked_paths: List[str] = None,
                 allowed_methods_by_path: Dict[str, List[str]] = None):
        self.blocked_paths = blocked_paths or []
        self.allowed_methods_by_path = allowed_methods_by_path or {}
    
    async def __call__(self, request: Request, call_next):
        path = str(request.url.path)
        method = request.method
        
        for blocked_path in self.blocked_paths:
            if blocked_path in path:
                raise HTTPException(
                    status_code=404,
                    detail="Not found"
                )
        
        for restricted_path, allowed_methods in self.allowed_methods_by_path.items():
            if restricted_path in path and method not in allowed_methods:
                raise HTTPException(
                    status_code=405,
                    detail=f"Method {method} not allowed for this path"
                )
        
        return await call_next(request)


class CountryRestrictionMiddleware:
    def __init__(self, allowed_countries: List[str] = None,
                 blocked_countries: List[str] = None):
        self.allowed_countries = set(allowed_countries or [])
        self.blocked_countries = set(blocked_countries or [])
    
    async def __call__(self, request: Request, call_next):
        client_ip = request.client.host
        
        try:
            country = self._get_country_from_ip(client_ip)
            
            if country:
                if country in self.blocked_countries:
                    raise HTTPException(
                        status_code=403,
                        detail=f"Access from {country} not allowed"
                    )
                
                if self.allowed_countries and country not in self.allowed_countries:
                    raise HTTPException(
                        status_code=403,
                        detail=f"Access from {country} not allowed"
                    )
        
        except:
            pass
        
        return await call_next(request)
    
    def _get_country_from_ip(self, ip: str) -> Optional[str]:
        return None