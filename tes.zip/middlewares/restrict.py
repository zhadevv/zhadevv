from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import json
import re


class RestrictMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.blocked_methods = ["TRACE", "TRACK", "CONNECT"]
        self.blocked_headers = [
            "proxy-",
            "via",
            "x-forwarded-",
            "x-proxy-",
            "client-ip",
            "real-ip",
        ]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if request.method in self.blocked_methods:
            return Response(
                content=json.dumps({
                    "status": 405,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": f"Method {request.method} not allowed"
                }),
                status_code=405,
                media_type="application/json"
            )
        
        for header_name in request.headers.keys():
            header_lower = header_name.lower()
            for blocked in self.blocked_headers:
                if header_lower.startswith(blocked):
                    return Response(
                        content=json.dumps({
                            "status": 400,
                            "success": False,
                            "author": "zhadevv",
                            "data": None,
                            "message": f"Blocked header detected: {header_name}"
                        }),
                        status_code=400,
                        media_type="application/json"
                    )
        
        content_type = request.headers.get("content-type", "")
        if request.method in ["POST", "PUT", "PATCH"]:
            if not content_type:
                return Response(
                    content=json.dumps({
                        "status": 400,
                        "success": False,
                        "author": "zhadevv",
                        "data": None,
                        "message": "Content-Type header is required"
                    }),
                    status_code=400,
                    media_type="application/json"
                )
            
            allowed_content_types = [
                "application/json",
                "application/x-www-form-urlencoded",
                "multipart/form-data",
                "text/plain",
            ]
            
            content_type_valid = False
            for allowed in allowed_content_types:
                if allowed in content_type:
                    content_type_valid = True
                    break
            
            if not content_type_valid:
                return Response(
                    content=json.dumps({
                        "status": 415,
                        "success": False,
                        "author": "zhadevv",
                        "data": None,
                        "message": f"Unsupported media type: {content_type}"
                    }),
                    status_code=415,
                    media_type="application/json"
                )
        
        host = request.headers.get("host", "")
        if not host or len(host) > 255:
            return Response(
                content=json.dumps({
                    "status": 400,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Invalid Host header"
                }),
                status_code=400,
                media_type="application/json"
            )
        
        user_agent = request.headers.get("user-agent", "")
        if len(user_agent) > 512:
            return Response(
                content=json.dumps({
                    "status": 400,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "User-Agent header too long"
                }),
                status_code=400,
                media_type="application/json"
            )
        
        referer = request.headers.get("referer", "")
        if referer and len(referer) > 2048:
            return Response(
                content=json.dumps({
                    "status": 400,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Referer header too long"
                }),
                status_code=400,
                media_type="application/json"
            )
        
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                length = int(content_length)
                if length > 100 * 1024 * 1024:
                    return Response(
                        content=json.dumps({
                            "status": 413,
                            "success": False,
                            "author": "zhadevv",
                            "data": None,
                            "message": "Request entity too large"
                        }),
                        status_code=413,
                        media_type="application/json"
                    )
            except ValueError:
                return Response(
                    content=json.dumps({
                        "status": 400,
                        "success": False,
                        "author": "zhadevv",
                        "data": None,
                        "message": "Invalid Content-Length header"
                    }),
                    status_code=400,
                    media_type="application/json"
                )
        
        path = request.url.path
        if len(path) > 2048:
            return Response(
                content=json.dumps({
                    "status": 414,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "URI too long"
                }),
                status_code=414,
                media_type="application/json"
            )
        
        return await call_next(request)