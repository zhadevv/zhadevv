import crypto from 'crypto';

export function validateSecret(req, res, next) {
  const secret = req.headers.get('x-secret') || req.query.secret;
  const expectedSecret = process.env.ADMIN_SECRET;
  
  if (!expectedSecret || !secret) {
    return res.status(401).json({
      status: 401,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Secret required',
    });
  }
  
  const hash = crypto.createHash('sha256').update(secret).digest('hex');
  const expectedHash = crypto.createHash('sha256').update(expectedSecret).digest('hex');
  
  if (hash !== expectedHash) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Invalid secret',
    });
  }
  
  next();
}