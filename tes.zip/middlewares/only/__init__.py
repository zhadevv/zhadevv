from middlewares.only.secrets import SecretsOnlyMiddleware

__all__ = ["SecretsOnlyMiddleware"]