from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from typing import Callable
import json
import re

from lib.system.config import settings
from lib.system.validator import Validator


class SecretsOnlyMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path
        
        if not self._is_secrets_path(path):
            return await call_next(request)
        
        authorization = request.headers.get("authorization")
        api_key = Validator.extract_api_key_from_header(authorization)
        
        if not api_key:
            return Response(
                content=json.dumps({
                    "status": 401,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Missing API key"
                }),
                status_code=401,
                media_type="application/json"
            )
        
        if not self._is_authorized_key(api_key):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Unauthorized access to secrets endpoint"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        return await call_next(request)
    
    def _is_secrets_path(self, path: str) -> bool:
        secrets_patterns = [
            r'^/api/admin/',
            r'^/api/@me$',
            r'^/api/check$',
        ]
        
        for pattern in secrets_patterns:
            if re.match(pattern, path):
                return True
        
        return False
    
    def _is_authorized_key(self, api_key: str) -> bool:
        if api_key in [settings.security.owner_apikey, 
                       settings.security.dev_apikey,
                       settings.security.admin_apikey]:
            return True
        
        if api_key.startswith("SK_zhadev-admin_") or \
           api_key.startswith("SK_zhadev-dev_") or \
           api_key.startswith("SK_zhadev-owner_"):
            return True
        
        return False