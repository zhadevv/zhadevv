export function restrictMethods(allowedMethods) {
  return function(req, res, next) {
    if (!allowedMethods.includes(req.method)) {
      return res.status(405).json({
        status: 405,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `Method ${req.method} not allowed`,
      });
    }
    
    next();
  };
}