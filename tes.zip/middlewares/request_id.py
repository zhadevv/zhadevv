from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import time
import hashlib
import secrets


class RequestIDMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = self._generate_request_id(request)
        request.state.request_id = request_id
        
        response = await call_next(request)
        
        response.headers["X-Request-ID"] = request_id
        
        return response
    
    def _generate_request_id(self, request: Request) -> str:
        timestamp = int(time.time() * 1000)
        client_ip = request.client.host if request.client else "0.0.0.0"
        user_agent = request.headers.get("user-agent", "")
        
        random_part = secrets.token_hex(4)
        
        hash_input = f"{timestamp}{client_ip}{user_agent}{random_part}"
        hash_value = hashlib.sha256(hash_input.encode()).hexdigest()[:16]
        
        return f"req_{timestamp}_{hash_value}"