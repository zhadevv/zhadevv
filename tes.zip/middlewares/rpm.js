import Redis from 'redis';
import { createClient } from 'redis';

let redisClient;
if (process.env.REDIS_URL) {
  redisClient = createClient({
    url: process.env.REDIS_URL,
  });
  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  redisClient.connect();
} else {
  redisClient = {
    get: async () => null,
    incr: async () => 1,
    expire: async () => 1,
  };
}

export function rpmMiddleware(limit) {
  return async function(req, res, next) {
    const ip = req.ip || req.headers.get('x-forwarded-for') || 'unknown';
    const key = `rpm:${ip}:${Math.floor(Date.now() / 60000)}`;
    
    try {
      const current = await redisClient.incr(key);
      if (current === 1) {
        await redisClient.expire(key, 60);
      }
      
      res.setHeader('X-RateLimit-Limit', limit);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, limit - current));
      res.setHeader('X-RateLimit-Reset', Math.floor(Date.now() / 1000) + 60);
      
      if (current > limit) {
        res.status(429).json({
          status: 429,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Requests per minute limit exceeded',
        });
        return;
      }
      
      next();
    } catch (error) {
      console.error('RPM middleware error:', error);
      next();
    }
  };
}