export function requireApiKey(req, res, next) {
  const apiKey = req.headers.get('x-api-key') || req.query.apikey;
  
  if (!apiKey) {
    return res.status(401).json({
      status: 401,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'API key required',
    });
  }
  
  req.apiKey = apiKey;
  next();
}