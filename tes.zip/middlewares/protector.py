

from fastapi import HTTPException, Request
import re
import json
from typing import Dict, List, Optional
from datetime import datetime

class RequestProtectorMiddleware:
    def __init__(self):
        self.blocked_paths = [
            "/.env", "/config", "/secret", "/admin", "/phpmyadmin",
            "/wp-admin", "/wp-login", "/administrator", "/backup",
            "/sql", "/database", "/debug", "/test", "/api-docs"
        ]
        
        self.blocked_user_agents = [
            "sqlmap", "nmap", "nikto", "metasploit", "hydra",
            "burpsuite", "wpscan", "acunetix", "nessus", "openvas",
            "zap", "arachni", "skipfish", "w3af", "havij"
        ]
        
        self.blocked_ips = set()
        
        self.sql_injection_patterns = [
            r"(\%27)|(\')|(\-\-)|(\%23)|(#)",
            r"((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))",
            r"\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))",
            r"((\%27)|(\'))union",
            r"exec(\s|\+)+(s|x)p\w+",
            r"/\*.*\*/",
            r"(\-\-).*"
        ]
        
        self.xss_patterns = [
            r"<script.*?>.*?</script>",
            r"javascript:",
            r"onload\s*=",
            r"onerror\s*=",
            r"onclick\s*=",
            r"alert\s*\(",
            r"document\.cookie",
            r"<iframe.*?>",
            r"<object.*?>",
            r"<embed.*?>"
        ]
    
    async def __call__(self, request: Request, call_next):
        client_ip = request.client.host
        
        if client_ip in self.blocked_ips:
            raise HTTPException(
                status_code=403,
                detail="IP address blocked"
            )
        
        if self._is_blocked_path(str(request.url.path)):
            raise HTTPException(
                status_code=404,
                detail="Not found"
            )
        
        user_agent = request.headers.get("user-agent", "")
        if self._is_malicious_user_agent(user_agent):
            self.blocked_ips.add(client_ip)
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )
        
        if self._contains_sql_injection(str(request.url)):
            self.blocked_ips.add(client_ip)
            raise HTTPException(
                status_code=403,
                detail="Invalid request"
            )
        
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body = await request.body()
                
                if body:
                    body_str = body.decode('utf-8', errors='ignore')
                    
                    if self._contains_sql_injection(body_str):
                        self.blocked_ips.add(client_ip)
                        raise HTTPException(
                            status_code=403,
                            detail="Invalid request data"
                        )
                    
                    if self._contains_xss(body_str):
                        self.blocked_ips.add(client_ip)
                        raise HTTPException(
                            status_code=403,
                            detail="Invalid request data"
                        )
            except:
                pass
        
        response = await call_next(request)
        
        response.headers["X-Content-Security"] = "protected"
        
        return response
    
    def _is_blocked_path(self, path: str) -> bool:
        path_lower = path.lower()
        
        for blocked_path in self.blocked_paths:
            if blocked_path in path_lower:
                return True
        
        return False
    
    def _is_malicious_user_agent(self, user_agent: str) -> bool:
        if not user_agent:
            return False
        
        ua_lower = user_agent.lower()
        
        for blocked_ua in self.blocked_user_agents:
            if blocked_ua.lower() in ua_lower:
                return True
        
        return False
    
    def _contains_sql_injection(self, text: str) -> bool:
        if not text:
            return False
        
        for pattern in self.sql_injection_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def _contains_xss(self, text: str) -> bool:
        if not text:
            return False
        
        for pattern in self.xss_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def unblock_ip(self, ip: str):
        self.blocked_ips.discard(ip)


class SizeLimitMiddleware:
    def __init__(self, max_size: int = 10 * 1024 * 1024):
        self.max_size = max_size
    
    async def __call__(self, request: Request, call_next):
        content_length = request.headers.get("content-length")
        
        if content_length:
            try:
                size = int(content_length)
                if size > self.max_size:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Request too large. Maximum size: {self.max_size} bytes"
                    )
            except ValueError:
                pass
        
        response = await call_next(request)
        
        response.headers["X-Size-Limit"] = str(self.max_size)
        
        return response


class MethodFilterMiddleware:
    def __init__(self, allowed_methods: List[str] = None):
        self.allowed_methods = allowed_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    
    async def __call__(self, request: Request, call_next):
        if request.method not in self.allowed_methods:
            raise HTTPException(
                status_code=405,
                detail=f"Method {request.method} not allowed"
            )
        
        response = await call_next(request)
        
        response.headers["Allow"] = ", ".join(self.allowed_methods)
        
        return response