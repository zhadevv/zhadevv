from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import json
import re

from lib.database import Database


class ProtectorMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.db = Database()
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        client_ip = request.state.get("client_ip", "0.0.0.0")
        
        if self.db.is_ip_banned(client_ip):
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Access denied"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if self._is_malicious_request(request):
            self.db.ban_ip(
                client_ip,
                reason="Malicious request detected",
                banned_by="protector_middleware"
            )
            
            return Response(
                content=json.dumps({
                    "status": 403,
                    "success": False,
                    "author": "zhadevv",
                    "data": None,
                    "message": "Access denied"
                }),
                status_code=403,
                media_type="application/json"
            )
        
        if self._is_suspicious_activity(request):
            request.state.suspicious = True
        
        return await call_next(request)
    
    def _is_malicious_request(self, request: Request) -> bool:
        path = request.url.path
        user_agent = request.headers.get("user-agent", "").lower()
        
        malicious_patterns = [
            r'(\.\./|\.\.\\|/\.\./)',
            r'(union.*select|insert.*into|drop.*table|delete.*from)',
            r'(<script|javascript:|onload=|onerror=)',
            r'(eval\(|exec\(|system\(|passthru\()',
            r'(\.env|\.git|\.svn|\.DS_Store)',
            r'(phpmyadmin|adminer|webshell|backdoor)',
        ]
        
        for pattern in malicious_patterns:
            if re.search(pattern, path, re.IGNORECASE):
                return True
        
        bad_bots = [
            'ahrefs', 'semrush', 'mj12bot', 'dotbot', 'rogerbot',
            'seznambot', 'exabot', 'gigabot', 'blexbot', 'yandexbot',
            'spbot', 'ltx71', 'masscan', 'nmap', 'sqlmap',
            'wpscan', 'nikto', 'acunetix', 'nessus', 'openvas'
        ]
        
        for bot in bad_bots:
            if bot in user_agent:
                return True
        
        query_params = dict(request.query_params)
        for param_value in query_params.values():
            if isinstance(param_value, str):
                for pattern in malicious_patterns:
                    if re.search(pattern, param_value, re.IGNORECASE):
                        return True
        
        headers = dict(request.headers)
        for header_value in headers.values():
            if isinstance(header_value, str):
                for pattern in malicious_patterns[:3]:
                    if re.search(pattern, header_value, re.IGNORECASE):
                        return True
        
        return False
    
    def _is_suspicious_activity(self, request: Request) -> bool:
        user_agent = request.headers.get("user-agent", "")
        
        if not user_agent:
            return True
        
        if len(user_agent) > 500:
            return True
        
        suspicious_patterns = [
            'curl/', 'wget/', 'python-requests/', 'go-http-client/',
            'java/', 'scrapy/', 'phantomjs', 'headlesschrome',
        ]
        
        for pattern in suspicious_patterns:
            if pattern in user_agent.lower():
                return True
        
        referer = request.headers.get("referer", "")
        if referer and "http" not in referer.lower():
            return True
        
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > 10 * 1024 * 1024:
            return True
        
        return False