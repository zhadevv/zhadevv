import uuid
import time
from fastapi import Request


class RequestIDMiddleware:
    def __init__(self, header_name: str = "X-Request-ID", generate_if_missing: bool = True):
        self.header_name = header_name
        self.generate_if_missing = generate_if_missing
    
    async def __call__(self, request: Request, call_next):
        request_id = request.headers.get(self.header_name)
        
        if not request_id and self.generate_if_missing:
            request_id = self._generate_request_id()
        
        request.state.request_id = request_id
        
        response = await call_next(request)
        
        if request_id:
            response.headers[self.header_name] = request_id
        
        response.headers["X-Request-Timestamp"] = str(int(time.time()))
        
        return response
    
    def _generate_request_id(self) -> str:
        return str(uuid.uuid4())


class CorrelationIDMiddleware:
    def __init__(self):
        self.correlation_header = "X-Correlation-ID"
        self.parent_header = "X-Parent-Request-ID"
    
    async def __call__(self, request: Request, call_next):
        correlation_id = request.headers.get(self.correlation_header)
        parent_id = request.headers.get(self.parent_header)
        
        if not correlation_id:
            correlation_id = str(uuid.uuid4())
        
        request.state.correlation_id = correlation_id
        
        if parent_id:
            request.state.parent_id = parent_id
        
        response = await call_next(request)
        
        response.headers[self.correlation_header] = correlation_id
        
        if parent_id:
            response.headers[self.parent_header] = parent_id
        
        if hasattr(request.state, "request_id"):
            response.headers["X-Request-ID"] = request.state.request_id
        
        return response