const puppeteer = require('puppeteer');
const { EventEmitter } = require('events');

class BrowserAutomation extends EventEmitter {
  constructor(options = {}) {
    super();
    this.options = {
      headless: true,
      devtools: false,
      slowMo: 0,
      defaultViewport: {
        width: 1920,
        height: 1080
      },
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-web-security',
        '--disable-features=IsolateOrigins,site-per-process',
        '--disable-blink-features=AutomationControlled',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-infobars',
        '--window-position=0,0',
        '--ignore-certificate-errors',
        '--ignore-certificate-errors-spki-list',
        '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0'
      ],
      ...options
    };
    
    this.browser = null;
    this.page = null;
    this.isInitialized = false;
  }

  async initialize() {
    if (this.isInitialized && this.browser) {
      return;
    }

    try {
      this.browser = await puppeteer.launch(this.options);
      this.page = await this.browser.newPage();
      
      await this.page.setViewport(this.options.defaultViewport);
      await this.page.setUserAgent(this.options.args.find(arg => arg.includes('user-agent'))?.split('=')[1] || 
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0');
      
      await this.page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', {
          get: () => false
        });
        
        Object.defineProperty(navigator, 'plugins', {
          get: () => [1, 2, 3, 4, 5]
        });
        
        Object.defineProperty(navigator, 'languages', {
          get: () => ['en-US', 'en', 'zh-CN', 'zh']
        });
        
        window.chrome = {
          runtime: {},
          loadTimes: function() {},
          csi: function() {},
          app: {}
        };
      });

      await this.page.setExtraHTTPHeaders({
        'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      });

      this.isInitialized = true;
      this.emit('initialized');
      
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  async goto(url, options = {}) {
    if (!this.isInitialized) {
      await this.initialize();
    }

    try {
      const navigationOptions = {
        waitUntil: 'networkidle2',
        timeout: 60000,
        ...options
      };

      await this.page.goto(url, navigationOptions);
      this.emit('navigated', url);
      
      return this.page;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  async getCookies() {
    if (!this.page) {
      throw new Error('Page not initialized');
    }
    
    const cookies = await this.page.cookies();
    return cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
  }

  async setCookies(cookieString) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const cookies = cookieString.split(';').map(cookie => {
      const [name, ...valueParts] = cookie.trim().split('=');
      const value = valueParts.join('=');
      return { name: name.trim(), value: value.trim(), domain: '.douyin.com' };
    });

    await this.page.setCookie(...cookies);
  }

  async waitForSelector(selector, options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const waitOptions = {
      timeout: 30000,
      ...options
    };

    return await this.page.waitForSelector(selector, waitOptions);
  }

  async waitForXPath(xpath, options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const waitOptions = {
      timeout: 30000,
      ...options
    };

    return await this.page.waitForXPath(xpath, waitOptions);
  }

  async waitForNetworkIdle(options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const waitOptions = {
      idleTime: 500,
      timeout: 30000,
      ...options
    };

    await this.page.waitForNetworkIdle(waitOptions);
  }

  async screenshot(options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const screenshotOptions = {
      type: 'png',
      fullPage: false,
      ...options
    };

    return await this.page.screenshot(screenshotOptions);
  }

  async evaluate(fn, ...args) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    return await this.page.evaluate(fn, ...args);
  }

  async evaluateHandle(fn, ...args) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    return await this.page.evaluateHandle(fn, ...args);
  }

  async type(selector, text, options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const typeOptions = {
      delay: 100,
      ...options
    };

    await this.page.type(selector, text, typeOptions);
  }

  async click(selector, options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const clickOptions = {
      delay: 100,
      ...options
    };

    await this.page.click(selector, clickOptions);
  }

  async scrollToBottom(options = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const scrollOptions = {
      step: 100,
      delay: 100,
      maxScrolls: 100,
      ...options
    };

    let previousHeight = 0;
    let currentHeight = 0;
    let scrollCount = 0;

    while (scrollCount < scrollOptions.maxScrolls) {
      previousHeight = await this.page.evaluate('document.body.scrollHeight');
      await this.page.evaluate(`window.scrollTo(0, ${previousHeight})`);
      await this.page.waitForTimeout(scrollOptions.delay);
      currentHeight = await this.page.evaluate('document.body.scrollHeight');
      
      if (previousHeight === currentHeight) {
        break;
      }
      
      scrollCount++;
    }
  }

  async extractData(extractors = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const data = {};

    for (const [key, extractor] of Object.entries(extractors)) {
      try {
        if (typeof extractor === 'function') {
          data[key] = await extractor(this.page);
        } else if (typeof extractor === 'string') {
          const element = await this.page.$(extractor);
          if (element) {
            data[key] = await this.page.evaluate(el => el.textContent, element);
          }
        }
      } catch (error) {
        data[key] = null;
        this.emit('extract_error', { key, error });
      }
    }

    return data;
  }

  async interceptRequests(handlers = {}) {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    await this.page.setRequestInterception(true);

    this.page.on('request', async (request) => {
      const url = request.url();
      const resourceType = request.resourceType();

      if (handlers[resourceType]) {
        const result = await handlers[resourceType](request);
        if (result === false) {
          return request.abort();
        }
      }

      if (handlers[url]) {
        const result = await handlers[url](request);
        if (result === false) {
          return request.abort();
        }
      }

      request.continue();
    });
  }

  async getPageSource() {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    return await this.page.content();
  }

  async getMetrics() {
    if (!this.page) {
      throw new Error('Page not initialized');
    }

    const metrics = await this.page.metrics();
    const performance = await this.page.evaluate(() => JSON.stringify(window.performance));
    
    return {
      metrics,
      performance: JSON.parse(performance)
    };
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
      this.isInitialized = false;
      this.emit('closed');
    }
  }

  async restart() {
    await this.close();
    await this.initialize();
  }

  isConnected() {
    return this.browser && this.browser.connected;
  }
}

module.exports = BrowserAutomation;