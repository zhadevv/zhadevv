import { DouTiksApp } from './Build/app';
import { DouTiksLoader } from './Build/loader';
import { createDouTiks, createDouyin, createTikTok, createSearch } from './Build/create';
import { Douyin } from './App/Douyin';
import { TikTok } from './App/Tiktok';
import { Search } from './App';
import { Utils } from './Utils';

export * from './Types';
export * from './Utils';
export * from './App/Douyin';
export * from './App/Tiktok';
export * from './App';
export * from './Build/app';
export * from './Build/create';
export * from './Build/loader';

export {
  DouTiksApp,
  DouTiksLoader,
  createDouTiks,
  createDouyin,
  createTikTok,
  createSearch,
  Douyin,
  TikTok,
  Search,
  Utils
};

export default {
  DouTiksApp,
  DouTiksLoader,
  createDouTiks,
  createDouyin,
  createTikTok,
  createSearch,
  Douyin,
  TikTok,
  Search,
  Utils
};