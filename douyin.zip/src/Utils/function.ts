import axios from 'axios';
import { CryptoManager } from './Libs/Crypto';
import { Helper } from './helper';
import {
  NetworkError,
  APIError,
  AuthenticationError,
  RateLimitError,
  NotFoundError,
  ParseError,
  DouyinRequestParams,
  TikTokRequestParams,
  DouTiksConfig
} from '../Types';

export class RequestManager {
  private static instance: RequestManager;
  private axiosInstance: AxiosInstance;
  private config: DouTiksConfig;
  private crypto: CryptoManager;
  private helper: Helper;

  private constructor(config: DouTiksConfig) {
    this.config = {
      timeout: 30000,
      maxRetries: 3,
      retryDelay: 1000,
      requestDelay: 1000,
      debug: false,
      ...config
    };

    this.crypto = CryptoManager.getInstance();
    this.helper = Helper.getInstance();

    this.axiosInstance = axios.create({
      timeout: this.config.timeout,
      headers: {
        'User-Agent': this.config.userAgent || 
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        ...(this.config.cookie ? { 'Cookie': this.config.cookie } : {})
      }
    });

    if (this.config.proxy) {
      this.axiosInstance.defaults.proxy = this.config.proxy;
    }

    this.setupInterceptors();
  }

  public static getInstance(config?: DouTiksConfig): RequestManager {
    if (!RequestManager.instance && config) {
      RequestManager.instance = new RequestManager(config);
    } else if (!RequestManager.instance) {
      throw new Error('RequestManager must be initialized with config first');
    }
    return RequestManager.instance;
  }

  public static initialize(config: DouTiksConfig): RequestManager {
    if (RequestManager.instance) {
      RequestManager.instance.updateConfig(config);
    } else {
      RequestManager.instance = new RequestManager(config);
    }
    return RequestManager.instance;
  }

  private setupInterceptors(): void {
    this.axiosInstance.interceptors.request.use(
      (config) => {
        if (this.config.debug) {
          console.log('Request:', {
            method: config.method,
            url: config.url,
            headers: config.headers,
            data: config.data
          });
        }
        return config;
      },
      (error) => {
        if (this.config.debug) {
          console.error('Request error:', error);
        }
        return Promise.reject(new NetworkError('Request setup failed', error));
      }
    );

    this.axiosInstance.interceptors.response.use(
      (response) => {
        if (this.config.debug) {
          console.log('Response:', {
            status: response.status,
            statusText: response.statusText,
            headers: response.headers,
            data: response.data
          });
        }
        return response;
      },
      async (error) => {
        if (this.config.debug) {
          console.error('Response error:', error);
        }

        if (error.response) {
          const { status, data } = error.response;

          switch (status) {
            case 401:
            case 403:
              throw new AuthenticationError(
                data?.status_msg || 'Authentication failed',
                error
              );
            case 404:
              throw new NotFoundError(
                data?.status_msg || 'Resource not found',
                error
              );
            case 429:
              const retryAfter = error.response.headers['retry-after'];
              throw new RateLimitError(
                data?.status_msg || 'Rate limit exceeded',
                parseInt(retryAfter) || 60,
                error
              );
            case 500:
            case 502:
            case 503:
            case 504:
              throw new APIError(
                data?.status_msg || 'Server error',
                status,
                data,
                error
              );
            default:
              throw new APIError(
                data?.status_msg || 'Request failed',
                status,
                data,
                error
              );
          }
        } else if (error.request) {
          throw new NetworkError('Network error', error);
        } else {
          throw new NetworkError('Request error', error);
        }
      }
    );
  }

  public updateConfig(config: Partial<DouTiksConfig>): void {
    this.config = { ...this.config, ...config };

    if (config.userAgent) {
      this.axiosInstance.defaults.headers['User-Agent'] = config.userAgent;
    }

    if (config.cookie) {
      this.axiosInstance.defaults.headers['Cookie'] = config.cookie;
    }

    if (config.proxy) {
      this.axiosInstance.defaults.proxy = config.proxy;
    }

    if (config.timeout) {
      this.axiosInstance.defaults.timeout = config.timeout;
    }
  }

  public getConfig(): DouTiksConfig {
    return { ...this.config };
  }

  public async request<T = any>(
    config: AxiosRequestConfig,
    retries = this.config.maxRetries!
  ): Promise<AxiosResponse<T>> {
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        if (attempt > 0) {
          await this.helper.sleep(this.config.retryDelay! * Math.pow(2, attempt - 1));
        }

        const response = await this.axiosInstance.request<T>(config);
        
        if (this.config.requestDelay && this.config.requestDelay > 0) {
          await this.helper.sleep(this.config.requestDelay);
        }

        return response;
      } catch (error) {
        lastError = error as Error;

        if (attempt === retries) {
          break;
        }

        if (error instanceof RateLimitError) {
          await this.helper.sleep(error.retryAfter || 60);
          continue;
        }

        if (error instanceof NetworkError || error instanceof APIError) {
          continue;
        }

        break;
      }
    }

    throw lastError || new NetworkError('Request failed after retries');
  }

  public async get<T = any>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> {
    return this.request<T>({
      method: 'GET',
      url,
      ...config
    });
  }

  public async post<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<AxiosResponse<T>> {
    return this.request<T>({
      method: 'POST',
      url,
      data,
      ...config
    });
  }

  public async downloadFile(
    url: string,
    options?: {
      headers?: Record<string, string>;
      timeout?: number;
      onProgress?: (progress: {
        total: number;
        downloaded: number;
        percentage: number;
        speed: number;
        estimatedTime: number;
      }) => void;
    }
  ): Promise<Buffer> {
    try {
      const response = await this.axiosInstance({
        method: 'GET',
        url,
        responseType: 'stream',
        headers: options?.headers,
        timeout: options?.timeout || this.config.timeout
      });

      const total = parseInt(response.headers['content-length'] || '0', 10);
      let downloaded = 0;
      const startTime = Date.now();
      let lastUpdate = startTime;

      const chunks: Buffer[] = [];

      return new Promise((resolve, reject) => {
        response.data.on('data', (chunk: Buffer) => {
          downloaded += chunk.length;
          chunks.push(chunk);

          const currentTime = Date.now();
          if (currentTime - lastUpdate >= 1000 && options?.onProgress) {
            const percentage = total > 0 ? (downloaded / total) * 100 : 0;
            const elapsed = (currentTime - startTime) / 1000;
            const speed = downloaded / elapsed;
            const estimatedTime = speed > 0 ? (total - downloaded) / speed : 0;

            options.onProgress({
              total,
              downloaded,
              percentage,
              speed,
              estimatedTime
            });

            lastUpdate = currentTime;
          }
        });

        response.data.on('end', () => {
          const buffer = Buffer.concat(chunks);
          resolve(buffer);
        });

        response.data.on('error', (error: Error) => {
          reject(new NetworkError('Download failed', error));
        });
      });
    } catch (error) {
      throw new NetworkError('Download failed', error);
    }
  }

  public async validateResponse<T>(response: AxiosResponse<T>): Promise<T> {
    const data = response.data as any;

    if (data?.status_code !== 0 && data?.status_code !== 200) {
      throw new APIError(
        data?.status_msg || 'API returned error',
        data?.status_code,
        data
      );
    }

    return response.data;
  }

  public async parseJsonResponse<T>(response: AxiosResponse): Promise<T> {
    try {
      const text = response.data;
      if (typeof text !== 'string') {
        return text as T;
      }

      const json = JSON.parse(text);
      return json as T;
    } catch (error) {
      throw new ParseError('Failed to parse JSON response', error);
    }
  }

  public generateDouyinParams(overrides: Partial<DouyinRequestParams> = {}): DouyinRequestParams {
    const baseParams: DouyinRequestParams = {
      device_platform: 'webapp',
      aid: '6383',
      channel: 'channel_pc_web',
      pc_client_type: 1,
      version_code: '290100',
      version_name: '29.1.0',
      cookie_enabled: 'true',
      screen_width: 1920,
      screen_height: 1080,
      browser_language: 'zh-CN',
      browser_platform: 'Win32',
      browser_name: 'Chrome',
      browser_version: '130.0.0.0',
      browser_online: 'true',
      engine_name: 'Blink',
      engine_version: '130.0.0.0',
      os_name: 'Windows',
      os_version: '10',
      cpu_core_num: 12,
      device_memory: 8,
      platform: 'PC',
      downlink: '10',
      effective_type: '4g',
      round_trip_time: '0',
      webid: this.helper.generateWebId(),
      ...overrides
    };

    return baseParams;
  }

  public generateTikTokParams(overrides: Partial<TikTokRequestParams> = {}): TikTokRequestParams {
    const baseParams: TikTokRequestParams = {
      aid: '1988',
      app_language: 'en',
      app_name: 'tiktok_web',
      browser_language: 'en-US',
      browser_name: 'Mozilla',
      browser_online: 'true',
      browser_platform: 'Win32',
      browser_version: '5.0%20%28Windows%29',
      channel: 'tiktok_web',
      cookie_enabled: 'true',
      device_id: parseInt(this.crypto.generateRandomString(19)),
      odinId: parseInt(this.crypto.generateRandomString(19)),
      device_platform: 'web_pc',
      focus_state: 'true',
      from_page: 'user',
      history_len: 4,
      is_fullscreen: 'false',
      is_page_visible: 'true',
      language: 'en',
      os: 'windows',
      priority_region: 'US',
      referer: '',
      region: 'US',
      root_referer: 'https%3A%2F%2Fwww.tiktok.com%2F',
      screen_height: 1080,
      screen_width: 1920,
      webcast_language: 'en',
      tz_name: 'America%2FTijuana',
      ...overrides
    };

    return baseParams;
  }

  public createHeaders(additionalHeaders?: Record<string, string>): Record<string, string> {
    const headers: Record<string, string> = {
      'User-Agent': this.config.userAgent || 
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive'
    };

    if (this.config.cookie) {
      headers['Cookie'] = this.config.cookie;
    }

    if (additionalHeaders) {
      Object.assign(headers, additionalHeaders);
    }

    return headers;
  }
}