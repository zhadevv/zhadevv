export * from './Libs/Crypto';
export * from './Libs/aBogus';
export * from './Libs/xBogus';
export * from './helper';
export * from './function';
export * from './manager';
export * from './mapping';

import { CryptoManager } from './Libs/Crypto';
import { Helper } from './helper';
import { RequestManager } from './function';
import { TokenManager, SignatureManager } from './manager';
import { DataMapper } from './mapping';
import { DouTiksConfig } from '../Types';

export class Utils {
  private static crypto: CryptoManager;
  private static helper: Helper;
  private static requestManager: RequestManager | null = null;
  private static tokenManager: TokenManager | null = null;
  private static signatureManager: SignatureManager | null = null;
  private static dataMapper: DataMapper;

  public static initialize(config: DouTiksConfig): void {
    Utils.crypto = CryptoManager.getInstance();
    Utils.helper = Helper.getInstance();
    Utils.requestManager = RequestManager.initialize(config);
    Utils.tokenManager = TokenManager.initialize(config);
    Utils.signatureManager = SignatureManager.getInstance(config.userAgent);
    Utils.dataMapper = DataMapper.getInstance();
  }

  public static getCrypto(): CryptoManager {
    if (!Utils.crypto) {
      Utils.crypto = CryptoManager.getInstance();
    }
    return Utils.crypto;
  }

  public static getHelper(): Helper {
    if (!Utils.helper) {
      Utils.helper = Helper.getInstance();
    }
    return Utils.helper;
  }

  public static getRequestManager(): RequestManager {
    if (!Utils.requestManager) {
      throw new Error('RequestManager not initialized. Call Utils.initialize() first.');
    }
    return Utils.requestManager;
  }

  public static getTokenManager(): TokenManager {
    if (!Utils.tokenManager) {
      throw new Error('TokenManager not initialized. Call Utils.initialize() first.');
    }
    return Utils.tokenManager;
  }

  public static getSignatureManager(): SignatureManager {
    if (!Utils.signatureManager) {
      Utils.signatureManager = SignatureManager.getInstance();
    }
    return Utils.signatureManager;
  }

  public static getDataMapper(): DataMapper {
    if (!Utils.dataMapper) {
      Utils.dataMapper = DataMapper.getInstance();
    }
    return Utils.dataMapper;
  }

  public static async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  public static generateRandomDeviceId(): string {
    return Utils.getHelper().generateDeviceId();
  }

  public static generateRandomWebId(): string {
    return Utils.getHelper().generateWebId();
  }

  public static isValidUrl(url: string): boolean {
    return Utils.getHelper().isValidUrl(url);
  }

  public static extractValidUrls(urls: string | string[]): string[] {
    return Utils.getHelper().extractValidUrls(urls);
  }

  public static parseQueryString(query: string): Record<string, string> {
    return Utils.getHelper().parseQueryString(query);
  }

  public static buildQueryString(params: Record<string, any>): string {
    return Utils.getHelper().buildQueryString(params);
  }

  public static formatBytes(bytes: number, decimals = 2): string {
    return Utils.getHelper().formatBytes(bytes, decimals);
  }

  public static formatDuration(ms: number): string {
    return Utils.getHelper().formatDuration(ms);
  }

  public static sanitizeFilename(filename: string): string {
    return Utils.getHelper().sanitizeFilename(filename);
  }

  public static getFileExtension(filename: string): string {
    return Utils.getHelper().getFileExtension(filename);
  }

  public static createProgressTracker(
    total: number,
    onProgress?: (progress: {
      total: number;
      downloaded: number;
      percentage: number;
      speed: number;
      estimatedTime: number;
    }) => void
  ): (chunkLength: number) => void {
    return Utils.getHelper().createProgressTracker(total, onProgress);
  }

  public static calculateDownloadSpeed(
    downloaded: number,
    startTime: number,
    endTime: number
  ): number {
    return Utils.getHelper().calculateDownloadSpeed(downloaded, startTime, endTime);
  }

  public static debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    return Utils.getHelper().debounce(func, wait);
  }

  public static throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    return Utils.getHelper().throttle(func, limit);
  }
}