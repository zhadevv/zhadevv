import { CryptoManager } from './Libs/Crypto';
import { ABogus } from './Libs/aBogus';
import { XBogus } from './Libs/xBogus';
import { Helper } from './helper';
import { RequestManager } from './function';
import {
  DouyinRequestParams,
  TikTokRequestParams,
  DouTiksConfig,
  Platform,
  CryptoError,
  NetworkError
} from '../Types';

export interface Token {
  msToken: string;
  ttwid: string;
  odin_tt?: string;
  verifyFp: string;
  s_v_web_id: string;
  timestamp: number;
  expiresAt: number;
}

export interface SignatureResult {
  params: string;
  signature: string;
  user_agent: string;
}

export class TokenManager {
  private static instance: TokenManager;
  private tokens: Map<Platform, Token> = new Map();
  private config: DouTiksConfig;
  private crypto: CryptoManager;
  private helper: Helper;
  private requestManager: RequestManager;
  private refreshThreshold = 3600000;

  private constructor(config: DouTiksConfig) {
    this.config = config;
    this.crypto = CryptoManager.getInstance();
    this.helper = Helper.getInstance();
    this.requestManager = RequestManager.getInstance(config);
  }

  public static getInstance(config?: DouTiksConfig): TokenManager {
    if (!TokenManager.instance && config) {
      TokenManager.instance = new TokenManager(config);
    } else if (!TokenManager.instance) {
      throw new Error('TokenManager must be initialized with config first');
    }
    return TokenManager.instance;
  }

  public static initialize(config: DouTiksConfig): TokenManager {
    if (TokenManager.instance) {
      TokenManager.instance.updateConfig(config);
    } else {
      TokenManager.instance = new TokenManager(config);
    }
    return TokenManager.instance;
  }

  public updateConfig(config: Partial<DouTiksConfig>): void {
    this.config = { ...this.config, ...config };
    this.requestManager.updateConfig(this.config);
  }

  private async generateVerifyFp(): Promise<string> {
    const baseStr = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const t = baseStr.length;
    const milliseconds = Date.now();
    
    let base36 = '';
    let temp = milliseconds;
    
    while (temp > 0) {
      const remainder = temp % 36;
      if (remainder < 10) {
        base36 = remainder.toString() + base36;
      } else {
        base36 = String.fromCharCode('a'.charCodeAt(0) + remainder - 10) + base36;
      }
      temp = Math.floor(temp / 36);
    }
    
    const r = base36;
    const o = new Array(36).fill('');
    
    o[8] = o[13] = o[18] = o[23] = '_';
    o[14] = '4';

    for (let i = 0; i < 36; i++) {
      if (!o[i]) {
        let n = Math.floor(Math.random() * t);
        if (i === 19) {
          n = 3 & n | 8;
        }
        o[i] = baseStr.charAt(n);
      }
    }

    return `verify_${r}_${o.join('')}`;
  }

  private async generateRealMsToken(platform: Platform): Promise<string> {
    try {
      const config = platform === 'douyin' ? {
        url: 'https://mssdk.bytedance.com/web/report',
        magic: 538969122,
        version: 1,
        dataType: 8,
        strData: this.config.strdata || '',
        userAgent: this.config.userAgent || 
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.47'
      } : {
        url: 'https://mssdk.tiktokw.us/web/report',
        magic: 538969122,
        version: 1,
        dataType: 8,
        strData: this.config.strdata || '',
        userAgent: this.config.userAgent || 
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
      };

      const payload = JSON.stringify({
        magic: config.magic,
        version: config.version,
        dataType: config.dataType,
        strData: config.strData,
        tspFromClient: Date.now()
      });

      const response = await this.requestManager.post(
        config.url,
        payload,
        {
          headers: {
            'User-Agent': config.userAgent,
            'Content-Type': 'application/json'
          }
        }
      );

      const cookies = response.headers['set-cookie'] || [];
      const msTokenCookie = cookies.find((cookie: string) => 
        cookie.startsWith('msToken=')
      );

      if (msTokenCookie) {
        const msToken = msTokenCookie.split(';')[0].split('=')[1];
        if (msToken.length >= 120) {
          return msToken;
        }
      }

      throw new Error('Invalid msToken received');
    } catch (error) {
      if (this.config.debug) {
        console.warn('Failed to generate real msToken, using fake one:', error);
      }
      return this.generateFakeMsToken();
    }
  }

  private generateFakeMsToken(): string {
    return this.crypto.generateRandomString(126) + '==';
  }

  private async generateTtwid(platform: Platform): Promise<string> {
    try {
      const config = platform === 'douyin' ? {
        url: 'https://ttwid.bytedance.com/ttwid/union/register/',
        data: JSON.stringify({
          region: 'cn',
          aid: 1768,
          needFid: false,
          service: 'www.ixigua.com',
          migrate_info: { ticket: '', source: 'node' },
          cbUrlProtocol: 'https',
          union: true
        })
      } : {
        url: 'https://www.tiktok.com/ttwid/check/',
        data: JSON.stringify({
          aid: 1988,
          service: 'www.tiktok.com',
          union: false,
          unionHost: '',
          needFid: false,
          fid: '',
          migrate_priority: 0
        })
      };

      const response = await this.requestManager.post(config.url, config.data, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const cookies = response.headers['set-cookie'] || [];
      const ttwidCookie = cookies.find((cookie: string) => 
        cookie.startsWith('ttwid=')
      );

      if (ttwidCookie) {
        return ttwidCookie.split(';')[0].split('=')[1];
      }

      throw new Error('Invalid ttwid received');
    } catch (error) {
      if (this.config.debug) {
        console.warn('Failed to generate ttwid:', error);
      }
      throw new NetworkError('Failed to generate ttwid', error);
    }
  }

  private async generateOdinTt(): Promise<string> {
    try {
      const url = 'https://www.tiktok.com/passport/web/account/info/?aid=1459&app_language=zh-Hans&app_name=tiktok_web&browser_language=zh-CN&browser_name=Mozilla&browser_online=true&browser_platform=Win32&browser_version=5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%28KHTML%2C%20like%20Gecko%29%20Chrome%2F119.0.0.0%20Safari%2F537.36&channel=tiktok_web&cookie_enabled=true&device_id=7306060721837852167&root_referer=https%3A%2F%2Fwww.tiktok.com%2Flogin%2F';

      const response = await this.requestManager.get(url);

      const cookies = response.headers['set-cookie'] || [];
      const odinTtCookie = cookies.find((cookie: string) => 
        cookie.startsWith('odin_tt=')
      );

      if (odinTtCookie) {
        return odinTtCookie.split(';')[0].split('=')[1];
      }

      throw new Error('Invalid odin_tt received');
    } catch (error) {
      if (this.config.debug) {
        console.warn('Failed to generate odin_tt:', error);
      }
      throw new NetworkError('Failed to generate odin_tt', error);
    }
  }

  public async getToken(platform: Platform, forceRefresh = false): Promise<Token> {
    const cachedToken = this.tokens.get(platform);
    const now = Date.now();

    if (cachedToken && !forceRefresh && cachedToken.expiresAt > now) {
      if (cachedToken.expiresAt - now < this.refreshThreshold) {
        setTimeout(() => this.refreshToken(platform), 0);
      }
      return cachedToken;
    }

    return this.refreshToken(platform);
  }

  public async refreshToken(platform: Platform): Promise<Token> {
    try {
      const verifyFp = await this.generateVerifyFp();
      const msToken = await this.generateRealMsToken(platform);
      const ttwid = await this.generateTtwid(platform);
      
      const token: Token = {
        msToken,
        ttwid,
        verifyFp,
        s_v_web_id: verifyFp,
        timestamp: Date.now(),
        expiresAt: Date.now() + 7200000
      };

      if (platform === 'tiktok') {
        try {
          token.odin_tt = await this.generateOdinTt();
        } catch (error) {
          if (this.config.debug) {
            console.warn('Failed to generate odin_tt for TikTok:', error);
          }
        }
      }

      this.tokens.set(platform, token);
      return token;
    } catch (error) {
      if (this.config.debug) {
        console.error('Failed to refresh token:', error);
      }
      
      const fallbackToken: Token = {
        msToken: this.generateFakeMsToken(),
        ttwid: this.crypto.generateRandomString(50),
        verifyFp: await this.generateVerifyFp(),
        s_v_web_id: await this.generateVerifyFp(),
        timestamp: Date.now(),
        expiresAt: Date.now() + 3600000
      };

      this.tokens.set(platform, fallbackToken);
      return fallbackToken;
    }
  }

  public getCachedToken(platform: Platform): Token | null {
    const token = this.tokens.get(platform);
    if (token && token.expiresAt > Date.now()) {
      return token;
    }
    return null;
  }

  public clearToken(platform: Platform): void {
    this.tokens.delete(platform);
  }

  public clearAllTokens(): void {
    this.tokens.clear();
  }
}

export class SignatureManager {
  private static instance: SignatureManager;
  private crypto: CryptoManager;
  private helper: Helper;
  private aBogus: ABogus;
  private xBogus: XBogus;

  private constructor(userAgent?: string) {
    this.crypto = CryptoManager.getInstance();
    this.helper = Helper.getInstance();
    this.aBogus = new ABogus();
    this.xBogus = new XBogus(userAgent);
  }

  public static getInstance(userAgent?: string): SignatureManager {
    if (!SignatureManager.instance) {
      SignatureManager.instance = new SignatureManager(userAgent);
    }
    return SignatureManager.instance;
  }

  public generateXBogus(url: string, userAgent?: string): SignatureResult {
    try {
      if (userAgent) {
        this.xBogus = new XBogus(userAgent);
      }

      const result = this.xBogus.getXBogus(url);
      return {
        params: result.params,
        signature: result.xb,
        user_agent: result.user_agent
      };
    } catch (error) {
      throw new CryptoError(`Failed to generate X-Bogus: ${error}`, error);
    }
  }

  public generateABogus(
    params: Record<string, any>,
    userAgent?: string
  ): string {
    try {
      return this.aBogus.getValue(params);
    } catch (error) {
      throw new CryptoError(`Failed to generate A-Bogus: ${error}`, error);
    }
  }

  public generateSignature(
    params: Record<string, any>,
    method: 'GET' | 'POST' = 'GET',
    path: string,
    secret?: string
  ): string {
    try {
      const timestamp = Date.now();
      const nonce = this.crypto.generateRandomString(8);
      
      const signParams = {
        ...params,
        timestamp,
        nonce,
        path
      };

      const sortedKeys = Object.keys(signParams).sort();
      const signString = sortedKeys
        .map(key => `${key}=${signParams[key]}`)
        .join('&');

      const dataToSign = `${method.toUpperCase()}&${signString}`;
      
      if (secret) {
        return this.crypto.sha256(dataToSign + secret);
      } else {
        return this.crypto.md5(dataToSign);
      }
    } catch (error) {
      throw new CryptoError(`Failed to generate signature: ${error}`, error);
    }
  }

  public generateDouyinSignature(
    params: DouyinRequestParams,
    endpoint: string,
    userAgent?: string,
    useABogus = true
  ): SignatureResult {
    try {
      const queryString = this.helper.buildQueryString(params);
      const fullUrl = `${endpoint}${queryString}`;

      if (useABogus) {
        const aBogus = this.generateABogus(params, userAgent);
        const signedUrl = `${fullUrl}&a_bogus=${encodeURIComponent(aBogus)}`;
        
        return {
          params: signedUrl,
          signature: aBogus,
          user_agent: userAgent || this.xBogus.getXBogus('').user_agent
        };
      } else {
        return this.generateXBogus(fullUrl, userAgent);
      }
    } catch (error) {
      throw new CryptoError(`Failed to generate Douyin signature: ${error}`, error);
    }
  }

  public generateTikTokSignature(
    params: TikTokRequestParams,
    endpoint: string,
    userAgent?: string
  ): SignatureResult {
    try {
      const queryString = this.helper.buildQueryString(params);
      const fullUrl = `${endpoint}${queryString}`;
      
      return this.generateXBogus(fullUrl, userAgent);
    } catch (error) {
      throw new CryptoError(`Failed to generate TikTok signature: ${error}`, error);
    }
  }

  public validateSignature(
    data: string,
    signature: string,
    secret?: string
  ): boolean {
    try {
      const expectedSignature = secret 
        ? this.crypto.sha256(data + secret)
        : this.crypto.md5(data);
      
      return expectedSignature === signature;
    } catch (error) {
      return false;
    }
  }
}