import { 
  UserProfile, 
  VideoInfo, 
  Comment, 
  LiveInfo, 
  SearchResult,
  MixInfo,
  Collection
} from '../Types';

export class DataMapper {
  private static instance: DataMapper;

  private constructor() {}

  public static getInstance(): DataMapper {
    if (!DataMapper.instance) {
      DataMapper.instance = new DataMapper();
    }
    return DataMapper.instance;
  }

  public mapDouyinUser(rawData: any): UserProfile {
    if (!rawData || !rawData.user) {
      throw new Error('Invalid user data');
    }

    const user = rawData.user;
    
    return {
      uid: user.uid || user.short_id || '',
      sec_uid: user.sec_uid || '',
      unique_id: user.unique_id || user.short_id || '',
      nickname: user.nickname || '',
      signature: user.signature || '',
      avatar_thumb: {
        url_list: user.avatar_thumb?.url_list || user.avatar_thumb?.url_list || [],
        uri: user.avatar_thumb?.uri || user.avatar_thumb?.uri || ''
      },
      avatar_medium: {
        url_list: user.avatar_medium?.url_list || user.avatar_medium?.url_list || [],
        uri: user.avatar_medium?.uri || user.avatar_medium?.uri || ''
      },
      avatar_larger: {
        url_list: user.avatar_larger?.url_list || user.avatar_larger?.url_list || [],
        uri: user.avatar_larger?.uri || user.avatar_larger?.uri || ''
      },
      follow_status: user.follow_status || 0,
      is_block: user.is_block || false,
      custom_verify: user.custom_verify || '',
      enterprise_verify_reason: user.enterprise_verify_reason || '',
      verification_type: user.verification_type || 0,
      secret: user.secret || 0,
      room_id: user.room_id,
      live_room: user.room_data || user.live_room,
      ...user
    };
  }

  public mapTikTokUser(rawData: any): UserProfile {
    if (!rawData || !rawData.userInfo || !rawData.userInfo.user) {
      throw new Error('Invalid user data');
    }

    const user = rawData.userInfo.user;
    
    return {
      uid: user.id || '',
      sec_uid: user.secUid || '',
      unique_id: user.uniqueId || '',
      nickname: user.nickname || '',
      signature: user.signature || '',
      avatar_thumb: {
        url_list: [user.avatarThumb] || [],
        uri: user.avatarThumb || ''
      },
      avatar_medium: {
        url_list: [user.avatarMedium] || [],
        uri: user.avatarMedium || ''
      },
      avatar_larger: {
        url_list: [user.avatarLarger] || [],
        uri: user.avatarLarger || ''
      },
      follow_status: user.followingVisibility || 0,
      is_block: user.block || false,
      custom_verify: user.verifiedReason || '',
      enterprise_verify_reason: user.commerceUserInfo?.commerce_user || '',
      verification_type: user.verified ? 1 : 0,
      secret: user.secret || 0,
      ...user
    };
  }

  public mapDouyinVideo(rawData: any): VideoInfo {
    if (!rawData || !rawData.aweme_id) {
      throw new Error('Invalid video data');
    }

    return {
      aweme_id: rawData.aweme_id,
      desc: rawData.desc || '',
      create_time: rawData.create_time || 0,
      author: this.mapDouyinUser({ user: rawData.author }),
      music: {
        id: rawData.music?.id || '',
        title: rawData.music?.title || '',
        author: rawData.music?.author || '',
        album: rawData.music?.album || '',
        play_url: {
          uri: rawData.music?.play_url?.uri || '',
          url_list: rawData.music?.play_url?.url_list || []
        },
        cover_large: {
          uri: rawData.music?.cover_large?.uri || '',
          url_list: rawData.music?.cover_large?.url_list || []
        },
        duration: rawData.music?.duration || 0,
        ...rawData.music
      },
      video: {
        play_addr: {
          uri: rawData.video?.play_addr?.uri || '',
          url_list: rawData.video?.play_addr?.url_list || []
        },
        cover: {
          uri: rawData.video?.cover?.uri || '',
          url_list: rawData.video?.cover?.url_list || []
        },
        height: rawData.video?.height || 0,
        width: rawData.video?.width || 0,
        duration: rawData.video?.duration || 0,
        ratio: rawData.video?.ratio || '540p',
        bit_rate: rawData.video?.bit_rate || [],
        ...rawData.video
      },
      statistics: {
        aweme_id: rawData.aweme_id,
        comment_count: rawData.statistics?.comment_count || 0,
        digg_count: rawData.statistics?.digg_count || 0,
        download_count: rawData.statistics?.download_count || 0,
        play_count: rawData.statistics?.play_count || 0,
        share_count: rawData.statistics?.share_count || 0,
        forward_count: rawData.statistics?.forward_count || 0,
        lose_count: rawData.statistics?.lose_count || 0,
        lose_comment_count: rawData.statistics?.lose_comment_count || 0,
        ...rawData.statistics
      },
      ...rawData
    };
  }

  public mapTikTokVideo(rawData: any): VideoInfo {
    if (!rawData || !rawData.itemInfo || !rawData.itemInfo.itemStruct) {
      throw new Error('Invalid video data');
    }

    const video = rawData.itemInfo.itemStruct;
    
    return {
      aweme_id: video.id || '',
      desc: video.desc || '',
      create_time: video.createTime || 0,
      author: this.mapTikTokUser({ userInfo: { user: video.author } }),
      music: {
        id: video.music?.id || '',
        title: video.music?.title || '',
        author: video.music?.authorName || '',
        album: video.music?.album || '',
        play_url: {
          uri: video.music?.playUrl || '',
          url_list: video.music?.playUrl ? [video.music.playUrl] : []
        },
        cover_large: {
          uri: video.music?.coverLarge || '',
          url_list: video.music?.coverLarge ? [video.music.coverLarge] : []
        },
        duration: video.music?.duration || 0,
        ...video.music
      },
      video: {
        play_addr: {
          uri: video.video?.playAddr || '',
          url_list: video.video?.downloadAddr ? [video.video.downloadAddr] : []
        },
        cover: {
          uri: video.video?.cover || '',
          url_list: video.video?.cover ? [video.video.cover] : []
        },
        height: video.video?.height || 0,
        width: video.video?.width || 0,
        duration: video.video?.duration || 0,
        ratio: video.video?.ratio || '540p',
        bit_rate: video.video?.bitRate || [],
        ...video.video
      },
      statistics: {
        aweme_id: video.id,
        comment_count: video.stats?.commentCount || 0,
        digg_count: video.stats?.diggCount || 0,
        download_count: video.stats?.downloadCount || 0,
        play_count: video.stats?.playCount || 0,
        share_count: video.stats?.shareCount || 0,
        forward_count: video.stats?.forwardCount || 0,
        lose_count: video.stats?.loseCount || 0,
        lose_comment_count: video.stats?.loseCommentCount || 0,
        ...video.stats
      },
      ...video
    };
  }

  public mapDouyinComment(rawData: any): Comment {
    if (!rawData || !rawData.cid) {
      throw new Error('Invalid comment data');
    }

    return {
      cid: rawData.cid,
      text: rawData.text || '',
      create_time: rawData.create_time || 0,
      digg_count: rawData.digg_count || 0,
      user: this.mapDouyinUser({ user: rawData.user }),
      reply_id: rawData.reply_id || '',
      reply_comment_total: rawData.reply_comment_total || 0,
      ...rawData
    };
  }

  public mapTikTokComment(rawData: any): Comment {
    if (!rawData || !rawData.cid) {
      throw new Error('Invalid comment data');
    }

    return {
      cid: rawData.cid,
      text: rawData.text || '',
      create_time: rawData.createTime || 0,
      digg_count: rawData.diggCount || 0,
      user: this.mapTikTokUser({ userInfo: { user: rawData.user } }),
      reply_id: rawData.replyId || '',
      reply_comment_total: rawData.replyCommentTotal || 0,
      ...rawData
    };
  }

  public mapDouyinLive(rawData: any): LiveInfo {
    if (!rawData || !rawData.data) {
      throw new Error('Invalid live data');
    }

    const data = rawData.data[0] || rawData.data;
    
    return {
      room_id: data.room_id || '',
      status: data.status || 0,
      title: data.title || '',
      user_count: data.user_count || 0,
      cover: {
        uri: data.cover?.uri || '',
        url_list: data.cover?.url_list || []
      },
      stream_url: {
        flv_pull_url: data.stream_url?.flv_pull_url || {},
        hls_pull_url_map: data.stream_url?.hls_pull_url_map || {}
      },
      owner: this.mapDouyinUser({ user: data.owner }),
      ...data
    };
  }

  public mapTikTokLive(rawData: any): LiveInfo {
    if (!rawData || !rawData.data) {
      throw new Error('Invalid live data');
    }

    const data = rawData.data;
    
    return {
      room_id: data.roomId || '',
      status: data.status || 0,
      title: data.title || '',
      user_count: data.userCount || 0,
      cover: {
        uri: data.cover || '',
        url_list: data.cover ? [data.cover] : []
      },
      stream_url: {
        flv_pull_url: data.streamUrl?.flvPullUrl || {},
        hls_pull_url_map: data.streamUrl?.hlsPullUrlMap || {}
      },
      owner: this.mapTikTokUser({ userInfo: { user: data.owner } }),
      ...data
    };
  }

  public mapDouyinSearchResult(rawData: any): SearchResult {
    if (!rawData) {
      throw new Error('Invalid search result data');
    }

    const result: SearchResult = {
      type: rawData.type || 0
    };

    if (rawData.aweme_info) {
      result.aweme_info = this.mapDouyinVideo(rawData.aweme_info);
    }

    if (rawData.user_info) {
      result.user_info = this.mapDouyinUser({ user: rawData.user_info });
    }

    if (rawData.live_info) {
      result.live_info = this.mapDouyinLive({ data: rawData.live_info });
    }

    return {
      ...result,
      ...rawData
    };
  }

  public mapTikTokSearchResult(rawData: any): SearchResult {
    if (!rawData) {
      throw new Error('Invalid search result data');
    }

    const result: SearchResult = {
      type: rawData.type || 0
    };

    if (rawData.item) {
      result.aweme_info = this.mapTikTokVideo({ itemInfo: { itemStruct: rawData.item } });
    }

    if (rawData.user) {
      result.user_info = this.mapTikTokUser({ userInfo: { user: rawData.user } });
    }

    return {
      ...result,
      ...rawData
    };
  }

  public mapDouyinMix(rawData: any): MixInfo {
    if (!rawData || !rawData.mix_info) {
      throw new Error('Invalid mix data');
    }

    const mix = rawData.mix_info;
    
    return {
      mix_id: mix.mix_id || '',
      mix_name: mix.mix_name || '',
      mix_desc: mix.mix_desc || '',
      mix_cover: {
        uri: mix.mix_cover?.uri || '',
        url_list: mix.mix_cover?.url_list || []
      },
      aweme_count: mix.aweme_count || 0,
      play_count: mix.play_count || 0,
      create_time: mix.create_time || 0,
      ...mix
    };
  }

  public mapTikTokMix(rawData: any): MixInfo {
    if (!rawData || !rawData.mixInfo) {
      throw new Error('Invalid mix data');
    }

    const mix = rawData.mixInfo;
    
    return {
      mix_id: mix.mixId || '',
      mix_name: mix.mixName || '',
      mix_desc: mix.mixDesc || '',
      mix_cover: {
        uri: mix.mixCover || '',
        url_list: mix.mixCover ? [mix.mixCover] : []
      },
      aweme_count: mix.awemeCount || 0,
      play_count: mix.playCount || 0,
      create_time: mix.createTime || 0,
      ...mix
    };
  }

  public mapDouyinCollection(rawData: any): Collection {
    if (!rawData || !rawData.collection_info) {
      throw new Error('Invalid collection data');
    }

    const collection = rawData.collection_info;
    
    return {
      collection_id: collection.collection_id || '',
      collection_name: collection.collection_name || '',
      cover: {
        uri: collection.cover?.uri || '',
        url_list: collection.cover?.url_list || []
      },
      count: collection.count || 0,
      ...collection
    };
  }

  public mapTikTokCollection(rawData: any): Collection {
    if (!rawData || !rawData.collectionInfo) {
      throw new Error('Invalid collection data');
    }

    const collection = rawData.collectionInfo;
    
    return {
      collection_id: collection.collectionId || '',
      collection_name: collection.collectionName || '',
      cover: {
        uri: collection.cover || '',
        url_list: collection.cover ? [collection.cover] : []
      },
      count: collection.count || 0,
      ...collection
    };
  }

  public mapVideoList(rawData: any[], platform: 'douyin' | 'tiktok'): VideoInfo[] {
    if (!Array.isArray(rawData)) {
      return [];
    }

    return rawData
      .filter(item => item)
      .map(item => {
        try {
          if (platform === 'douyin') {
            return this.mapDouyinVideo(item);
          } else {
            return this.mapTikTokVideo(item);
          }
        } catch (error) {
          return null;
        }
      })
      .filter((item): item is VideoInfo => item !== null);
  }

  public mapUserList(rawData: any[], platform: 'douyin' | 'tiktok'): UserProfile[] {
    if (!Array.isArray(rawData)) {
      return [];
    }

    return rawData
      .filter(item => item)
      .map(item => {
        try {
          if (platform === 'douyin') {
            return this.mapDouyinUser({ user: item });
          } else {
            return this.mapTikTokUser({ userInfo: { user: item } });
          }
        } catch (error) {
          return null;
        }
      })
      .filter((item): item is UserProfile => item !== null);
  }

  public mapCommentList(rawData: any[], platform: 'douyin' | 'tiktok'): Comment[] {
    if (!Array.isArray(rawData)) {
      return [];
    }

    return rawData
      .filter(item => item)
      .map(item => {
        try {
          if (platform === 'douyin') {
            return this.mapDouyinComment(item);
          } else {
            return this.mapTikTokComment(item);
          }
        } catch (error) {
          return null;
        }
      })
      .filter((item): item is Comment => item !== null);
  }

  public normalizeUrl(url: string, platform: 'douyin' | 'tiktok'): string {
    if (!url) return '';

    let normalized = url.trim();
    
    if (platform === 'douyin') {
      if (normalized.includes('v.douyin.com')) {
        return normalized;
      }
      if (!normalized.startsWith('http')) {
        normalized = `https://www.douyin.com${normalized}`;
      }
    } else {
      if (!normalized.startsWith('http')) {
        normalized = `https://www.tiktok.com${normalized}`;
      }
    }

    return normalized;
  }

  public extractIdsFromUrl(url: string): {
    aweme_id?: string;
    sec_uid?: string;
    unique_id?: string;
    mix_id?: string;
    room_id?: string;
  } {
    const result: any = {};

    if (!url) return result;

    const awemeMatch = url.match(/video\/(\d+)/) || url.match(/photo\/(\d+)/);
    if (awemeMatch) {
      result.aweme_id = awemeMatch[1];
    }

    const secUidMatch = url.match(/sec_uid=([^&]+)/);
    if (secUidMatch) {
      result.sec_uid = secUidMatch[1];
    }

    const uniqueIdMatch = url.match(/@([^/?]+)/);
    if (uniqueIdMatch) {
      result.unique_id = uniqueIdMatch[1];
    }

    const mixIdMatch = url.match(/collection\/(\d+)/) || url.match(/mix\/(\d+)/);
    if (mixIdMatch) {
      result.mix_id = mixIdMatch[1];
    }

    const roomIdMatch = url.match(/live\/(\d+)/) || url.match(/roomId=(\d+)/);
    if (roomIdMatch) {
      result.room_id = roomIdMatch[1];
    }

    return result;
  }
}