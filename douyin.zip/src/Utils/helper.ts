import { URL } from 'url';
import { CryptoManager } from './Libs/Crypto';
import { 
  DouTiksError, 
  ValidationError, 
  ParseError,
  DownloadProgress,
  DownloadOptions
} from '../Types';

export class Helper {
  private static instance: Helper;
  private crypto: CryptoManager;

  private constructor() {
    this.crypto = CryptoManager.getInstance();
  }

  public static getInstance(): Helper {
    if (!Helper.instance) {
      Helper.instance = new Helper();
    }
    return Helper.instance;
  }

  public isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  public extractUrl(text: string): string | null {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const matches = text.match(urlRegex);
    return matches ? matches[0] : null;
  }

  public extractUrls(text: string): string[] {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const matches = text.match(urlRegex);
    return matches || [];
  }

  public extractValidUrls(urls: string | string[]): string[] {
    const urlArray = Array.isArray(urls) ? urls : [urls];
    const validUrls: string[] = [];

    for (const url of urlArray) {
      if (typeof url === 'string' && this.isValidUrl(url)) {
        validUrls.push(url);
      }
    }

    return validUrls;
  }

  public parseQueryString(query: string): Record<string, string> {
    const params: Record<string, string> = {};
    
    if (!query) return params;
    
    const queryString = query.startsWith('?') ? query.substring(1) : query;
    const pairs = queryString.split('&');
    
    for (const pair of pairs) {
      const [key, value] = pair.split('=');
      if (key) {
        params[decodeURIComponent(key)] = value ? decodeURIComponent(value) : '';
      }
    }
    
    return params;
  }

  public buildQueryString(params: Record<string, any>): string {
    const parts: string[] = [];
    
    for (const [key, value] of Object.entries(params)) {
      if (value !== null && value !== undefined) {
        parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
      }
    }
    
    return parts.length > 0 ? `?${parts.join('&')}` : '';
  }

  public sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  public generateRandomHex(length: number): string {
    const chars = '0123456789abcdef';
    let result = '';
    
    for (let i = 0; i < length; i++) {
      result += chars[Math.floor(Math.random() * chars.length)];
    }
    
    return result;
  }

  public generateRandomNumber(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  public formatBytes(bytes: number, decimals = 2): string {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  public formatDuration(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days}d ${hours % 24}h`;
    } else if (hours > 0) {
      return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  }

  public validateAwemeId(awemeId: string): boolean {
    return /^\d+$/.test(awemeId) && awemeId.length >= 15 && awemeId.length <= 20;
  }

  public validateSecUserId(secUserId: string): boolean {
    return /^MS4wLjAB[A-Za-z0-9_-]+$/.test(secUserId);
  }

  public validateMixId(mixId: string): boolean {
    return /^\d+$/.test(mixId) && mixId.length >= 15 && mixId.length <= 20;
  }

  public validateRoomId(roomId: string): boolean {
    return /^\d+$/.test(roomId) && roomId.length >= 10 && roomId.length <= 20;
  }

  public safeJsonParse<T>(jsonString: string): T | null {
    try {
      return JSON.parse(jsonString) as T;
    } catch (error) {
      return null;
    }
  }

  public safeJsonStringify(obj: any, space = 2): string {
    try {
      return JSON.stringify(obj, null, space);
    } catch (error) {
      return '{}';
    }
  }

  public deepClone<T>(obj: T): T {
    return JSON.parse(JSON.stringify(obj));
  }

  public mergeObjects<T>(target: T, source: Partial<T>): T {
    return { ...target, ...source };
  }

  public chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    
    return chunks;
  }

  public debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout | null = null;
    
    return (...args: Parameters<T>) => {
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  public throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;
    
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  public getFileExtension(filename: string): string {
    const parts = filename.split('.');
    return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
  }

  public sanitizeFilename(filename: string): string {
    return filename
      .replace(/[<>:"/\\|?*]/g, '_')
      .replace(/\s+/g, '_')
      .replace(/__+/g, '_')
      .trim();
  }

  public calculateDownloadSpeed(
    downloaded: number,
    startTime: number,
    endTime: number
  ): number {
    const timeInSeconds = (endTime - startTime) / 1000;
    return timeInSeconds > 0 ? downloaded / timeInSeconds : 0;
  }

  public createProgressTracker(
    total: number,
    onProgress?: (progress: DownloadProgress) => void
  ): (chunkLength: number) => void {
    let downloaded = 0;
    let startTime = Date.now();
    let lastUpdate = startTime;

    return (chunkLength: number) => {
      downloaded += chunkLength;
      const currentTime = Date.now();
      
      if (currentTime - lastUpdate >= 1000) {
        const percentage = (downloaded / total) * 100;
        const elapsed = (currentTime - startTime) / 1000;
        const speed = downloaded / elapsed;
        const estimatedTime = speed > 0 ? (total - downloaded) / speed : 0;

        if (onProgress) {
          onProgress({
            total,
            downloaded,
            percentage,
            speed,
            estimatedTime
          });
        }

        lastUpdate = currentTime;
      }
    };
  }

  public parseUserAgent(userAgent: string): {
    browser: string;
    version: string;
    os: string;
    platform: string;
  } {
    const result = {
      browser: 'Unknown',
      version: 'Unknown',
      os: 'Unknown',
      platform: 'Unknown'
    };

    if (userAgent.includes('Chrome')) {
      result.browser = 'Chrome';
      const match = userAgent.match(/Chrome\/(\d+\.\d+)/);
      if (match) result.version = match[1];
    } else if (userAgent.includes('Firefox')) {
      result.browser = 'Firefox';
      const match = userAgent.match(/Firefox\/(\d+\.\d+)/);
      if (match) result.version = match[1];
    } else if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) {
      result.browser = 'Safari';
      const match = userAgent.match(/Version\/(\d+\.\d+)/);
      if (match) result.version = match[1];
    } else if (userAgent.includes('Edge')) {
      result.browser = 'Edge';
      const match = userAgent.match(/Edge\/(\d+\.\d+)/);
      if (match) result.version = match[1];
    }

    if (userAgent.includes('Windows')) {
      result.os = 'Windows';
      result.platform = 'Win32';
    } else if (userAgent.includes('Mac')) {
      result.os = 'macOS';
      result.platform = 'MacIntel';
    } else if (userAgent.includes('Linux')) {
      result.os = 'Linux';
      result.platform = 'Linux';
    } else if (userAgent.includes('Android')) {
      result.os = 'Android';
      result.platform = 'Android';
    } else if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
      result.os = 'iOS';
      result.platform = 'iOS';
    }

    return result;
  }

  public generateDeviceId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 10);
    return `${timestamp}${random}`.substring(0, 19);
  }

  public generateWebId(): string {
    const crypto = CryptoManager.getInstance();
    const timestamp = Date.now();
    const random = crypto.generateRandomString(10);
    return crypto.md5(`${timestamp}${random}`).substring(0, 19);
  }
}