import { CryptoManager } from './Crypto';
import { CryptoError } from '../../Types';

export class ABogus {
  private readonly filter = /%([0-9A-F]{2})/g;
  private readonly arguments = [0, 1, 14];
  private readonly ua_key = "\u0000\u0001\u000e";
  private readonly end_string = "cus";
  private readonly version = [1, 0, 1, 5];
  private readonly browser = "1536|742|1536|864|0|0|0|0|1536|864|1536|864|1536|742|24|24|MacIntel";
  private readonly reg = [
    1937774191, 1226093241, 388252375, 3666478592,
    2842636476, 372324522, 3817729613, 2969243214
  ];
  private readonly str = {
    s0: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    s1: "Dkdpgh4ZKsQB80/Mfvw36XI1R25+WUAlEi7NLboqYTOPuzmFjJnryx9HVGcaStCe=",
    s2: "Dkdpgh4ZKsQB80/Mfvw36XI1R25-WUAlEi7NLboqYTOPuzmFjJnryx9HVGcaStCe=",
    s3: "ckdp1h4ZKsUB80/Mfvw36XIgR25+WQAlEi7NLboqYTOPuzmFjJnryx9HVGDaStCe",
    s4: "Dkdpgh2ZmsQB80/MfvV36XI1R45-WUAlEixNLwoqYTOPuzKFjJnry79HbGcaStCe"
  };

  private chunk: number[] = [];
  private size = 0;
  private regState = [...this.reg];
  private readonly ua_code = [
    76, 98, 15, 131, 97, 245, 224, 133, 122, 199,
    241, 166, 79, 34, 90, 191, 128, 126, 122, 98,
    66, 11, 14, 40, 49, 110, 110, 173, 67, 96,
    138, 252
  ];
  private readonly browser_code: number[];
  private readonly browser_len: number;

  constructor(platform?: string) {
    this.browser_code = this.charCodeAt(this.browser);
    this.browser_len = this.browser.length;
  }

  private list1(random_num?: number, a = 170, b = 85, c = 45): number[] {
    return this.randomList(random_num, a, b, 1, 2, 5, c & a);
  }

  private list2(random_num?: number, a = 170, b = 85): number[] {
    return this.randomList(random_num, a, b, 1, 0, 0, 0);
  }

  private list3(random_num?: number, a = 170, b = 85): number[] {
    return this.randomList(random_num, a, b, 1, 0, 5, 0);
  }

  private randomList(
    a: number = Math.random() * 10000,
    b = 170,
    c = 85,
    d = 0,
    e = 0,
    f = 0,
    g = 0
  ): number[] {
    const r = a;
    const v = [r, Math.floor(r) & 255, Math.floor(r) >> 8];
    const result: number[] = [];

    result.push(v[1] & b | d);
    result.push(v[1] & c | e);
    result.push(v[2] & b | f);
    result.push(v[2] & c | g);

    return result;
  }

  private fromCharCode(...args: number[]): string {
    return String.fromCharCode(...args);
  }

  private generateString1(
    random_num_1?: number,
    random_num_2?: number,
    random_num_3?: number
  ): string {
    return this.fromCharCode(...this.list1(random_num_1)) +
           this.fromCharCode(...this.list2(random_num_2)) +
           this.fromCharCode(...this.list3(random_num_3));
  }

  private generateString2(
    url_params: string,
    method = "GET",
    start_time = 0,
    end_time = 0
  ): string {
    const a = this.generateString2List(url_params, method, start_time, end_time);
    const e = this.endCheckNum(a);
    a.push(...this.browser_code);
    a.push(e);
    return this.rc4Encrypt(this.fromCharCode(...a), "y");
  }

  private generateString2List(
    url_params: string,
    method = "GET",
    start_time = 0,
    end_time = 0
  ): number[] {
    const start = start_time || Date.now();
    const end = end_time || (start + Math.floor(Math.random() * 5) + 4);
    const params_array = this.generateParamsCode(url_params);
    const method_array = this.generateMethodCode(method);

    return this.list4(
      (end >> 24) & 255, params_array[21], this.ua_code[23],
      (end >> 16) & 255, params_array[22], this.ua_code[24],
      (end >> 8) & 255, (end >> 0) & 255,
      (start >> 24) & 255, (start >> 16) & 255,
      (start >> 8) & 255, (start >> 0) & 255,
      method_array[21], method_array[22],
      Math.floor(end / 256 / 256 / 256 / 256) >> 0,
      Math.floor(start / 256 / 256 / 256 / 256) >> 0,
      this.browser_len
    );
  }

  private list4(...args: number[]): number[] {
    return [
      44, args[0], 0, 0, 0, 0, 24, args[1], args[12], 0,
      args[2], args[3], 0, 0, 0, 1, 0, 239, args[4], args[13],
      args[5], args[6], 0, 0, 0, 0, args[7], 0, 0, 14,
      args[8], args[9], 0, args[10], args[11], 3, args[14],
      1, args[15], 1, args[16], 0, 0, 0
    ];
  }

  private endCheckNum(a: number[]): number {
    let r = 0;
    for (const i of a) {
      r ^= i;
    }
    return r;
  }

  private decodeString(url_string: string): string {
    return url_string.replace(this.filter, (match) => {
      return String.fromCharCode(parseInt(match.substring(1), 16));
    });
  }

  private de(e: number, r: number): number {
    r %= 32;
    return ((e << r) & 0xFFFFFFFF) | (e >>> (32 - r));
  }

  private pe(e: number): number {
    return e >= 0 && e < 16 ? 2043430169 : 2055708042;
  }

  private he(e: number, r: number, t: number, n: number): number {
    if (e >= 0 && e < 16) {
      return (r ^ t ^ n) & 0xFFFFFFFF;
    } else if (e >= 16 && e < 64) {
      return (r & t | r & n | t & n) & 0xFFFFFFFF;
    }
    throw new Error("Invalid parameter");
  }

  private ve(e: number, r: number, t: number, n: number): number {
    if (e >= 0 && e < 16) {
      return (r ^ t ^ n) & 0xFFFFFFFF;
    } else if (e >= 16 && e < 64) {
      return (r & t | ~r & n) & 0xFFFFFFFF;
    }
    throw new Error("Invalid parameter");
  }

  private regToArray(a: number[]): number[] {
    const o = new Array(32).fill(0);
    
    for (let i = 0; i < 8; i++) {
      let c = a[i];
      o[4 * i + 3] = (255 & c);
      c >>>= 8;
      o[4 * i + 2] = (255 & c);
      c >>>= 8;
      o[4 * i + 1] = (255 & c);
      c >>>= 8;
      o[4 * i] = (255 & c);
    }

    return o;
  }

  private compress(a: number[]): void {
    const f = this.generateF(a);
    const i = [...this.regState];

    for (let o = 0; o < 64; o++) {
      let c = this.de(i[0], 12) + i[4] + this.de(this.pe(o), o);
      c = (c & 0xFFFFFFFF);
      c = this.de(c, 7);
      const s = (c ^ this.de(i[0], 12)) & 0xFFFFFFFF;

      const u = this.he(o, i[0], i[1], i[2]);
      const u2 = (u + i[3] + s + f[o + 68]) & 0xFFFFFFFF;

      const b = this.ve(o, i[4], i[5], i[6]);
      const b2 = (b + i[7] + c + f[o]) & 0xFFFFFFFF;

      i[3] = i[2];
      i[2] = this.de(i[1], 9);
      i[1] = i[0];
      i[0] = u2;

      i[7] = i[6];
      i[6] = this.de(i[5], 19);
      i[5] = i[4];
      i[4] = (b2 ^ this.de(b2, 9) ^ this.de(b2, 17)) & 0xFFFFFFFF;
    }

    for (let l = 0; l < 8; l++) {
      this.regState[l] = (this.regState[l] ^ i[l]) & 0xFFFFFFFF;
    }
  }

  private generateF(e: number[]): number[] {
    const r = new Array(132).fill(0);

    for (let t = 0; t < 16; t++) {
      r[t] = (e[4 * t] << 24) | (e[4 * t + 1] << 16) | 
             (e[4 * t + 2] << 8) | e[4 * t + 3];
      r[t] &= 0xFFFFFFFF;
    }

    for (let n = 16; n < 68; n++) {
      const a = r[n - 16] ^ r[n - 9] ^ this.de(r[n - 3], 15);
      const a2 = a ^ this.de(a, 15) ^ this.de(a, 23);
      r[n] = (a2 ^ this.de(r[n - 13], 7) ^ r[n - 6]) & 0xFFFFFFFF;
    }

    for (let n = 68; n < 132; n++) {
      r[n] = (r[n - 68] ^ r[n - 64]) & 0xFFFFFFFF;
    }

    return r;
  }

  private padArray(arr: number[], length = 60): number[] {
    while (arr.length < length) {
      arr.push(0);
    }
    return arr;
  }

  private fill(length = 60): void {
    const size = 8 * this.size;
    this.chunk.push(128);
    this.chunk = this.padArray(this.chunk, length);
    
    for (let i = 0; i < 4; i++) {
      this.chunk.push((size >>> (8 * (3 - i))) & 255);
    }
  }

  private write(e: string | number[]): void {
    if (typeof e === 'string') {
      e = this.decodeString(e);
      e = this.charCodeAt(e);
    }

    this.size = e.length;

    if (e.length <= 64) {
      this.chunk = [...e];
    } else {
      const chunks = this.splitArray(e, 64);
      for (let i = 0; i < chunks.length - 1; i++) {
        this.compress(chunks[i]);
      }
      this.chunk = chunks[chunks.length - 1];
    }
  }

  private reset(): void {
    this.chunk = [];
    this.size = 0;
    this.regState = [...this.reg];
  }

  private sum(e: string | number[], length = 60): number[] {
    this.reset();
    this.write(e);
    this.fill(length);
    this.compress(this.chunk);
    return this.regToArray(this.regState);
  }

  private generateResultUnit(n: number, s: keyof typeof this.str): string {
    let r = '';
    const values = [
      { shift: 18, mask: 16515072 },
      { shift: 12, mask: 258048 },
      { shift: 6, mask: 4032 },
      { shift: 0, mask: 63 }
    ];

    for (const value of values) {
      r += this.str[s][(n & value.mask) >>> value.shift];
    }

    return r;
  }

  private generateResult(s: string, e: keyof typeof this.str = "s4"): string {
    const r: string[] = [];

    for (let i = 0; i < s.length; i += 3) {
      let n: number;
      
      if (i + 2 < s.length) {
        n = (s.charCodeAt(i) << 16) | 
            (s.charCodeAt(i + 1) << 8) | 
            s.charCodeAt(i + 2);
      } else if (i + 1 < s.length) {
        n = (s.charCodeAt(i) << 16) | 
            (s.charCodeAt(i + 1) << 8);
      } else {
        n = s.charCodeAt(i) << 16;
      }

      const masks = [
        { shift: 18, mask: 0xFC0000 },
        { shift: 12, mask: 0x03F000 },
        { shift: 6, mask: 0x0FC0 },
        { shift: 0, mask: 0x3F }
      ];

      for (let j = 0; j < masks.length; j++) {
        const { shift, mask } = masks[j];
        
        if ((j === 2 && i + 1 >= s.length) || 
            (j === 3 && i + 2 >= s.length)) {
          break;
        }

        r.push(this.str[e][(n & mask) >>> shift]);
      }
    }

    const padding = "=".repeat((4 - (r.length % 4)) % 4);
    return r.join('') + padding;
  }

  private generateArgsCode(): number[] {
    const a: number[] = [];
    
    for (let j = 24; j >= 0; j -= 8) {
      a.push(this.arguments[0] >>> j);
    }
    
    a.push(this.arguments[1] / 256);
    a.push(this.arguments[1] % 256);
    a.push(this.arguments[1] >>> 24);
    a.push(this.arguments[1] >>> 16);
    
    for (let j = 24; j >= 0; j -= 8) {
      a.push(this.arguments[2] >>> j);
    }
    
    return a.map(i => Math.floor(i) & 255);
  }

  private generateMethodCode(method: string): number[] {
    return this.sm3ToArray(this.sm3ToArray(method + this.end_string));
  }

  private generateParamsCode(params: string): number[] {
    return this.sm3ToArray(this.sm3ToArray(params + this.end_string));
  }

  private sm3ToArray(data: string | number[]): number[] {
    const crypto = CryptoManager.getInstance();
    
    if (typeof data === 'string') {
      const hash = crypto.sm3Hash(data, 'hex');
      const result: number[] = [];
      
      for (let i = 0; i < hash.length; i += 2) {
        result.push(parseInt(hash.substring(i, i + 2), 16));
      }
      
      return result;
    } else {
      const buffer = Buffer.from(data);
      const hash = crypto.sm3Hash(buffer, 'hex');
      const result: number[] = [];
      
      for (let i = 0; i < hash.length; i += 2) {
        result.push(parseInt(hash.substring(i, i + 2), 16));
      }
      
      return result;
    }
  }

  private generateBrowserInfo(platform = "Win32"): string {
    const inner_width = Math.floor(Math.random() * (1920 - 1280 + 1)) + 1280;
    const inner_height = Math.floor(Math.random() * (1080 - 720 + 1)) + 720;
    const outer_width = Math.floor(Math.random() * (1920 - inner_width + 1)) + inner_width;
    const outer_height = Math.floor(Math.random() * (1080 - inner_height + 1)) + inner_height;
    const screen_x = 0;
    const screen_y = Math.random() > 0.5 ? 0 : 30;

    const value_list = [
      inner_width, inner_height, outer_width, outer_height,
      screen_x, screen_y, 0, 0, outer_width, outer_height,
      outer_width, outer_height, inner_width, inner_height,
      24, 24, platform
    ];

    return value_list.join("|");
  }

  private rc4Encrypt(plaintext: string, key: string): string {
    const s = Array.from({ length: 256 }, (_, i) => i);
    let j = 0;

    for (let i = 0; i < 256; i++) {
      j = (j + s[i] + key.charCodeAt(i % key.length)) % 256;
      [s[i], s[j]] = [s[j], s[i]];
    }

    let i = 0;
    j = 0;
    const cipher: string[] = [];

    for (let k = 0; k < plaintext.length; k++) {
      i = (i + 1) % 256;
      j = (j + s[i]) % 256;
      [s[i], s[j]] = [s[j], s[i]];
      const t = (s[i] + s[j]) % 256;
      cipher.push(String.fromCharCode(s[t] ^ plaintext.charCodeAt(k)));
    }

    return cipher.join('');
  }

  private charCodeAt(s: string): number[] {
    return s.split('').map(c => c.charCodeAt(0));
  }

  private splitArray(arr: number[], chunkSize: number): number[][] {
    const result: number[][] = [];
    for (let i = 0; i < arr.length; i += chunkSize) {
      result.push(arr.slice(i, i + chunkSize));
    }
    return result;
  }

  public getValue(
    url_params: Record<string, any> | string,
    method = "GET",
    start_time = 0,
    end_time = 0,
    random_num_1?: number,
    random_num_2?: number,
    random_num_3?: number
  ): string {
    try {
      const string1 = this.generateString1(random_num_1, random_num_2, random_num_3);
      
      let paramsStr: string;
      if (typeof url_params === 'string') {
        paramsStr = url_params;
      } else {
        paramsStr = Object.entries(url_params)
          .map(([key, value]) => `${key}=${value}`)
          .join('&');
      }
      
      const string2 = this.generateString2(paramsStr, method, start_time, end_time);
      const string = string1 + string2;
      
      return this.generateResult(string, "s4");
    } catch (error) {
      throw new CryptoError(`Failed to generate a_bogus: ${error}`, error);
    }
  }
}