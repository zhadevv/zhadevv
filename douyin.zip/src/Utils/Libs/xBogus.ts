import { CryptoManager } from './Crypto';
import { CryptoError } from '../../Types';

export class XBogus {
  private readonly Array = [
    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, null, null, null, null, null, null, null, null, null, null, null,
    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
    null, null, null, null, null, null, null, null, null, null, null, null, 10, 11, 12, 13, 14, 15
  ];

  private readonly character = "Dkdpgh4ZKsQB80/Mfvw36XI1R25-WUAlEi7NLboqYTOPuzmFjJnryx9HVGcaStCe=";
  private readonly ua_key = "\x00\x01\x0c";
  private user_agent: string;

  constructor(user_agent?: string) {
    this.user_agent = user_agent || 
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0";
  }

  private md5StrToArray(md5_str: string): number[] {
    if (typeof md5_str === 'string' && md5_str.length > 32) {
      return Array.from(md5_str).map(char => char.charCodeAt(0));
    } else {
      const array: number[] = [];
      let idx = 0;
      
      while (idx < md5_str.length) {
        const high = this.Array[md5_str.charCodeAt(idx)]!;
        const low = this.Array[md5_str.charCodeAt(idx + 1)]!;
        array.push((high << 4) | low);
        idx += 2;
      }
      
      return array;
    }
  }

  private md5Encrypt(url_path: string): number[] {
    const crypto = CryptoManager.getInstance();
    
    const md5_hash1 = crypto.md5(url_path);
    const array1 = this.md5StrToArray(md5_hash1);
    const md5_hash2 = crypto.md5(Buffer.from(array1).toString('binary'));
    const array2 = this.md5StrToArray(md5_hash2);
    
    return array2;
  }

  private md5(input_data: string | number[]): string {
    const crypto = CryptoManager.getInstance();
    
    if (typeof input_data === 'string') {
      const array = this.md5StrToArray(input_data);
      return crypto.md5(Buffer.from(array));
    } else if (Array.isArray(input_data)) {
      return crypto.md5(Buffer.from(input_data));
    } else {
      throw new CryptoError("Invalid input type. Expected str or list.");
    }
  }

  private encodingConversion(
    a: number, b: number, c: number, e: number, d: number,
    t: number, f: number, r: number, n: number, o: number,
    i: number, _: number, x: number, u: number, s: number,
    l: number, v: number, h: number, p: number
  ): string {
    const y = [a, i, b, _, c, x, e, u, d, s, t, l, f, v, r, h, n, p, o];
    const buffer = Buffer.from(y);
    return buffer.toString('latin1');
  }

  private encodingConversion2(a: number, b: number, c: string): string {
    return String.fromCharCode(a) + String.fromCharCode(b) + c;
  }

  private rc4Encrypt(key: number[], data: string): string {
    const S = Array.from({ length: 256 }, (_, i) => i);
    let j = 0;
    const encrypted_data: number[] = [];

    for (let i = 0; i < 256; i++) {
      j = (j + S[i] + key[i % key.length]) % 256;
      [S[i], S[j]] = [S[j], S[i]];
    }

    let i = 0;
    j = 0;
    
    for (const byte of data) {
      i = (i + 1) % 256;
      j = (j + S[i]) % 256;
      [S[i], S[j]] = [S[j], S[i]];
      const encrypted_byte = byte.charCodeAt(0) ^ S[(S[i] + S[j]) % 256];
      encrypted_data.push(encrypted_byte);
    }

    return String.fromCharCode(...encrypted_data);
  }

  private calculation(a1: number, a2: number, a3: number): string {
    const x1 = (a1 & 255) << 16;
    const x2 = (a2 & 255) << 8;
    const x3 = x1 | x2 | a3;
    
    let result = '';
    result += this.character[(x3 & 16515072) >> 18];
    result += this.character[(x3 & 258048) >> 12];
    result += this.character[(x3 & 4032) >> 6];
    result += this.character[x3 & 63];
    
    return result;
  }

  public getXBogus(url_path: string): { params: string; xb: string; user_agent: string } {
    try {
      const crypto = CryptoManager.getInstance();
      
      const array1 = this.md5StrToArray(
        this.md5(
          Buffer.from(
            this.rc4Encrypt(
              Array.from(this.ua_key).map(c => c.charCodeAt(0)),
              this.user_agent
            ),
            'latin1'
          ).toString('base64')
        )
      );

      const array2 = this.md5StrToArray(
        this.md5(this.md5StrToArray("d41d8cd98f00b204e9800998ecf8427e"))
      );

      const url_path_array = this.md5Encrypt(url_path);

      const timer = Math.floor(Date.now() / 1000);
      const ct = 536919696;
      const array3: number[] = [];
      const array4: number[] = [];
      let xb_ = "";

      const new_array = [
        64, 0.00390625, 1, 12,
        url_path_array[14], url_path_array[15], 
        array2[14], array2[15], 
        array1[14], array1[15],
        (timer >> 24) & 255, (timer >> 16) & 255, 
        (timer >> 8) & 255, timer & 255,
        (ct >> 24) & 255, (ct >> 16) & 255, 
        (ct >> 8) & 255, ct & 255
      ];

      let xor_result = new_array[0];
      for (let i = 1; i < new_array.length; i++) {
        let b = new_array[i];
        if (typeof b === 'number' && !Number.isInteger(b)) {
          b = Math.floor(b);
        }
        xor_result ^= b as number;
      }

      const final_array = [...new_array, xor_result];

      let idx = 0;
      while (idx < final_array.length) {
        array3.push(final_array[idx] as number);
        if (idx + 1 < final_array.length) {
          array4.push(final_array[idx + 1] as number);
        }
        idx += 2;
      }

      const merge_array = [...array3, ...array4];

      const garbled_code = this.encodingConversion2(
        2,
        255,
        this.rc4Encrypt(
          [255],
          this.encodingConversion(...merge_array as [number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number])
        )
      );

      idx = 0;
      while (idx < garbled_code.length) {
        xb_ += this.calculation(
          garbled_code.charCodeAt(idx),
          garbled_code.charCodeAt(idx + 1),
          garbled_code.charCodeAt(idx + 2)
        );
        idx += 3;
      }

      const params = `${url_path}&X-Bogus=${xb_}`;
      
      return {
        params,
        xb: xb_,
        user_agent: this.user_agent
      };
    } catch (error) {
      throw new CryptoError(`Failed to generate X-Bogus: ${error}`, error);
    }
  }
}