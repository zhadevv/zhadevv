import { MD5, SHA256, SHA512, AES, Base64, Hex, UTF8 } from 'crypto-es';
import { SM2, SM3, SM4 } from 'gm-crypto-wasm';
import { CryptoError } from '../../Types';

export class CryptoManager {
  private static instance: CryptoManager;

  private constructor() {}

  public static getInstance(): CryptoManager {
    if (!CryptoManager.instance) {
      CryptoManager.instance = new CryptoManager();
    }
    return CryptoManager.instance;
  }

  public md5(input: string | Buffer): string {
    try {
      const data = typeof input === 'string' ? input : input.toString('utf8');
      return MD5(data).toString();
    } catch (error) {
      throw new CryptoError(`MD5 hash failed: ${error}`, error);
    }
  }

  public sha256(input: string | Buffer): string {
    try {
      const data = typeof input === 'string' ? input : input.toString('utf8');
      return SHA256(data).toString();
    } catch (error) {
      throw new CryptoError(`SHA256 hash failed: ${error}`, error);
    }
  }

  public sha512(input: string | Buffer): string {
    try {
      const data = typeof input === 'string' ? input : input.toString('utf8');
      return SHA512(data).toString();
    } catch (error) {
      throw new CryptoError(`SHA512 hash failed: ${error}`, error);
    }
  }

  public base64Encode(input: string | Buffer): string {
    try {
      const data = typeof input === 'string' ? UTF8.parse(input) : input;
      return Base64.stringify(data);
    } catch (error) {
      throw new CryptoError(`Base64 encode failed: ${error}`, error);
    }
  }

  public base64Decode(input: string): string {
    try {
      const decoded = Base64.parse(input);
      return UTF8.stringify(decoded);
    } catch (error) {
      throw new CryptoError(`Base64 decode failed: ${error}`, error);
    }
  }

  public hexEncode(input: string | Buffer): string {
    try {
      const data = typeof input === 'string' ? UTF8.parse(input) : input;
      return Hex.stringify(data);
    } catch (error) {
      throw new CryptoError(`Hex encode failed: ${error}`, error);
    }
  }

  public hexDecode(input: string): string {
    try {
      const decoded = Hex.parse(input);
      return UTF8.stringify(decoded);
    } catch (error) {
      throw new CryptoError(`Hex decode failed: ${error}`, error);
    }
  }

  public aesEncrypt(data: string, key: string, iv?: string): string {
    try {
      const keyBuffer = UTF8.parse(key);
      const ivBuffer = iv ? UTF8.parse(iv) : undefined;
      
      return AES.encrypt(data, keyBuffer, {
        iv: ivBuffer,
        mode: ivBuffer ? AES.mode.CBC : AES.mode.ECB,
        padding: AES.pad.PKCS7
      }).toString();
    } catch (error) {
      throw new CryptoError(`AES encryption failed: ${error}`, error);
    }
  }

  public aesDecrypt(encrypted: string, key: string, iv?: string): string {
    try {
      const keyBuffer = UTF8.parse(key);
      const ivBuffer = iv ? UTF8.parse(iv) : undefined;
      
      return AES.decrypt(encrypted, keyBuffer, {
        iv: ivBuffer,
        mode: ivBuffer ? AES.mode.CBC : AES.mode.ECB,
        padding: AES.pad.PKCS7
      }).toString(UTF8);
    } catch (error) {
      throw new CryptoError(`AES decryption failed: ${error}`, error);
    }
  }

  public sm3Hash(input: string | Buffer, encoding: 'hex' | 'base64' = 'hex'): string {
    try {
      const data = typeof input === 'string' ? input : input.toString('utf8');
      return SM3.digest(data, encoding);
    } catch (error) {
      throw new CryptoError(`SM3 hash failed: ${error}`, error);
    }
  }

  public sm4Encrypt(data: string, key: string, iv?: string, mode: 'ECB' | 'CBC' = 'ECB'): string {
    try {
      const options: any = {
        inputEncoding: 'utf8',
        outputEncoding: 'hex'
      };

      if (iv && mode === 'CBC') {
        options.iv = iv;
        options.mode = SM4.constants.CBC;
      }

      return SM4.encrypt(data, key, options);
    } catch (error) {
      throw new CryptoError(`SM4 encryption failed: ${error}`, error);
    }
  }

  public sm4Decrypt(encrypted: string, key: string, iv?: string, mode: 'ECB' | 'CBC' = 'ECB'): string {
    try {
      const options: any = {
        inputEncoding: 'hex',
        outputEncoding: 'utf8'
      };

      if (iv && mode === 'CBC') {
        options.iv = iv;
        options.mode = SM4.constants.CBC;
      }

      return SM4.decrypt(encrypted, key, options);
    } catch (error) {
      throw new CryptoError(`SM4 decryption failed: ${error}`, error);
    }
  }

  public generateSignature(params: Record<string, any>, secret: string): string {
    try {
      const sortedParams = Object.keys(params)
        .sort()
        .map(key => `${key}=${params[key]}`)
        .join('&');
      
      const data = `${sortedParams}&${secret}`;
      return this.md5(data);
    } catch (error) {
      throw new CryptoError(`Signature generation failed: ${error}`, error);
    }
  }

  public generateRandomString(length: number): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return result;
  }

  public generateTimestamp(unit: 'ms' | 'sec' = 'ms'): number {
    const timestamp = Date.now();
    return unit === 'sec' ? Math.floor(timestamp / 1000) : timestamp;
  }
}