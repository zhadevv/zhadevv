export * from './response/api';
export * from './response/models';
export * from './response/errors';
export * from './response/utils';

export interface DouTiksConfig {
  cookie?: string;
  strdata?: string;
  userAgent?: string;
  timeout?: number;
  maxRetries?: number;
  retryDelay?: number;
  requestDelay?: number;
  proxy?: {
    http?: string;
    https?: string;
  };
  debug?: boolean;
}

export type Platform = 'douyin' | 'tiktok';
export type Region = 'CN' | 'US' | 'SG' | 'JP' | 'KR' | 'TW' | 'HK' | 'VN' | 'TH' | 'ID' | 'MY' | 'PH';

export interface SearchOptions {
  keyword: string;
  cursor?: number;
  count?: number;
  sort_type?: number;
  publish_time?: number | string;
  search_type?: 'video' | 'user' | 'live' | 'general';
}