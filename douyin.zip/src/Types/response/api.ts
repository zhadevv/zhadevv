export interface APIResponse<T = any> {
  status_code: number;
  status_msg?: string;
  extra?: {
    now: number;
    fatal_item_ids?: any[];
    logid: string;
  };
  has_more?: boolean;
  cursor?: number;
  aweme_list?: T[];
  data?: T;
  [key: string]: any;
}

export interface ErrorResponse {
  status_code: number;
  status_msg: string;
  log_id: string;
  now: number;
  [key: string]: any;
}

export interface DouyinAPIResponse<T> extends APIResponse<T> {
  status_code: number;
  status_msg?: string;
  has_more: boolean;
  max_cursor: number;
  min_cursor: number;
  [key: string]: any;
}

export interface TikTokAPIResponse<T> extends APIResponse<T> {
  status_code: number;
  status_msg?: string;
  has_more: boolean;
  cursor: string;
  [key: string]: any;
}