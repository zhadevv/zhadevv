export interface PaginationParams {
  cursor?: number;
  max_cursor?: number;
  min_cursor?: number;
  count?: number;
}

export interface BaseRequestParams {
  device_platform?: string;
  aid?: string;
  channel?: string;
  pc_client_type?: number;
  version_code?: string;
  version_name?: string;
  cookie_enabled?: boolean | string;
  screen_width?: number;
  screen_height?: number;
  browser_language?: string;
  browser_platform?: string;
  browser_name?: string;
  browser_version?: string;
  browser_online?: boolean | string;
  engine_name?: string;
  engine_version?: string;
  os_name?: string;
  os_version?: string;
  cpu_core_num?: number;
  device_memory?: number;
  platform?: string;
  downlink?: string;
  effective_type?: string;
  round_trip_time?: string | number;
  msToken?: string;
  [key: string]: any;
}

export interface DouyinRequestParams extends BaseRequestParams {
  webid?: string;
  a_bogus?: string;
  X_Bogus?: string;
  _signature?: string;
  verifyFp?: string;
  fp?: string;
  ttwid?: string;
  [key: string]: any;
}

export interface TikTokRequestParams extends BaseRequestParams {
  app_language?: string;
  app_name?: string;
  device_id?: string;
  odinId?: string;
  device_platform?: string;
  focus_state?: boolean | string;
  from_page?: string;
  history_len?: number;
  is_fullscreen?: boolean | string;
  is_page_visible?: boolean | string;
  priority_region?: string;
  referer?: string;
  region?: string;
  root_referer?: string;
  webcast_language?: string;
  tz_name?: string;
  [key: string]: any;
}

export interface DownloadOptions {
  path?: string;
  filename?: string;
  overwrite?: boolean;
  timeout?: number;
  retry?: number;
  chunkSize?: number;
  onProgress?: (progress: DownloadProgress) => void;
}

export interface DownloadProgress {
  total: number;
  downloaded: number;
  percentage: number;
  speed: number;
  estimatedTime: number;
}