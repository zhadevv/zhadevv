export class DouTiksError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode?: number,
    public originalError?: any
  ) {
    super(message);
    this.name = 'DouTiksError';
  }
}

export class NetworkError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'NETWORK_ERROR', undefined, originalError);
    this.name = 'NetworkError';
  }
}

export class APIError extends DouTiksError {
  constructor(
    message: string,
    statusCode?: number,
    public response?: any,
    originalError?: any
  ) {
    super(message, 'API_ERROR', statusCode, originalError);
    this.name = 'APIError';
  }
}

export class AuthenticationError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'AUTHENTICATION_ERROR', 401, originalError);
    this.name = 'AuthenticationError';
  }
}

export class RateLimitError extends DouTiksError {
  constructor(message: string, retryAfter?: number, originalError?: any) {
    super(message, 'RATE_LIMIT_ERROR', 429, originalError);
    this.name = 'RateLimitError';
    if (retryAfter) {
      this.retryAfter = retryAfter;
    }
  }
  retryAfter?: number;
}

export class ValidationError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'VALIDATION_ERROR', 400, originalError);
    this.name = 'ValidationError';
  }
}

export class NotFoundError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'NOT_FOUND_ERROR', 404, originalError);
    this.name = 'NotFoundError';
  }
}

export class ParseError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'PARSE_ERROR', undefined, originalError);
    this.name = 'ParseError';
  }
}

export class CryptoError extends DouTiksError {
  constructor(message: string, originalError?: any) {
    super(message, 'CRYPTO_ERROR', undefined, originalError);
    this.name = 'CryptoError';
  }
}