export interface UserProfile {
  uid: string;
  sec_uid: string;
  unique_id: string;
  nickname: string;
  signature: string;
  avatar_thumb: {
    url_list: string[];
    uri: string;
    [key: string]: any;
  };
  avatar_medium: {
    url_list: string[];
    uri: string;
    [key: string]: any;
  };
  avatar_larger: {
    url_list: string[];
    uri: string;
    [key: string]: any;
  };
  follow_status: number;
  is_block: boolean;
  custom_verify: string;
  enterprise_verify_reason: string;
  verification_type: number;
  secret: number;
  room_id?: string;
  live_room?: {
    [key: string]: any;
  };
  [key: string]: any;
}

export interface VideoInfo {
  aweme_id: string;
  desc: string;
  create_time: number;
  author: UserProfile;
  music: {
    id: string;
    title: string;
    author: string;
    album: string;
    play_url: {
      uri: string;
      url_list: string[];
      [key: string]: any;
    };
    cover_large: {
      uri: string;
      url_list: string[];
      [key: string]: any;
    };
    duration: number;
    [key: string]: any;
  };
  video: {
    play_addr: {
      uri: string;
      url_list: string[];
      [key: string]: any;
    };
    cover: {
      uri: string;
      url_list: string[];
      [key: string]: any;
    };
    height: number;
    width: number;
    duration: number;
    ratio: string;
    bit_rate: {
      [key: string]: any;
    }[];
    [key: string]: any;
  };
  statistics: {
    aweme_id: string;
    comment_count: number;
    digg_count: number;
    download_count: number;
    play_count: number;
    share_count: number;
    forward_count: number;
    lose_count: number;
    lose_comment_count: number;
  };
  [key: string]: any;
}

export interface Comment {
  cid: string;
  text: string;
  create_time: number;
  digg_count: number;
  user: UserProfile;
  reply_id: string;
  reply_comment_total: number;
  [key: string]: any;
}

export interface LiveInfo {
  room_id: string;
  status: number;
  title: string;
  user_count: number;
  cover: {
    uri: string;
    url_list: string[];
    [key: string]: any;
  };
  stream_url: {
    flv_pull_url: {
      FULL_HD1?: string;
      HD1?: string;
      SD1?: string;
      SD2?: string;
      [key: string]: any;
    };
    hls_pull_url_map: {
      FULL_HD1?: string;
      HD1?: string;
      SD1?: string;
      SD2?: string;
      [key: string]: any;
    };
    [key: string]: any;
  };
  owner: UserProfile;
  [key: string]: any;
}

export interface SearchResult {
  type: number;
  aweme_info?: VideoInfo;
  user_info?: UserProfile;
  live_info?: LiveInfo;
  [key: string]: any;
}

export interface MixInfo {
  mix_id: string;
  mix_name: string;
  mix_desc: string;
  mix_cover: {
    uri: string;
    url_list: string[];
    [key: string]: any;
  };
  aweme_count: number;
  play_count: number;
  create_time: number;
  [key: string]: any;
}

export interface Collection {
  collection_id: string;
  collection_name: string;
  cover: {
    uri: string;
    url_list: string[];
    [key: string]: any;
  };
  count: number;
  [key: string]: any;
}