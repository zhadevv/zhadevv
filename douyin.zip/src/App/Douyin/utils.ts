import axios from 'axios';
import { URL } from 'url';
import { Utils } from '../../Utils';
import {
  DouyinRequestParams,
  NetworkError,
  NotFoundError,
  APIError,
  ParseError
} from '../../Types';

export class DouyinUtils {
  private static readonly DOUYIN_URL_PATTERN = /user\/([^/?]*)/;
  private static readonly REDIRECT_URL_PATTERN = /sec_uid=([^&]*)/;
  private static readonly DOUYIN_VIDEO_URL_PATTERN = /video\/([^/?]*)/;
  private static readonly DOUYIN_NOTE_URL_PATTERN = /note\/([^/?]*)/;
  private static readonly DOUYIN_DISCOVER_URL_PATTERN = /modal_id=([0-9]+)/;
  private static readonly DOUYIN_LIVE_URL_PATTERN = /live\/([^/?]*)/;
  private static readonly DOUYIN_LIVE_URL_PATTERN2 = /http[s]?:\/\/live\.douyin\.com\/(\d+)/;
  private static readonly DOUYIN_LIVE_URL_PATTERN3 = /reflow\/([^/?]*)/;

  public static async extractSecUserId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const pattern = validUrl.includes('v.douyin.com') 
        ? this.REDIRECT_URL_PATTERN 
        : this.DOUYIN_URL_PATTERN;

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      const match = pattern.exec(finalUrl || '');

      if (!match || !match[1]) {
        throw new NotFoundError('sec_user_id not found in URL');
      }

      return match[1];
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract sec_user_id', error);
    }
  }

  public static async extractSecUserIds(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractSecUserId(url))
    );

    const secUserIds: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        secUserIds.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract sec_user_id from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (secUserIds.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any sec_user_id', errors[0]);
    }

    return secUserIds;
  }

  public static async extractAwemeId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      
      let match = this.DOUYIN_VIDEO_URL_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      match = this.DOUYIN_NOTE_URL_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      match = this.DOUYIN_DISCOVER_URL_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      throw new NotFoundError('aweme_id not found in URL');
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract aweme_id', error);
    }
  }

  public static async extractAwemeIds(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractAwemeId(url))
    );

    const awemeIds: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        awemeIds.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract aweme_id from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (awemeIds.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any aweme_id', errors[0]);
    }

    return awemeIds;
  }

  public static async extractWebcastId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      
      let match = this.DOUYIN_LIVE_URL_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      match = this.DOUYIN_LIVE_URL_PATTERN2.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      match = this.DOUYIN_LIVE_URL_PATTERN3.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      throw new NotFoundError('webcast_id not found in URL');
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract webcast_id', error);
    }
  }

  public static async extractWebcastIds(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractWebcastId(url))
    );

    const webcastIds: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        webcastIds.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract webcast_id from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (webcastIds.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any webcast_id', errors[0]);
    }

    return webcastIds;
  }

  public static async extractMixId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      const urlObj = new URL(finalUrl || '');
      const pathParts = urlObj.pathname.split('/');

      for (let i = 0; i < pathParts.length; i++) {
        if (pathParts[i] === 'collection' && i + 1 < pathParts.length) {
          return pathParts[i + 1];
        }
        if (pathParts[i] === 'mix' && i + 1 < pathParts.length) {
          return pathParts[i + 1];
        }
      }

      throw new NotFoundError('mix_id not found in URL');
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract mix_id', error);
    }
  }

  public static generateDouyinParams(overrides: Partial<DouyinRequestParams> = {}): DouyinRequestParams {
    const requestManager = Utils.getRequestManager();
    return requestManager.generateDouyinParams(overrides);
  }

  public static validateDouyinResponse(response: any): boolean {
    if (!response) return false;
    
    if (response.status_code !== undefined && response.status_code !== 0) {
      return false;
    }
    
    if (response.status_code === 0 && response.aweme_list !== undefined) {
      return true;
    }
    
    if (response.status_code === 0 && response.data !== undefined) {
      return true;
    }
    
    return false;
  }

  public static parseDouyinResponse<T>(response: any): T {
    if (!this.validateDouyinResponse(response)) {
      throw new ParseError('Invalid Douyin response format');
    }

    if (response.aweme_list !== undefined) {
      return response.aweme_list as T;
    }

    if (response.data !== undefined) {
      return response.data as T;
    }

    return response as T;
  }

  public static formatVideoUrl(videoId: string): string {
    return `https://www.douyin.com/video/${videoId}`;
  }

  public static formatUserUrl(secUserId: string): string {
    return `https://www.douyin.com/user/${secUserId}`;
  }

  public static formatLiveUrl(webcastId: string): string {
    return `https://live.douyin.com/${webcastId}`;
  }

  public static formatMixUrl(mixId: string): string {
    return `https://www.douyin.com/collection/${mixId}`;
  }

  public static async generateSignature(
    endpoint: string,
    params: DouyinRequestParams,
    useABogus = true
  ): Promise<{ url: string; signature: string }> {
    const signatureManager = Utils.getSignatureManager();
    
    if (useABogus) {
      const aBogus = signatureManager.generateABogus(params);
      const queryString = Utils.buildQueryString(params);
      const url = `${endpoint}${queryString}&a_bogus=${encodeURIComponent(aBogus)}`;
      
      return {
        url,
        signature: aBogus
      };
    } else {
      const queryString = Utils.buildQueryString(params);
      const fullUrl = `${endpoint}${queryString}`;
      const result = signatureManager.generateXBogus(fullUrl);
      
      return {
        url: result.params,
        signature: result.signature
      };
    }
  }

  public static async checkVideoExists(videoId: string): Promise<boolean> {
    try {
      const requestManager = Utils.getRequestManager();
      const url = this.formatVideoUrl(videoId);
      
      const response = await requestManager.head(url, {
        timeout: 10000
      });

      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  public static async checkUserExists(secUserId: string): Promise<boolean> {
    try {
      const requestManager = Utils.getRequestManager();
      const url = this.formatUserUrl(secUserId);
      
      const response = await requestManager.head(url, {
        timeout: 10000
      });

      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  public static async checkLiveExists(webcastId: string): Promise<boolean> {
    try {
      const requestManager = Utils.getRequestManager();
      const url = this.formatLiveUrl(webcastId);
      
      const response = await requestManager.head(url, {
        timeout: 10000
      });

      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  public static sanitizeDescription(desc: string, maxLength = 200): string {
    if (!desc) return '';
    
    let sanitized = desc
      .replace(/[\r\n]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    if (sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength) + '...';
    }
    
    return sanitized;
  }

  public static extractHashtags(desc: string): string[] {
    if (!desc) return [];
    
    const hashtagRegex = /#([^#\s]+)/g;
    const matches = desc.match(hashtagRegex) || [];
    
    return matches.map(tag => tag.substring(1));
  }

  public static extractMentions(desc: string): string[] {
    if (!desc) return [];
    
    const mentionRegex = /@([^@\s]+)/g;
    const matches = desc.match(mentionRegex) || [];
    
    return matches.map(mention => mention.substring(1));
  }

  public static calculateVideoQuality(videoInfo: any): {
    quality: string;
    resolution: string;
    bitrate: number;
  } {
    const width = videoInfo?.width || 0;
    const height = videoInfo?.height || 0;
    const bitrate = videoInfo?.bit_rate?.[0]?.bit_rate || 0;

    let quality = 'SD';
    let resolution = `${width}x${height}`;

    if (height >= 1080) {
      quality = 'FHD';
    } else if (height >= 720) {
      quality = 'HD';
    } else if (height >= 480) {
      quality = 'SD';
    } else {
      quality = 'LD';
    }

    return {
      quality,
      resolution,
      bitrate
    };
  }

  public static async getVideoDownloadUrl(videoInfo: any): Promise<string | null> {
    try {
      if (!videoInfo?.video?.play_addr?.url_list) {
        return null;
      }

      const urlList = videoInfo.video.play_addr.url_list;
      if (!Array.isArray(urlList) || urlList.length === 0) {
        return null;
      }

      const sortedUrls = urlList.sort((a, b) => {
        const aMatch = a.match(/(\d+)p/);
        const bMatch = b.match(/(\d+)p/);
        
        const aHeight = aMatch ? parseInt(aMatch[1]) : 0;
        const bHeight = bMatch ? parseInt(bMatch[1]) : 0;
        
        return bHeight - aHeight;
      });

      return sortedUrls[0];
    } catch (error) {
      return null;
    }
  }
}