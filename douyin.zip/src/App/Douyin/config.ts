import { DouTiksConfig, Region } from '../../Types';

export interface DouyinConfig extends DouTiksConfig {
  region?: Region;
  defaultHeaders?: Record<string, string>;
  endpoints?: Record<string, string>;
}

export const DEFAULT_DOUYIN_CONFIG: DouyinConfig = {
  cookie: '',
  strdata: '',
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
  timeout: 30000,
  maxRetries: 3,
  retryDelay: 1000,
  requestDelay: 1000,
  debug: false,
  region: 'CN',
  defaultHeaders: {
    'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
    'Referer': 'https://www.douyin.com/',
    'Origin': 'https://www.douyin.com',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  },
  endpoints: {
    DOMAIN: 'https://www.douyin.com',
    IES_DOMAIN: 'https://www.iesdouyin.com',
    LIVE_DOMAIN: 'https://live.douyin.com',
    LIVE_DOMAIN2: 'https://webcast.amemv.com',
    SSO_DOMAIN: 'https://sso.douyin.com',
    WEBCAST_WSS_DOMAIN: 'wss://webcast5-ws-web-lf.douyin.com'
  }
};