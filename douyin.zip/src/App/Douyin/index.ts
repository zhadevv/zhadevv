import { Utils } from '../../Utils';
import { DouyinEndpoints } from './endpoint';
import { DouyinUtils } from './utils';
import { DEFAULT_DOUYIN_CONFIG, DouyinConfig } from './config';
import {
  APIResponse,
  UserProfile,
  VideoInfo,
  Comment,
  LiveInfo,
  SearchResult,
  MixInfo,
  Collection,
  PaginationParams,
  SearchOptions,
  DouyinRequestParams,
  NetworkError,
  APIError,
  NotFoundError,
  AuthenticationError
} from '../../Types';

export class Douyin {
  private config: DouyinConfig;
  private utils: typeof Utils;
  private endpoint: typeof DouyinEndpoints;
  private douyinUtils: typeof DouyinUtils;

  constructor(config: Partial<DouyinConfig> = {}) {
    this.config = { ...DEFAULT_DOUYIN_CONFIG, ...config };
    this.utils = Utils;
    this.endpoint = DouyinEndpoints;
    this.douyinUtils = DouyinUtils;
    
    this.utils.initialize(this.config);
  }

  public updateConfig(config: Partial<DouyinConfig>): void {
    this.config = { ...this.config, ...config };
    this.utils.initialize(this.config);
  }

  public getConfig(): DouyinConfig {
    return { ...this.config };
  }

  public async getUserProfile(secUserId: string): Promise<UserProfile> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        sec_user_id: secUserId,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.USER_DETAIL,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapDouyinUser(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError || error instanceof AuthenticationError) {
        throw error;
      }
      throw new APIError('Failed to get user profile', undefined, undefined, error);
    }
  }

  public async getVideoDetail(awemeId: string): Promise<VideoInfo> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        aweme_id: awemeId,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.POST_DETAIL,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapDouyinVideo(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get video detail', undefined, undefined, error);
    }
  }

  public async getUserVideos(
    secUserId: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: number }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        sec_user_id: secUserId,
        max_cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.USER_POST,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.aweme_list || [], 'douyin');
      
      return {
        videos,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.max_cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user videos', undefined, undefined, error);
    }
  }

  public async getUserLikedVideos(
    secUserId: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: number }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        sec_user_id: secUserId,
        max_cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.USER_FAVORITE_A,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.aweme_list || [], 'douyin');
      
      return {
        videos,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.max_cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user liked videos', undefined, undefined, error);
    }
  }

  public async getUserMixVideos(
    mixId: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: number }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        mix_id: mixId,
        cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.MIX_AWEME,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.aweme_list || [], 'douyin');
      
      return {
        videos,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user mix videos', undefined, undefined, error);
    }
  }

  public async getUserCollections(
    pagination: PaginationParams = {}
  ): Promise<{ collections: Collection[]; has_more: boolean; cursor: number }> {
    try {
      if (!this.config.cookie) {
        throw new AuthenticationError('Cookie is required for user collections');
      }

      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.USER_COLLECTION,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.post(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const collections = validatedResponse.collection_list?.map((item: any) => 
        dataMapper.mapDouyinCollection({ collection_info: item })
      ) || [];
      
      return {
        collections,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError || error instanceof AuthenticationError) {
        throw error;
      }
      throw new APIError('Failed to get user collections', undefined, undefined, error);
    }
  }

  public async getVideoComments(
    awemeId: string,
    pagination: PaginationParams = {}
  ): Promise<{ comments: Comment[]; has_more: boolean; cursor: number }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        aweme_id: awemeId,
        cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.POST_COMMENT,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const comments = dataMapper.mapCommentList(validatedResponse.comments || [], 'douyin');
      
      return {
        comments,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get video comments', undefined, undefined, error);
    }
  }

  public async getLiveInfo(webcastId: string): Promise<LiveInfo> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        web_rid: webcastId,
        room_id_str: '',
        aid: '6383',
        app_name: 'douyin_web',
        live_id: 1,
        device_platform: 'web',
        language: 'zh-CN',
        cookie_enabled: 'true',
        enter_source: '',
        is_need_double_stream: 'false',
        msToken: token.msToken
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.LIVE_INFO,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapDouyinLive(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get live info', undefined, undefined, error);
    }
  }

  public async getLiveInfoByRoomId(roomId: string): Promise<LiveInfo> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        verifyFp: token.verifyFp,
        type_id: '0',
        live_id: '1',
        sec_user_id: '',
        version_code: '99.99.99',
        app_id: '1128',
        room_id: roomId,
        msToken: token.msToken
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.LIVE_INFO_ROOM_ID,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapDouyinLive(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get live info by room ID', undefined, undefined, error);
    }
  }

  public async search(options: SearchOptions): Promise<{
    results: SearchResult[];
    has_more: boolean;
    cursor: number;
  }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      let endpoint: string;
      let params: DouyinRequestParams;

      switch (options.search_type) {
        case 'video':
          endpoint = this.endpoint.VIDEO_SEARCH;
          params = this.douyinUtils.generateDouyinParams({
            keyword: options.keyword,
            offset: options.cursor || 0,
            count: options.count || 20,
            sort_type: options.sort_type || 0,
            publish_time: options.publish_time || 0,
            msToken: token.msToken,
            verifyFp: token.verifyFp,
            ttwid: token.ttwid
          });
          break;

        case 'user':
          endpoint = this.endpoint.USER_SEARCH;
          params = this.douyinUtils.generateDouyinParams({
            keyword: options.keyword,
            offset: options.cursor || 0,
            count: options.count || 20,
            msToken: token.msToken,
            verifyFp: token.verifyFp,
            ttwid: token.ttwid
          });
          break;

        case 'live':
          endpoint = this.endpoint.LIVE_SEARCH;
          params = this.douyinUtils.generateDouyinParams({
            keyword: options.keyword,
            offset: options.cursor || 0,
            count: options.count || 20,
            msToken: token.msToken,
            verifyFp: token.verifyFp,
            ttwid: token.ttwid
          });
          break;

        default:
          endpoint = this.endpoint.GENERAL_SEARCH;
          params = this.douyinUtils.generateDouyinParams({
            keyword: options.keyword,
            offset: options.cursor || 0,
            count: options.count || 20,
            sort_type: options.sort_type || 0,
            publish_time: options.publish_time || 0,
            filter_duration: 0,
            msToken: token.msToken,
            verifyFp: token.verifyFp,
            ttwid: token.ttwid
          });
      }

      const signatureResult = await this.douyinUtils.generateSignature(
        endpoint,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const results = validatedResponse.data || [];
      const mappedResults = results.map((item: any) => 
        dataMapper.mapDouyinSearchResult(item)
      );
      
      return {
        results: mappedResults,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to search', undefined, undefined, error);
    }
  }

  public async getHotSearch(): Promise<Array<{
    word: string;
    hot_value: number;
    position: number;
    sentence_id: string;
  }>> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.DOUYIN_HOT_SEARCH,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      return validatedResponse.data?.word_list || [];
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get hot search', undefined, undefined, error);
    }
  }

  public async getSuggestWords(keyword: string): Promise<Array<{
    word: string;
    type: number;
    extra: string;
  }>> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        query: keyword,
        count: 8,
        business_id: '',
        from_group_id: '',
        rsp_source: '',
        penetrate_params: {},
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.SUGGEST_WORDS,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      return validatedResponse.data?.suggest_words || [];
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get suggest words', undefined, undefined, error);
    }
  }

  public async getHomeFeed(pagination: PaginationParams = {}): Promise<{
    videos: VideoInfo[];
    has_more: boolean;
    cursor: number;
  }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('douyin');
      
      const params = this.douyinUtils.generateDouyinParams({
        count: pagination.count || 10,
        msToken: token.msToken,
        verifyFp: token.verifyFp,
        ttwid: token.ttwid
      });

      const signatureResult = await this.douyinUtils.generateSignature(
        this.endpoint.TAB_FEED,
        params,
        true
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.aweme_list || [], 'douyin');
      
      return {
        videos,
        has_more: validatedResponse.has_more || false,
        cursor: validatedResponse.max_cursor || 0
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get home feed', undefined, undefined, error);
    }
  }

  public async extractSecUserId(url: string): Promise<string> {
    return this.douyinUtils.extractSecUserId(url);
  }

  public async extractSecUserIds(urls: string[]): Promise<string[]> {
    return this.douyinUtils.extractSecUserIds(urls);
  }

  public async extractAwemeId(url: string): Promise<string> {
    return this.douyinUtils.extractAwemeId(url);
  }

  public async extractAwemeIds(urls: string[]): Promise<string[]> {
    return this.douyinUtils.extractAwemeIds(urls);
  }

  public async extractWebcastId(url: string): Promise<string> {
    return this.douyinUtils.extractWebcastId(url);
  }

  public async extractWebcastIds(urls: string[]): Promise<string[]> {
    return this.douyinUtils.extractWebcastIds(urls);
  }

  public async extractMixId(url: string): Promise<string> {
    return this.douyinUtils.extractMixId(url);
  }

  public async generateToken(): Promise<{
    msToken: string;
    ttwid: string;
    verifyFp: string;
    s_v_web_id: string;
  }> {
    const tokenManager = this.utils.getTokenManager();
    const token = await tokenManager.getToken('douyin');
    
    return {
      msToken: token.msToken,
      ttwid: token.ttwid,
      verifyFp: token.verifyFp,
      s_v_web_id: token.s_v_web_id
    };
  }

  public async refreshToken(): Promise<void> {
    const tokenManager = this.utils.getTokenManager();
    await tokenManager.refreshToken('douyin');
  }

  public async downloadVideo(
    videoInfo: VideoInfo,
    options?: {
      path?: string;
      filename?: string;
      onProgress?: (progress: {
        total: number;
        downloaded: number;
        percentage: number;
        speed: number;
        estimatedTime: number;
      }) => void;
    }
  ): Promise<string> {
    try {
      const downloadUrl = await this.douyinUtils.getVideoDownloadUrl(videoInfo);
      
      if (!downloadUrl) {
        throw new NotFoundError('Video download URL not found');
      }

      const requestManager = this.utils.getRequestManager();
      const buffer = await requestManager.downloadFile(downloadUrl, {
        onProgress: options?.onProgress
      });

      const helper = this.utils.getHelper();
      const filename = options?.filename || 
        `${videoInfo.aweme_id}_${Date.now()}.mp4`;
      const sanitizedFilename = helper.sanitizeFilename(filename);
      
      const path = options?.path || './downloads';
      const fs = require('fs');
      const pathModule = require('path');

      if (!fs.existsSync(path)) {
        fs.mkdirSync(path, { recursive: true });
      }

      const filePath = pathModule.join(path, sanitizedFilename);
      fs.writeFileSync(filePath, buffer);

      return filePath;
    } catch (error) {
      if (error instanceof NetworkError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to download video', error);
    }
  }

  public async batchDownloadVideos(
    videoInfos: VideoInfo[],
    options?: {
      path?: string;
      concurrency?: number;
      onProgress?: (index: number, total: number, progress: any) => void;
    }
  ): Promise<string[]> {
    const concurrency = options?.concurrency || 3;
    const path = options?.path || './downloads';
    const fs = require('fs');
    
    if (!fs.existsSync(path)) {
      fs.mkdirSync(path, { recursive: true });
    }

    const results: string[] = [];
    const total = videoInfos.length;

    const chunks = this.utils.getHelper().chunkArray(videoInfos, concurrency);

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const promises = chunk.map(async (videoInfo, index) => {
        const absoluteIndex = i * concurrency + index;
        
        try {
          const filePath = await this.downloadVideo(videoInfo, {
            path,
            filename: `${videoInfo.aweme_id}.mp4`
          });
          
          results.push(filePath);
          
          if (options?.onProgress) {
            options.onProgress(absoluteIndex + 1, total, {
              success: true,
              filePath
            });
          }
        } catch (error) {
          if (options?.onProgress) {
            options.onProgress(absoluteIndex + 1, total, {
              success: false,
              error: error instanceof Error ? error.message : 'Unknown error'
            });
          }
        }
      });

      await Promise.all(promises);
    }

    return results;
  }
}