export class DouyinEndpoints {
  public static readonly DOMAIN = "https://www.douyin.com";
  public static readonly IES_DOMAIN = "https://www.iesdouyin.com";
  public static readonly LIVE_DOMAIN = "https://live.douyin.com";
  public static readonly LIVE_DOMAIN2 = "https://webcast.amemv.com";
  public static readonly SSO_DOMAIN = "https://sso.douyin.com";
  public static readonly WEBCAST_WSS_DOMAIN = "wss://webcast5-ws-web-lf.douyin.com";

  public static readonly TAB_FEED = `${this.DOMAIN}/aweme/v1/web/tab/feed/`;
  public static readonly USER_SHORT_INFO = `${this.DOMAIN}/aweme/v1/web/im/user/info/`;
  public static readonly USER_DETAIL = `${this.DOMAIN}/aweme/v1/web/user/profile/other/`;
  public static readonly BASE_AWEME = `${this.DOMAIN}/aweme/v1/web/aweme/`;
  public static readonly USER_POST = `${this.DOMAIN}/aweme/v1/web/aweme/post/`;
  public static readonly LOCATE_POST = `${this.DOMAIN}/aweme/v1/web/locate/post/`;
  public static readonly GENERAL_SEARCH = `${this.DOMAIN}/aweme/v1/web/general/search/single/`;
  public static readonly VIDEO_SEARCH = `${this.DOMAIN}/aweme/v1/web/search/item/`;
  public static readonly USER_SEARCH = `${this.DOMAIN}/aweme/v1/web/discover/search/`;
  public static readonly LIVE_SEARCH = `${this.DOMAIN}/aweme/v1/web/live/search/`;
  public static readonly POST_DETAIL = `${this.DOMAIN}/aweme/v1/web/aweme/detail/`;
  public static readonly POST_DANMAKU = `${this.DOMAIN}/aweme/v1/web/danmaku/get_v2/`;
  public static readonly USER_FAVORITE_A = `${this.DOMAIN}/aweme/v1/web/aweme/favorite/`;
  public static readonly USER_FAVORITE_B = `${this.IES_DOMAIN}/web/api/v2/aweme/like/`;
  public static readonly USER_FOLLOWING = `${this.DOMAIN}/aweme/v1/web/user/following/list/`;
  public static readonly USER_FOLLOWER = `${this.DOMAIN}/aweme/v1/web/user/follower/list/`;
  public static readonly MIX_AWEME = `${this.DOMAIN}/aweme/v1/web/mix/aweme/`;
  public static readonly USER_HISTORY = `${this.DOMAIN}/aweme/v1/web/history/read/`;
  public static readonly USER_COLLECTION = `${this.DOMAIN}/aweme/v1/web/aweme/listcollection/`;
  public static readonly USER_COLLECTS = `${this.DOMAIN}/aweme/v1/web/collects/list/`;
  public static readonly USER_COLLECTS_VIDEO = `${this.DOMAIN}/aweme/v1/web/collects/video/list/`;
  public static readonly USER_MUSIC_COLLECTION = `${this.DOMAIN}/aweme/v1/web/music/listcollection/`;
  public static readonly FRIEND_FEED = `${this.DOMAIN}/aweme/v1/web/familiar/feed/`;
  public static readonly FOLLOW_FEED = `${this.DOMAIN}/aweme/v1/web/follow/feed/`;
  public static readonly POST_RELATED = `${this.DOMAIN}/aweme/v1/web/aweme/related/`;
  public static readonly FOLLOW_USER_LIVE = `${this.DOMAIN}/webcast/web/feed/follow/`;
  public static readonly LIVE_INFO = `${this.LIVE_DOMAIN}/webcast/room/web/enter/`;
  public static readonly LIVE_INFO_ROOM_ID = `${this.LIVE_DOMAIN2}/webcast/room/reflow/info/`;
  public static readonly LIVE_GIFT_RANK = `${this.LIVE_DOMAIN}/webcast/ranklist/audience/`;
  public static readonly LIVE_USER_INFO = `${this.LIVE_DOMAIN}/webcast/user/me/`;
  public static readonly SUGGEST_WORDS = `${this.DOMAIN}/aweme/v1/web/api/suggest_words/`;
  public static readonly SSO_LOGIN_GET_QR = `${this.SSO_DOMAIN}/get_qrcode/`;
  public static readonly SSO_LOGIN_CHECK_QR = `${this.SSO_DOMAIN}/check_qrconnect/`;
  public static readonly SSO_LOGIN_CHECK_LOGIN = `${this.SSO_DOMAIN}/check_login/`;
  public static readonly SSO_LOGIN_REDIRECT = `${this.DOMAIN}/login/`;
  public static readonly SSO_LOGIN_CALLBACK = `${this.DOMAIN}/passport/sso/login/callback/`;
  public static readonly POST_COMMENT = `${this.DOMAIN}/aweme/v1/web/comment/list/`;
  public static readonly POST_COMMENT_REPLY = `${this.DOMAIN}/aweme/v1/web/comment/list/reply/`;
  public static readonly POST_COMMENT_PUBLISH = `${this.DOMAIN}/aweme/v1/web/comment/publish/`;
  public static readonly POST_COMMENT_DELETE = `${this.DOMAIN}/aweme/v1/web/comment/delete/`;
  public static readonly POST_COMMENT_DIGG = `${this.DOMAIN}/aweme/v1/web/comment/digg/`;
  public static readonly DOUYIN_HOT_SEARCH = `${this.DOMAIN}/aweme/v1/web/hot/search/list/`;
  public static readonly DOUYIN_VIDEO_CHANNEL = `${this.DOMAIN}/aweme/v1/web/channel/feed/`;

  public static getEndpoint(name: keyof typeof DouyinEndpoints): string {
    if (name in this) {
      return (this as any)[name];
    }
    throw new Error(`Endpoint ${name} not found`);
  }
}