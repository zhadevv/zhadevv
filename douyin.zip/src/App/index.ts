import { Douyin } from './Douyin';
import { TikTok } from './Tiktok';
import { DouTiksConfig } from '../Types';

export { Douyin, TikTok };

export class Search {
  private douyin: Douyin;
  private tiktok: TikTok;

  constructor(config: DouTiksConfig = {}) {
    this.douyin = new Douyin(config);
    this.tiktok = new TikTok(config);
  }

  public getDouyin(): Douyin {
    return this.douyin;
  }

  public getTikTok(): TikTok {
    return this.tiktok;
  }

  public async searchDouyin(keyword: string, options: {
    search_type?: 'video' | 'user' | 'live' | 'general';
    cursor?: number;
    count?: number;
    sort_type?: number;
    publish_time?: number | string;
  } = {}) {
    return this.douyin.search({
      keyword,
      search_type: options.search_type || 'general',
      cursor: options.cursor,
      count: options.count,
      sort_type: options.sort_type,
      publish_time: options.publish_time
    });
  }

  public async searchTikTok(keyword: string, options: {
    cursor?: number;
    count?: number;
  } = {}) {
    return this.douyin.search({
      keyword,
      search_type: 'video',
      cursor: options.cursor,
      count: options.count
    });
  }
}

export default {
  Douyin,
  TikTok,
  Search
};