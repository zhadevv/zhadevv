import { Utils } from '../../Utils';
import { TikTokEndpoints } from './endpoint';
import { TikTokUtils } from './utils';
import { DEFAULT_TIKTOK_CONFIG, TikTokConfig } from './config';
import {
  APIResponse,
  UserProfile,
  VideoInfo,
  Comment,
  SearchResult,
  MixInfo,
  Collection,
  PaginationParams,
  SearchOptions,
  TikTokRequestParams,
  NetworkError,
  APIError,
  NotFoundError,
  AuthenticationError
} from '../../Types';

export class TikTok {
  private config: TikTokConfig;
  private utils: typeof Utils;
  private endpoint: typeof TikTokEndpoints;
  private tiktokUtils: typeof TikTokUtils;

  constructor(config: Partial<TikTokConfig> = {}) {
    this.config = { ...DEFAULT_TIKTOK_CONFIG, ...config };
    this.utils = Utils;
    this.endpoint = TikTokEndpoints;
    this.tiktokUtils = TikTokUtils;
    
    this.utils.initialize(this.config);
  }

  public updateConfig(config: Partial<TikTokConfig>): void {
    this.config = { ...this.config, ...config };
    this.utils.initialize(this.config);
  }

  public getConfig(): TikTokConfig {
    return { ...this.config };
  }

  public async getUserProfile(secUid: string, uniqueId: string): Promise<UserProfile> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        uniqueId,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_DETAIL,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapTikTokUser(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError || error instanceof AuthenticationError) {
        throw error;
      }
      throw new APIError('Failed to get user profile', undefined, undefined, error);
    }
  }

  public async getVideoDetail(itemId: string): Promise<VideoInfo> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        itemId,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.POST_DETAIL,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      return dataMapper.mapTikTokVideo(validatedResponse);
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get video detail', undefined, undefined, error);
    }
  }

  public async getUserVideos(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        cursor: pagination.cursor || 0,
        count: pagination.count || 35,
        coverFormat: 2,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_POST,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.itemList || [], 'tiktok');
      
      return {
        videos,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user videos', undefined, undefined, error);
    }
  }

  public async getUserLikedVideos(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        cursor: pagination.cursor || 0,
        count: pagination.count || 30,
        coverFormat: 2,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_LIKE,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.itemList || [], 'tiktok');
      
      return {
        videos,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user liked videos', undefined, undefined, error);
    }
  }

  public async getUserCollections(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ collections: Collection[]; has_more: boolean; cursor: string }> {
    try {
      if (!this.config.cookie) {
        throw new AuthenticationError('Cookie is required for user collections');
      }

      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        cursor: pagination.cursor || 0,
        count: pagination.count || 30,
        coverFormat: 2,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_COLLECT,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url, {
        headers: {
          'Cookie': this.config.cookie
        }
      });
      
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const collections = validatedResponse.collectList?.map((item: any) => 
        dataMapper.mapTikTokCollection({ collectionInfo: item })
      ) || [];
      
      return {
        collections,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError || error instanceof AuthenticationError) {
        throw error;
      }
      throw new APIError('Failed to get user collections', undefined, undefined, error);
    }
  }

  public async getUserPlayLists(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ playlists: any[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        cursor: pagination.cursor || 0,
        count: pagination.count || 30,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_PLAY_LIST,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      return {
        playlists: validatedResponse.playList || [],
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user playlists', undefined, undefined, error);
    }
  }

  public async getUserMixVideos(
    mixId: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        mixId,
        cursor: pagination.cursor || 0,
        count: pagination.count || 30,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_MIX,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.itemList || [], 'tiktok');
      
      return {
        videos,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user mix videos', undefined, undefined, error);
    }
  }

  public async getVideoComments(
    awemeId: string,
    pagination: PaginationParams = {}
  ): Promise<{ comments: Comment[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        aweme_id: awemeId,
        cursor: pagination.cursor || 0,
        count: pagination.count || 20,
        current_region: this.config.region || 'US',
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.POST_COMMENT,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const comments = dataMapper.mapCommentList(validatedResponse.comments || [], 'tiktok');
      
      return {
        comments,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get video comments', undefined, undefined, error);
    }
  }

  public async getRelatedVideos(
    awemeId: string,
    pagination: PaginationParams = {}
  ): Promise<{ videos: VideoInfo[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        itemId: awemeId,
        cursor: pagination.cursor || 0,
        count: pagination.count || 30,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.GUESS_YOU_LIKE,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.itemList || [], 'tiktok');
      
      return {
        videos,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get related videos', undefined, undefined, error);
    }
  }

  public async getUserFollowers(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ users: UserProfile[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        count: pagination.count || 30,
        maxCursor: pagination.max_cursor || 0,
        minCursor: pagination.min_cursor || 0,
        scene: 67,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_FANS,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const users = dataMapper.mapUserList(validatedResponse.userList || [], 'tiktok');
      
      return {
        users,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user followers', undefined, undefined, error);
    }
  }

  public async getUserFollowing(
    secUid: string,
    pagination: PaginationParams = {}
  ): Promise<{ users: UserProfile[]; has_more: boolean; cursor: string }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        secUid,
        count: pagination.count || 30,
        maxCursor: pagination.max_cursor || 0,
        minCursor: pagination.min_cursor || 0,
        scene: 21,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.USER_FOLLOW,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const users = dataMapper.mapUserList(validatedResponse.userList || [], 'tiktok');
      
      return {
        users,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get user following', undefined, undefined, error);
    }
  }

  public async getHomeFeed(pagination: PaginationParams = {}): Promise<{
    videos: VideoInfo[];
    has_more: boolean;
    cursor: string;
  }> {
    try {
      const tokenManager = this.utils.getTokenManager();
      const token = await tokenManager.getToken('tiktok');
      
      const params = this.tiktokUtils.generateTikTokParams({
        count: pagination.count || 30,
        cursor: pagination.cursor || 0,
        msToken: token.msToken
      });

      const signatureResult = await this.tiktokUtils.generateSignature(
        this.endpoint.HOME_RECOMMEND,
        params
      );

      const requestManager = this.utils.getRequestManager();
      const response = await requestManager.get(signatureResult.url);
      const validatedResponse = await requestManager.validateResponse(response);
      
      const dataMapper = this.utils.getDataMapper();
      const videos = dataMapper.mapVideoList(validatedResponse.itemList || [], 'tiktok');
      
      return {
        videos,
        has_more: validatedResponse.hasMore || false,
        cursor: validatedResponse.cursor || '0'
      };
    } catch (error) {
      if (error instanceof APIError || error instanceof NetworkError) {
        throw error;
      }
      throw new APIError('Failed to get home feed', undefined, undefined, error);
    }
  }

  public async extractSecUid(url: string): Promise<string> {
    return this.tiktokUtils.extractSecUid(url);
  }

  public async extractSecUids(urls: string[]): Promise<string[]> {
    return this.tiktokUtils.extractSecUids(urls);
  }

  public async extractUniqueId(url: string): Promise<string> {
    return this.tiktokUtils.extractUniqueId(url);
  }

  public async extractUniqueIds(urls: string[]): Promise<string[]> {
    return this.tiktokUtils.extractUniqueIds(urls);
  }

  public async extractAwemeId(url: string): Promise<string> {
    return this.tiktokUtils.extractAwemeId(url);
  }

  public async extractAwemeIds(urls: string[]): Promise<string[]> {
    return this.tiktokUtils.extractAwemeIds(urls);
  }

  public async generateToken(): Promise<{
    msToken: string;
    ttwid: string;
    odin_tt?: string;
    verifyFp: string;
    s_v_web_id: string;
  }> {
    const tokenManager = this.utils.getTokenManager();
    const token = await tokenManager.getToken('tiktok');
    
    return {
      msToken: token.msToken,
      ttwid: token.ttwid,
      odin_tt: token.odin_tt,
      verifyFp: token.verifyFp,
      s_v_web_id: token.s_v_web_id
    };
  }

  public async refreshToken(): Promise<void> {
    const tokenManager = this.utils.getTokenManager();
    await tokenManager.refreshToken('tiktok');
  }

  public async downloadVideo(
    videoInfo: VideoInfo,
    options?: {
      path?: string;
      filename?: string;
      onProgress?: (progress: {
        total: number;
        downloaded: number;
        percentage: number;
        speed: number;
        estimatedTime: number;
      }) => void;
    }
  ): Promise<string> {
    try {
      const downloadUrl = await this.tiktokUtils.getVideoDownloadUrl(videoInfo);
      
      if (!downloadUrl) {
        throw new NotFoundError('Video download URL not found');
      }

      const requestManager = this.utils.getRequestManager();
      const buffer = await requestManager.downloadFile(downloadUrl, {
        onProgress: options?.onProgress
      });

      const helper = this.utils.getHelper();
      const filename = options?.filename || 
        `${videoInfo.aweme_id}_${Date.now()}.mp4`;
      const sanitizedFilename = helper.sanitizeFilename(filename);
      
      const path = options?.path || './downloads';
      const fs = require('fs');
      const pathModule = require('path');

      if (!fs.existsSync(path)) {
        fs.mkdirSync(path, { recursive: true });
      }

      const filePath = pathModule.join(path, sanitizedFilename);
      fs.writeFileSync(filePath, buffer);

      return filePath;
    } catch (error) {
      if (error instanceof NetworkError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to download video', error);
    }
  }

  public async batchDownloadVideos(
    videoInfos: VideoInfo[],
    options?: {
      path?: string;
      concurrency?: number;
      onProgress?: (index: number, total: number, progress: any) => void;
    }
  ): Promise<string[]> {
    const concurrency = options?.concurrency || 3;
    const path = options?.path || './downloads';
    const fs = require('fs');
    
    if (!fs.existsSync(path)) {
      fs.mkdirSync(path, { recursive: true });
    }

    const results: string[] = [];
    const total = videoInfos.length;

    const chunks = this.utils.getHelper().chunkArray(videoInfos, concurrency);

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const promises = chunk.map(async (videoInfo, index) => {
        const absoluteIndex = i * concurrency + index;
        
        try {
          const filePath = await this.downloadVideo(videoInfo, {
            path,
            filename: `${videoInfo.aweme_id}.mp4`
          });
          
          results.push(filePath);
          
          if (options?.onProgress) {
            options.onProgress(absoluteIndex + 1, total, {
              success: true,
              filePath
            });
          }
        } catch (error) {
          if (options?.onProgress) {
            options.onProgress(absoluteIndex + 1, total, {
              success: false,
              error: error instanceof Error ? error.message : 'Unknown error'
            });
          }
        }
      });

      await Promise.all(promises);
    }

    return results;
  }
}