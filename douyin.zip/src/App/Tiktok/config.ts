import { DouTiksConfig, Region } from '../../Types';

export interface TikTokConfig extends DouTiksConfig {
  region?: Region;
  defaultHeaders?: Record<string, string>;
  endpoints?: Record<string, string>;
}

export const DEFAULT_TIKTOK_CONFIG: TikTokConfig = {
  cookie: '',
  strdata: '',
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
  timeout: 30000,
  maxRetries: 3,
  retryDelay: 1000,
  requestDelay: 1000,
  debug: false,
  region: 'US',
  defaultHeaders: {
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': 'https://www.tiktok.com/',
    'Origin': 'https://www.tiktok.com',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  },
  endpoints: {
    DOMAIN: 'https://www.tiktok.com',
    WEBCAST_DOMAIN: 'https://webcast.tiktok.com'
  }
};