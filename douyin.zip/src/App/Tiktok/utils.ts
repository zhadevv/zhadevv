import { URL } from 'url';
import { Utils } from '../../Utils';
import {
  TikTokRequestParams,
  NetworkError,
  NotFoundError,
  APIError,
  ParseError
} from '../../Types';

export class TikTokUtils {
  private static readonly TIKTOK_SECUID_PATTERN = 
    /<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application\/json">(.*?)<\/script>/;
  private static readonly TIKTOK_UNIQUEID_PATTERN = /@([^/?]*)/;
  private static readonly TIKTOK_NOTFOUND_PATTERN = /notfound/;
  private static readonly TIKTOK_AWEMEID_PATTERN = /video\/(\d+)/;
  private static readonly TIKTOK_PHOTOID_PATTERN = /photo\/(\d+)/;

  public static async extractSecUid(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const responseText = typeof response.data === 'string' 
        ? response.data 
        : JSON.stringify(response.data);

      if (this.TIKTOK_NOTFOUND_PATTERN.test(responseText)) {
        throw new NotFoundError('Page not found or region restricted');
      }

      const match = this.TIKTOK_SECUID_PATTERN.exec(responseText);
      if (!match || !match[1]) {
        throw new NotFoundError('secUid not found in page');
      }

      try {
        const data = JSON.parse(match[1]);
        const defaultScope = data?.__DEFAULT_SCOPE__ || {};
        const userDetail = defaultScope['webapp.user-detail'] || {};
        const userInfo = userDetail?.userInfo?.user || {};
        const secUid = userInfo?.secUid;

        if (!secUid) {
          throw new NotFoundError('secUid not found in JSON data');
        }

        return secUid;
      } catch (parseError) {
        throw new ParseError('Failed to parse JSON data', parseError);
      }
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError || error instanceof ParseError) {
        throw error;
      }
      throw new NetworkError('Failed to extract secUid', error);
    }
  }

  public static async extractSecUids(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractSecUid(url))
    );

    const secUids: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        secUids.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract secUid from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (secUids.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any secUid', errors[0]);
    }

    return secUids;
  }

  public static async extractUniqueId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      
      if (this.TIKTOK_NOTFOUND_PATTERN.test(finalUrl || '')) {
        throw new NotFoundError('Page not found or region restricted');
      }

      const match = this.TIKTOK_UNIQUEID_PATTERN.exec(finalUrl || '');
      if (!match || !match[1]) {
        throw new NotFoundError('uniqueId not found in URL');
      }

      return match[1];
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract uniqueId', error);
    }
  }

  public static async extractUniqueIds(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractUniqueId(url))
    );

    const uniqueIds: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        uniqueIds.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract uniqueId from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (uniqueIds.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any uniqueId', errors[0]);
    }

    return uniqueIds;
  }

  public static async extractAwemeId(url: string): Promise<string> {
    try {
      const helper = Utils.getHelper();
      const validUrl = helper.extractValidUrls([url])[0];
      
      if (!validUrl) {
        throw new NotFoundError('Invalid URL');
      }

      if (url.includes('@') && url.includes('tiktok.com')) {
        let match = this.TIKTOK_AWEMEID_PATTERN.exec(url);
        if (match && match[1]) {
          return match[1];
        }

        match = this.TIKTOK_PHOTOID_PATTERN.exec(url);
        if (match && match[1]) {
          return match[1];
        }

        throw new NotFoundError('aweme_id not found in direct URL');
      }

      const requestManager = Utils.getRequestManager();
      const response = await requestManager.get(validUrl, {
        maxRedirects: 5,
        followRedirect: true
      });

      if (response.status !== 200) {
        throw new APIError(`HTTP ${response.status}`, response.status);
      }

      const finalUrl = response.request?.res?.responseUrl || response.config.url;
      
      if (this.TIKTOK_NOTFOUND_PATTERN.test(finalUrl || '')) {
        throw new NotFoundError('Page not found or region restricted');
      }

      let match = this.TIKTOK_AWEMEID_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      match = this.TIKTOK_PHOTOID_PATTERN.exec(finalUrl || '');
      if (match && match[1]) {
        return match[1];
      }

      throw new NotFoundError('aweme_id not found in URL');
    } catch (error) {
      if (error instanceof NetworkError || error instanceof APIError || error instanceof NotFoundError) {
        throw error;
      }
      throw new NetworkError('Failed to extract aweme_id', error);
    }
  }

  public static async extractAwemeIds(urls: string[]): Promise<string[]> {
    const helper = Utils.getHelper();
    const validUrls = helper.extractValidUrls(urls);
    
    if (validUrls.length === 0) {
      throw new NotFoundError('No valid URLs provided');
    }

    const results = await Promise.allSettled(
      validUrls.map(url => this.extractAwemeId(url))
    );

    const awemeIds: string[] = [];
    const errors: Error[] = [];

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        awemeIds.push(result.value);
      } else {
        errors.push(new Error(`Failed to extract aweme_id from ${validUrls[index]}: ${result.reason}`));
      }
    });

    if (awemeIds.length === 0 && errors.length > 0) {
      throw new NetworkError('Failed to extract any aweme_id', errors[0]);
    }

    return awemeIds;
  }

  public static generateTikTokParams(overrides: Partial<TikTokRequestParams> = {}): TikTokRequestParams {
    const requestManager = Utils.getRequestManager();
    return requestManager.generateTikTokParams(overrides);
  }

  public static validateTikTokResponse(response: any): boolean {
    if (!response) return false;
    
    if (response.statusCode !== undefined && response.statusCode !== 0) {
      return false;
    }
    
    if (response.status_code !== undefined && response.status_code !== 0) {
      return false;
    }
    
    if ((response.statusCode === 0 || response.status_code === 0) && response.itemList !== undefined) {
      return true;
    }
    
    if ((response.statusCode === 0 || response.status_code === 0) && response.itemInfo !== undefined) {
      return true;
    }
    
    if ((response.statusCode === 0 || response.status_code === 0) && response.userInfo !== undefined) {
      return true;
    }
    
    return false;
  }

  public static parseTikTokResponse<T>(response: any): T {
    if (!this.validateTikTokResponse(response)) {
      throw new ParseError('Invalid TikTok response format');
    }

    if (response.itemList !== undefined) {
      return response.itemList as T;
    }

    if (response.itemInfo !== undefined) {
      return response.itemInfo as T;
    }

    if (response.userInfo !== undefined) {
      return response.userInfo as T;
    }

    return response as T;
  }

  public static formatVideoUrl(videoId: string): string {
    return `https://www.tiktok.com/@tiktok/video/${videoId}`;
  }

  public static formatUserUrl(uniqueId: string): string {
    return `https://www.tiktok.com/@${uniqueId}`;
  }

  public static async generateSignature(
    endpoint: string,
    params: TikTokRequestParams
  ): Promise<{ url: string; signature: string }> {
    const signatureManager = Utils.getSignatureManager();
    const queryString = Utils.buildQueryString(params);
    const fullUrl = `${endpoint}${queryString}`;
    const result = signatureManager.generateXBogus(fullUrl);
    
    return {
      url: result.params,
      signature: result.signature
    };
  }

  public static async checkVideoExists(videoId: string): Promise<boolean> {
    try {
      const requestManager = Utils.getRequestManager();
      const url = this.formatVideoUrl(videoId);
      
      const response = await requestManager.head(url, {
        timeout: 10000
      });

      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  public static async checkUserExists(uniqueId: string): Promise<boolean> {
    try {
      const requestManager = Utils.getRequestManager();
      const url = this.formatUserUrl(uniqueId);
      
      const response = await requestManager.head(url, {
        timeout: 10000
      });

      return response.status === 200;
    } catch (error) {
      return false;
    }
  }

  public static sanitizeDescription(desc: string, maxLength = 200): string {
    if (!desc) return '';
    
    let sanitized = desc
      .replace(/[\r\n]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    if (sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength) + '...';
    }
    
    return sanitized;
  }

  public static extractHashtags(desc: string): string[] {
    if (!desc) return [];
    
    const hashtagRegex = /#([^#\s]+)/g;
    const matches = desc.match(hashtagRegex) || [];
    
    return matches.map(tag => tag.substring(1));
  }

  public static extractMentions(desc: string): string[] {
    if (!desc) return [];
    
    const mentionRegex = /@([^@\s]+)/g;
    const matches = desc.match(mentionRegex) || [];
    
    return matches.map(mention => mention.substring(1));
  }

  public static calculateVideoQuality(videoInfo: any): {
    quality: string;
    resolution: string;
    bitrate: number;
  } {
    const width = videoInfo?.width || 0;
    const height = videoInfo?.height || 0;
    const bitrate = videoInfo?.bitrate || 0;

    let quality = 'SD';
    let resolution = `${width}x${height}`;

    if (height >= 1080) {
      quality = 'FHD';
    } else if (height >= 720) {
      quality = 'HD';
    } else if (height >= 480) {
      quality = 'SD';
    } else {
      quality = 'LD';
    }

    return {
      quality,
      resolution,
      bitrate
    };
  }

  public static async getVideoDownloadUrl(videoInfo: any): Promise<string | null> {
    try {
      if (!videoInfo?.video?.downloadAddr) {
        return null;
      }

      const downloadAddr = videoInfo.video.downloadAddr;
      if (typeof downloadAddr !== 'string' || downloadAddr.trim() === '') {
        return null;
      }

      return downloadAddr;
    } catch (error) {
      return null;
    }
  }

  public static getVideoPlayUrl(videoInfo: any): string | null {
    try {
      if (!videoInfo?.video?.playAddr) {
        return null;
      }

      const playAddr = videoInfo.video.playAddr;
      if (typeof playAddr !== 'string' || playAddr.trim() === '') {
        return null;
      }

      return playAddr;
    } catch (error) {
      return null;
    }
  }
}