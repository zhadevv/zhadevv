export class TikTokEndpoints {
  public static readonly DOMAIN = "https://www.tiktok.com";
  public static readonly WEBCAST_DOMAIN = "https://webcast.tiktok.com";

  public static readonly LOGIN_ENDPOINT = `${this.DOMAIN}/login/`;
  public static readonly HOME_RECOMMEND = `${this.DOMAIN}/api/recommend/item_list/`;
  public static readonly USER_DETAIL = `${this.DOMAIN}/api/user/detail/`;
  public static readonly USER_POST = `${this.DOMAIN}/api/post/item_list/`;
  public static readonly USER_LIKE = `${this.DOMAIN}/api/favorite/item_list/`;
  public static readonly USER_COLLECT = `${this.DOMAIN}/api/user/collect/item_list/`;
  public static readonly USER_PLAY_LIST = `${this.DOMAIN}/api/user/playlist/`;
  public static readonly USER_MIX = `${this.DOMAIN}/api/mix/item_list/`;
  public static readonly GUESS_YOU_LIKE = `${this.DOMAIN}/api/related/item_list/`;
  public static readonly USER_FOLLOW = `${this.DOMAIN}/api/user/list/`;
  public static readonly USER_FANS = `${this.DOMAIN}/api/user/list/`;
  public static readonly POST_DETAIL = `${this.DOMAIN}/api/item/detail/`;
  public static readonly POST_COMMENT = `${this.DOMAIN}/api/comment/list/`;
  public static readonly POST_COMMENT_REPLY = `${this.DOMAIN}/api/comment/list/reply/`;

  public static getEndpoint(name: keyof typeof TikTokEndpoints): string {
    if (name in this) {
      return (this as any)[name];
    }
    throw new Error(`Endpoint ${name} not found`);
  }
}