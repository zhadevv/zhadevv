import Database from 'better-sqlite3';
import path from 'path';

const dbPath = process.env.DATABASE_URL || path.join(process.cwd(), 'src/data/anidong.db');

let dbInstance: Database.Database | null = null;

export const getDb = (): Database.Database => {
  if (!dbInstance) {
    dbInstance = new Database(dbPath, { verbose: process.env.NODE_ENV === 'development' ? console.log : undefined });
    dbInstance.pragma('journal_mode = WAL');
    initializeTables(dbInstance);
  }
  return dbInstance;
};

const initializeTables = (db: Database.Database) => {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      avatar TEXT DEFAULT 'https://i.pravatar.cc/150?img=12',
      role TEXT DEFAULT 'user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bookmarks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      slug TEXT NOT NULL,
      title TEXT NOT NULL,
      thumbnail TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      UNIQUE(user_id, slug)
    );

    CREATE TABLE IF NOT EXISTS history (
      user_id INTEGER,
      slug TEXT NOT NULL,
      episode TEXT NOT NULL,
      title TEXT,
      thumbnail TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, slug),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      slug TEXT NOT NULL,
      episode TEXT,
      content TEXT NOT NULL,
      parent_id INTEGER DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS ads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      image_url TEXT NOT NULL,
      link_url TEXT NOT NULL,
      position TEXT NOT NULL, -- header, sidebar, footer, banner
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
  
  // Migration for parent_id if it doesn't exist (for existing DBs)
  try {
    db.exec("ALTER TABLE comments ADD COLUMN parent_id INTEGER DEFAULT NULL");
  } catch (e) {
    // Column likely exists
  }

  const stmt = db.prepare('SELECT count(*) as count FROM settings');
  const result = stmt.get() as { count: number };
  
  if (result.count === 0) {
     const insert = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
     insert.run('site_name', 'Anidong');
     insert.run('maintenance_mode', 'false');
  }
};

// --- User Helpers ---
export const createUser = (username: string, email: string, passwordHash: string) => {
  const db = getDb();
  try {
    const stmt = db.prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    const info = stmt.run(username, email, passwordHash);
    return { id: info.lastInsertRowid, username, email };
  } catch (error: any) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      throw new Error('Username or email already exists');
    }
    throw error;
  }
};

export const findUserByEmail = (email: string) => {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
  return stmt.get(email) as any;
};

export const findUserById = (id: number) => {
  const db = getDb();
  const stmt = db.prepare('SELECT id, username, email, avatar, role, created_at FROM users WHERE id = ?');
  return stmt.get(id) as any;
};

export const getAllUsers = () => {
    const db = getDb();
    const stmt = db.prepare('SELECT id, username, email, avatar, role, created_at FROM users ORDER BY created_at DESC');
    return stmt.all();
};

export const deleteUser = (id: number) => {
    const db = getDb();
    const stmt = db.prepare('DELETE FROM users WHERE id = ?');
    return stmt.run(id);
};

export const updateUserProfile = (id: number, avatar: string, password?: string) => {
    const db = getDb();
    if (password) {
        const stmt = db.prepare('UPDATE users SET avatar = ?, password = ? WHERE id = ?');
        return stmt.run(avatar, password, id);
    } else {
        const stmt = db.prepare('UPDATE users SET avatar = ? WHERE id = ?');
        return stmt.run(avatar, id);
    }
};

// --- Bookmark Helpers ---
export const addBookmark = (userId: number, slug: string, title: string, thumbnail: string) => {
  const db = getDb();
  try {
    const stmt = db.prepare('INSERT INTO bookmarks (user_id, slug, title, thumbnail) VALUES (?, ?, ?, ?)');
    stmt.run(userId, slug, title, thumbnail);
    return true;
  } catch (error: any) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return false; // Already bookmarked
    throw error;
  }
};

export const removeBookmark = (userId: number, slug: string) => {
  const db = getDb();
  const stmt = db.prepare('DELETE FROM bookmarks WHERE user_id = ? AND slug = ?');
  const info = stmt.run(userId, slug);
  return info.changes > 0;
};

export const getBookmarks = (userId: number) => {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC');
  return stmt.all(userId);
};

export const checkBookmark = (userId: number, slug: string) => {
  const db = getDb();
  const stmt = db.prepare('SELECT 1 FROM bookmarks WHERE user_id = ? AND slug = ?');
  return !!stmt.get(userId, slug);
};

// --- History Helpers ---
export const updateHistory = (userId: number, slug: string, episode: string, title: string, thumbnail: string) => {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO history (user_id, slug, episode, title, thumbnail, updated_at) 
    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id, slug) DO UPDATE SET
      episode = excluded.episode,
      title = excluded.title,
      thumbnail = excluded.thumbnail,
      updated_at = CURRENT_TIMESTAMP
  `);
  stmt.run(userId, slug, episode, title, thumbnail);
};

export const getHistory = (userId: number) => {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM history WHERE user_id = ? ORDER BY updated_at DESC LIMIT 50');
  return stmt.all(userId);
};

// --- Comment Helpers ---
export const addComment = (userId: number, slug: string, episode: string | null, content: string, parentId: number | null = null) => {
  const db = getDb();
  const stmt = db.prepare('INSERT INTO comments (user_id, slug, episode, content, parent_id) VALUES (?, ?, ?, ?, ?)');
  const info = stmt.run(userId, slug, episode, content, parentId);
  
  const getStmt = db.prepare(`
    SELECT c.*, u.username, u.avatar 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.id = ?
  `);
  return getStmt.get(info.lastInsertRowid);
};

export const getComments = (slug: string) => {
  const db = getDb();
  // Fetch all comments for slug, ordered by creation
  const stmt = db.prepare(`
    SELECT c.*, u.username, u.avatar 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.slug = ? 
    ORDER BY c.created_at ASC
  `);
  const rows = stmt.all(slug);
  
  // Build nested structure in Javascript
  const commentMap = new Map();
  const roots: any[] = [];

  rows.forEach((row: any) => {
    row.replies = [];
    commentMap.set(row.id, row);
  });

  rows.forEach((row: any) => {
    if (row.parent_id) {
      const parent = commentMap.get(row.parent_id);
      if (parent) {
        parent.replies.push(row);
      } else {
         // Parent deleted or missing, treat as root or orphan (adding to root for visibility)
         roots.push(row);
      }
    } else {
      roots.push(row);
    }
  });

  // Reverse roots to show newest first
  return roots.reverse();
};

// --- Ads Helpers ---
export const getActiveAds = () => {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM ads WHERE active = 1');
  return stmt.all();
};

export const getAllAds = () => {
  const db = getDb();
  const stmt = db.prepare('SELECT * FROM ads ORDER BY created_at DESC');
  return stmt.all();
};

export const createAd = (title: string, imageUrl: string, linkUrl: string, position: string) => {
  const db = getDb();
  const stmt = db.prepare('INSERT INTO ads (title, image_url, link_url, position) VALUES (?, ?, ?, ?)');
  return stmt.run(title, imageUrl, linkUrl, position);
};

export const updateAd = (id: number, title: string, imageUrl: string, linkUrl: string, position: string, active: number) => {
  const db = getDb();
  const stmt = db.prepare('UPDATE ads SET title = ?, image_url = ?, link_url = ?, position = ?, active = ? WHERE id = ?');
  return stmt.run(title, imageUrl, linkUrl, position, active, id);
};

export const deleteAd = (id: number) => {
  const db = getDb();
  const stmt = db.prepare('DELETE FROM ads WHERE id = ?');
  return stmt.run(id);
};

// --- Admin Stats Helper ---
export const getSystemStats = () => {
    const db = getDb();
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as {count: number};
    const adsCount = db.prepare('SELECT COUNT(*) as count FROM ads WHERE active = 1').get() as {count: number};
    const historyCount = db.prepare('SELECT COUNT(*) as count FROM history').get() as {count: number};
    
    return {
        users: userCount.count,
        active_ads: adsCount.count,
        total_plays: historyCount.count
    };
};

export default getDb;