export interface Donghua {
  title: string;
  slug: string;
  thumbnail: string;
  episode?: string;
  type?: string;
  badge?: string;
  url: string;
  description?: string;
  rating?: string;
  genres?: string[];
  release_date?: string;
  countdown?: {
    raw: string;
    formatted: string;
  };
  release_time?: {
    raw: string;
    formatted: string;
  };
  current_episode?: string;
}

export interface SlideItem extends Donghua {
  description: string;
}

export interface Pagination {
  previous: string;
  current_page: string;
  next: string;
}

export interface HomeData {
  slider: SlideItem[];
  popular_today: Donghua[];
  latest_release: Donghua[];
  ongoing_series: Donghua[];
  popular_series: {
    weekly: Donghua[];
    monthly: Donghua[];
    all_time: Donghua[];
  };
  new_movie?: Donghua[];
}

export interface DonghuaDetail {
  slug: string;
  title: string;
  alter_title: string;
  synopsis: string;
  cover: {
    banner: string;
    thumbnail: string;
  };
  information: {
    status: string;
    network: string;
    studio: string;
    released: string;
    duration: string;
    season: string;
    country: string;
    type: string;
    episode: string;
  };
  genre: Array<{
    title_genre: string;
    slug: string;
    url: string;
  }>;
  episode_list: Array<{
    number: string;
    title: string;
    slug: string;
    released_on: string;
    url: string;
  }>;
}

export interface WatchData {
  title: string;
  slug: string;
  thumbnail?: string;
  episode: string;
  server: Array<{
    server_id: string;
    server_name: string;
    server_url: string;
  }>;
  pagination: {
    prev_episode: string;
    all_episode: string;
    next_episode: string;
  };
}

export interface ScheduleDay {
  list: Donghua[];
}

export interface ScheduleData {
  monday: ScheduleDay;
  tuesday: ScheduleDay;
  wednesday: ScheduleDay;
  thursday: ScheduleDay;
  friday: ScheduleDay;
  saturday: ScheduleDay;
  sunday: ScheduleDay;
  [key: string]: ScheduleDay; // index signature
}

export interface ListingData {
  items: Donghua[];
  pagination: Pagination;
  genre_title?: string;
}

export interface FilterOption {
  value: string;
  label: string;
  count: string;
}

export interface FilterOptionsData {
  status: FilterOption[];
  type: FilterOption[];
  sub: FilterOption[];
  order: FilterOption[];
  studio: FilterOption[];
  season: FilterOption[];
  genre: FilterOption[];
}

export interface RandomData {
  random_selection: {
    total_available: number;
    selected_from: string;
  };
  cover: {
    banner: string;
    thumbnail: string;
  };
  slug: string;
  title: string;
  alter_title: string;
  synopsis: string;
  information: any;
  genre: any[];
  episode: {
    list: any[];
  };
}

export interface Ad {
  id: number;
  title: string;
  image_url: string;
  link_url: string;
  position: 'header' | 'sidebar' | 'footer' | 'banner';
  active: number;
  created_at: string;
}

export interface ApiResponse<T> {
  status: number;
  success: boolean;
  author: string;
  data: T;
  message: string | null;
}