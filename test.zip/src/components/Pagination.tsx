import React from 'react';
import Link from 'next/link';
import { BiChevronLeft, BiChevronRight } from 'react-icons/bi';
import { extractPageNumber } from '../services/api';
import { Pagination as PaginationType } from '../types';

interface PaginationProps {
  data: PaginationType;
  baseUrl: string;
  queryParams?: Record<string, string>;
}

const Pagination: React.FC<PaginationProps> = ({ data, baseUrl, queryParams = {} }) => {
  const prevPage = extractPageNumber(data.previous);
  const nextPage = extractPageNumber(data.next);

  const buildUrl = (page: number) => {
    const params = new URLSearchParams(queryParams);
    params.set('page', page.toString());
    // If baseUrl already has query params logic handled in page, we might just append. 
    // Simplified for this architecture:
    if (baseUrl.includes('?')) {
      return `${baseUrl}&page=${page}`;
    }
    return `${baseUrl}?page=${page}`;
  };

  if (!prevPage && !nextPage) return null;

  return (
    <div className="flex justify-center gap-2 mt-8">
      {prevPage && (
        <Link 
          href={buildUrl(prevPage)}
          className="flex items-center gap-1 bg-white dark:bg-gray-800 px-4 py-2 rounded-lg hover:bg-primary hover:text-white transition-colors"
        >
          <BiChevronLeft /> Previous
        </Link>
      )}
      
      <span className="bg-primary text-white px-4 py-2 rounded-lg font-bold">
        {data.current_page}
      </span>

      {nextPage && (
        <Link 
          href={buildUrl(nextPage)}
          className="flex items-center gap-1 bg-white dark:bg-gray-800 px-4 py-2 rounded-lg hover:bg-primary hover:text-white transition-colors"
        >
          Next <BiChevronRight />
        </Link>
      )}
    </div>
  );
};

export default Pagination;