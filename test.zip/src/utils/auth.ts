import jwt from 'jsonwebtoken';
import type { NextApiRequest, NextApiResponse } from 'next';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_key_change_me';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;

export type AuthenticatedRequest = NextApiRequest & {
  user?: {
    userId: number;
    email: string;
    role: string;
    isAdmin: boolean;
  };
}

export const authenticate = (handler: (req: AuthenticatedRequest, res: NextApiResponse) => Promise<void> | void, requireAdmin: boolean = false) => {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const token = authHeader.split(' ')[1];

    try {
      const decoded: any = jwt.verify(token, JWT_SECRET);
      const isAdmin = !!(ADMIN_EMAIL && decoded.email === ADMIN_EMAIL);

      if (requireAdmin && !isAdmin) {
        return res.status(403).json({ message: 'Forbidden: Admins only' });
      }

      (req as AuthenticatedRequest).user = {
        ...decoded,
        isAdmin
      };
      
      return handler(req as AuthenticatedRequest, res);
    } catch (error) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }
  };
};