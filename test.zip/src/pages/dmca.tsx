import Head from 'next/head';

export default function DMCA() {
  return (
    <div style={{ gridArea: 'main' }} className="max-w-4xl mx-auto p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm my-8">
      <Head>
        <title>DMCA - Anidong</title>
      </Head>
      <h1 className="text-3xl font-bold mb-6 border-b pb-4 border-gray-200 dark:border-gray-700">DMCA</h1>
      
      <div className="prose dark:prose-invert max-w-none space-y-4 text-sm md:text-base">
        <p>Anidong respects the intellectual property rights of others. We comply with the Digital Millennium Copyright Act (DMCA) and other applicable copyright laws.</p>
        
        <h3 className="text-xl font-bold mt-6">Copyright Infringement Notification</h3>
        <p>If you believe that your work has been copied in a way that constitutes copyright infringement, please provide us with the following information:</p>
        <ul className="list-disc pl-5 space-y-2">
            <li>A physical or electronic signature of the copyright owner or a person authorized to act on their behalf.</li>
            <li>Identification of the copyrighted work claimed to have been infringed.</li>
            <li>Identification of the material that is claimed to be infringing or to be the subject of infringing activity and that is to be removed or access to which is to be disabled.</li>
            <li>Information reasonably sufficient to permit us to contact you, such as an email address.</li>
        </ul>
        
        <p className="mt-6">Please send all DMCA takedown requests to: <strong>legal@anidong.my.id</strong></p>
      </div>
    </div>
  );
}