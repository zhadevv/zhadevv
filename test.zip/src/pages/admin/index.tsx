import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import axios from 'axios';
import { BiShield, BiDollarCircle, BiUser, BiBarChart } from 'react-icons/bi';

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState({ users: 0, active_ads: 0, total_plays: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
        const token = localStorage.getItem('token');
        if (!token) {
            router.push('/login');
            return;
        }

        try {
            const res = await axios.get('/api/admin/stats', {
                headers: { Authorization: `Bearer ${token}` }
            });
            setStats(res.data.stats);
        } catch (error) {
            console.error('Failed to load admin stats');
            router.push('/');
        } finally {
            setLoading(false);
        }
    };

    fetchStats();
  }, [router]);

  const statCards = [
    { title: 'Total Users', count: stats.users, icon: <BiUser />, color: 'bg-blue-500' },
    { title: 'Active Ads', count: stats.active_ads, icon: <BiDollarCircle />, color: 'bg-green-500' },
    { title: 'Total Plays', count: stats.total_plays, icon: <BiBarChart />, color: 'bg-purple-500' },
  ];

  if (loading) return <div className="p-10 text-center">Loading Admin Panel...</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-6">
      <Head>
        <title>Admin Dashboard - Anidong</title>
      </Head>

      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <BiShield className="text-red-500" /> Admin Dashboard
        </h1>
        <div className="flex gap-4">
           <Link href="/admin/users" className="bg-gray-800 text-white px-4 py-2 rounded-lg font-bold hover:bg-gray-900 transition-colors">
             Manage Users
           </Link>
           <Link href="/admin/ads" className="bg-primary text-white px-4 py-2 rounded-lg font-bold hover:bg-blue-600 transition-colors">
             Manage Ads
           </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {statCards.map((stat, idx) => (
          <div key={idx} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm flex items-center gap-4">
            <div className={`p-4 rounded-lg text-white text-2xl ${stat.color}`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-gray-500 text-sm">{stat.title}</p>
              <h3 className="text-2xl font-bold">{stat.count}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h3 className="font-bold text-lg mb-4">System Status</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
           <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded">
             <span className="text-gray-500">Node Environment:</span>
             <span className="font-mono ml-2 font-bold">{process.env.NODE_ENV}</span>
           </div>
           <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded">
             <span className="text-gray-500">Database:</span>
             <span className="font-mono ml-2 font-bold">Connected (SQLite)</span>
           </div>
           <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded">
             <span className="text-gray-500">Admin Email:</span>
             <span className="font-mono ml-2 font-bold">{process.env.ADMIN_EMAIL || 'Not Configured'}</span>
           </div>
        </div>
      </div>
    </div>
  );
}