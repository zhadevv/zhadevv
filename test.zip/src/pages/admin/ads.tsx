import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import axios from 'axios';
import { BiPlus, BiTrash, BiEdit, BiArrowBack } from 'react-icons/bi';
import Link from 'next/link';
import { Ad } from '../../types';

export default function AdsManager() {
  const router = useRouter();
  const [ads, setAds] = useState<Ad[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    title: '',
    image_url: '',
    link_url: '',
    position: 'header'
  });
  const [error, setError] = useState('');

  const fetchAds = async () => {
    try {
        const token = localStorage.getItem('token');
        const res = await axios.get('/api/admin/ads', {
            headers: { Authorization: `Bearer ${token}` }
        });
        setAds(res.data.ads);
    } catch (err) {
        // If 403/401, redirect to login or home
        router.push('/');
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    fetchAds();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const token = localStorage.getItem('token');

    try {
        await axios.post('/api/admin/ads', formData, {
            headers: { Authorization: `Bearer ${token}` }
        });
        setFormData({ title: '', image_url: '', link_url: '', position: 'header' });
        fetchAds();
    } catch (err: any) {
        setError(err.response?.data?.message || 'Failed to create ad');
    }
  };

  const handleDelete = async (id: number) => {
      if(!confirm('Are you sure?')) return;
      const token = localStorage.getItem('token');
      try {
          await axios.delete(`/api/admin/ads?id=${id}`, {
             headers: { Authorization: `Bearer ${token}` }
          });
          fetchAds();
      } catch (err) {
          alert('Failed to delete');
      }
  };

  const toggleActive = async (ad: Ad) => {
      const token = localStorage.getItem('token');
      try {
          await axios.put('/api/admin/ads', {
              ...ad,
              active: ad.active ? 0 : 1
          }, {
              headers: { Authorization: `Bearer ${token}` }
          });
          fetchAds();
      } catch (err) {
          alert('Failed to update');
      }
  };

  if (loading) return <div className="p-10 text-center">Checking permissions...</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-6">
      <Head>
        <title>Manage Ads - Anidong Admin</title>
      </Head>

      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin" className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
            <BiArrowBack size={24} />
        </Link>
        <h1 className="text-2xl font-bold">Ads Manager</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         {/* Form */}
         <div className="lg:col-span-1">
             <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm sticky top-24">
                 <h2 className="font-bold text-lg mb-4 flex items-center gap-2"><BiPlus /> Add New Ad</h2>
                 {error && <div className="text-red-500 text-sm mb-4 bg-red-50 p-2 rounded">{error}</div>}
                 
                 <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                         <label className="block text-sm font-medium mb-1">Title</label>
                         <input 
                            type="text"
                            required
                            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-transparent"
                            value={formData.title}
                            onChange={e => setFormData({...formData, title: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="block text-sm font-medium mb-1">Image URL</label>
                         <input 
                            type="url"
                            required
                            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-transparent"
                            value={formData.image_url}
                            onChange={e => setFormData({...formData, image_url: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="block text-sm font-medium mb-1">Link URL</label>
                         <input 
                            type="url"
                            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-transparent"
                            value={formData.link_url}
                            onChange={e => setFormData({...formData, link_url: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="block text-sm font-medium mb-1">Position</label>
                         <select 
                            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-transparent dark:bg-gray-800"
                            value={formData.position}
                            onChange={e => setFormData({...formData, position: e.target.value})}
                         >
                             <option value="header">Header</option>
                             <option value="sidebar">Sidebar</option>
                             <option value="footer">Footer</option>
                             <option value="banner">Banner</option>
                         </select>
                     </div>
                     <button type="submit" className="w-full bg-primary text-white font-bold py-2 rounded hover:bg-blue-600">
                         Create Ad
                     </button>
                 </form>
             </div>
         </div>

         {/* List */}
         <div className="lg:col-span-2">
             <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
                 <table className="w-full text-left border-collapse">
                     <thead className="bg-gray-50 dark:bg-gray-700">
                         <tr>
                             <th className="p-4">Image</th>
                             <th className="p-4">Details</th>
                             <th className="p-4">Status</th>
                             <th className="p-4 text-right">Actions</th>
                         </tr>
                     </thead>
                     <tbody>
                         {ads.map(ad => (
                             <tr key={ad.id} className="border-b border-gray-100 dark:border-gray-700 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                 <td className="p-4 w-32">
                                     <img src={ad.image_url} alt={ad.title} className="w-24 h-16 object-cover rounded bg-gray-200" />
                                 </td>
                                 <td className="p-4">
                                     <h4 className="font-bold">{ad.title}</h4>
                                     <div className="text-xs text-gray-500 mt-1">
                                         Pos: <span className="uppercase font-semibold">{ad.position}</span>
                                     </div>
                                     <a href={ad.link_url} target="_blank" className="text-xs text-blue-500 hover:underline truncate block max-w-[200px]">
                                         {ad.link_url}
                                     </a>
                                 </td>
                                 <td className="p-4">
                                     <button 
                                        onClick={() => toggleActive(ad)}
                                        className={`px-3 py-1 rounded-full text-xs font-bold ${ad.active ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}
                                     >
                                         {ad.active ? 'Active' : 'Inactive'}
                                     </button>
                                 </td>
                                 <td className="p-4 text-right">
                                     <button 
                                        onClick={() => handleDelete(ad.id)}
                                        className="text-red-500 hover:bg-red-50 p-2 rounded-full transition-colors"
                                     >
                                         <BiTrash />
                                     </button>
                                 </td>
                             </tr>
                         ))}
                         {ads.length === 0 && (
                             <tr>
                                 <td colSpan={4} className="p-8 text-center text-gray-500">No ads found.</td>
                             </tr>
                         )}
                     </tbody>
                 </table>
             </div>
         </div>
      </div>
    </div>
  );
}