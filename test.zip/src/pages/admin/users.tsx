import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import axios from 'axios';
import { BiArrowBack, BiTrash, BiUser } from 'react-icons/bi';

interface User {
    id: number;
    username: string;
    email: string;
    role: string;
    created_at: string;
}

export default function UsersManager() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    const token = localStorage.getItem('token');
    try {
        const res = await axios.get('/api/admin/users', {
            headers: { Authorization: `Bearer ${token}` }
        });
        setUsers(res.data.users);
    } catch (error) {
        console.error('Failed to fetch users');
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (id: number) => {
      if(!confirm('Are you sure you want to delete this user? This cannot be undone.')) return;
      const token = localStorage.getItem('token');
      try {
          await axios.delete(`/api/admin/users?id=${id}`, {
              headers: { Authorization: `Bearer ${token}` }
          });
          fetchUsers();
      } catch (err: any) {
          alert(err.response?.data?.message || 'Failed to delete user');
      }
  };

  if (loading) return <div className="p-10 text-center">Loading Users...</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-6">
      <Head>
        <title>Manage Users - Anidong Admin</title>
      </Head>

      <div className="flex items-center gap-4 mb-8">
        <Link href="/admin" className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
            <BiArrowBack size={24} />
        </Link>
        <h1 className="text-2xl font-bold">Users Manager</h1>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
         <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th className="p-4">ID</th>
                        <th className="p-4">User</th>
                        <th className="p-4">Role</th>
                        <th className="p-4">Joined</th>
                        <th className="p-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.id} className="border-b border-gray-100 dark:border-gray-700 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="p-4 font-mono text-sm text-gray-500">#{user.id}</td>
                            <td className="p-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                                        <BiUser />
                                    </div>
                                    <div>
                                        <div className="font-bold">{user.username}</div>
                                        <div className="text-xs text-gray-500">{user.email}</div>
                                    </div>
                                </div>
                            </td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded text-xs uppercase font-bold ${user.role === 'admin' ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600'}`}>
                                    {user.role}
                                </span>
                            </td>
                            <td className="p-4 text-sm text-gray-500">
                                {new Date(user.created_at).toLocaleDateString()}
                            </td>
                            <td className="p-4 text-right">
                                <button 
                                    onClick={() => handleDelete(user.id)}
                                    className="text-red-500 hover:bg-red-50 p-2 rounded-full transition-colors"
                                    title="Delete User"
                                >
                                    <BiTrash />
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
         </div>
      </div>
    </div>
  );
}