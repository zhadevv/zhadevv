import Head from 'next/head';

export default function Privacy() {
  return (
    <div style={{ gridArea: 'main' }} className="max-w-4xl mx-auto p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm my-8">
      <Head>
        <title>Privacy Policy - Anidong</title>
      </Head>
      <h1 className="text-3xl font-bold mb-6 border-b pb-4 border-gray-200 dark:border-gray-700">Privacy Policy</h1>
      
      <div className="prose dark:prose-invert max-w-none space-y-4 text-sm md:text-base">
        <p>Your privacy is important to us. It is Anidong's policy to respect your privacy regarding any information we may collect from you across our website.</p>
        
        <h3 className="text-xl font-bold mt-6">Log Data</h3>
        <p>We may collect information that your browser sends whenever you visit our Service ("Log Data"). This Log Data may include information such as your computer's Internet Protocol ("IP") address, browser version, pages of our Service that you visit, the time and date of your visit, the time spent on those pages, and other statistics.</p>
        
        <h3 className="text-xl font-bold mt-6">Cookies</h3>
        <p>Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computer's hard drive. We use "cookies" to collect information.</p>
      </div>
    </div>
  );
}