import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import axios from 'axios';
import { BiSave, BiCog, BiUpload } from 'react-icons/bi';

export default function Settings() {
  const router = useRouter();
  const [avatar, setAvatar] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState({ type: '', text: '' });

  useEffect(() => {
    const userStr = localStorage.getItem('user');
    if (userStr) {
        const user = JSON.parse(userStr);
        setAvatar(user.avatar || '');
    } else {
        router.push('/login');
    }
  }, [router]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        try {
            setMsg({ type: '', text: 'Uploading...' });
            const token = localStorage.getItem('token');
            const res = await axios.post('/api/upload', { image: base64 }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setAvatar(res.data.url);
            setMsg({ type: 'success', text: 'Image uploaded! Click Save to apply.' });
        } catch (err) {
            setMsg({ type: 'error', text: 'Upload failed. File might be too large (Max 4MB).' });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMsg({ type: '', text: '' });
    
    const token = localStorage.getItem('token');

    try {
        const res = await axios.put('/api/user/profile', {
            avatar,
            password: password || undefined
        }, {
            headers: { Authorization: `Bearer ${token}` }
        });

        localStorage.setItem('user', JSON.stringify(res.data.user));
        setMsg({ type: 'success', text: 'Profile updated successfully!' });
        setPassword('');
    } catch (err: any) {
        setMsg({ type: 'error', text: err.response?.data?.message || 'Failed to update profile' });
    } finally {
        setLoading(false);
    }
  };

  return (
    <div style={{ gridArea: 'main' }} className="p-6">
      <Head>
        <title>Settings - Anidong</title>
      </Head>

      <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
        <h1 className="text-2xl font-bold mb-6 flex items-center gap-2 border-b border-gray-100 dark:border-gray-700 pb-4">
            <BiCog className="text-primary" /> Account Settings
        </h1>

        {msg.text && (
            <div className={`p-4 rounded-lg mb-6 text-sm text-center ${msg.type === 'success' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                {msg.text}
            </div>
        )}

        <form onSubmit={handleUpdate} className="space-y-6">
            <div>
                <label className="block text-sm font-medium mb-2">Avatar</label>
                <div className="flex gap-4 items-center mb-4">
                    <img src={avatar || 'https://via.placeholder.com/150'} alt="Preview" className="w-16 h-16 rounded-full object-cover border-2 border-gray-200" />
                    <div className="flex-1">
                        <label className="cursor-pointer bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 px-4 py-2 rounded text-sm font-bold flex items-center w-fit gap-2 transition-colors">
                            <BiUpload /> Upload New Image
                            <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                        </label>
                    </div>
                </div>
                <input 
                    type="url" 
                    className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-transparent focus:border-primary outline-none text-sm text-gray-500"
                    value={avatar}
                    onChange={(e) => setAvatar(e.target.value)}
                    placeholder="Or enter image URL"
                />
            </div>

            <div>
                <label className="block text-sm font-medium mb-2">New Password (Optional)</label>
                <input 
                    type="password" 
                    className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-transparent focus:border-primary outline-none"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Leave blank to keep current password"
                    minLength={6}
                />
            </div>

            <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-primary text-white font-bold py-3 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
            >
                {loading ? 'Saving...' : <><BiSave /> Save Changes</>}
            </button>
        </form>
      </div>
    </div>
  );
}