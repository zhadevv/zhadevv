import React from 'react';
import Head from 'next/head';
import { GetServerSideProps } from 'next';
import Link from 'next/link';
import { getCompleted } from '../services/api';
import { ListingData, Donghua } from '../types';
import { BiPlay, BiCheckCircle } from 'react-icons/bi';
import Pagination from '../components/Pagination';

interface CompletedProps {
  data: ListingData | null;
  page: number;
}

const Card: React.FC<{ item: Donghua }> = ({ item }) => (
  <div className="relative group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all">
    <Link href={`/series/${item.slug}`}>
      <div className="relative aspect-[3/4] overflow-hidden">
        <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <BiPlay className="text-white text-5xl" />
        </div>
        <span className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded shadow">Completed</span>
        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded backdrop-blur-sm">{item.type || 'Donghua'}</span>
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold line-clamp-2 leading-tight group-hover:text-primary transition-colors">{item.title}</h3>
      </div>
    </Link>
  </div>
);

export default function Completed({ data, page }: CompletedProps) {
  if (!data) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head>
        <title>Completed Series - Page {page} - Anidong</title>
      </Head>

      <div className="flex items-center gap-2 mb-6">
        <BiCheckCircle className="text-2xl text-green-500" />
        <h1 className="text-2xl font-bold">Completed Series</h1>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {data.items.map((item, idx) => (
          <Card key={idx} item={item} />
        ))}
      </div>

      <Pagination data={data.pagination} baseUrl="/completed" />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const page = context.query.page ? parseInt(context.query.page as string) : 1;
  const data = await getCompleted(page);
  return { props: { data, page } };
};