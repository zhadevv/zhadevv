import React, { useEffect, useState } from 'react';
import { GetServerSideProps } from 'next';
import Head from 'next/head';
import Link from 'next/link';
import axios from 'axios';
import { getWatchData } from '../../services/api';
import { WatchData } from '../../types';
import { BiCommentDetail, BiSend, BiReply } from 'react-icons/bi';

interface WatchProps {
  data: WatchData | null;
}

interface Comment {
    id: number;
    username: string;
    avatar: string;
    content: string;
    created_at: string;
    replies?: Comment[];
}

export default function WatchPage({ data }: WatchProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyContent, setReplyContent] = useState('');
  const [activeReplyId, setActiveReplyId] = useState<number | null>(null);
  const [posting, setPosting] = useState(false);
  const [userToken, setUserToken] = useState<string | null>(null);

  useEffect(() => {
    if (!data) return;
    const token = localStorage.getItem('token');
    setUserToken(token);
    if (token) {
        axios.post('/api/user/history', {
            slug: data.slug,
            episode: data.episode,
            title: data.title,
            thumbnail: data.thumbnail || ''
        }, { headers: { Authorization: `Bearer ${token}` } }).catch(console.error);
    }
    fetchComments();
  }, [data]);

  const fetchComments = async () => {
    if(!data) return;
    try {
        const res = await axios.get(`/api/comments?slug=${data.slug}`);
        setComments(res.data.comments);
    } catch(err) {
        console.error('Failed to load comments');
    }
  };

  const handlePostComment = async (e: React.FormEvent, parentId: number | null = null) => {
      e.preventDefault();
      const content = parentId ? replyContent : newComment;
      if(!content.trim()) return;
      if(!userToken) return alert('Please login');

      setPosting(true);
      try {
          await axios.post('/api/comments', {
              slug: data?.slug,
              episode: data?.episode,
              content: content,
              parent_id: parentId
          }, { headers: { Authorization: `Bearer ${userToken}` } });
          
          setNewComment('');
          setReplyContent('');
          setActiveReplyId(null);
          fetchComments();
      } catch (err) {
          alert('Failed to post');
      } finally {
          setPosting(false);
      }
  };
  
  if (!data) return <div className="p-10 text-center">Video unavailable.</div>;
  
  const decodeFrame = (str: string) => {
      try {
          if (str.trim().startsWith('<iframe')) return str;
          return Buffer.from(str, 'base64').toString('utf-8');
      } catch (e) { return ''; }
  };

  const CommentItem: React.FC<{ comment: Comment; isReply?: boolean }> = ({ comment, isReply = false }) => (
      <div className={`flex gap-4 ${isReply ? 'ml-12 mt-4 border-l-2 border-gray-100 dark:border-gray-700 pl-4' : ''}`}>
          <div className="shrink-0">
              <img src={comment.avatar} alt={comment.username} className="w-10 h-10 rounded-full object-cover" />
          </div>
          <div className="flex-1">
              <div className="flex items-baseline gap-2 mb-1">
                  <span className="font-bold text-sm">{comment.username}</span>
                  <span className="text-xs text-gray-500">{new Date(comment.created_at).toLocaleDateString()}</span>
              </div>
              <p className="text-sm text-gray-700 dark:text-gray-300">{comment.content}</p>
              
              {!isReply && (
                  <button 
                    onClick={() => setActiveReplyId(activeReplyId === comment.id ? null : comment.id)}
                    className="text-xs text-primary mt-2 flex items-center gap-1 hover:underline"
                  >
                      <BiReply /> Reply
                  </button>
              )}

              {activeReplyId === comment.id && (
                  <form onSubmit={(e) => handlePostComment(e, comment.id)} className="mt-3 flex gap-2">
                      <input 
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                        placeholder="Write a reply..."
                        className="flex-1 bg-gray-50 dark:bg-gray-700 rounded px-3 py-1 text-sm outline-none border border-transparent focus:border-primary"
                        autoFocus
                      />
                      <button type="submit" disabled={posting} className="text-primary disabled:opacity-50 font-bold text-sm">Post</button>
                  </form>
              )}

              {comment.replies && comment.replies.map(reply => (
                  <CommentItem key={reply.id} comment={reply} isReply={true} />
              ))}
          </div>
      </div>
  );

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head><title>{data.title} - Anidong</title></Head>
      <div className="bg-black rounded-xl overflow-hidden shadow-lg aspect-video mb-4 relative z-10">
        <div dangerouslySetInnerHTML={{ __html: decodeFrame(data.server[0].server_url) }} className="w-full h-full [&>iframe]:w-full [&>iframe]:h-full" />
      </div>
      <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm mb-6">
        <h1 className="text-lg md:text-xl font-bold mb-4">{data.title}</h1>
        <div className="flex flex-wrap gap-2 mb-4">
          <span className="text-sm font-bold text-gray-500 self-center mr-2">Servers:</span>
          {data.server.map((srv, idx) => (
            <button key={idx} className={`px-4 py-1.5 rounded text-sm font-medium transition-colors ${idx === 0 ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200'}`}>{srv.server_name}</button>
          ))}
        </div>
        <div className="flex justify-between items-center border-t border-gray-200 dark:border-gray-700 pt-4">
          <Link href={data.pagination.prev_episode ? data.pagination.prev_episode.replace('https://anichin.cafe', '') : '#'} className={`px-4 py-2 rounded text-sm font-bold ${data.pagination.prev_episode ? 'bg-gray-200 dark:bg-gray-700 hover:bg-primary hover:text-white' : 'opacity-50 cursor-not-allowed'}`}>Previous</Link>
          <Link href={`/series/${data.slug}`} className="text-2xl hover:text-primary"><span title="List">≣</span></Link>
          <Link href={data.pagination.next_episode ? data.pagination.next_episode.replace('https://anichin.cafe', '') : '#'} className={`px-4 py-2 rounded text-sm font-bold ${data.pagination.next_episode ? 'bg-gray-200 dark:bg-gray-700 hover:bg-primary hover:text-white' : 'opacity-50 cursor-not-allowed'}`}>Next</Link>
        </div>
      </div>
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h3 className="font-bold text-lg mb-6 flex items-center gap-2"><BiCommentDetail /> Comments</h3>
        {userToken ? (
            <form onSubmit={(e) => handlePostComment(e)} className="mb-8 flex gap-4">
                <textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Write a comment..." className="flex-1 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg p-3 outline-none focus:border-primary transition-colors resize-none h-24" />
                <button type="submit" disabled={posting} className="h-10 w-10 bg-primary text-white rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors disabled:opacity-50"><BiSend /></button>
            </form>
        ) : <div className="mb-8 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg text-center text-sm">Please <Link href="/login" className="text-primary font-bold hover:underline">Login</Link> to post a comment.</div>}
        <div className="space-y-6">
            {comments.map((comment) => <CommentItem key={comment.id} comment={comment} />)}
            {comments.length === 0 && <p className="text-center text-gray-500 text-sm py-4">No comments yet. Be the first to comment!</p>}
        </div>
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { slug } = context.params as { slug: string[] };
  if (slug.length !== 2) return { notFound: true };
  const data = await getWatchData(slug[0], slug[1]);
  return { props: { data } };
};