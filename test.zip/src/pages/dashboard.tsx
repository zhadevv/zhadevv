import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import axios from 'axios';
import { BiUser, BiCog, BiLogOut, BiBookmark, BiTime } from 'react-icons/bi';

interface User {
  username: string;
  email: string;
  avatar: string;
  created_at: string;
}

interface BookmarkItem {
    id: number;
    slug: string;
    title: string;
    thumbnail: string;
}

interface HistoryItem {
    slug: string;
    title: string;
    episode: string;
    thumbnail: string;
    updated_at: string;
}

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const [userRes, bookmarksRes, historyRes] = await Promise.all([
            axios.get('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } }),
            axios.get('/api/user/bookmark', { headers: { Authorization: `Bearer ${token}` } }),
            axios.get('/api/user/history', { headers: { Authorization: `Bearer ${token}` } })
        ]);

        setUser(userRes.data.user);
        setBookmarks(bookmarksRes.data.bookmarks);
        setHistory(historyRes.data.history);

      } catch (error) {
        console.error('Failed to fetch dashboard data', error);
        localStorage.removeItem('token');
        router.push('/login');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    router.push('/login');
  };

  if (loading) return <div className="p-10 text-center">Loading dashboard...</div>;
  if (!user) return null;

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head>
        <title>Dashboard - Anidong</title>
      </Head>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Menu */}
        <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 h-fit">
          <div className="flex flex-col items-center mb-6">
            <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-surface dark:border-gray-700">
              <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <h2 className="font-bold text-lg">{user.username}</h2>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>

          <nav className="space-y-2">
            <button className="w-full flex items-center gap-3 px-4 py-2 bg-primary text-white rounded-lg transition-colors">
              <BiUser /> Profile
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors text-gray-600 dark:text-gray-300">
              <BiBookmark /> Bookmarks
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors text-gray-600 dark:text-gray-300">
              <BiCog /> Settings
            </button>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-2 hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 rounded-lg transition-colors mt-4"
            >
              <BiLogOut /> Logout
            </button>
          </nav>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border-l-4 border-primary">
              <h3 className="text-gray-500 text-sm mb-1">Bookmarks</h3>
              <p className="text-2xl font-bold">{bookmarks.length}</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border-l-4 border-green-500">
              <h3 className="text-gray-500 text-sm mb-1">Watched</h3>
              <p className="text-2xl font-bold">{history.length}</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border-l-4 border-purple-500">
              <h3 className="text-gray-500 text-sm mb-1">Joined</h3>
              <p className="text-sm font-bold mt-2">
                {new Date(user.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>

          {/* Bookmarks */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <BiBookmark className="text-primary" /> Bookmarks
            </h3>
            
            {bookmarks.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {bookmarks.map((item) => (
                    <div key={item.id} className="flex gap-4 p-3 border border-gray-100 dark:border-gray-700 rounded-lg hover:border-primary transition-colors cursor-pointer">
                    <img src={item.thumbnail} alt={item.title} className="w-16 h-20 object-cover rounded" />
                    <div className="flex flex-col justify-center">
                        <h4 className="font-bold text-sm line-clamp-2">{item.title}</h4>
                        <div className="mt-2">
                           <Link href={`/series/${item.slug}`} className="text-xs text-primary font-bold hover:underline">View Series</Link>
                        </div>
                    </div>
                    </div>
                ))}
                </div>
            ) : (
                <p className="text-gray-500 text-sm">No bookmarks yet.</p>
            )}
          </div>

          {/* Watch History */}
           <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <BiTime className="text-primary" /> Watch History
            </h3>
            
            {history.length > 0 ? (
                <div className="space-y-3">
                    {history.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4 border-b border-gray-100 dark:border-gray-700 last:border-0 pb-3 last:pb-0">
                             <img src={item.thumbnail} alt={item.title} className="w-12 h-16 object-cover rounded" />
                             <div>
                                 <h4 className="font-bold text-sm line-clamp-1">{item.title}</h4>
                                 <div className="flex items-center gap-2 mt-1">
                                    <span className="text-xs bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded">
                                        Episode {item.episode}
                                    </span>
                                    <span className="text-xs text-gray-500">
                                        {new Date(item.updated_at).toLocaleDateString()}
                                    </span>
                                 </div>
                             </div>
                             <Link href={`/watch/${item.slug}/${item.episode}`} className="ml-auto text-xs bg-primary text-white px-3 py-1.5 rounded-full hover:bg-blue-600 transition-colors">
                                Play
                             </Link>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-gray-500 text-sm">No watch history yet.</p>
            )}
           </div>
        </div>
      </div>
    </div>
  );
}