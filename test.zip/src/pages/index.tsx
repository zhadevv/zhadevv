import React from 'react';
import Head from 'next/head';
import { GetServerSideProps } from 'next';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination as SwiperPagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import Link from 'next/link';
import { BiPlay, BiTime } from 'react-icons/bi';
import { getHomeData } from '../services/api';
import { HomeData, Donghua } from '../types';

interface HomeProps {
  data: HomeData | null;
}

const Card: React.FC<{ item: Donghua }> = ({ item }) => (
  <div className="relative group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all">
    <Link href={`/series/${item.slug}`}>
      <div className="relative aspect-[3/4] overflow-hidden">
        <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <BiPlay className="text-white text-5xl" />
        </div>
        <span className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-0.5 rounded shadow">{item.badge || 'Sub'}</span>
        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded backdrop-blur-sm">{item.episode}</span>
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold line-clamp-2 leading-tight group-hover:text-primary transition-colors">{item.title}</h3>
      </div>
    </Link>
  </div>
);

export default function Home({ data }: HomeProps) {
  if (!data) return <div className="p-10 text-center">Failed to load data. Please try again later.</div>;

  return (
    <>
      <Head>
        <title>{process.env.SITE_NAME || 'Anidong'} - Stream Donghua</title>
      </Head>

      {/* Banner Area */}
      <div className="mb-6 rounded-xl overflow-hidden shadow-lg" style={{ gridArea: 'banner' }}>
        <Swiper
          modules={[Autoplay, SwiperPagination]}
          spaceBetween={0}
          slidesPerView={1}
          autoplay={{ delay: 5000 }}
          pagination={{ clickable: true }}
          className="w-full h-[250px] md:h-[400px]"
        >
          {data.slider.map((slide, idx) => (
            <SwiperSlide key={idx} className="relative">
              <img src={slide.thumbnail} alt={slide.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent flex items-center p-8">
                <div className="max-w-xl text-white">
                  <h2 className="text-3xl font-bold mb-2">{slide.title}</h2>
                  <p className="text-sm text-gray-200 line-clamp-3 mb-4">{slide.description}</p>
                  <Link href={`/series/${slide.slug}`} className="inline-flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-full font-bold hover:bg-blue-600 transition-colors">
                    <BiPlay size={24} /> Watch Now
                  </Link>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      {/* Main Content */}
      <main className="flex flex-col gap-8 px-4 lg:px-0" style={{ gridArea: 'main' }}>
        
        {/* Latest Release */}
        <section>
          <div className="flex justify-between items-center mb-4 border-b border-gray-200 dark:border-gray-700 pb-2">
            <h2 className="text-xl font-bold text-primary flex items-center gap-2"><BiTime /> Latest Release</h2>
            <Link href="/ongoing" className="text-xs text-gray-500 hover:text-primary">View All</Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {data.latest_release.map((item, idx) => (
              <Card key={idx} item={item} />
            ))}
          </div>
        </section>

        {/* Popular Today */}
        <section>
          <div className="flex justify-between items-center mb-4 border-b border-gray-200 dark:border-gray-700 pb-2">
            <h2 className="text-xl font-bold text-primary">Popular Today</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {data.popular_today.map((item, idx) => (
              <Card key={idx} item={item} />
            ))}
          </div>
        </section>

      </main>

      {/* Low/Bottom Section */}
      <div className="mt-8 px-4 lg:px-0" style={{ gridArea: 'low' }}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
             <h3 className="font-bold mb-4">New Movies</h3>
             <div className="space-y-4">
                {data.new_movie?.map((movie, idx) => (
                   <div key={idx} className="flex gap-4">
                      <img src={movie.thumbnail} className="w-20 h-28 object-cover rounded" />
                      <div>
                         <h4 className="font-semibold text-sm">{movie.title}</h4>
                         <span className="text-xs bg-primary text-white px-1 rounded mt-1 inline-block">Movie</span>
                      </div>
                   </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const data = await getHomeData(1);
  return {
    props: {
      data,
    },
  };
};