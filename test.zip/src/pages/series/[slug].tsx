import React, { useEffect, useState } from 'react';
import { GetServerSideProps } from 'next';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import axios from 'axios';
import { getDetail } from '../../services/api';
import { DonghuaDetail } from '../../types';
import { BiPlayCircle, BiBookmark, BiCheck } from 'react-icons/bi';

interface DetailProps {
  data: DonghuaDetail | null;
}

export default function SeriesDetail({ data }: DetailProps) {
  const router = useRouter();
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [loadingBookmark, setLoadingBookmark] = useState(false);
  const [userToken, setUserToken] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setUserToken(token);
    
    if (token && data) {
      checkBookmarkStatus(token);
    }
  }, [data]);

  const checkBookmarkStatus = async (token: string) => {
    try {
      const res = await axios.get(`/api/user/bookmark?slug=${data?.slug}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setIsBookmarked(res.data.isBookmarked);
    } catch (err) {
      console.error(err);
    }
  };

  const toggleBookmark = async () => {
    if (!userToken) {
      router.push('/login');
      return;
    }
    if (!data) return;

    setLoadingBookmark(true);
    try {
      if (isBookmarked) {
        await axios.delete(`/api/user/bookmark?slug=${data.slug}`, {
          headers: { Authorization: `Bearer ${userToken}` }
        });
        setIsBookmarked(false);
      } else {
        await axios.post('/api/user/bookmark', {
          slug: data.slug,
          title: data.title,
          thumbnail: data.cover.thumbnail
        }, {
          headers: { Authorization: `Bearer ${userToken}` }
        });
        setIsBookmarked(true);
      }
    } catch (err) {
      alert('Failed to update bookmark');
    } finally {
      setLoadingBookmark(false);
    }
  };

  if (!data) return <div className="p-10 text-center">Content not found.</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head>
        <title>{data.title} - Anidong</title>
      </Head>

      <div className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg mb-8">
        <div className="h-48 md:h-64 overflow-hidden relative">
          <img src={data.cover.banner} alt={data.title} className="w-full h-full object-cover opacity-50 blur-sm" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
        </div>
        
        <div className="px-6 pb-6 relative -mt-32 flex flex-col md:flex-row gap-8">
          <div className="shrink-0 mx-auto md:mx-0">
            <img src={data.cover.thumbnail} alt={data.title} className="w-56 h-80 object-cover rounded-lg shadow-2xl border-4 border-white dark:border-gray-700" />
            
            <button 
                onClick={toggleBookmark}
                disabled={loadingBookmark}
                className={`w-full mt-4 flex items-center justify-center gap-2 py-2.5 rounded-lg font-bold transition-colors shadow-md ${
                    isBookmarked 
                    ? 'bg-green-500 text-white hover:bg-green-600' 
                    : 'bg-primary text-white hover:bg-blue-600'
                }`}
            >
                {loadingBookmark ? (
                    'Processing...'
                ) : isBookmarked ? (
                    <><BiCheck className="text-xl" /> Bookmarked</>
                ) : (
                    <><BiBookmark className="text-xl" /> Add Bookmark</>
                )}
            </button>
          </div>
          
          <div className="flex-1 pt-12 md:pt-32 text-center md:text-left">
            <h1 className="text-3xl font-bold mb-2">{data.title}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{data.alter_title}</p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-6">
              {data.genre.map((g, idx) => (
                <span key={idx} className="bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full text-xs font-medium">
                  {g.title_genre}
                </span>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm mb-6 bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
              <div><span className="text-gray-500">Status:</span> {data.information.status}</div>
              <div><span className="text-gray-500">Studio:</span> {data.information.studio}</div>
              <div><span className="text-gray-500">Released:</span> {data.information.released}</div>
              <div><span className="text-gray-500">Type:</span> {data.information.type}</div>
            </div>

            <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mb-6">
              {data.synopsis}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h3 className="text-xl font-bold mb-6 flex items-center gap-2 border-b pb-4 dark:border-gray-700">
          <BiPlayCircle /> Episode List
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
          {data.episode_list.map((ep, idx) => (
             <Link 
               key={idx} 
               href={`/watch/${data.slug}/${ep.number}`}
               className="block bg-gray-50 dark:bg-gray-700 hover:bg-primary hover:text-white dark:hover:bg-primary p-3 rounded text-center transition-colors text-sm font-medium"
             >
               Episode {ep.number}
             </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { slug } = context.params as { slug: string };
  const data = await getDetail(slug);
  return { props: { data } };
};