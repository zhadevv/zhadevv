import React from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { GetServerSideProps } from 'next';
import axios from 'axios';
import { BiListUl } from 'react-icons/bi';

interface ListModeProps {
  data: Record<string, Array<{ title: string; slug: string; url: string; }>> | null;
}

export default function ListMode({ data }: ListModeProps) {
  if (!data) return <div className="p-10 text-center">Loading List...</div>;

  const letters = Object.keys(data).sort();

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head>
        <title>List Mode - Anidong</title>
      </Head>

      <div className="flex items-center gap-2 mb-6">
        <BiListUl className="text-2xl text-primary" />
        <h1 className="text-2xl font-bold">Donghua List (Text Mode)</h1>
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm">
        <div className="flex flex-wrap gap-2 mb-8 justify-center border-b border-gray-100 dark:border-gray-700 pb-4">
          {letters.map((char) => (
            <a key={char} href={`#letter-${char}`} className="w-8 h-8 flex items-center justify-center rounded font-bold hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
              {char}
            </a>
          ))}
        </div>

        <div className="space-y-8">
          {letters.map((char) => (
            <div key={char} id={`letter-${char}`} className="scroll-mt-24">
              <h2 className="text-2xl font-bold text-primary mb-4 border-l-4 border-primary pl-3">{char}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {data[char].map((item, idx) => (
                  <Link 
                    key={idx} 
                    href={`/series/${item.slug}`}
                    className="block px-3 py-2 text-sm hover:bg-gray-50 dark:hover:bg-gray-700 rounded transition-colors truncate"
                  >
                    {item.title}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  try {
    // Calling the endpoint directly as defined in prompt
    const res = await axios.get('https://dh.zhadev.my.id/api/v1/donghua/filters/list-mode');
    return { props: { data: res.data.data } };
  } catch (e) {
    return { props: { data: null } };
  }
};