import React from 'react';
import Head from 'next/head';
import { GetServerSideProps } from 'next';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { getAdvancedSearch, getFilterValues } from '../../services/api';
import { ListingData, Donghua, FilterOptionsData } from '../../types';
import { BiPlay, BiFilterAlt, BiChevronDown, BiChevronUp } from 'react-icons/bi';
import Pagination from '../../components/Pagination';

interface SeriesProps {
  data: ListingData | null;
  filterOptions: FilterOptionsData | null;
  page: number;
}

const Card: React.FC<{ item: Donghua }> = ({ item }) => (
  <div className="relative group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all">
    <Link href={`/series/${item.slug}`}>
      <div className="relative aspect-[3/4] overflow-hidden">
        <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <BiPlay className="text-white text-5xl" />
        </div>
        <span className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-0.5 rounded shadow">{item.badge || 'Sub'}</span>
        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded backdrop-blur-sm">{item.episode || item.type}</span>
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold line-clamp-2 leading-tight group-hover:text-primary transition-colors">{item.title}</h3>
      </div>
    </Link>
  </div>
);

const FilterSection: React.FC<{ 
  title: string; 
  children: React.ReactNode; 
  isOpenDefault?: boolean 
}> = ({ title, children, isOpenDefault = true }) => {
  const [isOpen, setIsOpen] = React.useState(isOpenDefault);
  return (
    <div className="mb-4 border-b border-gray-100 dark:border-gray-700 pb-4 last:border-0">
      <button 
        className="flex justify-between items-center w-full font-bold mb-2 text-sm uppercase tracking-wider text-gray-500 hover:text-primary transition-colors"
        onClick={() => setIsOpen(!isOpen)}
      >
        {title}
        {isOpen ? <BiChevronUp /> : <BiChevronDown />}
      </button>
      {isOpen && <div className="space-y-1">{children}</div>}
    </div>
  );
};

export default function Series({ data, filterOptions, page }: SeriesProps) {
  const router = useRouter();
  const [showMobileFilter, setShowMobileFilter] = React.useState(false);

  // Helper to handle filter changes
  const handleFilterChange = (key: string, value: string, type: 'radio' | 'checkbox') => {
    const currentQuery = { ...router.query };
    delete currentQuery.slug; // Remove slug if present (nextjs dynamic route artifact)
    
    if (type === 'radio') {
      if (value === '') {
        delete currentQuery[key];
      } else {
        currentQuery[key] = value;
      }
    } else {
      // Checkbox logic for arrays (genre, studio, season)
      // The API expects format: genre=[val1+val2]
      // This is a bit complex to simulate purely client side with standard URLSearchParams
      // We will assume single selection for checkbox for simplicity in this MVP 
      // or simplistic append logic if the API supports standard repeats like ?genre=a&genre=b
      
      // Based on prompt: ?genre=[value_1+value_2]
      // Let's implement simpler single toggle for now or direct replace for UX simplicity
      if (currentQuery[key] === value) {
        delete currentQuery[key];
      } else {
        currentQuery[key] = value;
      }
    }

    // Reset to page 1 on filter change
    currentQuery.page = '1';

    router.push({
      pathname: '/series',
      query: currentQuery,
    });
  };

  const isChecked = (key: string, value: string) => {
    const queryVal = router.query[key];
    if (key === 'status' && !queryVal && value === '') return true; // Default All
    if (key === 'order' && !queryVal && value === '') return true; // Default Default
    if (key === 'type' && !queryVal && value === '') return true;
    if (key === 'sub' && !queryVal && value === '') return true;
    return queryVal === value;
  };

  if (!data || !filterOptions) return <div className="p-10 text-center">Loading filters...</div>;

  return (
    <div className="grid-layout-desktop" style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '2rem', padding: '1rem', gridArea: 'main' }}>
      <Head>
        <title>Advanced Search - Anidong</title>
      </Head>

      {/* Mobile Filter Toggle */}
      <button 
        className="lg:hidden fixed bottom-4 right-4 z-50 bg-primary text-white p-3 rounded-full shadow-lg"
        onClick={() => setShowMobileFilter(!showMobileFilter)}
      >
        <BiFilterAlt size={24} />
      </button>

      {/* Filters Sidebar */}
      <aside className={`bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm h-fit ${showMobileFilter ? 'fixed inset-0 z-40 overflow-y-auto m-0 rounded-none' : 'hidden lg:block'}`}>
        <div className="flex justify-between items-center mb-4 lg:hidden">
          <h2 className="text-xl font-bold">Filters</h2>
          <button onClick={() => setShowMobileFilter(false)} className="text-2xl">&times;</button>
        </div>
        
        <h2 className="text-xl font-bold mb-6 hidden lg:flex items-center gap-2">
          <BiFilterAlt /> Advanced Filter
        </h2>

        {/* Radio Filters */}
        <FilterSection title="Status">
          {filterOptions.status.map((opt) => (
            <label key={opt.value} className="flex items-center space-x-2 cursor-pointer text-sm">
              <input 
                type="radio" 
                name="status" 
                checked={isChecked('status', opt.value)}
                onChange={() => handleFilterChange('status', opt.value, 'radio')}
                className="text-primary focus:ring-primary"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </FilterSection>

        <FilterSection title="Type">
          {filterOptions.type.map((opt) => (
            <label key={opt.value} className="flex items-center space-x-2 cursor-pointer text-sm">
              <input 
                type="radio" 
                name="type" 
                checked={isChecked('type', opt.value)}
                onChange={() => handleFilterChange('type', opt.value, 'radio')}
                className="text-primary focus:ring-primary"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </FilterSection>

        <FilterSection title="Order By">
          {filterOptions.order.map((opt) => (
            <label key={opt.value} className="flex items-center space-x-2 cursor-pointer text-sm">
              <input 
                type="radio" 
                name="order" 
                checked={isChecked('order', opt.value)}
                onChange={() => handleFilterChange('order', opt.value, 'radio')}
                className="text-primary focus:ring-primary"
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </FilterSection>

        {/* Checkbox Filters (Functionally treating as single select for MVP based on available API data structure usually being simpler for clients) */}
        <FilterSection title="Genre">
          <div className="flex flex-wrap gap-2">
             {filterOptions.genre.map((opt) => (
               <button
                 key={opt.value}
                 onClick={() => handleFilterChange('genre', opt.value, 'checkbox')}
                 className={`text-xs px-2 py-1 rounded border transition-colors ${
                   router.query.genre === opt.value 
                   ? 'bg-primary text-white border-primary' 
                   : 'bg-transparent border-gray-200 dark:border-gray-600 hover:border-primary hover:text-primary'
                 }`}
               >
                 {opt.label}
               </button>
             ))}
          </div>
        </FilterSection>

        <FilterSection title="Season">
          <div className="flex flex-wrap gap-2">
             {filterOptions.season.map((opt) => (
               <button
                 key={opt.value}
                 onClick={() => handleFilterChange('season', opt.value, 'checkbox')}
                 className={`text-xs px-2 py-1 rounded border transition-colors ${
                   router.query.season === opt.value 
                   ? 'bg-primary text-white border-primary' 
                   : 'bg-transparent border-gray-200 dark:border-gray-600 hover:border-primary hover:text-primary'
                 }`}
               >
                 {opt.label}
               </button>
             ))}
          </div>
        </FilterSection>

        <FilterSection title="Studio" isOpenDefault={false}>
            {filterOptions.studio.map((opt) => (
               <label key={opt.value} className="flex items-center space-x-2 cursor-pointer text-sm block mb-1">
                 <input 
                   type="checkbox" 
                   checked={router.query.studio === opt.value}
                   onChange={() => handleFilterChange('studio', opt.value, 'checkbox')}
                   className="rounded text-primary focus:ring-primary"
                 />
                 <span className="line-clamp-1">{opt.label}</span>
               </label>
            ))}
        </FilterSection>

      </aside>

      {/* Main Results */}
      <div>
        <div className="mb-4">
          <h1 className="text-2xl font-bold mb-2">Series List</h1>
          <p className="text-gray-500 text-sm">Found {data.items.length} results</p>
        </div>

        {data.items.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {data.items.map((item, idx) => (
              <Card key={idx} item={item} />
            ))}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 p-8 rounded text-center">
            <p className="text-gray-500">No results found matching your filters.</p>
            <button 
              onClick={() => router.push('/series')}
              className="mt-4 text-primary underline"
            >
              Reset Filters
            </button>
          </div>
        )}

        <Pagination data={data.pagination} baseUrl="/series" queryParams={router.query as any} />
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const page = context.query.page ? parseInt(context.query.page as string) : 1;
  const filterOptions = await getFilterValues();
  const data = await getAdvancedSearch(page, context.query);
  
  return { props: { data, filterOptions, page } };
};