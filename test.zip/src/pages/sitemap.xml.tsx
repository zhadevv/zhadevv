import { GetServerSideProps } from 'next';
import axios from 'axios';

const EXTERNAL_DATA_URL = 'https://dh.zhadev.my.id/api/v1/donghua/a-z/1';

function generateSiteMap(series: any[]) {
  return `<?xml version="1.0" encoding="UTF-8"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
     <url>
       <loc>https://anidong.my.id</loc>
     </url>
     <url>
       <loc>https://anidong.my.id/ongoing</loc>
     </url>
     <url>
       <loc>https://anidong.my.id/completed</loc>
     </url>
     ${series
       .map(({ slug }) => {
         return `
       <url>
           <loc>${`https://anidong.my.id/series/${slug}`}</loc>
       </url>
     `;
       })
       .join('')}
   </urlset>
 `;
}

function SiteMap() {}

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
  // We make an API call to gather the URLs for our site
  try {
      const request = await axios.get(EXTERNAL_DATA_URL);
      const series = request.data.data.items || [];
      const sitemap = generateSiteMap(series);
    
      res.setHeader('Content-Type', 'text/xml');
      res.write(sitemap);
      res.end();
  } catch (e) {
      res.write('<?xml version="1.0" encoding="UTF-8"?><urlset></urlset>');
      res.end();
  }

  return { props: {} };
};

export default SiteMap;