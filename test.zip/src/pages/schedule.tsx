import React from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { GetServerSideProps } from 'next';
import { getSchedule } from '../services/api';
import { ScheduleData, Donghua } from '../types';
import { BiTime } from 'react-icons/bi';

interface ScheduleProps {
  data: ScheduleData | null;
}

const ScheduleItem: React.FC<{ item: Donghua }> = ({ item }) => (
  <Link href={`/series/${item.slug}`} className="flex gap-4 p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all group">
    <div className="w-16 h-20 shrink-0 rounded overflow-hidden">
      <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
    </div>
    <div className="flex flex-col justify-center">
      <h4 className="font-bold text-sm line-clamp-1 group-hover:text-primary transition-colors">{item.title}</h4>
      <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
        <BiTime /> {item.release_time?.formatted}
      </div>
      <div className="text-xs text-primary mt-1 font-medium">
        {item.countdown?.formatted} left
      </div>
    </div>
  </Link>
);

export default function Schedule({ data }: ScheduleProps) {
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const [activeDay, setActiveDay] = React.useState(days[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1]);

  if (!data) return <div className="p-10 text-center">Loading schedule...</div>;

  return (
    <div style={{ gridArea: 'main' }} className="p-4">
      <Head>
        <title>Schedule - Anidong</title>
      </Head>

      <div className="flex items-center gap-2 mb-6">
        <BiTime className="text-2xl text-primary" />
        <h1 className="text-2xl font-bold">Release Schedule</h1>
      </div>

      {/* Day Tabs */}
      <div className="flex overflow-x-auto gap-2 mb-6 pb-2 custom-scrollbar">
        {days.map((day) => (
          <button
            key={day}
            onClick={() => setActiveDay(day)}
            className={`px-6 py-2 rounded-full capitalize whitespace-nowrap font-medium transition-colors ${
              activeDay === day 
                ? 'bg-primary text-white shadow-lg shadow-blue-500/30' 
                : 'bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
          >
            {day}
          </button>
        ))}
      </div>

      {/* Schedule List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {data[activeDay]?.list?.length > 0 ? (
          data[activeDay].list.map((item, idx) => (
            <ScheduleItem key={idx} item={item} />
          ))
        ) : (
          <div className="col-span-full text-center py-10 text-gray-500">
            No releases scheduled for this day.
          </div>
        )}
      </div>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const data = await getSchedule();
  return { props: { data } };
};