import type { NextApiRequest, NextApiResponse } from 'next';
import { getActiveAds } from '../../models/database';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const ads = getActiveAds();
    return res.status(200).json({ ads });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to fetch ads' });
  }
}