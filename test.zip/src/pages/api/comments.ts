import type { NextApiRequest, NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../utils/auth';
import { getComments, addComment } from '../../models/database';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  
  if (req.method === 'GET') {
    const { slug } = req.query;
    if (!slug) return res.status(400).json({ message: 'Slug required' });
    
    try {
      const comments = getComments(slug as string);
      return res.status(200).json({ comments });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to fetch comments' });
    }
  }

  // POST requires auth
  if (req.method === 'POST') {
    const authHandler = authenticate(async (authReq: AuthenticatedRequest, authRes: NextApiResponse) => {
        const { slug, episode, content, parent_id } = authReq.body;
        const userId = authReq.user!.userId;

        if (!slug || !content) return authRes.status(400).json({ message: 'Missing fields' });
        
        try {
            const comment = addComment(userId, slug, episode, content, parent_id);
            return authRes.status(201).json({ comment });
        } catch (error) {
            return authRes.status(500).json({ message: 'Failed to post comment' });
        }
    });

    return authHandler(req as AuthenticatedRequest, res);
  }

  return res.status(405).json({ message: 'Method not allowed' });
}