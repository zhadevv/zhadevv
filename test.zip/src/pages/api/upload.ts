import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import { authenticate } from '../../utils/auth';

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '4mb',
    },
  },
};

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Method not allowed' });

  const { image } = req.body; // Expects base64 string: "data:image/png;base64,..."

  if (!image) return res.status(400).json({ message: 'No image provided' });

  try {
    // Simple Base64 decoding
    const matches = image.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.status(400).json({ message: 'Invalid image format' });
    }

    const type = matches[1];
    const buffer = Buffer.from(matches[2], 'base64');
    const extension = type.split('/')[1];
    
    // Validate type
    if (!['png', 'jpeg', 'jpg', 'webp'].includes(extension)) {
        return res.status(400).json({ message: 'Only images are allowed' });
    }

    const fileName = `avatar-${Date.now()}.${extension}`;
    const publicDir = path.join(process.cwd(), 'public', 'uploads');
    
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }

    fs.writeFileSync(path.join(publicDir, fileName), buffer);

    const fileUrl = `/uploads/${fileName}`;
    return res.status(200).json({ url: fileUrl });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Upload failed' });
  }
}

export default authenticate(handler);