import type { NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { getSystemStats } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const stats = getSystemStats();
    return res.status(200).json({ stats });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to fetch stats' });
  }
}

export default authenticate(handler, true);