import type { NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { getAllAds, createAd, updateAd, deleteAd } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  const method = req.method;

  if (method === 'GET') {
    try {
      const ads = getAllAds();
      return res.status(200).json({ ads });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to fetch ads' });
    }
  }

  if (method === 'POST') {
    const { title, image_url, link_url, position } = req.body;
    if (!title || !image_url || !position) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    try {
      createAd(title, image_url, link_url || '#', position);
      return res.status(201).json({ message: 'Ad created' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to create ad' });
    }
  }

  if (method === 'PUT') {
    const { id, title, image_url, link_url, position, active } = req.body;
    if (!id) return res.status(400).json({ message: 'Missing ID' });

    try {
      updateAd(id, title, image_url, link_url, position, active ? 1 : 0);
      return res.status(200).json({ message: 'Ad updated' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to update ad' });
    }
  }

  if (method === 'DELETE') {
    const { id } = req.query;
    if (!id) return res.status(400).json({ message: 'Missing ID' });

    try {
      deleteAd(Number(id));
      return res.status(200).json({ message: 'Ad deleted' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to delete ad' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default authenticate(handler, true);