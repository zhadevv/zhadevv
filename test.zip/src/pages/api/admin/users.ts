import type { NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { getAllUsers, deleteUser } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  const method = req.method;

  if (method === 'GET') {
    try {
      const users = getAllUsers();
      return res.status(200).json({ users });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to fetch users' });
    }
  }

  if (method === 'DELETE') {
    const { id } = req.query;
    if (!id) return res.status(400).json({ message: 'Missing User ID' });

    // Prevent deleting self
    if (Number(id) === req.user?.userId) {
        return res.status(403).json({ message: 'Cannot delete your own admin account' });
    }

    try {
      deleteUser(Number(id));
      return res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to delete user' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default authenticate(handler, true);