import type { NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { getHistory, updateHistory } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  const userId = req.user!.userId;

  if (req.method === 'GET') {
    try {
      const history = getHistory(userId);
      return res.status(200).json({ history });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to fetch history' });
    }
  }

  if (req.method === 'POST') {
    const { slug, episode, title, thumbnail } = req.body;
    if (!slug || !episode) return res.status(400).json({ message: 'Missing fields' });

    try {
      updateHistory(userId, slug, episode, title || '', thumbnail || '');
      return res.status(200).json({ success: true });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to update history' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default authenticate(handler);