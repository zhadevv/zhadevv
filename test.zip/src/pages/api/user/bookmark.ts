import type { NextApiResponse } from 'next';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { getBookmarks, addBookmark, removeBookmark, checkBookmark } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  const userId = req.user!.userId;

  if (req.method === 'GET') {
    // If slug query param is present, check specific status
    const { slug } = req.query;
    if (slug) {
        const isBookmarked = checkBookmark(userId, slug as string);
        return res.status(200).json({ isBookmarked });
    }
    
    // Otherwise return list
    try {
      const bookmarks = getBookmarks(userId);
      return res.status(200).json({ bookmarks });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to fetch bookmarks' });
    }
  }

  if (req.method === 'POST') {
    const { slug, title, thumbnail } = req.body;
    if (!slug || !title) return res.status(400).json({ message: 'Missing required fields' });

    try {
      const success = addBookmark(userId, slug, title, thumbnail || '');
      return res.status(200).json({ success, message: success ? 'Added to bookmarks' : 'Already bookmarked' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to add bookmark' });
    }
  }

  if (req.method === 'DELETE') {
    const { slug } = req.query;
    if (!slug) return res.status(400).json({ message: 'Missing slug' });

    try {
      const success = removeBookmark(userId, slug as string);
      return res.status(200).json({ success, message: 'Removed from bookmarks' });
    } catch (error) {
      return res.status(500).json({ message: 'Failed to remove bookmark' });
    }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default authenticate(handler);