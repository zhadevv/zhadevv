import type { NextApiResponse } from 'next';
import bcrypt from 'bcrypt';
import { authenticate, AuthenticatedRequest } from '../../../utils/auth';
import { updateUserProfile, findUserById } from '../../../models/database';

async function handler(req: AuthenticatedRequest, res: NextApiResponse) {
  if (req.method !== 'PUT') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const { avatar, password } = req.body;
  const userId = req.user!.userId;

  try {
    let hashedPassword;
    if (password) {
        if (password.length < 6) return res.status(400).json({ message: 'Password too short' });
        const salt = await bcrypt.genSalt(10);
        hashedPassword = await bcrypt.hash(password, salt);
    }

    updateUserProfile(userId, avatar, hashedPassword);
    
    // Return updated user info
    const updatedUser = findUserById(userId);
    const { password: _, ...safeUser } = updatedUser;

    return res.status(200).json({ 
        message: 'Profile updated',
        user: safeUser
    });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to update profile' });
  }
}

export default authenticate(handler);