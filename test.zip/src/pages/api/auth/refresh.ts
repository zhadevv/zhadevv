import type { NextApiRequest, NextApiResponse } from 'next';
import jwt from 'jsonwebtoken';
import { findUserById } from '../../../models/database';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_key_change_me';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const oldToken = authHeader.split(' ')[1];

  try {
    // Verify ignoring expiration to allow refresh of recently expired tokens if implementing rotation
    // For simple stateless JWT, we usually just re-issue if the user is valid and token is valid.
    const decoded: any = jwt.verify(oldToken, JWT_SECRET, { ignoreExpiration: true });
    
    const user = findUserById(decoded.userId);
    if (!user) return res.status(401).json({ message: 'User not found' });

    // Issue new token
    const newToken = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(200).json({ token: newToken });
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}