import Head from 'next/head';

export default function Terms() {
  return (
    <div style={{ gridArea: 'main' }} className="max-w-4xl mx-auto p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm my-8">
      <Head>
        <title>Terms of Service - Anidong</title>
      </Head>
      <h1 className="text-3xl font-bold mb-6 border-b pb-4 border-gray-200 dark:border-gray-700">Terms of Service</h1>
      
      <div className="prose dark:prose-invert max-w-none space-y-4 text-sm md:text-base">
        <p>Welcome to Anidong. By accessing this website, you agree to be bound by these Terms of Service.</p>
        
        <h3 className="text-xl font-bold mt-6">1. Usage License</h3>
        <p>Permission is granted to temporarily view the materials (information or software) on Anidong's website for personal, non-commercial transitory viewing only.</p>
        
        <h3 className="text-xl font-bold mt-6">2. Disclaimer</h3>
        <p>The materials on Anidong's website are provided on an 'as is' basis. Anidong makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
        
        <h3 className="text-xl font-bold mt-6">3. Content</h3>
        <p>Anidong does not host any files on its servers. All content is provided by non-affiliated third parties.</p>
      </div>
    </div>
  );
}