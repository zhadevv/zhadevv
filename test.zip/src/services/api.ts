import axios from 'axios';
import { ApiResponse, HomeData, DonghuaDetail, WatchData, Donghua, Pagination, ScheduleData, ListingData, FilterOptionsData, RandomData } from '../types';

const API_BASE_URL = 'https://dh.zhadev.my.id/api/v1/donghua';
const API_KEY = process.env.ZHADEV_APIKEY;

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  params: {
    apikey: API_KEY,
  },
});

export const getHomeData = async (page: number = 1): Promise<HomeData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<HomeData>>(`/home/${page}`);
    if (response.data.success) {
      return response.data.data;
    }
    return null;
  } catch (error) {
    console.error('Error fetching home data:', error);
    return null;
  }
};

export const getSchedule = async (): Promise<ScheduleData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<ScheduleData>>('/schedule');
    return response.data.data;
  } catch (error) {
    console.error('Error fetching schedule:', error);
    return null;
  }
};

export const getDetail = async (slug: string): Promise<DonghuaDetail | null> => {
  try {
    const response = await apiClient.get<ApiResponse<DonghuaDetail>>(`/detail/${slug}`);
    return response.data.data;
  } catch (error) {
    console.error('Error fetching detail:', error);
    return null;
  }
};

export const getWatchData = async (slug: string, episode: string): Promise<WatchData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<WatchData>>(`/watch/${slug}/${episode}`);
    return response.data.data;
  } catch (error) {
    console.error('Error fetching watch data:', error);
    return null;
  }
};

export const searchDonghua = async (query: string, page: number = 1): Promise<ListingData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<ListingData>>(`/search/${page}`, {
      params: { s: query }
    });
    return response.data.data;
  } catch (error) {
    console.error('Search error:', error);
    return null;
  }
};

export const getOngoing = async (page: number = 1): Promise<ListingData | null> => {
   try {
    const response = await apiClient.get<ApiResponse<ListingData>>(`/ongoing/${page}`);
    return response.data.data;
  } catch (error) {
    console.error('Ongoing error:', error);
    return null;
  }
}

export const getCompleted = async (page: number = 1): Promise<ListingData | null> => {
   try {
    const response = await apiClient.get<ApiResponse<ListingData>>(`/completed/${page}`);
    return response.data.data;
  } catch (error) {
    console.error('Completed error:', error);
    return null;
  }
}

export const getGenres = async (slug: string, page: number = 1): Promise<ListingData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<ListingData>>(`/genres/${slug}/${page}`);
    return response.data.data;
  } catch (error) {
    console.error('Genres error:', error);
    return null;
  }
}

export const getAzList = async (page: number = 1, letter?: string): Promise<ListingData | null> => {
  try {
    let url = `/a-z/${page}`;
    if (letter) {
      url = `/a-z/${letter}/${page}`;
    }
    const response = await apiClient.get<ApiResponse<ListingData>>(url);
    return response.data.data;
  } catch (error) {
    console.error('AZ List error:', error);
    return null;
  }
}

export const getFilterValues = async (): Promise<FilterOptionsData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<FilterOptionsData>>('/filters/value');
    return response.data.data;
  } catch (error) {
    console.error('Filter values error:', error);
    return null;
  }
}

export const getAdvancedSearch = async (page: number = 1, queryParams: any = {}): Promise<ListingData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<ListingData>>(`/filters/${page}/`, {
      params: queryParams
    });
    return response.data.data;
  } catch (error) {
    console.error('Advanced search error:', error);
    return null;
  }
}

export const getRandomDonghua = async (): Promise<RandomData | null> => {
  try {
    const response = await apiClient.get<ApiResponse<RandomData>>('/random');
    return response.data.data;
  } catch (error) {
    console.error('Random error:', error);
    return null;
  }
}

// Helper to sanitize next/prev urls from API if they contain full domain
export const extractPageNumber = (url: string): number | null => {
  if (!url) return null;
  const match = url.match(/page\/(\d+)/) || url.match(/page=(\d+)/);
  if (match && match[1]) {
    return parseInt(match[1]);
  }
  return null;
}