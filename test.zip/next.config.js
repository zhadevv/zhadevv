/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: [
      'anichin.cafe',
      'i0.wp.com',
      'i1.wp.com',
      'i2.wp.com',
      'via.placeholder.com',
      'picsum.photos',
      'i.pravatar.cc'
    ],
  },
  env: {
    SITE_NAME: process.env.SITE_NAME || 'Anidong',
    SITE_URL: process.env.SITE_URL || 'http://localhost:3000',
  }
}

module.exports = nextConfig