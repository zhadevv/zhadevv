/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
    "./App.tsx",
    "./index.html"
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: '#3b82f6', // Blue-500
        background: '#ffffff',
        surface: '#f3f4f6', // Gray-100
        darkBackground: '#0f172a', // Slate-900
        darkSurface: '#1e293b', // Slate-800
      },
    },
  },
  plugins: [],
}