# Anidong - Streaming Donghua Platform

Anidong is a modern, responsive, and full-stack web application for streaming Donghua (Chinese Anime). Built with Next.js, SQLite, and Tailwind CSS.

## Features

- **Full Stack Authentication**: Secure Login and Registration using SQLite and JWT.
- **Admin Dashboard**: Manage Ads/Banner placements easily.
- **Responsive Design**: Mobile-first approach with Tailwind CSS.
- **Advanced Search**: Filter by Genre, Status, Type, and more.
- **User Dashboard**: Track Watch History and manage Bookmarks.
- **Comments System**: Discuss episodes with other users.
- **Schedule**: Weekly release schedule tracking.
- **Dark Mode**: Built-in theme toggling.

## Tech Stack

- **Frontend**: React, Next.js, Tailwind CSS, Swiper.js, React Icons.
- **Backend**: Next.js API Routes.
- **Database**: Better-SQLite3.
- **Authentication**: JWT (JSON Web Tokens), Bcrypt.

## Prerequisites

- Node.js (v18 or higher recommended)
- npm or yarn

## Getting Started

1.  **Clone the repository**
    ```bash
    git clone https://github.com/username/anidong.git
    cd anidong
    ```

2.  **Install dependencies**
    ```bash
    npm install
    # or
    yarn install
    ```

3.  **Configure Environment Variables**
    Create a `.env` file in the root directory and add the following:

    ```env
    # Site Config
    SITE_NAME=Anidong
    SITE_URL=http://localhost:3000

    # API Configuration
    ZHADEV_APIKEY=your_optional_api_key_here

    # Auth Secrets
    JWT_SECRET=your_super_secret_jwt_key_must_be_long
    NEXTAUTH_SECRET=your_nextauth_secret
    
    # Admin Configuration
    # Important: The user with this email will have Admin access
    ADMIN_EMAIL=admin@anidong.my.id
    
    # Database (Optional, defaults to ./src/data/anidong.db)
    DATABASE_URL=./src/data/anidong.db
    ```

4.  **Initialize Database**
    The database tables are automatically created when the application starts/connects for the first time. No manual migration script is required for the initial setup.

5.  **Run Development Server**
    ```bash
    npm run dev
    ```

    Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Admin Setup

1.  Register a new account on the frontend with the email address specified in `ADMIN_EMAIL` (e.g., `admin@anidong.my.id`).
2.  Log in with that account.
3.  You will see an "Admin" link in the header menu.
4.  Navigate to the Admin Dashboard to manage Ads and view stats.

## Folder Structure

- `src/pages`: Next.js pages and API routes.
- `src/components`: Reusable UI components.
- `src/models`: Database connection and helper functions.
- `src/services`: External API integration services.
- `src/styles`: Global CSS and Tailwind directives.
- `src/types.ts`: TypeScript interfaces.

## API Documentation

- **Auth**: `/api/auth/[signup|signin|me|refresh]`
- **User**: `/api/user/[bookmark|history]`
- **Comments**: `/api/comments`
- **Ads**: `/api/ads` (Public), `/api/admin/ads` (Private)

## License

This project is for educational purposes.

---

**Note**: The video content is served via an external API and iframe embedding. Anidong does not host video files locally.
