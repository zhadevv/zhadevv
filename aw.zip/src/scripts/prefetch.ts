import AnichinScraper from '@zhadev/anichin';
import { LocalCache } from '../utils/cache-local';

const scraper = new AnichinScraper({
  baseUrl: 'https://anichin.cafe',
  timeout: 30000,
});

async function runPrefetch() {
  console.log('Starting API Prefetch...');

  try {
    // 1. Prefetch Home
    console.log('Fetching Home...');
    const homeData = await scraper.home(1);
    if (homeData.success) {
      LocalCache.write('home', homeData.data.home, { page: 1 });
    }

    // 2. Prefetch Schedule
    console.log('Fetching Schedule...');
    const scheduleData = await scraper.schedule();
    if (scheduleData.success) {
      LocalCache.write('schedule', scheduleData.data.schedule);
    }

    // 3. Prefetch Ongoing
    console.log('Fetching Ongoing...');
    const ongoingData = await scraper.ongoing(1);
    if (ongoingData.success) {
      LocalCache.write('ongoing', ongoingData.data, { page: 1 });
    }

    // 4. Prefetch Completed
    console.log('Fetching Completed...');
    const completedData = await scraper.completed(1);
    if (completedData.success) {
      LocalCache.write('completed', completedData.data, { page: 1 });
    }

    // 5. Prefetch Filters (for advanced search)
    console.log('Fetching Filters...');
    const filtersData = await scraper.quickfilter();
    if (filtersData.success) {
        LocalCache.write('quickfilter', filtersData.data);
    }

    // 6. Create Sidebar Data (Static + Dynamic)
    console.log('Generating Sidebar...');
    const sidebarData = {
        genres: [
            { title: "Action", url: "/genres/action" },
            { title: "Adventure", url: "/genres/adventure" },
            { title: "Martial Arts", url: "/genres/martial-arts" },
            { title: "Fantasy", url: "/genres/fantasy" },
            { title: "Magic", url: "/genres/magic" },
            { title: "Romance", url: "/genres/romance" },
            { title: "School", url: "/genres/school" },
            { title: "Comedy", url: "/genres/comedy" },
            { title: "Drama", url: "/genres/drama" },
            { title: "Sci-Fi", url: "/genres/sci-fi" }
        ],
        partners: [
            { title: "Anichin", url: "https://anichin.cafe" }
        ]
    };
    LocalCache.write('sidebar', sidebarData);

    console.log('Prefetch completed successfully.');
  } catch (error) {
    console.error('Prefetch failed:', error);
    (process as any).exit(1);
  }
}

runPrefetch();