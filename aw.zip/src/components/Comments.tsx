import React, { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import axios from 'axios';
import Button from '@/components/modal/Button';

export default function Comments({ slug }: { slug: string }) {
  const { data: session } = useSession();
  const [comments, setComments] = useState<any[]>([]);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchComments();
  }, [slug]);

  const fetchComments = async () => {
    try {
      const res = await axios.get(`/api/comment?slug=${slug}`);
      if (res.data.success) {
        setComments(res.data.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    setLoading(true);
    try {
      await axios.post('/api/comment', { slug, content: commentText });
      setCommentText('');
      fetchComments();
    } catch (e) {
      alert('Failed to post comment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bixbox commentx">
      <div className="releases"><h3>Comments</h3></div>
      <div className="cmt">
        <div id="respond">
            {session ? (
                <form onSubmit={handleSubmit}>
                    <textarea 
                        name="comment" 
                        id="comment" 
                        cols={45} 
                        rows={4} 
                        placeholder="Type your comment here..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        required
                    ></textarea>
                    <div className="mt-2 text-right">
                        <Button type="submit" isLoading={loading}>Post Comment</Button>
                    </div>
                </form>
            ) : (
                <div className="p-4 bg-gray-100 text-center rounded">
                    Please <a href="/auth" className="text-blue-600 font-bold">Login</a> to post a comment.
                </div>
            )}
        </div>

        <div className="mt-6">
            <ul className="comment-list">
                {comments.length > 0 ? comments.map((comment) => (
                    <li key={comment.id}>
                        <div className="comment-body">
                            <div className="comment-author vcard">
                                <img src={`https://ui-avatars.com/api/?name=${comment.user_name}&background=random`} alt="" className="avatar" />
                                <cite className="fn">
                                    {comment.user_name} 
                                    {comment.user_role === 'admin' && <span className="ml-2 px-1 bg-red-600 text-white text-xs rounded">Admin</span>}
                                </cite>
                            </div>
                            <div className="comment-meta">
                                {new Date(comment.created_at).toLocaleString()}
                            </div>
                            <p>{comment.content}</p>
                        </div>
                    </li>
                )) : (
                    <li className="text-center text-gray-500">No comments yet. Be the first!</li>
                )}
            </ul>
        </div>
      </div>
    </div>
  );
}