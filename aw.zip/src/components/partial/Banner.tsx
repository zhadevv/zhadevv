import Link from 'next/link';
import { useEffect } from 'react';

export default function Banner({ items }: { items: any[] }) {
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).jQuery) {
        const $ = (window as any).jQuery;
        if ($('.owl-carousel').length) {
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                items: 1,
                autoplay: true,
                autoplayTimeout: 5000
            });
        }
    }
  }, [items]);

  if (!items || items.length === 0) return null;

  return (
    <div className="slidtop">
        <div className="owl-carousel owl-theme">
            {items.map((item, idx) => (
                <div className="slide-item" key={idx}>
                    <div className="slide-content">
                        <Link href={item.url.replace('https://anichin.cafe', '')}>
                            <div className="slide-shadow"></div>
                            <img src={item.thumbnail} alt={item.title} className="w-full h-64 object-cover" />
                            <div className="text-content absolute bottom-0 left-0 p-4 text-white z-10">
                                <h2 className="text-xl font-bold">{item.title}</h2>
                                <p className="text-sm line-clamp-2">{item.description}</p>
                            </div>
                        </Link>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
}
