import Link from 'next/link';
import { useRouter } from 'next/router';

export default function AdminNav() {
    const router = useRouter();
    
    const navs = [
        { label: 'Dashboard', href: '/dashboard/admin' },
        { label: 'Users', href: '/dashboard/admin/user' },
        { label: 'Ads', href: '/dashboard/admin/ad-slot' },
        { label: 'Reports', href: '/dashboard/admin/reports' },
        { label: 'Broadcast', href: '/dashboard/admin/broadcast' },
        { label: 'Settings', href: '/dashboard/admin/settings' },
        { label: 'Tools', href: '/dashboard/admin/tools' },
    ];

    return (
        <div className="mb-6 pb-2 overflow-x-auto">
            <div className="flex gap-2">
                {navs.map(nav => (
                    <Link 
                        key={nav.href} 
                        href={nav.href}
                        className={`px-4 py-2 rounded text-sm font-bold whitespace-nowrap transition-colors ${
                            router.pathname === nav.href 
                                ? 'bg-blue-600 text-white shadow-md' 
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                    >
                        {nav.label}
                    </Link>
                ))}
            </div>
        </div>
    );
}