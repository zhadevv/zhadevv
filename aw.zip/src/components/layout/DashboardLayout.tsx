import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { signOut, useSession } from 'next-auth/react';
import React, { useEffect } from 'react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth');
    }
  }, [status, router]);

  if (status === 'loading') return <div id="content"><div className="wrapper p-10 text-center">Loading...</div></div>;
  if (!session) return null;

  const navItems = [
    { label: 'Dashboard', href: '/dashboard', icon: 'fa-tachometer-alt' },
    { label: 'My Bookmarks', href: '/dashboard/profile', icon: 'fa-bookmark' },
    { label: 'Watch History', href: '/dashboard/history', icon: 'fa-history' },
    { label: 'Settings', href: '/dashboard/settings', icon: 'fa-cog' },
  ];

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>User Dashboard</h3></div>
                <div className="p-6">
                    <div className="flex flex-col md:flex-row gap-6">
                        {/* Sidebar Navigation */}
                        <div className="w-full md:w-1/4">
                            <div className="bg-gray-50 border rounded-lg p-4 sticky top-4">
                                <div className="text-center mb-6 pb-4 border-b">
                                    <div className="w-20 h-20 rounded-full bg-blue-100 mx-auto mb-3 flex items-center justify-center text-blue-600 text-3xl font-bold">
                                        {session.user?.name?.charAt(0).toUpperCase()}
                                    </div>
                                    <h4 className="font-bold text-gray-800 truncate">{session.user?.name}</h4>
                                    <p className="text-xs text-gray-500 truncate">{session.user?.email}</p>
                                    {session.user?.role === 'admin' && (
                                        <Link href="/dashboard/admin" className="mt-2 inline-block text-xs bg-red-600 text-white px-2 py-1 rounded">
                                            Admin Panel
                                        </Link>
                                    )}
                                </div>
                                <nav className="flex flex-col space-y-1">
                                    {navItems.map((item) => (
                                        <Link 
                                            key={item.href} 
                                            href={item.href}
                                            className={`flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                                                router.pathname === item.href
                                                    ? 'bg-blue-600 text-white'
                                                    : 'text-gray-700 hover:bg-gray-200'
                                            }`}
                                        >
                                            <i className={`fas ${item.icon} w-6 text-center mr-2`}></i>
                                            {item.label}
                                        </Link>
                                    ))}
                                    <button 
                                        onClick={() => signOut({ callbackUrl: '/' })}
                                        className="flex items-center px-4 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 transition-colors w-full text-left mt-4 border-t pt-4"
                                    >
                                        <i className="fas fa-sign-out-alt w-6 text-center mr-2"></i>
                                        Logout
                                    </button>
                                </nav>
                            </div>
                        </div>

                        {/* Main Content */}
                        <div className="w-full md:w-3/4">
                            <div className="bg-white border rounded-lg p-6 min-h-[400px]">
                                {children}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}