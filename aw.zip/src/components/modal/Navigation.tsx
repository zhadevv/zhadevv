import Link from 'next/link';

interface PaginationProps {
  current: number;
  total?: number; // Optional if not known
  hasNext: boolean;
  hasPrev: boolean;
  baseUrl: string;
}

export default function Navigation({ current, hasNext, hasPrev, baseUrl }: PaginationProps) {
  const cleanUrl = (url: string) => url.replace(/\/page\/\d+\/?$/, '');
  const base = cleanUrl(baseUrl);

  return (
    <div className="pagination">
      {hasPrev && (
        <Link href={current - 1 === 1 ? base : `${base}/page/${current - 1}`} className="prev">
          Previous
        </Link>
      )}
      <span className="page-numbers current">{current}</span>
      {hasNext && (
        <Link href={`${base}/page/${current + 1}`} className="next">
          Next
        </Link>
      )}
    </div>
  );
}