import AnichinScraper from '@zhadev/anichin';
import axios from 'axios';
import { LocalCache } from '@/utils/cache-local';

const scraper = new AnichinScraper({
  baseUrl: process.env.SCRAPER_BASE_URL || 'https://anichin.cafe',
  timeout: parseInt(process.env.API_TIMEOUT || '30000'),
});

const FALLBACK_API = 'https://anidong-api.vercel.app/api/v1/donghua';

export const ZhadevService = {
  async getHome(page = 1) {
    try {
      const response = await scraper.home(page);
      if (response.success) return response.data.home;
      throw new Error(response.message || 'Scraper failed');
    } catch (e) {
      const cached = LocalCache.read('home', { page });
      if (cached) return cached;
      
      try {
        const res = await axios.get(`${FALLBACK_API}/home/${page}`);
        return res.data.data;
      } catch (err) {
        return null;
      }
    }
  },

  async getSearch(query: string, page = 1) {
    try {
      const response = await scraper.search(query, page);
      if (response.success) return response.data.search;
      throw new Error('Search failed');
    } catch (e) {
      const cached = LocalCache.read('search', { query, page });
      if (cached) return cached;

      try {
        const res = await axios.get(`${FALLBACK_API}/search/${page}?s=${query}`);
        return { lists: res.data.data.items, pagination: res.data.data.pagination };
      } catch (err) {
        return { lists: [], pagination: {} };
      }
    }
  },

  async getSeries(slug: string) {
    try {
      const response = await scraper.series(slug);
      if (response.success) return response.data.detail;
      throw new Error('Series detail failed');
    } catch (e) {
      const cached = LocalCache.read('series', { slug });
      if (cached) return cached;

      try {
        const res = await axios.get(`${FALLBACK_API}/detail/${slug}`);
        return res.data.data;
      } catch (err) {
        return null;
      }
    }
  },

  async getWatch(slug: string, episode: number | string) {
    try {
      const parts = slug.split('-episode-');
      const seriesSlug = parts[0];
      const epNum = parts[1]?.replace('-subtitle-indonesia', '') || episode;

      const response = await scraper.watch(seriesSlug, parseInt(epNum as string));
      if (response.success) return response.data.watch;
      throw new Error('Watch failed');
    } catch (e) {
       const cached = LocalCache.read('watch', { slug }); 
       if (cached) return cached;

       try {
        const res = await axios.get(`${FALLBACK_API}/watch/${slug}/${episode}`);
        return res.data.data;
      } catch (err) {
        return null;
      }
    }
  },

  async getSchedule() {
    try {
      const response = await scraper.schedule();
      if (response.success) return response.data.schedule;
      throw new Error('Schedule failed');
    } catch (e) {
        const cached = LocalCache.read('schedule');
        if (cached) return cached;
       try {
        const res = await axios.get(`${FALLBACK_API}/schedule`);
        return res.data.data;
      } catch (err) {
        return null;
      }
    }
  },

  async getOngoing(page = 1) {
    try {
      const response = await scraper.ongoing(page);
      if (response.success) return response.data;
      throw new Error('Ongoing failed');
    } catch (e) {
        const cached = LocalCache.read('ongoing', { page });
        if (cached) return cached;

        try {
        const res = await axios.get(`${FALLBACK_API}/ongoing/${page}`);
        return { lists: res.data.data.items, pagination: res.data.data.pagination };
      } catch (err) {
        return null;
      }
    }
  },

  async getCompleted(page = 1) {
    try {
      const response = await scraper.completed(page);
      if (response.success) return response.data;
      throw new Error('Completed failed');
    } catch (e) {
        const cached = LocalCache.read('completed', { page });
        if (cached) return cached;

        try {
        const res = await axios.get(`${FALLBACK_API}/completed/${page}`);
        return { lists: res.data.data.items, pagination: res.data.data.pagination };
      } catch (err) {
        return null;
      }
    }
  },

  async getGenre(slug: string, page = 1) {
    try {
        const response = await scraper.genres(slug, page);
        if(response.success) return response.data;
        throw new Error('Genre failed');
    } catch (e) {
        const cached = LocalCache.read('genre', { slug, page });
        if (cached) return cached;

        try {
            const res = await axios.get(`${FALLBACK_API}/genres/${slug}/${page}`);
            return { lists: res.data.data.items, pagination: res.data.data.pagination, genre: { name: res.data.data.genre_title } };
        } catch(err) {
            return null;
        }
    }
  },

  async getAzList(letter = 'A', page = 1) {
      try {
          const response = await scraper.azlist(page, letter);
          if(response.success) return response.data;
          throw new Error('AZ List failed');
      } catch(e) {
          try {
              const res = await axios.get(`${FALLBACK_API}/a-z/${letter}/${page}`);
              return { lists: res.data.data.items, pagination: res.data.data.pagination };
          } catch(err) {
              return null;
          }
      }
  },

  async getStudio(slug: string, page = 1) {
    try {
      const response = await scraper.studio(slug, page);
      if (response.success) return response.data;
      throw new Error('Studio failed');
    } catch (e) {
      const cached = LocalCache.read('studio', { slug, page });
      if (cached) return cached;
      return null;
    }
  },

  async getNetwork(slug: string, page = 1) {
    try {
      const response = await scraper.network(slug, page);
      if (response.success) return response.data;
      throw new Error('Network failed');
    } catch (e) {
      const cached = LocalCache.read('network', { slug, page });
      if (cached) return cached;
      return null;
    }
  },

  async getSeason(slug: string, page = 1) {
    try {
      const response = await scraper.season(slug, page);
      if (response.success) return response.data;
      throw new Error('Season failed');
    } catch (e) {
      const cached = LocalCache.read('season', { slug, page });
      if (cached) return cached;
      return null;
    }
  },

  async getCountry(slug: string, page = 1) {
    try {
      const response = await scraper.country(slug, page);
      if (response.success) return response.data;
      throw new Error('Country failed');
    } catch (e) {
      const cached = LocalCache.read('country', { slug, page });
      if (cached) return cached;
      return null;
    }
  },

  async getAdvancedSearch(page = 1, filters = {}) {
    try {
      // @ts-ignore
      const response = await scraper.advancedsearch('image', filters, page);
      if (response.success) return response.data;
      throw new Error('Advanced search failed');
    } catch (e) {
        try {
            const queryString = new URLSearchParams(filters as any).toString();
            const res = await axios.get(`${FALLBACK_API}/filters/${page}?${queryString}`);
            return { lists: res.data.data.items, pagination: res.data.data.pagination };
        } catch(err) {
            return null;
        }
    }
  },
  
  async getQuickFilters() {
      try {
          const response = await scraper.quickfilter();
          if (response.success) return response.data;
          throw new Error('Quick Filter Failed');
      } catch (e) {
          const cached = LocalCache.read('quickfilter');
          if (cached) return cached;
          return null;
      }
  },

  async getSidebar() {
      try {
          const cached = LocalCache.read('sidebar');
          if (cached) return cached;
          // Fallback static data if not cached
          return {
              genres: [
                  { title: "Action", url: "/genres/action" },
                  { title: "Adventure", url: "/genres/adventure" },
                  { title: "Comedy", url: "/genres/comedy" },
                  { title: "Drama", url: "/genres/drama" },
                  { title: "Ecchi", url: "/genres/ecchi" },
                  { title: "Fantasy", url: "/genres/fantasy" },
                  { title: "Harem", url: "/genres/harem" },
                  { title: "Historical", url: "/genres/historical" },
                  { title: "Horror", url: "/genres/horror" },
                  { title: "Josei", url: "/genres/josei" },
                  { title: "Magic", url: "/genres/magic" },
                  { title: "Martial Arts", url: "/genres/martial-arts" },
                  { title: "Mecha", url: "/genres/mecha" },
                  { title: "Music", url: "/genres/music" },
                  { title: "Mystery", url: "/genres/mystery" },
                  { title: "Psychological", url: "/genres/psychological" },
                  { title: "Romance", url: "/genres/romance" },
                  { title: "Sci-Fi", url: "/genres/sci-fi" },
                  { title: "Seinen", url: "/genres/seinen" },
                  { title: "Shoujo", url: "/genres/shoujo" },
                  { title: "Shounen", url: "/genres/shounen" },
                  { title: "Slice of Life", url: "/genres/slice-of-life" },
                  { title: "Sports", url: "/genres/sports" },
                  { title: "Supernatural", url: "/genres/supernatural" },
                  { title: "Thriller", url: "/genres/thriller" }
              ]
          };
      } catch (e) {
          return null;
      }
  }
};