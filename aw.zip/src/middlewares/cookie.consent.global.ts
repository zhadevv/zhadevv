import { NextApiRequest, NextApiResponse } from 'next';

export const checkCookieConsent = (req: NextApiRequest, res: NextApiResponse) => {
  const consent = req.cookies['cookie_consent'];
  if (!consent) {
    // Logic to maybe set a flag header or similar if needed for server-side checks
    // Usually handled client-side
  }
};