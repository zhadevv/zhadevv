import db from '@/models/database';

export const loadGlobalConfig = () => {
  try {
    const stmt = db.prepare('SELECT key, value FROM settings');
    const rows = stmt.all() as { key: string; value: string }[];
    const config: Record<string, string> = {};
    rows.forEach(row => {
      config[row.key] = row.value;
    });
    return config;
  } catch (error) {
    return {};
  }
};