import { createContext, useContext, useState } from 'react';

type MiscContextType = {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  closeSidebar: () => void;
};

// Creating a simple React Context as a store since no external lib like Zustand was in package.json
export const MiscContext = createContext<MiscContextType>({
  isSidebarOpen: false,
  toggleSidebar: () => {},
  closeSidebar: () => {},
});

export const useMiscStore = () => useContext(MiscContext);