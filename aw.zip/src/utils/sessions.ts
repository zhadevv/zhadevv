export const saveSession = (token: string) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('session_token', token);
  }
};

export const getSessionToken = () => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('session_token');
  }
  return null;
};

export const clearSession = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('session_token');
  }
};