import fs from 'fs';
import path from 'path';

const CACHE_DIR = path.join((process as any).cwd(), 'src', 'data', 'api.loaded');

type CacheType = 
  | 'home' 
  | 'schedule' 
  | 'ongoing' 
  | 'completed' 
  | 'quickfilter' 
  | 'sidebar' 
  | 'search'
  | 'genre'
  | 'studio'
  | 'network'
  | 'season'
  | 'country'
  | 'series'
  | 'watch';

interface CacheOptions {
  page?: number;
  query?: string;
  slug?: string;
  seriesSlug?: string;
}

const getFilePath = (type: CacheType, options: CacheOptions = {}) => {
  const page = options.page || 1;
  const isPaged = page > 1;
  const safeSlug = options.slug ? decodeURIComponent(options.slug) : '';
  const safeQuery = options.query ? decodeURIComponent(options.query) : '';

  let relativePath = '';

  switch (type) {
    case 'sidebar':
    case 'schedule':
    case 'quickfilter':
      return path.join('without_pagination', `${type}.json`);

    case 'home':
      relativePath = path.join('with_pagination', 'home');
      return path.join(relativePath, isPaged ? `page/home_${page}.json` : 'home.json');

    case 'ongoing':
    case 'completed':
      relativePath = path.join('with_pagination', 'lists', type);
      return path.join(relativePath, isPaged ? `page/${type}_${page}.json` : `${type}.json`);

    case 'search':
      if (!safeQuery) throw new Error('Query required for search cache');
      relativePath = path.join('with_pagination', 'search', 'query', safeQuery);
      return path.join(relativePath, isPaged ? `page/${safeQuery}_${page}.json` : `${safeQuery}.json`);

    case 'genre':
    case 'network':
    case 'season':
    case 'studio':
    case 'country':
      // Maps to: with_pagination/with_slug/lists/{type}/{slug}/...
      if (!safeSlug) throw new Error('Slug required for list cache');
      // Pluralize directory name if needed (e.g., genre -> genres), currently using type as is or mapping custom
      const dirMap: Record<string, string> = { genre: 'genres' };
      const listDir = dirMap[type] || type;
      relativePath = path.join('with_pagination', 'with_slug', 'lists', listDir, safeSlug);
      return path.join(relativePath, isPaged ? `page/${safeSlug}_${page}.json` : `${safeSlug}.json`);

    case 'series':
      if (!safeSlug) throw new Error('Slug required for series cache');
      return path.join('with_pagination', 'with_slug', 'series', 'slug', safeSlug, `${safeSlug}.json`);

    case 'watch':
      // Maps to: with_pagination/with_slug/series/slug/{seriesSlug}/watch/{slug}.json
      if (!safeSlug) throw new Error('Slug required for watch cache');
      // We try to extract series slug from episode slug if seriesSlug not provided, but ideally provided
      const sSlug = options.seriesSlug || safeSlug.split('-episode-')[0];
      return path.join('with_pagination', 'with_slug', 'series', 'slug', sSlug, 'watch', `${safeSlug}.json`);

    default:
      return `${type}.json`;
  }
};

export const LocalCache = {
  write: (type: CacheType, data: any, options: CacheOptions = {}) => {
    try {
      const relPath = getFilePath(type, options);
      const fullPath = path.join(CACHE_DIR, relPath);
      const dirPath = path.dirname(fullPath);

      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }

      fs.writeFileSync(fullPath, JSON.stringify(data, null, 2));
      console.log(`[Cache] Wrote to ${relPath}`);
    } catch (error) {
      console.error(`[Cache] Error writing ${type}:`, error);
    }
  },

  read: (type: CacheType, options: CacheOptions = {}) => {
    try {
      const relPath = getFilePath(type, options);
      const fullPath = path.join(CACHE_DIR, relPath);

      if (fs.existsSync(fullPath)) {
        const fileContent = fs.readFileSync(fullPath, 'utf-8');
        console.log(`[Cache] Hit: ${relPath}`);
        return JSON.parse(fileContent);
      }
    } catch (error) {
      // Ignore errors, return null
    }
    return null;
  },

  exists: (type: CacheType, options: CacheOptions = {}) => {
      try {
          const relPath = getFilePath(type, options);
          return fs.existsSync(path.join(CACHE_DIR, relPath));
      } catch (e) {
          return false;
      }
  }
};