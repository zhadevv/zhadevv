import { GetServerSideProps } from 'next';
import Banner from '@/components/partial/Banner';
import Sidebar from '@/components/partial/Sidebar';
import SeriesGrid from '@/components/modal/SeriesGrid';
import Comments from '@/components/Comments';
import Layout from '@/pages/layout';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import axios from 'axios';
import Button from '@/components/modal/Button';
import { useNotification } from '@/context/NotificationContext';

interface PageProps {
  type: 'home' | 'watch' | 'ongoing' | 'completed' | 'notfound';
  data: any;
}

export default function IndexPage({ type, data }: PageProps) {
  const { data: session } = useSession();
  const { notify } = useNotification();
  
  // Watch Page State
  const [lightsOff, setLightsOff] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('video_broken');
  const [reportDesc, setReportDesc] = useState('');
  const [reportSending, setReportSending] = useState(false);

  // Watch History Logic
  useEffect(() => {
      if (type === 'watch' && data && session) {
          axios.post('/api/user/action', {
              action: 'history',
              slug: data.slug,
              episode: data.episode_number || data.episode
          }).catch(err => console.error('Failed to save history', err));
      }
  }, [type, data, session]);

  const handleReport = async (e: React.FormEvent) => {
      e.preventDefault();
      setReportSending(true);
      try {
          await axios.post('/api/report', {
              slug: data.slug,
              episode: data.episode_number || data.episode,
              reason: reportReason,
              description: reportDesc
          });
          notify('Laporan berhasil dikirim. Terima kasih!', 'success');
          setShowReport(false);
          setReportDesc('');
      } catch (err) {
          notify('Gagal mengirim laporan.', 'error');
      } finally {
          setReportSending(false);
      }
  };

  if (type === 'notfound' || !data) {
    return (
        <Layout title="404 Not Found">
            <div className="postbody">
                <div className="bixbox">
                    <div className="releases"><h1>404 Not Found</h1></div>
                </div>
            </div>
        </Layout>
    );
  }

  const renderHome = () => (
    <Layout>
        <div className="postbody">
        {data.slider && <Banner items={data.slider} />}
        <div className="bixbox">
            <div className="releases hothome">
                <h3>Popular Today</h3>
            </div>
            <SeriesGrid items={data.popular_today} />
        </div>
        <div className="bixbox">
            <div className="releases latesthome">
                <h3>Latest Release</h3>
            </div>
            <SeriesGrid items={data.latest_release} />
        </div>
        </div>
        <Sidebar />
    </Layout>
  );

  const renderWatch = () => (
    <Layout 
        title={`Nonton ${data.title} Subtitle Indonesia`} 
        description={`Streaming ${data.title} Subtitle Indonesia gratis di Anidong.`}
        image={data.thumbnail}
        type="video.episode"
    >
        <div className="postbody">
        {lightsOff && <div id="shadow" style={{display: 'block'}} onClick={() => setLightsOff(false)}></div>}
        
        <div className={`bixbox episodedl ${expanded ? 'megavid xp' : ''}`} style={lightsOff ? {position: 'relative', zIndex: 101} : {}}>
            <div className="epwrapper">
                <div className="epheader">
                    <h1>{data.title}</h1>
                    <div className="entry-info">
                    <span>Posted by {data.posted_by} on {data.released_on || data.release_date}</span>
                    </div>
                </div>
                
                <div className="video-nav">
                    <div className="iconx">
                        <div className={`icol ${lightsOff ? 'turnedOff' : ''}`} onClick={() => setLightsOff(!lightsOff)} title="Lights">
                            <i className="far fa-lightbulb"></i> <span>Light</span>
                        </div>
                        <div className="icol" onClick={() => setExpanded(!expanded)} title="Expand">
                            <i className="fas fa-expand"></i> <span>Expand</span>
                        </div>
                        <div className="icol" onClick={() => setShowReport(true)} title="Report">
                            <i className="fas fa-exclamation-triangle text-red-500"></i> <span className="text-red-500">Report</span>
                        </div>
                    </div>
                </div>

                <div className="epcontent" id="embed_holder">
                    <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
                        <iframe 
                            src={data.servers?.[0]?.server_url} 
                            style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }} 
                            frameBorder="0" 
                            allowFullScreen 
                        />
                    </div>
                </div>
                
                <div className="navimedia" style={{marginTop: '20px'}}>
                    <div className="naveps">
                        {data.episode_navigation?.prev_episode?.url && (
                            <div className="nvs"><Link href={data.episode_navigation.prev_episode.url.replace('https://anichin.cafe', '')}>Prev</Link></div>
                        )}
                        <div className="nvs nvsc"><Link href={data.episode_navigation?.all_episodes?.url?.replace('https://anichin.cafe', '') || '#'}>All</Link></div>
                        {data.episode_navigation?.next_episode?.url && (
                            <div className="nvs"><Link href={data.episode_navigation.next_episode.url.replace('https://anichin.cafe', '')}>Next</Link></div>
                        )}
                    </div>
                </div>
                
                {data.downloads && (
                    <div className="dlbox">
                        <div className="releases"><h3>Download</h3></div>
                        <ul>
                            {data.downloads.map((dl: any, idx: number) => (
                                <li key={idx}>
                                    <span className="q">{dl.title}</span>
                                    {dl.qualities?.map((q: any, qIdx: number) => (
                                        <span key={qIdx}>
                                            <strong>{q.quality}</strong>: 
                                            {q.links?.map((l: any, lIdx: number) => (
                                                <a href={l.url} key={lIdx} target="_blank" rel="noreferrer" className="ml-2 mr-2 text-blue-500">{l.name}</a>
                                            ))}
                                        </span>
                                    ))}
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>
        </div>

            {/* Report Modal */}
            {showReport && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black bg-opacity-50">
                    <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
                        <h3 className="text-lg font-bold mb-4 text-gray-800">Lapor Video Rusak</h3>
                        <form onSubmit={handleReport}>
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">Masalah</label>
                                <select 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 text-gray-800"
                                    value={reportReason}
                                    onChange={(e) => setReportReason(e.target.value)}
                                >
                                    <option value="video_broken">Video tidak bisa diputar</option>
                                    <option value="wrong_episode">Episode salah</option>
                                    <option value="audio_issue">Masalah Audio/Subtitle</option>
                                    <option value="other">Lainnya</option>
                                </select>
                            </div>
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">Deskripsi (Opsional)</label>
                                <textarea 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 text-gray-800"
                                    rows={3}
                                    value={reportDesc}
                                    onChange={(e) => setReportDesc(e.target.value)}
                                    placeholder="Jelaskan lebih detail..."
                                ></textarea>
                            </div>
                            <div className="flex justify-end gap-2">
                                <button 
                                    type="button" 
                                    onClick={() => setShowReport(false)}
                                    className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
                                >
                                    Batal
                                </button>
                                <Button type="submit" isLoading={reportSending}>
                                    Kirim Laporan
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

        <Comments slug={data.slug} />
        <Sidebar />
    </Layout>
  );

  const renderList = (title: string) => (
      <Layout title={title}>
          <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>{title}</h3></div>
                <SeriesGrid items={data.lists} />
                {data.pagination && (
                    <div className="pagination">
                        {data.pagination.has_prev && (
                            <Link href={data.pagination.prev.url.replace('https://anichin.cafe', '')} className="prev">Previous</Link>
                        )}
                        {data.pagination.has_next && (
                            <Link href={data.pagination.next.url.replace('https://anichin.cafe', '')} className="next">Next</Link>
                        )}
                    </div>
                )}
            </div>
        </div>
        <Sidebar />
      </Layout>
  );

  if (type === 'home') return renderHome();
  if (type === 'watch') return renderWatch();
  if (type === 'ongoing') return renderList('Ongoing Series');
  if (type === 'completed') return renderList('Completed Series');

  return null;
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { index } = context.params || {};
  
  // Home Page
  if (!index) {
    const data = await ZhadevService.getHome();
    return { props: { type: 'home', data } };
  }

  // Ongoing
  if (index.length === 1 && index[0] === 'ongoing') {
    const data = await ZhadevService.getOngoing(parseInt(context.query.page as string || '1'));
    return { props: { type: 'ongoing', data } };
  }

  // Completed
  if (index.length === 1 && index[0] === 'completed') {
    const data = await ZhadevService.getCompleted(parseInt(context.query.page as string || '1'));
    return { props: { type: 'completed', data } };
  }

  // Watch (Pattern: slug-episode-number-subtitle-indonesia)
  const slugStr = Array.isArray(index) ? index.join('/') : index;
  if (slugStr.includes('-episode-') || slugStr.endsWith('subtitle-indonesia')) {
     const data = await ZhadevService.getWatch(slugStr, 1);
     if (!data) return { props: { type: 'notfound', data: null } };
     return { props: { type: 'watch', data } };
  }

  return { props: { type: 'notfound', data: null } };
};