import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';

export default function ContactPage() {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Contact Us</h3></div>
                <div className="p-8 text-sm leading-relaxed">
                    <p className="mb-4">Have questions, suggestions, or just want to say hello? We'd love to hear from you!</p>
                    <p className="mb-4">You can reach us through the following channels:</p>
                    <ul className="list-disc ml-5 mb-4">
                        <li><strong>Email:</strong> support@anidong.my.id</li>
                        <li><strong>Discord:</strong> Join our server (Link coming soon)</li>
                    </ul>
                    <p>We try to respond to all inquiries within 24-48 hours.</p>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}