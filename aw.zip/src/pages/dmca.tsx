import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';

export default function DmcaPage() {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>DMCA</h3></div>
                <div className="p-8 text-sm leading-relaxed">
                    <p className="mb-4"><strong>Anidong</strong> respects the intellectual property rights of others. It is our policy to respond to any claim that Content posted on the Service infringes on the copyright or other intellectual property rights ("Infringement") of any person or entity.</p>
                    <p className="mb-4">If you are a copyright owner, or authorized on behalf of one, and you believe that the copyrighted work has been copied in a way that constitutes copyright infringement, please submit your claim via email to dmca@anidong.my.id, with the subject line: "Copyright Infringement" and include in your claim a detailed description of the alleged Infringement.</p>
                    <p className="mb-4">You may be held accountable for damages (including costs and attorneys' fees) for misrepresentation or bad-faith claims on the infringement of any Content found on and/or through the Service on your copyright.</p>
                    <h4 className="font-bold mb-2">DMCA Notice and Procedure for Copyright Infringement Claims</h4>
                    <p>You may submit a notification pursuant to the Digital Millennium Copyright Act (DMCA) by providing our Copyright Agent with the following information in writing (see 17 U.S.C 512(c)(3) for further detail):</p>
                    <ul className="list-disc ml-5 mt-2">
                        <li>An electronic or physical signature of the person authorized to act on behalf of the owner of the copyright's interest;</li>
                        <li>A description of the copyrighted work that you claim has been infringed, including the URL (i.e., web page address) of the location where the copyrighted work exists or a copy of the copyrighted work;</li>
                        <li>Identification of the URL or other specific location on the Service where the material that you claim is infringing is located;</li>
                        <li>Your address, telephone number, and email address;</li>
                        <li>A statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law;</li>
                        <li>A statement by you, made under penalty of perjury, that the above information in your notice is accurate and that you are the copyright owner or authorized to act on the copyright owner's behalf.</li>
                    </ul>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}