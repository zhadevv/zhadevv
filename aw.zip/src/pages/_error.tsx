import { NextPageContext } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';

function Error({ statusCode }: { statusCode: number }) {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox text-center p-20">
                <div className="releases"><h1>{statusCode ? `An error ${statusCode} occurred on server` : 'An error occurred on client'}</h1></div>
                <p className="mb-6">Please try again later.</p>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

Error.getInitialProps = ({ res, err }: NextPageContext) => {
  const statusCode = res ? res.statusCode : err ? err.statusCode : 404;
  return { statusCode };
};

export default Error;