import DashboardLayout from '@/components/layout/DashboardLayout';
import { useSession } from 'next-auth/react';
import React, { useState } from 'react';
import axios from 'axios';
import Button from '@/components/modal/Button';
import Input from '@/components/modal/Input';
import { useNotification } from '@/context/NotificationContext';

export default function SettingsPage() {
  const { data: session } = useSession();
  const { notify } = useNotification();
  const [formData, setFormData] = useState({
      name: session?.user?.name || '',
      password: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoading(true);
      try {
          const res = await axios.post('/api/user/update', formData);
          if (res.data.success) {
              notify('Profile updated successfully! Please re-login to see changes.', 'success');
              setFormData({...formData, password: ''});
          }
      } catch (e: any) {
          notify(e.response?.data?.message || 'Update failed', 'error');
      } finally {
          setLoading(false);
      }
  };

  return (
    <DashboardLayout>
        <h2 className="text-xl font-bold mb-6 text-gray-800 border-b pb-2">Account Settings</h2>
        
        <form onSubmit={handleSubmit} className="max-w-md">
            <div className="mb-6">
                <label className="block text-gray-700 font-bold mb-2 text-sm">Email Address</label>
                <input 
                    type="email" 
                    defaultValue={session?.user?.email || ''} 
                    className="border rounded w-full py-2 px-3 text-gray-500 bg-gray-100 text-sm" 
                    disabled 
                />
                <p className="text-xs text-gray-400 mt-1">Email cannot be changed manually.</p>
            </div>

            <Input 
                label="Display Name" 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
            />

            <Input 
                label="New Password" 
                type="password"
                placeholder="Leave blank to keep current password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
            />
            
            <div className="mt-6">
                <Button type="submit" isLoading={loading}>
                    Save Changes
                </Button>
            </div>
        </form>
    </DashboardLayout>
  );
}