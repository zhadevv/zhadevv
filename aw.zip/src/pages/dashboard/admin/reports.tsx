import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import AdminNav from '@/components/partial/AdminNav';
import Button from '@/components/modal/Button';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Link from 'next/link';

export default function ReportsPage() {
  const [reports, setReports] = useState<any[]>([]);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
        const res = await axios.get('/api/admin/reports');
        if(res.data.success) setReports(res.data.data);
    } catch(e) {}
  };

  const handleStatus = async (id: number, status: string) => {
      await axios.post('/api/admin/reports', { id, status });
      fetchReports();
  };

  const handleDelete = async (id: number) => {
      if(confirm('Delete this report?')) {
          await axios.delete('/api/admin/reports', { data: { id } });
          fetchReports();
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>User Reports</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border text-sm">
                            <thead>
                                <tr className="bg-gray-100 border-b font-bold text-left text-gray-600">
                                    <th className="p-3">Slug/Episode</th>
                                    <th className="p-3">Reason</th>
                                    <th className="p-3">Description</th>
                                    <th className="p-3 text-center">Status</th>
                                    <th className="p-3 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reports.map((item) => (
                                    <tr key={item.id} className="border-b hover:bg-gray-50">
                                        <td className="p-3">
                                            <Link href={`/${item.slug}`} className="text-blue-600 hover:underline font-bold">
                                                {item.slug}
                                            </Link>
                                            <div className="text-xs text-gray-500">Ep: {item.episode}</div>
                                            <div className="text-xs text-gray-400 mt-1">{new Date(item.created_at).toLocaleDateString()}</div>
                                        </td>
                                        <td className="p-3">
                                            <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-bold">{item.reason}</span>
                                        </td>
                                        <td className="p-3 text-gray-600 italic">"{item.description}"</td>
                                        <td className="p-3 text-center">
                                            <span className={`px-2 py-1 rounded text-white text-xs font-bold ${item.status === 'resolved' ? 'bg-green-500' : 'bg-yellow-500'}`}>
                                                {item.status}
                                            </span>
                                        </td>
                                        <td className="p-3 text-center">
                                            <div className="flex justify-center gap-2">
                                                {item.status !== 'resolved' && (
                                                    <Button onClick={() => handleStatus(item.id, 'resolved')} className="text-xs px-2 py-1">Fix</Button>
                                                )}
                                                <Button variant="danger" onClick={() => handleDelete(item.id)} className="text-xs px-2 py-1">Del</Button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {reports.length === 0 && (
                                    <tr><td colSpan={5} className="p-5 text-center text-gray-500">No reports found.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}