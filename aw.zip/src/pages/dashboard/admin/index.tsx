import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import AdminNav from '@/components/partial/AdminNav';
import { getSession } from 'next-auth/react';
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
      fetchData();
  }, []);

  const fetchData = async () => {
      try {
          const statsRes = await axios.get('/api/admin/stats');
          setStats(statsRes.data.stats);
          const usersRes = await axios.get('/api/admin/users');
          // Get top 5 recent users
          setUsers(usersRes.data.data.slice(0, 5));
      } catch (e) {
          console.error(e);
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Admin Dashboard</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    {stats && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                            <div className="bg-blue-50 p-6 rounded border border-blue-100 text-center">
                                <h4 className="font-bold text-3xl text-blue-600">{stats.users}</h4>
                                <span className="text-gray-600 font-medium">Total Users</span>
                            </div>
                            <div className="bg-green-50 p-6 rounded border border-green-100 text-center">
                                <h4 className="font-bold text-3xl text-green-600">{stats.bookmarks}</h4>
                                <span className="text-gray-600 font-medium">Total Bookmarks</span>
                            </div>
                            <div className="bg-yellow-50 p-6 rounded border border-yellow-100 text-center">
                                <h4 className="font-bold text-3xl text-yellow-600">{stats.history}</h4>
                                <span className="text-gray-600 font-medium">Total History</span>
                            </div>
                        </div>
                    )}

                    <h4 className="font-bold text-lg mb-4">Newest Members</h4>
                    <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border">
                            <thead>
                                <tr className="w-full bg-gray-100 text-left text-xs uppercase font-bold text-gray-600">
                                    <th className="py-3 px-4">Name</th>
                                    <th className="py-3 px-4">Email</th>
                                    <th className="py-3 px-4">Role</th>
                                    <th className="py-3 px-4">Joined</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map((user) => (
                                    <tr key={user.id} className="border-b hover:bg-gray-50 text-sm">
                                        <td className="py-3 px-4">{user.name}</td>
                                        <td className="py-3 px-4">{user.email}</td>
                                        <td className="py-3 px-4">
                                            <span className={`px-2 py-1 rounded text-xs font-bold text-white ${user.role === 'admin' ? 'bg-red-500' : 'bg-blue-500'}`}>
                                                {user.role}
                                            </span>
                                        </td>
                                        <td className="py-3 px-4 text-gray-500">
                                            {new Date(user.created_at).toLocaleDateString()}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps = async (context: any) => {
  const session = await getSession(context);
  
  if (!session) {
    return { redirect: { destination: '/auth', permanent: false } };
  }

  if (session.user.role !== 'admin') {
      return { redirect: { destination: '/dashboard', permanent: false } };
  }

  return { props: {} };
};