import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import AdminNav from '@/components/partial/AdminNav';
import Link from 'next/link';
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function UserManagementPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
      axios.get('/api/admin/users').then(res => {
          if(res.data.success) setUsers(res.data.data);
      });
  }, []);

  const filteredUsers = users.filter(u => 
      u.name.toLowerCase().includes(filter.toLowerCase()) || 
      u.email.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>User Management</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <div className="mb-4">
                        <input 
                            type="text" 
                            placeholder="Search user by name or email..." 
                            className="w-full border p-2 rounded"
                            value={filter}
                            onChange={(e) => setFilter(e.target.value)}
                        />
                    </div>

                    <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border">
                            <thead>
                                <tr className="bg-gray-100 text-left text-xs uppercase font-bold text-gray-600">
                                    <th className="py-3 px-4">Name</th>
                                    <th className="py-3 px-4">Email</th>
                                    <th className="py-3 px-4 text-center">Role</th>
                                    <th className="py-3 px-4">Joined</th>
                                    <th className="py-3 px-4 text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.map((user) => (
                                    <tr key={user.id} className="border-b hover:bg-gray-50">
                                        <td className="py-3 px-4 font-medium">{user.name}</td>
                                        <td className="py-3 px-4 text-gray-600">{user.email}</td>
                                        <td className="py-3 px-4 text-center">
                                            <span className={`px-2 py-1 rounded text-xs font-bold text-white ${user.role === 'admin' ? 'bg-red-500' : 'bg-blue-500'}`}>
                                                {user.role}
                                            </span>
                                        </td>
                                        <td className="py-3 px-4 text-sm text-gray-500">{new Date(user.created_at).toLocaleDateString()}</td>
                                        <td className="py-3 px-4 text-center">
                                            <Link href={`/dashboard/admin/user/${user.id}`} className="text-blue-600 hover:underline text-sm font-bold">
                                                Manage
                                            </Link>
                                        </td>
                                    </tr>
                                ))}
                                {filteredUsers.length === 0 && (
                                    <tr><td colSpan={5} className="py-4 text-center text-gray-500">No users found.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}