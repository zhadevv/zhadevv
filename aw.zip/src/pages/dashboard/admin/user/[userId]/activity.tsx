import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function UserActivityPage() {
  const router = useRouter();
  const { userId } = router.query;
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
      if(userId) {
          axios.get(`/api/admin/user/${userId}/activity`)
            .then(res => {
                if(res.data.success) setActivities(res.data.data);
            })
            .finally(() => setLoading(false));
      }
  }, [userId]);

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Activity Log: User #{userId}</h3></div>
                <div className="p-8">
                    {loading ? (
                        <div className="text-center">Loading activity...</div>
                    ) : activities.length > 0 ? (
                        <div className="space-y-4">
                            {activities.map((item, idx) => (
                                <div key={idx} className="flex items-center p-4 bg-white border rounded shadow-sm">
                                    <div className={`w-2 h-2 rounded-full mr-4 ${item.type === 'history' ? 'bg-blue-500' : 'bg-green-500'}`}></div>
                                    <div className="flex-1">
                                        <p className="text-sm font-bold text-gray-800">
                                            {item.type === 'history' ? 'Watched Episode' : 'Bookmarked Series'}
                                        </p>
                                        <p className="text-sm text-gray-600">
                                            {item.slug} {item.episode ? `- Episode ${item.episode}` : ''}
                                        </p>
                                    </div>
                                    <div className="text-xs text-gray-400">
                                        {new Date(item.date).toLocaleString()}
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="mt-4 border p-4 rounded bg-gray-50 text-center">
                            <p className="text-gray-500">No recent activity recorded.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}