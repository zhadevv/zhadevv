import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Button from '@/components/modal/Button';
import { useRouter } from 'next/router';
import axios from 'axios';
import { useState } from 'react';

export default function UserModeratePage() {
  const router = useRouter();
  const { userId } = router.query;
  const [loading, setLoading] = useState(false);

  const handleAction = async (action: string) => {
      if(!confirm('Are you sure you want to perform this action?')) return;
      
      setLoading(true);
      try {
          const res = await axios.post(`/api/admin/user/${userId}`, { action });
          if(res.data.success) {
              alert(res.data.message || 'Action successful');
              if(action === 'delete') {
                  router.push('/dashboard/admin/user');
              }
          }
      } catch (e) {
          alert('Action failed');
      } finally {
          setLoading(false);
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Moderate User #{userId}</h3></div>
                <div className="p-8">
                    <h4 className="font-bold mb-4">Security Actions</h4>
                    <div className="flex flex-col gap-4 max-w-md">
                        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
                            <h5 className="font-bold text-yellow-800">Reset Password</h5>
                            <p className="text-sm text-yellow-700 mb-2">Reset user password to default '123456'.</p>
                            <Button variant="secondary" onClick={() => handleAction('reset_password')} isLoading={loading}>
                                Reset Password
                            </Button>
                        </div>

                        <div className="p-4 bg-red-50 border border-red-200 rounded">
                            <h5 className="font-bold text-red-800">Delete Account</h5>
                            <p className="text-sm text-red-700 mb-2">Permanently remove this user and all their data.</p>
                            <Button variant="danger" onClick={() => handleAction('delete')} isLoading={loading}>
                                Delete Account
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}