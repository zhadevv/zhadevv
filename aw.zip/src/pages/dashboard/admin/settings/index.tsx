import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Button from '@/components/modal/Button';
import Input from '@/components/modal/Input';
import AdminNav from '@/components/partial/AdminNav';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState({
      site_name: 'Anidong',
      site_description: 'Streaming Donghua Indonesia',
      maintenance_mode: '0'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
      axios.get('/api/admin/settings').then(res => {
          if(res.data.success && Object.keys(res.data.data).length > 0) {
              setSettings(prev => ({ ...prev, ...res.data.data }));
          }
      });
  }, []);

  const handleChange = (e: any) => {
      const { name, value } = e.target;
      setSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
      setLoading(true);
      try {
          await axios.post('/api/admin/settings', { settings });
          alert('Settings saved successfully');
      } catch (e) {
          alert('Failed to save settings');
      } finally {
          setLoading(false);
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Site Configuration</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="max-w-2xl">
                        <Input 
                            label="Site Name" 
                            name="site_name"
                            value={settings.site_name} 
                            onChange={handleChange}
                        />
                        <Input 
                            label="Site Description" 
                            name="site_description"
                            value={settings.site_description} 
                            onChange={handleChange}
                        />
                        <div className="mb-6">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Maintenance Mode</label>
                            <select 
                                name="maintenance_mode"
                                value={settings.maintenance_mode} 
                                onChange={handleChange}
                                className="border rounded w-full py-2 px-3 focus:outline-none focus:shadow-outline bg-white"
                            >
                                <option value="0">Off (Site Live)</option>
                                <option value="1">On (Maintenance Page)</option>
                            </select>
                            <p className="text-xs text-gray-500 mt-1">If enabled, non-admin users will see a maintenance page.</p>
                        </div>
                        <Button type="submit" isLoading={loading}>Save Global Settings</Button>
                    </form>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}