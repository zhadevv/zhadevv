import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Button from '@/components/modal/Button';
import AdminNav from '@/components/partial/AdminNav';
import { useState, useEffect } from 'react';
import axios from 'axios';

export default function BroadcastPage() {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
      // Load existing broadcast
      axios.get('/api/admin/settings').then(res => {
          if(res.data.success && res.data.data.site_broadcast) {
              setMessage(res.data.data.site_broadcast);
          }
      });
  }, []);

  const handleSave = async () => {
      setLoading(true);
      try {
          await axios.post('/api/admin/settings', { 
              settings: { site_broadcast: message } 
          });
          alert('Broadcast updated successfully');
      } catch (e) {
          alert('Failed to update broadcast');
      } finally {
          setLoading(false);
      }
  };

  const handleClear = async () => {
      setMessage('');
      setLoading(true);
      try {
          await axios.post('/api/admin/settings', { 
              settings: { site_broadcast: '' } 
          });
          alert('Broadcast cleared');
      } catch (e) {
          alert('Failed to clear');
      } finally {
          setLoading(false);
      }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>System Broadcast</h3></div>
                <div className="p-8">
                    <AdminNav />
                    
                    <div className="bg-blue-50 border border-blue-100 p-4 rounded mb-6">
                        <p className="text-blue-800 text-sm">
                            <i className="fas fa-info-circle mr-2"></i>
                            This message will be displayed prominently at the top of every page. 
                            It supports HTML tags. Use it for maintenance notices or important announcements.
                        </p>
                    </div>

                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2">Broadcast Message (HTML Supported)</label>
                        <textarea 
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none" 
                            rows={5}
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            placeholder="Example: <b>Maintenance!</b> We will be back shortly."
                        ></textarea>
                    </div>
                    <div className="flex gap-2">
                        <Button onClick={handleSave} isLoading={loading}>Update Broadcast</Button>
                        <Button variant="danger" onClick={handleClear} isLoading={loading}>Clear/Remove</Button>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}