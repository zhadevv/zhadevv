import DashboardLayout from '@/components/layout/DashboardLayout';
import { getSession } from 'next-auth/react';
import db from '@/models/database';
import Link from 'next/link';
import { useState } from 'react';

export default function HistoryPage({ history, comments }: { history: any[], comments: any[] }) {
  const [activeTab, setActiveTab] = useState<'history' | 'comments'>('history');

  return (
    <DashboardLayout>
        <div className="flex border-b mb-6">
            <button 
                className={`py-2 px-4 font-medium text-sm transition-colors relative ${activeTab === 'history' ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('history')}
            >
                Watch History
                {activeTab === 'history' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-600"></span>}
            </button>
            <button 
                className={`py-2 px-4 font-medium text-sm transition-colors relative ${activeTab === 'comments' ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('comments')}
            >
                My Comments
                {activeTab === 'comments' && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-600"></span>}
            </button>
        </div>

        {activeTab === 'history' ? (
            history.length > 0 ? (
                <div className="space-y-3">
                    {history.map((item, idx) => (
                        <div className="flex items-center justify-between p-3 bg-gray-50 border rounded hover:bg-white hover:shadow-sm transition" key={idx}>
                            <div className="flex-1">
                                <Link href={`/${item.slug}-episode-${item.episode}-subtitle-indonesia`} className="font-bold text-blue-600 hover:underline">
                                    {item.slug.replace(/-/g, ' ').toUpperCase()}
                                </Link>
                                <div className="text-sm text-gray-600">Episode {item.episode}</div>
                            </div>
                            <div className="text-xs text-gray-400">
                                {new Date(item.watched_at).toLocaleDateString()}
                            </div>
                        </div>
                    ))}
                </div>
            ) : <div className="text-center py-8 text-gray-500">No watch history found.</div>
        ) : (
            comments.length > 0 ? (
                <div className="space-y-4">
                    {comments.map((item, idx) => (
                        <div className="p-4 bg-gray-50 border rounded" key={idx}>
                            <div className="flex justify-between items-center mb-2">
                                <span className="font-bold text-gray-700 text-sm">{item.slug.replace(/-/g, ' ')}</span>
                                <span className="text-xs text-gray-400">{new Date(item.created_at).toLocaleDateString()}</span>
                            </div>
                            <p className="text-sm text-gray-600 italic">"{item.content}"</p>
                        </div>
                    ))}
                </div>
            ) : <div className="text-center py-8 text-gray-500">No comments found.</div>
        )}
    </DashboardLayout>
  );
}

export const getServerSideProps = async (context: any) => {
  const session = await getSession(context);
  if (!session) {
    return { redirect: { destination: '/auth', permanent: false } };
  }

  const userId = session.user.id;

  const historyStmt = db.prepare('SELECT * FROM history WHERE user_id = ? ORDER BY watched_at DESC LIMIT 50');
  const history = historyStmt.all(userId);

  const commentsStmt = db.prepare('SELECT * FROM comments WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
  const comments = commentsStmt.all(userId);

  return {
    props: { 
        history: JSON.parse(JSON.stringify(history)),
        comments: JSON.parse(JSON.stringify(comments))
    },
  };
};