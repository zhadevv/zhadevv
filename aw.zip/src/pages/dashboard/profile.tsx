import DashboardLayout from '@/components/layout/DashboardLayout';
import { getSession } from 'next-auth/react';
import db from '@/models/database';
import Link from 'next/link';

export default function ProfilePage({ bookmarks }: { bookmarks: any[] }) {
  return (
    <DashboardLayout>
        <h2 className="text-xl font-bold mb-6 text-gray-800 border-b pb-2">My Bookmarks</h2>
        
        {bookmarks.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {bookmarks.map((item, idx) => (
                    <div className="bs" key={idx} style={{width: '100%', float: 'none'}}>
                        <div className="bsx">
                            <Link href={`/series/${item.slug}`}>
                                <div className="limit">
                                    <img src={item.thumbnail} alt={item.title} className="rounded" />
                                </div>
                                <div className="tt">
                                    <h2 className="text-sm font-medium mt-2 line-clamp-2">{item.title}</h2>
                                </div>
                            </Link>
                        </div>
                    </div>
                ))}
            </div>
        ) : (
            <div className="text-center py-10 bg-gray-50 rounded border border-dashed">
                <i className="fas fa-bookmark text-4xl text-gray-300 mb-3"></i>
                <p className="text-gray-500">You haven't bookmarked any series yet.</p>
                <Link href="/" className="text-blue-600 hover:underline mt-2 inline-block">Browse Series</Link>
            </div>
        )}
    </DashboardLayout>
  );
}

export const getServerSideProps = async (context: any) => {
  const session = await getSession(context);
  if (!session) {
    return { redirect: { destination: '/auth', permanent: false } };
  }

  const stmt = db.prepare('SELECT * FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC');
  const bookmarks = stmt.all(session.user.id);

  return {
    props: { bookmarks: JSON.parse(JSON.stringify(bookmarks)) },
  };
};