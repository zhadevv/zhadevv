import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';

export default function SearchPage({ data, query }: { data: any, query: string }) {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>Search Results for: {query}</h3></div>
                <div className="listupd">
                    <div className="excstf">
                        {data?.lists?.length > 0 ? (
                            data.lists.map((item: any, idx: number) => (
                                <div className="bs" key={idx}>
                                    <div className="bsx">
                                        <Link href={item.url.replace('https://anichin.cafe', '')}>
                                            <div className="limit">
                                                <img src={item.thumbnail} alt={item.title} />
                                                <div className="bt"><span className="epx">{item.badges?.[0]?.text || item.episode}</span></div>
                                            </div>
                                            <div className="tt"><h2>{item.title}</h2></div>
                                        </Link>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="p-4 text-center">No results found.</div>
                        )}
                    </div>
                </div>
            </div>
        </div>
        <div id="sidebar">
             <div className="section">
                <div className="releases"><h3>Tags</h3></div>
                <ul className="genre">
                    <li><Link href="/genres/action">Action</Link></li>
                    <li><Link href="/genres/adventure">Adventure</Link></li>
                    <li><Link href="/genres/martial-arts">Martial Arts</Link></li>
                </ul>
             </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const s = context.query.s as string;
  const page = parseInt(context.query.page as string || '1');
  const data = await ZhadevService.getSearch(s, page);
  return { props: { data, query: s } };
};