import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Sidebar from '@/components/partial/Sidebar';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';

export default function ListModePage({ data }: { data: any }) {
  // Data structure for text mode usually grouped by letter in 'text' mode of advanced search
  // If not, we map what we have. Assuming scraping 'text' mode returns groups or a flat list.
  // The provided scraper docs say advancedsearch('text') returns text mode.
  
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>List Mode</h3></div>
                <div className="soralist">
                    <div className="nav_apb">
                        <Link href="/az_lists">Switch to Image Mode</Link>
                    </div>
                    {/* Render lists assuming data is grouped by letter or just a list */}
                    {data?.lists ? (
                        <div className="blix">
                             <ul>
                                {data.lists.map((item: any, idx: number) => (
                                    <li key={idx}>
                                        <Link href={item.url.replace('https://anichin.cafe', '')}>{item.title}</Link>
                                    </li>
                                ))}
                             </ul>
                        </div>
                    ) : (
                        <div className="p-4">No data available</div>
                    )}
                </div>
            </div>
        </div>
        <Sidebar />
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  // @ts-ignore
  const scraper = (await import('@zhadev/anichin')).default; 
  // We need to use scraper direct for 'text' mode if service doesn't expose it well yet
  // Or extend service.
  const sc = new scraper();
  let data = null;
  try {
      const res = await sc.advancedsearch('text');
      if (res.success) data = res.data;
  } catch(e) {
      console.log('List mode fetch failed');
  }

  return { props: { data } };
};