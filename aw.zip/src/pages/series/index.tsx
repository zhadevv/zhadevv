import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import Sidebar from '@/components/partial/Sidebar';
import SeriesGrid from '@/components/modal/SeriesGrid';
import { ZhadevService } from '@/services/zhadev';
import { useState } from 'react';
import { useRouter } from 'next/router';

export default function AdvancedSearchPage({ data, filters }: { data: any, filters: any }) {
  const router = useRouter();
  const [selectedFilters, setSelectedFilters] = useState({
      status: router.query.status || '',
      type: router.query.type || '',
      order: router.query.order || '',
      genre: router.query.genre || []
  });

  const handleFilterChange = (key: string, value: string) => {
      setSelectedFilters({ ...selectedFilters, [key]: value });
  };

  const applyFilters = () => {
      const query: any = { ...selectedFilters };
      if (Array.isArray(query.genre)) query.genre = query.genre.join(',');
      // Basic implementation for query params
      const queryString = new URLSearchParams(query).toString();
      router.push(`/series?${queryString}`);
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox advancedsearch">
                <div className="releases"><h3>Advanced Search</h3></div>
                <div className="quickfilter">
                    <div className="filters">
                        <div className="filter">
                            <label>Status</label>
                            <select onChange={(e) => handleFilterChange('status', e.target.value)} value={selectedFilters.status} className="w-full p-2 border rounded">
                                <option value="">All</option>
                                <option value="ongoing">Ongoing</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                        <div className="filter">
                            <label>Type</label>
                            <select onChange={(e) => handleFilterChange('type', e.target.value)} value={selectedFilters.type} className="w-full p-2 border rounded">
                                <option value="">All</option>
                                <option value="TV">TV</option>
                                <option value="Movie">Movie</option>
                                <option value="OVA">OVA</option>
                            </select>
                        </div>
                        <div className="filter">
                            <label>Order</label>
                            <select onChange={(e) => handleFilterChange('order', e.target.value)} value={selectedFilters.order} className="w-full p-2 border rounded">
                                <option value="">Default</option>
                                <option value="latest">Latest</option>
                                <option value="popular">Popular</option>
                                <option value="title">A-Z</option>
                            </select>
                        </div>
                        <div className="filter submit">
                            <button onClick={applyFilters} className="mt-4 p-2 bg-blue-600 text-white rounded">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bixbox">
                <div className="releases"><h3>Results</h3></div>
                <SeriesGrid items={data?.lists || []} />
            </div>
        </div>
        <Sidebar />
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const page = parseInt(context.query.page as string || '1');
  const filters = context.query;
  const data = await ZhadevService.getAdvancedSearch(page, filters);
  // Also fetch available filter options if possible, for now hardcoded in UI
  return { props: { data, filters } };
};
