import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import axios from 'axios';
import { useState } from 'react';
import Comments from '@/components/Comments';
import { useNotification } from '@/context/NotificationContext';

export default function SeriesDetail({ data }: { data: any }) {
  const { data: session } = useSession();
  const { notify } = useNotification();
  const [isBookmarking, setIsBookmarking] = useState(false);

  const handleBookmark = async () => {
      if (!session) {
          notify('Please login to bookmark this series', 'warning');
          return;
      }
      setIsBookmarking(true);
      try {
          await axios.post('/api/user/action', {
              action: 'bookmark',
              slug: data.slug,
              title: data.title,
              thumbnail: data.cover?.thumbnail || data.thumbnail
          });
          notify('Series added to bookmarks!', 'success');
      } catch (e) {
          notify('Failed to bookmark', 'error');
      } finally {
          setIsBookmarking(false);
      }
  };

  if (!data) return <div>Not Found</div>;

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox animefull">
                <div className="bigcontent">
                    <div className="thumbook">
                        <div className="thumb">
                            <img src={data.cover?.thumbnail || data.thumbnail} alt={data.title} />
                        </div>
                        <div className="rt">
                            <button 
                                onClick={handleBookmark}
                                disabled={isBookmarking}
                                className="bookmark" 
                                style={{width: '100%', marginTop: '10px'}}
                            >
                                <i className="fas fa-bookmark"></i> {isBookmarking ? 'Adding...' : 'Bookmark'}
                            </button>
                        </div>
                    </div>
                    <div className="infox">
                        <h1>{data.title}</h1>
                        <div className="ninfo">
                            <div className="info-content">
                                <div className="spe">
                                    <span><b>Status:</b> {data.information?.status}</span>
                                    <span><b>Released:</b> {data.information?.released}</span>
                                    <span><b>Season:</b> {data.information?.season}</span>
                                    <span><b>Type:</b> {data.information?.type}</span>
                                    <span><b>Episodes:</b> {data.information?.total_episode || data.episodes?.length}</span>
                                </div>
                                <div className="genxed">
                                    {data.genres?.map((g: any, idx: number) => (
                                        <span key={idx}>{g.name || g.title_genre}</span>
                                    ))}
                                </div>
                                <div className="desc">{data.synopsis}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bxcl">
                    <div className="releases"><h3>Episodes</h3></div>
                    <ul>
                        {data.episodes?.map((ep: any, idx: number) => (
                            <li key={idx}>
                                <Link href={ep.url?.replace('https://anichin.cafe', '') || '#'}>
                                    <div className="epl-num">{ep.number}</div>
                                    <div className="epl-title">{ep.title}</div>
                                    <div className="epl-date">{ep.release_date}</div>
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
            
            <Comments slug={data.slug} />
        </div>
        <div id="sidebar">
             <div className="section">
                <div className="releases"><h3>Latest Updates</h3></div>
                <div className="textwidget text-sm p-4">
                    <p>Check out our ongoing series for more action!</p>
                    <Link href="/ongoing" className="block mt-2 text-blue-600 font-bold">Go to Ongoing &raquo;</Link>
                </div>
             </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { slug } = context.params || {};
  const data = await ZhadevService.getSeries(slug as string);
  return { props: { data } };
};