import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { signIn, useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import React, { useState } from 'react';
import axios from 'axios';
import Button from '@/components/modal/Button';
import Input from '@/components/modal/Input';

export default function AuthPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
      name: '',
      email: '',
      password: ''
  });

  if (session) {
    router.push('/dashboard');
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (isLogin) {
        const result = await signIn('credentials', {
            redirect: false,
            email: formData.email,
            password: formData.password,
        });

        if (result?.ok) {
            router.push('/dashboard');
        } else {
            alert('Login Failed: Periksa email dan password anda.');
            setLoading(false);
        }
    } else {
        try {
            await axios.post('/api/auth/signup', formData);
            alert('Registrasi Berhasil! Silahkan login.');
            setIsLogin(true);
        } catch (error: any) {
            alert(error.response?.data?.message || 'Registrasi Gagal');
        } finally {
            setLoading(false);
        }
    }
  };

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox max-w-md mx-auto mt-10 mb-10">
                <div className="releases"><h3>{isLogin ? 'Login' : 'Register'}</h3></div>
                <div className="p-8">
                    <form onSubmit={handleSubmit}>
                        {!isLogin && (
                            <Input 
                                label="Nama Lengkap" 
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                            />
                        )}
                        <Input 
                            label="Email Address" 
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                        <Input 
                            label="Password" 
                            type="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            required
                        />
                        
                        <Button type="submit" isLoading={loading} className="w-full mt-4">
                            {isLogin ? 'Sign In' : 'Sign Up'}
                        </Button>
                    </form>

                    <div className="mt-6 text-center text-sm">
                        <p>
                            {isLogin ? "Belum punya akun? " : "Sudah punya akun? "}
                            <button 
                                onClick={() => setIsLogin(!isLogin)} 
                                className="text-blue-600 font-bold hover:underline"
                            >
                                {isLogin ? 'Daftar disini' : 'Login disini'}
                            </button>
                        </p>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}