import { GetServerSideProps } from 'next';
import { ZhadevService } from '@/services/zhadev';

const SITE_URL = 'https://anidong.my.id';

function generateSiteMap(data: any) {
  const { ongoing, completed } = data;

  return `<?xml version="1.0" encoding="UTF-8"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
     <url>
       <loc>${SITE_URL}</loc>
       <changefreq>daily</changefreq>
       <priority>1.0</priority>
     </url>
     <url>
       <loc>${SITE_URL}/ongoing</loc>
       <changefreq>daily</changefreq>
       <priority>0.8</priority>
     </url>
     <url>
       <loc>${SITE_URL}/completed</loc>
       <changefreq>weekly</changefreq>
       <priority>0.8</priority>
     </url>
     ${ongoing
       .map(({ url }: any) => {
         return `
       <url>
           <loc>${url.replace('https://anichin.cafe', SITE_URL)}</loc>
           <changefreq>daily</changefreq>
           <priority>0.7</priority>
       </url>
     `;
       })
       .join('')}
      ${completed
       .map(({ url }: any) => {
         return `
       <url>
           <loc>${url.replace('https://anichin.cafe', SITE_URL)}</loc>
           <changefreq>monthly</changefreq>
           <priority>0.5</priority>
       </url>
     `;
       })
       .join('')}
   </urlset>
 `;
}

export default function SiteMap() {
  // getServerSideProps will do the heavy lifting
}

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
  // We make a few API calls to get the data
  const ongoing = await ZhadevService.getOngoing(1);
  const completed = await ZhadevService.getCompleted(1);

  const data = {
      ongoing: ongoing?.lists || [],
      completed: completed?.lists || []
  };

  // We generate the XML sitemap with the posts data
  const sitemap = generateSiteMap(data);

  res.setHeader('Content-Type', 'text/xml');
  // we send the XML to the browser
  res.write(sitemap);
  res.end();

  return {
    props: {},
  };
};