import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';

export default function AzListPage({ data, currentLetter }: { data: any, currentLetter: string }) {
  const letters = ['All', '#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>List Anime {currentLetter !== 'All' ? `- ${currentLetter}` : ''}</h3></div>
                <div className="soralist">
                    <div className="nav_apb">
                        {letters.map(l => (
                            <Link 
                                key={l} 
                                href={l === 'All' ? '/az_lists' : `/az_lists?show=${l}`}
                                className={currentLetter === l ? 'active' : ''}
                                style={{ fontWeight: currentLetter === l ? 'bold' : 'normal', background: currentLetter === l ? '#0c70de' : '#eee', color: currentLetter === l ? '#fff' : '#333' }}
                            >
                                {l}
                            </Link>
                        ))}
                    </div>
                    <div className="listupd normal">
                        <div className="excstf">
                            {data?.lists?.map((item: any, idx: number) => (
                                <div className="bs" key={idx}>
                                    <div className="bsx">
                                        <Link href={item.url.replace('https://anichin.cafe', '')}>
                                            <div className="limit">
                                                <img src={item.thumbnail} alt={item.title} />
                                                <div className="bt"><span className="epx">{item.badges?.[0]?.text || item.episode}</span></div>
                                            </div>
                                            <div className="tt"><h2>{item.title}</h2></div>
                                        </Link>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="sidebar">
             <div className="section">
                <div className="releases"><h3>Sidebar</h3></div>
             </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const show = context.query.show as string || 'All';
  const page = parseInt(context.query.page as string || '1');
  
  // If show is 'All', usually standard listing or just first page of A? 
  // Scraper supports specific letter. If 'All', maybe just null or 'A'.
  // Using scraper behavior:
  const data = await ZhadevService.getAzList(show === 'All' ? 'A' : show, page);
  
  return { props: { data, currentLetter: show } };
};