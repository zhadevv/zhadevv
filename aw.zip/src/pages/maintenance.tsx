import Head from 'next/head';

export default function MaintenancePage() {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-900 text-white">
      <Head>
        <title>Maintenance - Anidong</title>
      </Head>
      <div className="text-center p-8">
        <h1 className="text-5xl font-bold text-blue-500 mb-4">Maintenance</h1>
        <p className="text-xl mb-8 text-gray-300">Website sedang dalam perbaikan. Kami akan segera kembali.</p>
        <div className="animate-pulse flex justify-center">
            <i className="fas fa-tools text-6xl text-gray-500"></i>
        </div>
        <p className="mt-8 text-sm text-gray-500">&copy; Anidong Team</p>
      </div>
    </div>
  );
}