import { GetServerSideProps } from 'next';
import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';
import { ZhadevService } from '@/services/zhadev';
import Link from 'next/link';

export default function SchedulePage({ data }: { data: any }) {
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody">
            <div className="bixbox">
                <div className="releases"><h3>Jadwal Rilis</h3></div>
                <div className="page">
                    {days.map((day) => {
                        const dayData = data?.days?.[day] || data?.[day];
                        if (!dayData?.lists && !dayData?.list) return null;
                        const list = dayData.lists || dayData.list;

                        return (
                            <div key={day} className="mb-6">
                                <div className="releases latesthome"><h3>{day.toUpperCase()}</h3></div>
                                <div className="listupd normal">
                                    <div className="excstf">
                                        {list.map((item: any, idx: number) => (
                                            <div className="bs" key={idx}>
                                                <div className="bsx">
                                                    <Link href={item.url.replace('https://anichin.cafe', '')}>
                                                        <div className="limit">
                                                            <img src={item.thumbnail} alt={item.title} />
                                                            <div className="bt"><span className="epx">{item.current_episode}</span></div>
                                                            <div className="time absolute top-0 right-0 bg-blue-600 text-white text-xs px-1">
                                                                {item.release_time?.formatted?.split(' ').pop()}
                                                            </div>
                                                        </div>
                                                        <div className="tt"><h2>{item.title}</h2></div>
                                                    </Link>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
        <div id="sidebar">
             <div className="section">
                <div className="releases"><h3>Note</h3></div>
                <div className="textwidget">
                    <p>Jadwal dapat berubah sewaktu-waktu tanpa pemberitahuan.</p>
                </div>
             </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const data = await ZhadevService.getSchedule();
  return { props: { data: data || {} } };
};