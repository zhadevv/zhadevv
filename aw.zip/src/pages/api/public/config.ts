import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      // Fetch multiple settings efficiently
      const stmt = db.prepare("SELECT key, value FROM settings WHERE key IN ('site_broadcast', 'maintenance_mode', 'site_name', 'site_description')");
      const rows = stmt.all() as { key: string, value: string }[];
      
      // Convert array to object map
      const settings = rows.reduce((acc, curr) => {
          acc[curr.key] = curr.value;
          return acc;
      }, {} as Record<string, string>);
      
      return res.status(200).json({ 
        success: true, 
        data: {
            broadcast: settings.site_broadcast || null,
            maintenance_mode: settings.maintenance_mode === '1',
            site_name: settings.site_name || 'Anidong',
            site_description: settings.site_description || 'Streaming Donghua Indonesia'
        } 
      });
    } catch (e) {
      return res.status(500).json({ message: 'Error fetching config' });
    }
  }
  return res.status(405).json({ message: 'Method not allowed' });
}