import type { NextApiRequest, NextApiResponse } from 'next';
import { ZhadevService } from '@/services/zhadev';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { q } = req.query;
  
  if (!q || typeof q !== 'string' || q.length < 3) {
      return res.status(200).json({ success: true, data: [] });
  }

  try {
    // Limit to page 1 for live search
    const data = await ZhadevService.getSearch(q, 1);
    // Return only first 5 results for dropdown
    return res.status(200).json({ success: true, data: data.lists?.slice(0, 5) || [] });
  } catch (e) {
    return res.status(500).json({ success: false, data: [] });
  }
}