import type { NextApiRequest, NextApiResponse } from 'next';
import { ZhadevService } from '@/services/zhadev';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const data = await ZhadevService.getSidebar();
      return res.status(200).json({ success: true, data });
    } catch (e) {
      return res.status(500).json({ success: false, message: 'Error fetching sidebar' });
    }
  }
  return res.status(405).json({ message: 'Method not allowed' });
}