import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const stmt = db.prepare('SELECT * FROM ad_slots');
      const ads = stmt.all();
      return res.status(200).json({ success: true, data: ads });
    } catch (e) {
      return res.status(500).json({ message: 'Error fetching ads' });
    }
  }

  if (req.method === 'POST') {
    const { position, content, is_active } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO ad_slots (position, content, is_active) VALUES (?, ?, ?) ON CONFLICT(position) DO UPDATE SET content=excluded.content, is_active=excluded.is_active');
      stmt.run(position, content, is_active ? 1 : 0);
      return res.status(200).json({ success: true });
    } catch (e) {
      return res.status(500).json({ message: 'Error saving ad' });
    }
  }

  if (req.method === 'DELETE') {
      const { id } = req.body;
      try {
          const stmt = db.prepare('DELETE FROM ad_slots WHERE id = ?');
          stmt.run(id);
          return res.status(200).json({ success: true });
      } catch (e) {
          return res.status(500).json({ message: 'Error deleting ad' });
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);