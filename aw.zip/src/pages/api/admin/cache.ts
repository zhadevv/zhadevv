import type { NextApiRequest, NextApiResponse } from 'next';
import { withAdmin } from '@/middlewares/guard';
import fs from 'fs';
import path from 'path';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
      try {
          const cacheDir = path.join((process as any).cwd(), 'src', 'data', 'api.loaded');
          if (fs.existsSync(cacheDir)) {
              const files = fs.readdirSync(cacheDir);
              for (const file of files) {
                  fs.unlinkSync(path.join(cacheDir, file));
              }
              return res.status(200).json({ success: true, message: `Cleared ${files.length} cache files.` });
          }
          return res.status(200).json({ success: true, message: 'Cache directory empty or not found.' });
      } catch (e) {
          return res.status(500).json({ message: 'Failed to clear cache' });
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);