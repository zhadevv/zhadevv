import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
      try {
          const stmt = db.prepare('SELECT * FROM reports ORDER BY created_at DESC');
          const reports = stmt.all();
          return res.status(200).json({ success: true, data: reports });
      } catch (e) {
          return res.status(500).json({ message: 'Database error' });
      }
  }

  if (req.method === 'POST') {
      const { id, status } = req.body; // status: 'resolved'
      try {
          const stmt = db.prepare('UPDATE reports SET status = ? WHERE id = ?');
          stmt.run(status, id);
          return res.status(200).json({ success: true });
      } catch (e) {
          return res.status(500).json({ message: 'Database error' });
      }
  }
  
  if (req.method === 'DELETE') {
      const { id } = req.body;
      try {
          const stmt = db.prepare('DELETE FROM reports WHERE id = ?');
          stmt.run(id);
          return res.status(200).json({ success: true });
      } catch (e) {
          return res.status(500).json({ message: 'Database error' });
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);