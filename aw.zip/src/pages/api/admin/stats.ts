import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as any;
    const bookmarkCount = db.prepare('SELECT COUNT(*) as count FROM bookmarks').get() as any;
    const historyCount = db.prepare('SELECT COUNT(*) as count FROM history').get() as any;

    return res.status(200).json({
      success: true,
      stats: {
        users: userCount.count,
        bookmarks: bookmarkCount.count,
        history: historyCount.count
      }
    });
  } catch (error) {
    return res.status(500).json({ message: 'Database error' });
  }
}

export default withAdmin(handler);