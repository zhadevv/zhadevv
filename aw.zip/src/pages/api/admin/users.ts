import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const stmt = db.prepare('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC');
    const users = stmt.all();
    return res.status(200).json({ success: true, data: users });
  } catch (error) {
    return res.status(500).json({ message: 'Database error' });
  }
}

export default withAdmin(handler);