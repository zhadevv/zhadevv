import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { withAdmin } from '@/middlewares/guard';
import { hashPassword } from '@/utils/security';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;

  if (req.method === 'GET') {
      try {
          const stmt = db.prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?');
          const user = stmt.get(id);
          if(!user) return res.status(404).json({message: 'User not found'});
          return res.status(200).json({ success: true, data: user });
      } catch(e) {
          return res.status(500).json({ message: 'Database error' });
      }
  }

  // Moderate actions
  if (req.method === 'POST') {
      const { action } = req.body;
      
      if (action === 'delete') {
          try {
              const stmt = db.prepare('DELETE FROM users WHERE id = ?');
              stmt.run(id);
              return res.status(200).json({ success: true, message: 'User deleted' });
          } catch(e) {
              return res.status(500).json({ message: 'Error deleting user' });
          }
      }

      if (action === 'reset_password') {
          try {
              // Reset to '123456'
              const hashed = await hashPassword('123456');
              const stmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
              stmt.run(hashed, id);
              return res.status(200).json({ success: true, message: 'Password reset to 123456' });
          } catch(e) {
              return res.status(500).json({ message: 'Error resetting password' });
          }
      }
      
      if (action === 'change_role') {
          const { role } = req.body;
          try {
              const stmt = db.prepare('UPDATE users SET role = ? WHERE id = ?');
              stmt.run(role, id);
              return res.status(200).json({ success: true });
          } catch(e) {
              return res.status(500).json({ message: 'Error updating role' });
          }
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}

export default withAdmin(handler);