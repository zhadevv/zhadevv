import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import db from '@/models/database';
import { hashPassword } from '@/utils/security';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const { name, password } = req.body;
  const userId = session.user.id;

  try {
    if (name) {
        const stmt = db.prepare('UPDATE users SET name = ? WHERE id = ?');
        stmt.run(name, userId);
    }

    if (password && password.length >= 6) {
        const hashedPassword = await hashPassword(password);
        const stmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
        stmt.run(hashedPassword, userId);
    }

    return res.status(200).json({ success: true, message: 'Profile updated' });
  } catch (e) {
    return res.status(500).json({ message: 'Database error' });
  }
}