import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import db from '@/models/database';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getServerSession(req, res, authOptions);

  if (!session || !session.user?.id) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const userId = session.user.id;

  if (req.method === 'POST') {
    const { action, slug, title, thumbnail, episode } = req.body;

    if (action === 'bookmark') {
        try {
            const stmt = db.prepare('INSERT OR IGNORE INTO bookmarks (user_id, slug, title, thumbnail) VALUES (?, ?, ?, ?)');
            stmt.run(userId, slug, title, thumbnail);
            return res.status(200).json({ success: true });
        } catch (e) {
            return res.status(500).json({ error: 'Database error' });
        }
    }

    if (action === 'history') {
        try {
            const stmt = db.prepare('INSERT INTO history (user_id, slug, episode) VALUES (?, ?, ?)');
            stmt.run(userId, slug, episode);
            return res.status(200).json({ success: true });
        } catch (e) {
            return res.status(500).json({ error: 'Database error' });
        }
    }
  }

  if (req.method === 'DELETE') {
      const { action, slug } = req.body;
      if (action === 'bookmark') {
          try {
            const stmt = db.prepare('DELETE FROM bookmarks WHERE user_id = ? AND slug = ?');
            stmt.run(userId, slug);
            return res.status(200).json({ success: true });
          } catch (e) {
            return res.status(500).json({ error: 'Database error' });
          }
      }
  }

  return res.status(405).json({ message: 'Method not allowed' });
}