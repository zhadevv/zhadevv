import type { NextApiRequest, NextApiResponse } from 'next';
import db from '@/models/database';
import { hashPassword, isValidEmail } from '@/utils/security';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Data tidak lengkap' });
  }

  if (!isValidEmail(email)) {
    return res.status(400).json({ message: 'Format email tidak valid' });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: 'Password minimal 6 karakter' });
  }

  try {
    const checkStmt = db.prepare('SELECT id FROM users WHERE email = ?');
    const existingUser = checkStmt.get(email);

    if (existingUser) {
      return res.status(409).json({ message: 'Email sudah terdaftar' });
    }

    const hashedPassword = await hashPassword(password);
    
    let role = 'user';
    const envAdminEmail = process.env.ADMIN_EMAIL;

    if (envAdminEmail && email === envAdminEmail) {
        role = 'admin';
    } else if (!envAdminEmail) {
        const countStmt = db.prepare('SELECT COUNT(*) as count FROM users');
        const { count } = countStmt.get() as any;
        if (count === 0) role = 'admin';
    }

    const insertStmt = db.prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
    insertStmt.run(name, email, hashedPassword, role);

    return res.status(201).json({ message: 'Registrasi berhasil', role });
  } catch (error) {
    console.error('Signup error:', error);
    return res.status(500).json({ message: 'Terjadi kesalahan internal server' });
  }
}