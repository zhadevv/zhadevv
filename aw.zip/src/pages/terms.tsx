import Header from '@/components/partial/Header';
import Footer from '@/components/partial/Footer';

export default function TermsPage() {
  return (
    <div id="content">
      <Header />
      <div className="wrapper">
        <div className="postbody nosidebar">
            <div className="bixbox">
                <div className="releases"><h3>Terms of Service</h3></div>
                <div className="p-8 text-sm leading-relaxed">
                    <p className="mb-4"><strong>1. Acceptance of Terms</strong><br/>By accessing this website, you are agreeing to be bound by these website Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.</p>
                    <p className="mb-4"><strong>2. Disclaimer</strong><br/>The materials on Anidong's web site are provided "as is". Anidong makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties.</p>
                    <p className="mb-4"><strong>3. Limitations</strong><br/>In no event shall Anidong or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption,) arising out of the use or inability to use the materials on Anidong's Internet site.</p>
                    <p className="mb-4"><strong>4. Links</strong><br/>Anidong has not reviewed all of the sites linked to its Internet web site and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by Anidong of the site.</p>
                </div>
            </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}