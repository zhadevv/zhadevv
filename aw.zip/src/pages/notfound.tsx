import Custom404 from './404';

export default function NotFound() {
  return <Custom404 />;
}