import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcrypt'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  const roles = [
    {
      name: 'free',
      rpm: parseInt(process.env.FREE_RPM) || 50,
      max_requests: 5000
    },
    {
      name: 'starter',
      rpm: parseInt(process.env.PREM_1_RPM) || 100,
      max_requests: 10000
    },
    {
      name: 'medium',
      rpm: parseInt(process.env.PREM_2_RPM) || 150,
      max_requests: 50000
    },
    {
      name: 'highest',
      rpm: parseInt(process.env.PREM_3_RPM) || 200,
      max_requests: 100000
    },
    {
      name: 'enterprise',
      rpm: 1000,
      max_requests: 1000000
    },
    {
      name: 'admin',
      rpm: parseInt(process.env.ADMIN_RPM) || 500,
      max_requests: 1000000
    },
    {
      name: 'dev',
      rpm: parseInt(process.env.DEV_RPM) || 1000,
      max_requests: 1000000
    }
  ]

  console.log('Seeding complete!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })