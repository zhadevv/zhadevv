import Webly, { App, Loader } from '@neoxr/webly'
import middleware from './lib/system/middleware.js'
import { logRequest } from './lib/global.js'

await Loader.scraper('./lib/scraper')

const app = new App({
  name: 'Zhadev Creative API',
  staticPath: ['public'],
  routePath: './routes',
  middleware,
  socket: false,
  port: process.env.PORT || 3000,
  session: {
    name: 'token',
    keys: ['zhadev_session'],
    maxAge: 72 * 60 * 60 * 1000,
    httpOnly: true,
    sameSite: 'strict'
  },
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: '*',
    preflightContinue: false,
    optionsSuccessStatus: 204,
    exposedHeaders: '*',
    credentials: true
  },
  error: (req, res) => {
    res.status(404).sendFile('./public/404.html', { root: process.cwd() })
  }
})

app.use((req, res, next) => {
  res.startTime = Date.now()
  
  res.on('finish', () => {
    const responseTime = Date.now() - res.startTime
    logRequest(req, res, responseTime)
    
    res.setHeader('X-Process-Time', responseTime)
    res.setHeader('Server', 'Zhadev Creative API')
    res.setHeader('Date', new Date().toUTCString())
    
    if (res.statusCode === 200) {
      res.setHeader('Cache-Control', 'public, max-age=60')
    }
  })
  
  next()
})

app.start()