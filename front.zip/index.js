import Webly, { App, Loader } from '@neoxr/webly'
import './lib/global.js'
import middleware from './lib/system/middleware.js'
import os from 'node:os'

await Loader.scraper('./lib/scraper')

const app = new App({
  name: 'Zhadev API',
  staticPath: ['public'],
  routePath: './routers',
  middleware,
  socket: true,
  port: process.env.PORT || 3000,
  session: {
    name: 'token',
    keys: ['session'],
    maxAge: 72 * 60 * 60 * 1000,
    httpOnly: false,
    sameSite: 'strict'
  },
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: '*',
    preflightContinue: false,
    optionsSuccessStatus: 204,
    exposedHeaders: '*',
    credentials: true
  },
  error: (req, res) => {
    res.status(404).sendFile('./public/404.html', { root: process.cwd() })
  }
})

app.socket?.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`)

  const systemMonitorInterval = setInterval(() => {
    const totalMemory = os.totalmem()
    const freeMemory = os.freemem()
    const usedMemory = totalMemory - freeMemory
    const usagePercentage = (usedMemory / totalMemory) * 100

    const formattedData = {
      total: `${(totalMemory / 1024 / 1024).toFixed(2)} MB`,
      free: `${(freeMemory / 1024 / 1024).toFixed(2)} MB`,
      used: `${(usedMemory / 1024 / 1024).toFixed(2)} MB`,
      usagePercentage: usagePercentage.toFixed(2)
    }

    socket.emit('system_update', formattedData)

  }, 2000)

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`)
    clearInterval(systemMonitorInterval)
  })
})

app.start()