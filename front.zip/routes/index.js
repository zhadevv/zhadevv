import { allRoutes } from './endpoints/main.js'
import { allAdminRoutes } from './endpoints/admin.js'
import { allWebhookRoutes } from './endpoints/webhook.js'
import { allAuthRoutes } from './endpoints/ajax/auth.js'
import { allUserRoutes } from './endpoints/ajax/user.js'
import { allPaymentRoutes } from './endpoints/ajax/payment.js'
import { allPromoRoutes } from './endpoints/promo.js'

const allApiRoutes = [
  ...allRoutes,
  ...allAdminRoutes,
  ...allWebhookRoutes,
  ...allAuthRoutes,
  ...allUserRoutes,
  ...allPaymentRoutes,
  ...allPromoRoutes
]

export const routes = allApiRoutes

export default routes