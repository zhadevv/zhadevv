import { PrismaClient } from '@prisma/client'
import { generateApikey, getGeolocation } from '../../lib/global.js'
import { Validator } from '../../lib/system/validator.js'
import Config from '../../lib/system/config.js'
import cloudflare from '../../lib/cloudflare.js'
import requires from '../../middlewares/requires.js'

const prisma = new PrismaClient()

export const routes = [
  {
    category: 'admin',
    path: '/api/admin/generate_key',
    method: 'post',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { 
          username, 
          role = 'FREE', 
          custom_key, 
          active = 'all',
          contact,
          customNote 
        } = req.query
        
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (!Validator.validateRole(role)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid role'
          })
        }
        
        const generatedKey = generateApikey(role, custom_key)
        
        let finalUsername = username
        if (!finalUsername) {
          const randomNum = Math.floor(100000 + Math.random() * 900000)
          finalUsername = `zhadev_${randomNum}`
        }
        
        const monthlyLimit = Config.getMonthlyLimit(role)
        const rpmLimit = Config.getRoleRpm(role)
        
        const activeVersions = active === 'all' ? ['v1'] : [active]
        
        const apiKeyRecord = await prisma.apiKey.create({
          data: {
            key: generatedKey,
            owner: Validator.sanitizeInput(finalUsername),
            contact: contact ? Validator.sanitizeInput(contact) : 'contact@zhadev.my.id',
            role,
            monthlyLimit,
            rpmLimit,
            activeVersions,
            customNote: customNote ? Validator.sanitizeInput(customNote) : null,
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          }
        })
        
        await prisma.systemStats.updateMany({
          data: {
            totalApikeys: { increment: 1 },
            activeApikeys: { increment: 1 }
          }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            apikey: {
              key: generatedKey,
              owner: apiKeyRecord.owner,
              role: apiKeyRecord.role,
              monthlyLimit: apiKeyRecord.monthlyLimit,
              rpmLimit: apiKeyRecord.rpmLimit,
              activeVersions: apiKeyRecord.activeVersions,
              expiresAt: apiKeyRecord.expiresAt,
              createdAt: apiKeyRecord.createdAt
            }
          },
          message: 'Apikey generated successfully'
        })
      } catch (error) {
        console.error('Generate key error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.code === 'P2002') {
          res.status(409).json({
            status: 409,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Apikey already exists'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to generate apikey'
          })
        }
      }
    },
    middleware: [requires(['apikey'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/suspended_key',
    method: 'post',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { keys } = req.query
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (!keys) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Keys parameter required'
          })
        }
        
        const keyRecords = await prisma.apiKey.updateMany({
          where: {
            key: { in: keys.split(',') },
            isSuspended: false
          },
          data: {
            isSuspended: true,
            updatedAt: new Date()
          }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            suspendedCount: keyRecords.count
          },
          message: `${keyRecords.count} apikey(s) suspended`
        })
      } catch (error) {
        console.error('Suspend key error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to suspend apikey'
        })
      }
    },
    middleware: [requires(['apikey', 'keys'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/unsuspense_keys',
    method: 'put',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { keys } = req.query
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (!keys) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Keys parameter required'
          })
        }
        
        const keyRecords = await prisma.apiKey.updateMany({
          where: {
            key: { in: keys.split(',') },
            isSuspended: true
          },
          data: {
            isSuspended: false,
            monthlyUsed: 0,
            updatedAt: new Date()
          }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            unsuspendedCount: keyRecords.count
          },
          message: `${keyRecords.count} apikey(s) unsuspended`
        })
      } catch (error) {
        console.error('Unsuspense key error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to unsuspense apikey'
        })
      }
    },
    middleware: [requires(['apikey', 'keys'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/remove_key',
    method: 'delete',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { keys } = req.query
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isOwnerKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Owner access required'
          })
        }
        
        if (!keys) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Keys parameter required'
          })
        }
        
        const keysArray = keys.split(',')
        
        await prisma.request.deleteMany({
          where: {
            apikey: {
              key: { in: keysArray }
            }
          }
        })
        
        await prisma.ipLog.deleteMany({
          where: {
            apikey: {
              key: { in: keysArray }
            }
          }
        })
        
        const deletedKeys = await prisma.apiKey.deleteMany({
          where: {
            key: { in: keysArray }
          }
        })
        
        await prisma.systemStats.updateMany({
          data: {
            totalApikeys: { decrement: deletedKeys.count },
            activeApikeys: { decrement: deletedKeys.count }
          }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            removedCount: deletedKeys.count
          },
          message: `${deletedKeys.count} apikey(s) removed`
        })
      } catch (error) {
        console.error('Remove key error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to remove apikey'
        })
      }
    },
    middleware: [requires(['apikey', 'keys'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/stats',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const stats = await prisma.systemStats.findFirst({
          orderBy: { lastUpdated: 'desc' }
        })
        
        const totalApikeys = await prisma.apiKey.count()
        const activeApikeys = await prisma.apiKey.count({
          where: { isActive: true, isSuspended: false }
        })
        
        const suspendedApikeys = await prisma.apiKey.count({
          where: { isSuspended: true }
        })
        
        const roleDistribution = await prisma.apiKey.groupBy({
          by: ['role'],
          _count: true,
          where: { isActive: true }
        })
        
        const recentKeys = await prisma.apiKey.findMany({
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            key: false,
            owner: true,
            role: true,
            monthlyUsed: true,
            monthlyLimit: true,
            isSuspended: true,
            createdAt: true,
            expiresAt: true
          }
        })
        
        const topRequesters = await prisma.ipLog.groupBy({
          by: ['ip'],
          _sum: { requestCount: true },
          orderBy: { _sum: { requestCount: 'desc' } },
          take: 20,
          select: {
            ip: true,
            country: true,
            city: true
          }
        })
        
        const hourlyRequests = await prisma.request.groupBy({
          by: ['timestamp'],
          _count: true,
          where: {
            timestamp: {
              gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
            }
          },
          orderBy: { timestamp: 'asc' }
        })
        
        let cloudflareStats = null
        try {
          if (Config.CLOUDFLARE.API_TOKEN && Config.CLOUDFLARE.ZONE_ID) {
            cloudflareStats = await cloudflare.getAnalytics('24h')
          }
        } catch (error) {
          console.error('Cloudflare stats error:', error)
        }
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            summary: {
              totalApikeys,
              activeApikeys,
              suspendedApikeys,
              totalRequests: stats?.totalRequests || 0,
              dailyRequests: stats?.dailyRequests || 0,
              monthlyRequests: stats?.monthlyRequests || 0,
              lastUpdated: stats?.lastUpdated || new Date()
            },
            categoryBreakdown: {
              anime: stats?.animeRequests || 0,
              donghua: stats?.donghuaRequests || 0,
              dracin: stats?.dracinRequests || 0,
              tools: stats?.toolsRequests || 0,
              network: stats?.networkRequests || 0,
              guest: stats?.guestRequests || 0
            },
            roleDistribution: roleDistribution.reduce((acc, curr) => {
              acc[curr.role] = curr._count
              return acc
            }, {}),
            recentKeys,
            topRequesters: topRequesters.map(r => ({
              ip: r.ip,
              requestCount: r._sum.requestCount,
              location: r.country ? `${r.country}, ${r.city}` : 'Unknown'
            })),
            hourlyRequests: hourlyRequests.map(r => ({
              hour: r.timestamp.getHours(),
              count: r._count
            })),
            cloudflare: cloudflareStats,
            system: {
              uptime: process.uptime(),
              nodeVersion: process.version,
              memoryUsage: process.memoryUsage(),
              timestamp: new Date().toISOString()
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Admin stats error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch admin statistics'
        })
      }
    },
    middleware: [requires(['apikey'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/ip_logs',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { ip } = req.query
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        let logs
        let total = 0
        
        if (ip) {
          logs = await prisma.ipLog.findMany({
            where: { ip },
            orderBy: { lastRequest: 'desc' },
            include: {
              apikey: {
                select: {
                  owner: true,
                  role: true,
                  isSuspended: true
                }
              },
              requests: {
                orderBy: { timestamp: 'desc' },
                take: 50,
                select: {
                  path: true,
                  method: true,
                  statusCode: true,
                  responseTime: true,
                  timestamp: true
                }
              }
            }
          })
          
          total = logs.length
        } else {
          const page = Math.max(1, parseInt(req.query.page) || 1)
          const limit = 100
          const skip = (page - 1) * limit
          
          logs = await prisma.ipLog.findMany({
            orderBy: { lastRequest: 'desc' },
            take: limit,
            skip,
            include: {
              apikey: {
                select: {
                  owner: true,
                  role: true,
                  isSuspended: true
                }
              }
            }
          })
          
          total = await prisma.ipLog.count()
        }
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            logs: logs.map(log => ({
              ip: log.ip,
              userAgent: log.userAgent,
              location: log.country ? `${log.country}, ${log.region}, ${log.city}` : 'Unknown',
              isp: log.isp,
              isBanned: log.isBanned,
              requestCount: log.requestCount,
              monthlyUsed: log.monthlyUsed,
              lastRequest: log.lastRequest,
              apikey: log.apikey ? {
                owner: log.apikey.owner,
                role: log.apikey.role,
                isSuspended: log.apikey.isSuspended
              } : null,
              requests: log.requests || []
            })),
            total,
            page: parseInt(req.query.page) || 1
          },
          message: null
        })
      } catch (error) {
        console.error('IP logs error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch IP logs'
        })
      }
    },
    middleware: [requires(['apikey'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/moderate',
    method: 'post',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { ban, unban } = req.query
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (ban) {
          if (!Validator.isIp(ban)) {
            return res.status(400).json({
              status: 400,
              success: false,
              author: 'zhadevv',
              data: null,
              message: 'Invalid IP address'
            })
          }
          
          const geolocation = await getGeolocation(ban)
          
          const bannedIp = await prisma.bannedIp.create({
            data: {
              ip: ban,
              reason: req.query.reason || 'Violation of terms',
              bannedBy: 'admin',
              expiresAt: req.query.days ? 
                new Date(Date.now() + parseInt(req.query.days) * 24 * 60 * 60 * 1000) : 
                null
            }
          })
          
          await prisma.ipLog.updateMany({
            where: { ip: ban },
            data: { isBanned: true }
          })
          
          const responseTime = Date.now() - start
          
          res.setHeader('X-Process-Time', responseTime)
          
          res.json({
            status: 200,
            success: true,
            author: 'zhadevv',
            data: {
              bannedIp: {
                ip: bannedIp.ip,
                reason: bannedIp.reason,
                bannedAt: bannedIp.bannedAt,
                expiresAt: bannedIp.expiresAt,
                location: geolocation
              }
            },
            message: 'IP address banned successfully'
          })
          
        } else if (unban) {
          const deleted = await prisma.bannedIp.deleteMany({
            where: { ip: unban }
          })
          
          await prisma.ipLog.updateMany({
            where: { ip: unban },
            data: { isBanned: false }
          })
          
          const responseTime = Date.now() - start
          
          res.setHeader('X-Process-Time', responseTime)
          
          res.json({
            status: 200,
            success: true,
            author: 'zhadevv',
            data: {
              unbannedCount: deleted.count
            },
            message: deleted.count > 0 ? 'IP address unbanned' : 'IP not found in banned list'
          })
        } else {
          res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Either ban or unban parameter required'
          })
        }
      } catch (error) {
        console.error('Moderate error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.code === 'P2002') {
          res.status(409).json({
            status: 409,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'IP already banned'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Moderation failed'
          })
        }
      }
    },
    middleware: [requires(['apikey'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  },
  {
    category: 'admin',
    path: '/api/admin/moderate/:path',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { path } = req.params
        const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
        
        if (!Config.isAdminKey(apikey)) {
          return res.status(403).json({
            status: 403,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (path === 'banned-ips') {
          const bannedIps = await prisma.bannedIp.findMany({
            orderBy: { bannedAt: 'desc' }
          })
          
          const responseTime = Date.now() - start
          
          res.setHeader('X-Process-Time', responseTime)
          
          res.json({
            status: 200,
            success: true,
            author: 'zhadevv',
            data: {
              bannedIps: bannedIps.map(ip => ({
                ip: ip.ip,
                reason: ip.reason,
                bannedBy: ip.bannedBy,
                bannedAt: ip.bannedAt,
                expiresAt: ip.expiresAt
              })),
              total: bannedIps.length
            },
            message: null
          })
          
        } else if (path === 'total_keys') {
          const keysByRole = await prisma.apiKey.groupBy({
            by: ['role'],
            _count: true,
            where: { isActive: true }
          })
          
          const suspendedCount = await prisma.apiKey.count({
            where: { isSuspended: true }
          })
          
          const activeCount = await prisma.apiKey.count({
            where: { isActive: true, isSuspended: false }
          })
          
          const responseTime = Date.now() - start
          
          res.setHeader('X-Process-Time', responseTime)
          
          res.json({
            status: 200,
            success: true,
            author: 'zhadevv',
            data: {
              totalByRole: keysByRole.reduce((acc, curr) => {
                acc[curr.role] = curr._count
                return acc
              }, {}),
              suspended: suspendedCount,
              active: activeCount,
              total: activeCount + suspendedCount
            },
            message: null
          })
        } else {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Path not found'
          })
        }
      } catch (error) {
        console.error('Moderate path error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch data'
        })
      }
    },
    middleware: [requires(['apikey'])],
    error: false,
    rpm: true,
    premium: true,
    restrict: true
  }
]