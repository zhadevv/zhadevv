import { Loader } from '@neoxr/webly'
import { Validator } from '../../../lib/system/validator.js'
import requires from '../../../middlewares/requires.js'
const Scraper = Loader.scrapers

export const routes = [
  {
    category: 'donghua',
    path: '/api/v1/donghua/sidebar',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry('/')
        const result = await donghuaParser.parse_sidebar(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            sidebar: result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua sidebar error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua sidebar'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/schedule',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry('/schedule')
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_schedule(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            schedule: result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua schedule error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua schedule'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/home',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/page/${page}` : '/'
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        const result = await donghuaParser.parse_home(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua home error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua home'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/search',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { q } = req.query
        
        if (!q || q.trim().length === 0) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Query parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const encodedQuery = encodeURIComponent(q.trim())
        const url = `/page/${page}/?s=${encodedQuery}` : `/?s=${encodedQuery}`
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_search(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            query: q,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua search error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to search donghua'
        })
      }
    },
    middleware: [requires(['q'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/ongoing',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/ongoing/page/${page}` : '/ongoing'
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_ongoing(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua ongoing error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch ongoing donghua'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/completed',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/completed/page/${page}` : '/completed'
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_completed(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua completed error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch completed donghua'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/az_list',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const { show } = req.query
        let url = `/az_lists/`
        
        if (show) {
          url += `?show=${show}`
        }
        
        if (page > 1) {
          url += `${show ? '&' : '?'}page=${page}`
        }
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        
        let result
        if (show) {
          result = await donghuaParser.parse_az_list_with_show(response.data, show)
        } else {
          result = await donghuaParser.parse_az_list(response.data)
        }
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            show: show || 'all',
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua AZ list error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua A-Z list'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/genres/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Genre slug required'
          })
        }
        
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/genres/${slug}/page/${page}` : `/genres/${slug}`
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_genres(response.data, slug)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            genre: slug,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua genres error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua by genre'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/seasons/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Season slug required'
          })
        }
        
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/season/${slug}/page/${page}` : `/season/${slug}`
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_seasons(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            season: slug,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua seasons error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua by season'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/detail/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Donghua slug required'
          })
        }
        
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const url = `/seri/${slug}`
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        const result = await donghuaParser.parse_detail(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=7200')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            detail: result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua detail error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Donghua not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch donghua detail'
          })
        }
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/watch/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        const { episode } = req.query
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Donghua slug required'
          })
        }
        
        if (!episode) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const url = `/${slug}-episode-${episode}-subtitle-indonesia`
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        const result = await donghuaParser.parse_watch(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            episode: parseInt(episode),
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua watch error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch donghua episode'
          })
        }
      }
    },
    middleware: [requires(['episode'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/filters/list-mode',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const url = '/seri/list-mode'
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_advanced_search_text_mode(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            filters_list: result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua filters list error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua filters list'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/filters',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        
        const queryParams = new URLSearchParams()
        const allowedParams = ['status', 'type', 'order', 'sub', 'genres', 'studios', 'seasons']
        
        for (const param of allowedParams) {
          if (req.query[param]) {
            if (Array.isArray(req.query[param])) {
              req.query[param].forEach(value => {
                queryParams.append(`${param}[]`, value)
              })
            } else {
              queryParams.append(param, req.query[param])
            }
          }
        }
        
        let url = '/seri'
        if (queryParams.toString()) {
          url += `?${queryParams.toString()}`
        }
        
        if (page > 1) {
          url += `${queryParams.toString() ? '&' : '?'}page=${page}`
        }
        
        const donghuaParser = new Scraper.Donghua()
        const response = await donghuaParser.fetchWithRetry(url)
        donghuaParser.setCurrentUrl(response.url)
        const result = await donghuaParser.parse_advance_search(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            filters: Object.fromEntries(queryParams),
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua filters error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch donghua with filters'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'donghua',
    path: '/api/v1/donghua/random',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Donghua) {
          throw new Error('Donghua scraper not loaded')
        }
        
        const donghuaParser = new Scraper.Donghua()
        
        const listUrl = '/seri/list-mode'
        const listResponse = await donghuaParser.fetchWithRetry(listUrl)
        donghuaParser.setCurrentUrl(listResponse.url)
        const listResult = await donghuaParser.parse_advanced_search_text_mode(listResponse.data)
        
        if (!listResult.donghua || listResult.donghua.length === 0) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'No donghua found for random selection'
          })
        }
        
        const randomDonghua = listResult.donghua[Math.floor(Math.random() * listResult.donghua.length)]
        
        if (!randomDonghua.slug) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Random donghua slug not found'
          })
        }
        
        const detailUrl = `/series/${randomDonghua.slug}`
        const detailResponse = await donghuaParser.fetchWithRetry(detailUrl)
        const detailResult = await donghuaParser.parse_detail(detailResponse.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            random: {
              donghua: detailResult
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Donghua random error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch random donghua'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  }
]