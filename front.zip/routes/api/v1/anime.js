import { Loader } from '@neoxr/webly'
import { Validator } from '../../../lib/system/validator.js'
import requires from '../../../middlewares/requires.js'
const Scraper = Loader.scrapers

export const routes = [
  {
    category: 'anime',
    path: '/api/v1/anime/sidebar',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry('/')
        const result = await animeParser.parse_sidebar(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            sidebar: result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime sidebar error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime sidebar'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/schedule',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry('/jadwal-rilis')
        animeParser.setCurrentUrl(response.url)
        const result = await animeParser.parse_schedule(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            schedule: result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime schedule error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime schedule'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/home',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/page/${page}` : '/'
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        const result = await animeParser.parse_home(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime home error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime home'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/search',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { q } = req.query
        
        if (!q || q.trim().length === 0) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Query parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const encodedQuery = encodeURIComponent(q.trim())
        const url = `/page/${page}/?s=${encodedQuery}` : `/?s=${encodedQuery}`
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        animeParser.setCurrentUrl(response.url)
        const result = await animeParser.parse_search(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            query: q,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime search error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to search anime'
        })
      }
    },
    middleware: [requires(['q'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/genres/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Genre slug required'
          })
        }
        
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const url = page > 1 ? `/genres/${slug}/page/${page}` : `/genres/${slug}`
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        animeParser.setCurrentUrl(response.url)
        const result = await animeParser.parse_genres(response.data, slug)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            genre: slug,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime genres error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime by genre'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/detail/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Anime slug required'
          })
        }
        
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const url = `/anime/${slug}`
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        const result = await animeParser.parse_detail(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=7200')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            detail: result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime detail error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Anime not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch anime detail'
          })
        }
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/watch/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { slug } = req.params
        const { episode } = req.query
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Anime slug required'
          })
        }
        
        if (!episode) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const url = `/${slug}-episode-${episode}-subtitle-indonesia`
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        const result = await animeParser.parse_watch(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            episode: parseInt(episode),
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime watch error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch anime episode'
          })
        }
      }
    },
    middleware: [requires(['episode'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/filters/list-mode',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const url = '/anime/list-mode'
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        animeParser.setCurrentUrl(response.url)
        const result = await animeParser.parse_advanced_search_text_mode(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            filters_list: result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime filters list error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime filters list'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/filters',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        
        const queryParams = new URLSearchParams()
        const allowedParams = ['status', 'type', 'order', 'genres', 'studios', 'seasons']
        
        for (const param of allowedParams) {
          if (req.query[param]) {
            if (Array.isArray(req.query[param])) {
              req.query[param].forEach(value => {
                queryParams.append(`${param}[]`, value)
              })
            } else {
              queryParams.append(param, req.query[param])
            }
          }
        }
        
        let url = '/anime'
        if (queryParams.toString()) {
          url += `?${queryParams.toString()}`
        }
        
        if (page > 1) {
          url += `${queryParams.toString() ? '&' : '?'}page=${page}`
        }
        
        const animeParser = new Scraper.Anime()
        const response = await animeParser.fetchWithRetry(url)
        animeParser.setCurrentUrl(response.url)
        const result = await animeParser.parse_advance_search(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            page,
            filters: Object.fromEntries(queryParams),
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Anime filters error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch anime with filters'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'anime',
    path: '/api/v1/anime/random',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Anime) {
          throw new Error('Anime scraper not loaded')
        }
        
        const animeParser = new Scraper.Anime()
        
        const listUrl = '/anime/list-mode'
        const listResponse = await animeParser.fetchWithRetry(listUrl)
        animeParser.setCurrentUrl(listResponse.url)
        const listResult = await animeParser.parse_advanced_search_text_mode(listResponse.data)
        
        if (!listResult.anime || listResult.anime.length === 0) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'No anime found for random selection'
          })
        }
        
        const randomAnime = listResult.anime[Math.floor(Math.random() * listResult.anime.length)]
        
        if (!randomAnime.slug) {
          return res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Random anime slug not found'
          })
        }
        
        const detailUrl = `/anime/${randomAnime.slug}`
        const detailResponse = await animeParser.fetchWithRetry(detailUrl)
        const detailResult = await animeParser.parse_detail(detailResponse.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            random: {
              selected_letter: randomLetter,
              anime: detailResult
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Anime random error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch random anime'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  }
]