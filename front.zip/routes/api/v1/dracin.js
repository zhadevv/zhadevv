import { Loader } from '@neoxr/webly'
import { Validator } from '../../../lib/system/validator.js'
import requires from '../../../middlewares/requires.js'
const Scraper = Loader.scrapers

export const routes = [
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/sidecontent',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const regionPath = region === 'en' ? '/' : `/${region}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(regionPath)
        const result = await dracinParser.parse_home(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            sidecontent: result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin sidecontent error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin sidecontent'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/home',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const regionPath = region === 'en' ? '/' : `/${region}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(regionPath)
        const result = await dracinParser.parse_home(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            home: result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin home error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin home'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/channel/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region, slug } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Channel slug required'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const regionPath = region === 'en' ? '' : `/${region}`
        const url = page > 1 ? `${regionPath}/browse/${slug}/${page}` : `${regionPath}/browse/${slug}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_channel(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            channel: slug,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin channel error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin channel'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/genres',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const regionPath = region === 'en' ? '' : `/${region}`
        const url = `${regionPath}/category?typeTwoId=0`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_genres(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin genres error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin genres'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/genres/:id',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region, id } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!id || isNaN(parseInt(id))) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Valid genre ID required'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const page = Validator.validatePageNumber(req.query.page)
        const regionPath = region === 'en' ? '' : `/${region}`
        const url = page > 1 ? 
          `${regionPath}/category?typeTwoId=${id}&page=${page}` : 
          `${regionPath}/category?typeTwoId=${id}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_genres(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=1800')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            genre_id: parseInt(id),
            page,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin genre by ID error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin by genre'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/search',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region } = req.params
        const { q } = req.query
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!q || q.trim().length === 0) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Query parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const regionPath = region === 'en' ? '' : `/${region}`
        const encodedQuery = encodeURIComponent(q.trim())
        const url = `${regionPath}/search?searchValue=${encodedQuery}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_search(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            query: q,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin search error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to search dracin'
        })
      }
    },
    middleware: [requires(['q'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/detail/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region, slug } = req.params
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Series slug required'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const regionPath = region === 'en' ? '' : `/${region}`
        const url = `${regionPath}/movie/${slug}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_detail(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=7200')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            detail: result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin detail error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Series not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch series detail'
          })
        }
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/:region/watch/:slug',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region, slug } = req.params
        const { episode } = req.query
        
        if (!Validator.validateRegion(region)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid region. Valid regions: en, id, zh, hans, ko, ja, tl, th, ar, pt, fr, es'
          })
        }
        
        if (!slug) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Series slug required'
          })
        }
        
        if (!episode) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode parameter required'
          })
        }
        
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const regionPath = region === 'en' ? '' : `/${region}`
        const url = `${regionPath}/ep/${slug}/${episode}`
        
        const dracinParser = new Scraper.Dracin({ region })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_watch(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region,
            episode: episode,
            ...result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin watch error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        if (error.message.includes('404') || error.message.includes('not found')) {
          res.status(404).json({
            status: 404,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Episode not found'
          })
        } else {
          res.status(500).json({
            status: 500,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Failed to fetch episode'
          })
        }
      }
    },
    middleware: [requires(['episode'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'dracin',
    path: '/api/v1/dracin/en/resources',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        if (!Scraper || !Scraper.Dracin) {
          throw new Error('Dracin scraper not loaded')
        }
        
        const url = '/resources'
        
        const dracinParser = new Scraper.Dracin({ region: 'en' })
        const response = await dracinParser.fetchWithRetry(url)
        const result = await dracinParser.parse_resources(response.data)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=7200')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            region: 'en',
            resources: result
          },
          message: null
        })
      } catch (error) {
        console.error('Dracin resources error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch dracin resources'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  }
]