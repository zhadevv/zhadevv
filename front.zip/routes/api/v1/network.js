import { getGeolocation } from '../../../lib/global.js'
import { Validator } from '../../../lib/system/validator.js'
import requires from '../../../middlewares/requires.js'

export const routes = [
  {
    category: 'network',
    path: '/api/v1/network/@me',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip
        const userAgent = req.headers['user-agent']
        
        const geolocation = await getGeolocation(ip)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            network: {
              ip,
              user_agent: userAgent,
              geolocation: geolocation || {
                country: 'Unknown',
                region: 'Unknown',
                city: 'Unknown',
                isp: 'Unknown'
              },
              headers: {
                host: req.headers.host,
                accept: req.headers.accept,
                accept_encoding: req.headers['accept-encoding'],
                accept_language: req.headers['accept-language'],
                connection: req.headers.connection,
                dnt: req.headers.dnt,
                'sec-ch-ua': req.headers['sec-ch-ua'],
                'sec-ch-ua-mobile': req.headers['sec-ch-ua-mobile'],
                'sec-ch-ua-platform': req.headers['sec-ch-ua-platform'],
                'sec-fetch-dest': req.headers['sec-fetch-dest'],
                'sec-fetch-mode': req.headers['sec-fetch-mode'],
                'sec-fetch-site': req.headers['sec-fetch-site'],
                'upgrade-insecure-requests': req.headers['upgrade-insecure-requests']
              }
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Network @me error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch network information'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'network',
    path: '/api/v1/network/holiday_calendar',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { region = 'ID' } = req.query
        const currentYear = new Date().getFullYear()
        
        const response = await fetch(`https://date.nager.at/api/v3/publicholidays/${currentYear}/${region}`)
        
        if (!response.ok) {
          throw new Error(`Holiday API returned ${response.status}`)
        }
        
        const holidays = await response.json()
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=86400')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            holidays: {
              region,
              year: currentYear,
              holidays: holidays.map(holiday => ({
                date: holiday.date,
                local_name: holiday.localName,
                name: holiday.name,
                country_code: holiday.countryCode,
                global: holiday.global,
                counties: holiday.counties,
                launch_year: holiday.launchYear,
                types: holiday.types
              }))
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Holiday calendar error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch holiday calendar'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'network',
    path: '/api/v1/network/exchange',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { from = 'IDR', to = 'USD' } = req.query
        
        if (!from || !to) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Both from and to currency codes are required'
          })
        }
        
        const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${from}`)
        
        if (!response.ok) {
          throw new Error(`Exchange API returned ${response.status}`)
        }
        
        const data = await response.json()
        
        if (!data.rates || !data.rates[to]) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid currency code'
          })
        }
        
        const exchangeRate = data.rates[to]
        const timestamp = new Date(data.date).getTime()
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            exchange: {
              from,
              to,
              rate: exchangeRate,
              last_updated: new Date(timestamp).toISOString(),
              base_currency: data.base,
              rates_count: Object.keys(data.rates).length
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Exchange error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch exchange rates'
        })
      }
    },
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  }
]