import { Validator } from '../../../lib/system/validator.js'
import requires from '../../../middlewares/requires.js'

export const routes = [
  {
    category: 'tools',
    path: '/api/v1/tools/checkhost',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { url } = req.query
        
        if (!url) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'URL parameter required'
          })
        }
        
        if (!Validator.isUrl(url)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid URL format'
          })
        }
        
        let parsedUrl
        try {
          parsedUrl = new URL(url)
        } catch {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid URL'
          })
        }
        
        const hostname = parsedUrl.hostname
        
        const dnsLookupStart = Date.now()
        const dnsResponse = await fetch(`https://dns.google/resolve?name=${hostname}&type=A`)
        const dnsData = await dnsResponse.json()
        const dnsTime = Date.now() - dnsLookupStart
        
        let pingTime = null
        let httpStatus = null
        let sslInfo = null
        
        try {
          const pingStart = Date.now()
          const httpResponse = await fetch(url, {
            method: 'HEAD',
            timeout: 10000,
            redirect: 'follow'
          })
          pingTime = Date.now() - pingStart
          httpStatus = httpResponse.status
          
          if (parsedUrl.protocol === 'https:') {
            sslInfo = {
              protocol: 'TLS',
              secure: true
            }
          }
        } catch (error) {
          pingTime = null
          httpStatus = error.message
        }
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=60')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            checkhost: {
              url,
              hostname,
              ip_addresses: dnsData.Answer ? dnsData.Answer.map(a => a.data) : [],
              dns_response_time: dnsTime,
              ping_time: pingTime,
              http_status: httpStatus,
              ssl: sslInfo,
              timestamp: new Date().toISOString()
            }
          },
          message: null
        })
      } catch (error) {
        console.error('Checkhost error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to check host'
        })
      }
    },
    middleware: [requires(['url'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'tools',
    path: '/api/v1/tools/whois',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { domain } = req.query
        
        if (!domain) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Domain parameter required'
          })
        }
        
        if (!Validator.isDomain(domain)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid domain format'
          })
        }
        
        const whoisResponse = await fetch(`https://api.whoisfreaks.com/v1.0/whois?apiKey=demo&whois=live&domainName=${domain}`)
        
        if (!whoisResponse.ok) {
          throw new Error(`WHOIS API returned ${whoisResponse.status}`)
        }
        
        const whoisData = await whoisResponse.json()
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=3600')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            whois: {
              domain,
              registered: whoisData.registered || false,
              created_date: whoisData.create_date,
              updated_date: whoisData.updated_date,
              expiry_date: whoisData.expiry_date,
              registrar: whoisData.registrar,
              name_servers: whoisData.name_servers,
              status: whoisData.domain_status,
              registrant: {
                name: whoisData.registrant_name,
                organization: whoisData.registrant_organization,
                email: whoisData.registrant_email
              },
              admin: {
                name: whoisData.admin_name,
                organization: whoisData.admin_organization,
                email: whoisData.admin_email
              },
              tech: {
                name: whoisData.tech_name,
                organization: whoisData.tech_organization,
                email: whoisData.tech_email
              }
            }
          },
          message: null
        })
      } catch (error) {
        console.error('WHOIS error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch WHOIS information'
        })
      }
    },
    middleware: [requires(['domain'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  },
  {
    category: 'tools',
    path: '/api/v1/tools/ssweb',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const { url } = req.query
        
        if (!url) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'URL parameter required'
          })
        }
        
        if (!Validator.isUrl(url)) {
          return res.status(400).json({
            status: 400,
            success: false,
            author: 'zhadevv',
            data: null,
            message: 'Invalid URL format'
          })
        }
        
        const apiKey = process.env.SSWEB_API_KEY || 'demo'
        const screenshotUrl = `https://api.screenshotmachine.com/?key=${apiKey}&url=${encodeURIComponent(url)}&dimension=1024x768&format=png&delay=2000`
        
        const screenshotResponse = await fetch(screenshotUrl)
        
        if (!screenshotResponse.ok) {
          throw new Error(`Screenshot API returned ${screenshotResponse.status}`)
        }
        
        const imageBuffer = await screenshotResponse.arrayBuffer()
        const base64Image = Buffer.from(imageBuffer).toString('base64')
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=300')
        res.setHeader('Content-Type', 'application/json')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            ssweb: {
              url,
              screenshot: `data:image/png;base64,${base64Image}`,
              dimensions: '1024x768',
              format: 'png',
              timestamp: new Date().toISOString()
            }
          },
          message: null
        })
      } catch (error) {
        console.error('SSWeb error:', error)
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to capture screenshot'
        })
      }
    },
    middleware: [requires(['url'])],
    error: false,
    rpm: true,
    premium: false,
    restrict: true
  }
]