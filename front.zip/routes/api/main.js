import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export const routes = [
  {
    category: 'main',
    path: '/api/health',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        await prisma.$queryRaw`SELECT 1`
        
        const stats = await prisma.systemStats.findFirst({
          orderBy: { lastUpdated: 'desc' }
        })
        
        const totalApikeys = await prisma.apiKey.count()
        const activeApikeys = await prisma.apiKey.count({
          where: { isActive: true, isSuspended: false }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Server', 'Zhadev Creative API')
        res.setHeader('Date', new Date().toUTCString())
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            health: {
              database: 'connected',
              uptime: process.uptime(),
              memory: process.memoryUsage(),
              timestamp: new Date().toISOString()
            },
            stats: {
              totalApikeys,
              activeApikeys,
              totalRequests: stats?.totalRequests || 0,
              dailyRequests: stats?.dailyRequests || 0,
              monthlyRequests: stats?.monthlyRequests || 0
            }
          },
          message: null
        })
      } catch (error) {
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Database connection failed'
        })
      }
    },
    error: false,
    authorize: false,
    rpm: false,
    protect: false,
    premium: false,
    restrict: false
  },
  {
    category: 'main',
    path: '/api/stats',
    method: 'get',
    execution: async (req, res) => {
      const start = Date.now()
      
      try {
        const stats = await prisma.systemStats.findFirst({
          orderBy: { lastUpdated: 'desc' }
        })
        
        const totalApikeys = await prisma.apiKey.count()
        const activeApikeys = await prisma.apiKey.count({
          where: { isActive: true, isSuspended: false }
        })
        
        const roleCounts = await prisma.apiKey.groupBy({
          by: ['role'],
          _count: true,
          where: { isActive: true, isSuspended: false }
        })
        
        const topIps = await prisma.ipLog.findMany({
          orderBy: { requestCount: 'desc' },
          take: 10,
          select: {
            ip: true,
            requestCount: true,
            country: true,
            city: true,
            lastRequest: true
          }
        })
        
        const popularEndpoints = await prisma.request.groupBy({
          by: ['path'],
          _count: true,
          orderBy: { _count: 'desc' },
          take: 10,
          where: {
            timestamp: {
              gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
            }
          }
        })
        
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.setHeader('Cache-Control', 'public, max-age=60')
        res.setHeader('Age', '0')
        
        res.json({
          status: 200,
          success: true,
          author: 'zhadevv',
          data: {
            overview: {
              totalApikeys,
              activeApikeys,
              totalRequests: stats?.totalRequests || 0,
              dailyRequests: stats?.dailyRequests || 0,
              monthlyRequests: stats?.monthlyRequests || 0
            },
            categoryRequests: {
              anime: stats?.animeRequests || 0,
              donghua: stats?.donghuaRequests || 0,
              dracin: stats?.dracinRequests || 0,
              tools: stats?.toolsRequests || 0,
              network: stats?.networkRequests || 0,
              guest: stats?.guestRequests || 0
            },
            roleDistribution: roleCounts.reduce((acc, curr) => {
              acc[curr.role] = curr._count
              return acc
            }, {}),
            topIps,
            popularEndpoints: popularEndpoints.map(e => ({
              path: e.path,
              count: e._count
            })),
            system: {
              uptime: process.uptime(),
              nodeVersion: process.version,
              platform: process.platform,
              timestamp: new Date().toISOString()
            }
          },
          message: null
        })
      } catch (error) {
        const responseTime = Date.now() - start
        
        res.setHeader('X-Process-Time', responseTime)
        res.status(500).json({
          status: 500,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Failed to fetch statistics'
        })
      }
    },
    error: false,
    authorize: false,
    rpm: false,
    protect: false,
    premium: false,
    restrict: false
  }
]