import os from 'os'
import prisma from '../../prisma.config.js'

export const routes = [
  {
    category: 'api',
    path: '/api/health',
    method: 'get',
    execution: async (req, res) => {
      try {
        const uptime = process.uptime()
        const memoryUsage = process.memoryUsage()
        const cpuUsage = os.loadavg()
        
        const totalKeys = await prisma.apiKey.count()
        const activeKeys = await prisma.apiKey.count({
          where: { suspended: false }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            status: 'healthy',
            uptime: {
              seconds: Math.floor(uptime),
              formatted: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${Math.floor(uptime % 60)}s`
            },
            memory: {
              rss: `${Math.round(memoryUsage.rss / 1024 / 1024)} MB`,
              heapTotal: `${Math.round(memoryUsage.heapTotal / 1024 / 1024)} MB`,
              heapUsed: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)} MB`,
              external: `${Math.round(memoryUsage.external / 1024 / 1024)} MB`
            },
            system: {
              cpu: cpuUsage.map(load => load.toFixed(2)),
              platform: os.platform(),
              arch: os.arch(),
              hostname: os.hostname()
            },
            database: {
              connected: true,
              totalKeys,
              activeKeys
            },
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'api',
    path: '/api/stats',
    method: 'get',
    execution: async (req, res) => {
      try {
        const now = new Date()
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
        
        const [totalRequests, todayRequests, monthRequests, totalKeys, activeKeys, suspendedKeys, bannedIPs] = await Promise.all([
          prisma.requestLog.count(),
          prisma.requestLog.count({
            where: { timestamp: { gte: startOfDay } }
          }),
          prisma.requestLog.count({
            where: { timestamp: { gte: startOfMonth } }
          }),
          prisma.apiKey.count(),
          prisma.apiKey.count({ where: { suspended: false } }),
          prisma.apiKey.count({ where: { suspended: true } }),
          prisma.bannedIP.count({
            where: {
              OR: [
                { expires_at: null },
                { expires_at: { gt: now } }
              ]
            }
          })
        ])
        
        const topEndpoints = await prisma.requestLog.groupBy({
          by: ['endpoint'],
          _count: { endpoint: true },
          orderBy: { _count: { endpoint: 'desc' } },
          take: 10,
          where: { timestamp: { gte: startOfDay } }
        })
        
        const topIPs = await prisma.requestLog.groupBy({
          by: ['ip'],
          _count: { ip: true },
          orderBy: { _count: { ip: 'desc' } },
          take: 10,
          where: { timestamp: { gte: startOfDay } }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            requests: {
              total: totalRequests,
              today: todayRequests,
              thisMonth: monthRequests
            },
            apikeys: {
              total: totalKeys,
              active: activeKeys,
              suspended: suspendedKeys
            },
            security: {
              bannedIPs
            },
            topEndpoints: topEndpoints.map(item => ({
              endpoint: item.endpoint,
              count: item._count.endpoint
            })),
            topIPs: topIPs.map(item => ({
              ip: item.ip,
              count: item._count.ip
            })),
            timestamp: now.toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'api',
    path: '/api/check',
    method: 'get',
    parameter: ['apikey'],
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const keyData = await prisma.apiKey.findFirst({
          where: { key: apikey }
        })
        
        if (!keyData) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Apikey not found'
          })
        }
        
        const now = new Date()
        const resetDate = keyData.next_reset
        const daysUntilReset = Math.ceil((resetDate - now) / (1000 * 60 * 60 * 24))
        
        const todayRequests = await prisma.requestLog.count({
          where: {
            key_id: keyData.id,
            timestamp: {
              gte: new Date(now.getFullYear(), now.getMonth(), now.getDate())
            }
          }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            username: keyData.username,
            role: keyData.role,
            custom_key: keyData.custom_key,
            active: keyData.active,
            requests: {
              used: keyData.requests,
              limit: keyData.max_requests,
              remaining: Math.max(0, keyData.max_requests - keyData.requests),
              today: todayRequests
            },
            rpm_limit: keyData.rpm_limit,
            status: keyData.suspended ? 'suspended' : 'active',
            suspended_at: keyData.suspended_at,
            reset: {
              last_reset: keyData.last_reset,
              next_reset: keyData.next_reset,
              days_until_reset: daysUntilReset
            },
            created_at: keyData.created_at,
            updated_at: keyData.updated_at
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  }
]