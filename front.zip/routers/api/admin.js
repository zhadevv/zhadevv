import prisma from '../../prisma.config.js'
import { v4 as uuidv4 } from 'uuid'
import crypto from 'crypto'

const generateKey = (role, customKey = null) => {
  if (customKey) return customKey
  
  const prefix = role === 'free' ? 'SK_zhadev-freekeys_' : 'SK_zhadev_'
  const random = crypto.randomBytes(role === 'free' ? 8 : 16).toString('hex')
  return prefix + random
}

const getRpmLimit = (role) => {
  switch (role) {
    case 'free': return parseInt(process.env.FREE_RPM) || 50
    case 'starter': return parseInt(process.env.PREM_1_RPM) || 100
    case 'medium': return parseInt(process.env.PREM_2_RPM) || 150
    case 'highest': return parseInt(process.env.PREM_3_RPM) || 200
    case 'enterprise': return 1000
    case 'admin': return parseInt(process.env.ADMIN_RPM) || 500
    case 'dev': return parseInt(process.env.DEV_RPM) || 1000
    default: return parseInt(process.env.GUEST_RPM) || 25
  }
}

const getMaxRequests = (role) => {
  switch (role) {
    case 'free': return 5000
    case 'starter': return 10000
    case 'medium': return 50000
    case 'highest': return 100000
    case 'enterprise': return 1000000
    case 'admin': return 1000000
    case 'dev': return 1000000
    default: return 1000
  }
}

const validateAdminKey = (apikey) => {
  return apikey === process.env.DEV_APIKEY || apikey === process.env.OWNER_APIKEY
}

export const routes = [
  {
    category: 'admin',
    path: '/api/admin/generate_key',
    method: 'post',
    parameter: ['role', 'apikey'],
    execution: async (req, res) => {
      try {
        const { username, role, custom_key, active = 'all', apikey } = req.body
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const validRoles = ['free', 'starter', 'medium', 'highest', 'enterprise', 'admin', 'dev']
        if (!validRoles.includes(role)) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid role. Valid roles: free, starter, medium, highest, enterprise, admin, dev'
          })
        }
        
        const generatedUsername = username || `zhadev_${Math.random().toString(36).substring(2, 8)}`
        const keyValue = generateKey(role, custom_key)
        const now = new Date()
        const nextReset = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
        
        const newKey = await prisma.apiKey.create({
          data: {
            key: keyValue,
            username: generatedUsername,
            role: role,
            custom_key: custom_key || null,
            active: active,
            requests: 0,
            max_requests: getMaxRequests(role),
            rpm_limit: getRpmLimit(role),
            last_reset: now,
            next_reset: nextReset,
            suspended: false
          }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            key: newKey.key,
            username: newKey.username,
            role: newKey.role,
            active: newKey.active,
            max_requests: newKey.max_requests,
            rpm_limit: newKey.rpm_limit,
            next_reset: newKey.next_reset,
            created_at: newKey.created_at
          },
          message: 'Apikey generated successfully'
        })
      } catch (error) {
        if (error.code === 'P2002') {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Custom key already exists'
          })
        }
        
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/suspended_key',
    method: 'post',
    parameter: ['keys', 'apikey'],
    execution: async (req, res) => {
      try {
        const { keys, apikey } = req.body
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const keyData = await prisma.apiKey.findFirst({
          where: { key: keys }
        })
        
        if (!keyData) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Apikey not found'
          })
        }
        
        const updatedKey = await prisma.apiKey.update({
          where: { id: keyData.id },
          data: {
            suspended: true,
            suspended_at: new Date()
          }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            key: updatedKey.key,
            username: updatedKey.username,
            suspended: updatedKey.suspended,
            suspended_at: updatedKey.suspended_at,
            updated_at: updatedKey.updated_at
          },
          message: 'Apikey suspended successfully'
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/unsuspense_keys',
    method: 'put',
    parameter: ['keys', 'apikey'],
    execution: async (req, res) => {
      try {
        const { keys, apikey } = req.body
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const keyData = await prisma.apiKey.findFirst({
          where: { key: keys }
        })
        
        if (!keyData) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Apikey not found'
          })
        }
        
        const updatedKey = await prisma.apiKey.update({
          where: { id: keyData.id },
          data: {
            suspended: false,
            suspended_at: null
          }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            key: updatedKey.key,
            username: updatedKey.username,
            suspended: updatedKey.suspended,
            updated_at: updatedKey.updated_at
          },
          message: 'Apikey unsuspended successfully'
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/remove_key',
    method: 'delete',
    parameter: ['keys', 'apikey'],
    execution: async (req, res) => {
      try {
        const { keys, apikey } = req.query
        
        if (apikey !== process.env.OWNER_APIKEY) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Only owner can remove apikeys'
          })
        }
        
        const keyData = await prisma.apiKey.findFirst({
          where: { key: keys }
        })
        
        if (!keyData) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Apikey not found'
          })
        }
        
        await prisma.apiKey.delete({
          where: { id: keyData.id }
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            key: keys,
            deleted: true,
            timestamp: new Date().toISOString()
          },
          message: 'Apikey removed successfully'
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['owner']
  },
  {
    category: 'admin',
    path: '/api/admin/stats',
    method: 'get',
    parameter: ['apikey'],
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const now = new Date()
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
        
        const [
          totalRequests,
          todayRequests,
          monthRequests,
          totalKeys,
          keysByRole,
          activeKeys,
          suspendedKeys,
          bannedIPs,
          systemLogs
        ] = await Promise.all([
          prisma.requestLog.count(),
          prisma.requestLog.count({
            where: { timestamp: { gte: startOfDay } }
          }),
          prisma.requestLog.count({
            where: { timestamp: { gte: startOfMonth } }
          }),
          prisma.apiKey.count(),
          prisma.apiKey.groupBy({
            by: ['role'],
            _count: { role: true }
          }),
          prisma.apiKey.count({ where: { suspended: false } }),
          prisma.apiKey.count({ where: { suspended: true } }),
          prisma.bannedIP.count(),
          prisma.systemLog.count({
            where: { timestamp: { gte: startOfDay } }
          })
        ])
        
        const topEndpoints = await prisma.requestLog.groupBy({
          by: ['endpoint'],
          _count: { endpoint: true },
          orderBy: { _count: { endpoint: 'desc' } },
          take: 20,
          where: { timestamp: { gte: startOfDay } }
        })
        
        const topKeys = await prisma.requestLog.groupBy({
          by: ['key_id'],
          _count: { key_id: true },
          orderBy: { _count: { key_id: 'desc' } },
          take: 10,
          where: { 
            timestamp: { gte: startOfDay },
            key_id: { not: null }
          }
        })
        
        const keyDetails = await Promise.all(
          topKeys.map(async item => {
            const keyData = await prisma.apiKey.findFirst({
              where: { id: item.key_id }
            })
            return {
              key: keyData ? keyData.key.substring(0, 8) + '...' : 'unknown',
              username: keyData?.username,
              role: keyData?.role,
              requests: item._count.key_id
            }
          })
        )
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            overview: {
              total_requests: totalRequests,
              requests_today: todayRequests,
              requests_this_month: monthRequests,
              total_apikeys: totalKeys,
              active_apikeys: activeKeys,
              suspended_apikeys: suspendedKeys,
              banned_ips: bannedIPs,
              system_logs_today: systemLogs
            },
            keys_by_role: keysByRole.reduce((acc, item) => {
              acc[item.role] = item._count.role
              return acc
            }, {}),
            top_endpoints_today: topEndpoints.map(item => ({
              endpoint: item.endpoint,
              requests: item._count.endpoint
            })),
            top_keys_today: keyDetails,
            timestamp: now.toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/ip_logs',
    method: 'get',
    parameter: ['apikey'],
    execution: async (req, res) => {
      try {
        const { ip, apikey } = req.query
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        const now = new Date()
        const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000)
        
        const whereClause = ip 
          ? { ip: ip, timestamp: { gte: fiveMinutesAgo } }
          : { timestamp: { gte: fiveMinutesAgo } }
        
        const logs = await prisma.requestLog.findMany({
          where: whereClause,
          orderBy: { timestamp: 'desc' },
          take: ip ? 100 : 50
        })
        
        const logsWithKeyInfo = await Promise.all(
          logs.map(async log => {
            let keyInfo = null
            if (log.key_id) {
              const keyData = await prisma.apiKey.findFirst({
                where: { id: log.key_id },
                select: { username: true, role: true }
              })
              if (keyData) {
                keyInfo = {
                  username: keyData.username,
                  role: keyData.role
                }
              }
            }
            
            return {
              ...log,
              key_info: keyInfo
            }
          })
        )
        
        const uniqueIPs = await prisma.requestLog.groupBy({
          by: ['ip'],
          _count: { ip: true },
          where: { timestamp: { gte: fiveMinutesAgo } },
          orderBy: { _count: { ip: 'desc' } },
          take: 20
        })
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            filter: ip ? `IP: ${ip}` : 'All IPs (last 5 minutes)',
            logs: logsWithKeyInfo,
            summary: {
              total_logs: logs.length,
              unique_ips: uniqueIPs.length,
              top_ips: uniqueIPs.slice(0, 10).map(item => ({
                ip: item.ip,
                requests: item._count.ip
              }))
            },
            timestamp: now.toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/moderate',
    method: 'post',
    parameter: ['apikey'],
    execution: async (req, res) => {
      try {
        const { ban, unban, apikey } = req.body
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (!ban && !unban) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Either ban or unban parameter is required'
          })
        }
        
        if (ban && unban) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Cannot ban and unban at the same time'
          })
        }
        
        const ip = ban || unban
        const now = new Date()
        
        if (ban) {
          const existingBan = await prisma.bannedIP.findFirst({
            where: { ip: ip }
          })
          
          if (existingBan) {
            return res.status(400).json({
              creator: global.creator,
              status: false,
              data: null,
              message: 'IP already banned'
            })
          }
          
          const bannedIP = await prisma.bannedIP.create({
            data: {
              ip: ip,
              reason: 'Manually banned by admin',
              banned_by: 'admin',
              banned_at: now,
              expires_at: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000) // 7 days
            }
          })
          
          res.json({
            creator: global.creator,
            status: true,
            data: {
              action: 'banned',
              ip: bannedIP.ip,
              reason: bannedIP.reason,
              expires_at: bannedIP.expires_at,
              banned_at: bannedIP.banned_at
            },
            message: 'IP banned successfully'
          })
        } else if (unban) {
          const bannedIP = await prisma.bannedIP.findFirst({
            where: { ip: ip }
          })
          
          if (!bannedIP) {
            return res.status(404).json({
              creator: global.creator,
              status: false,
              data: null,
              message: 'IP not found in ban list'
            })
          }
          
          await prisma.bannedIP.delete({
            where: { id: bannedIP.id }
          })
          
          res.json({
            creator: global.creator,
            status: true,
            data: {
              action: 'unbanned',
              ip: ip,
              timestamp: now.toISOString()
            },
            message: 'IP unbanned successfully'
          })
        }
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  },
  {
    category: 'admin',
    path: '/api/admin/moderate/:path',
    method: 'get',
    parameter: ['apikey'],
    execution: async (req, res) => {
      try {
        const { path } = req.params
        const { apikey } = req.query
        
        if (!validateAdminKey(apikey)) {
          return res.status(403).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid admin apikey'
          })
        }
        
        if (path === 'banned-ips') {
          const bannedIPs = await prisma.bannedIP.findMany({
            orderBy: { banned_at: 'desc' },
            take: 100
          })
          
          res.json({
            creator: global.creator,
            status: true,
            data: {
              path: 'banned-ips',
              count: bannedIPs.length,
              ips: bannedIPs,
              timestamp: new Date().toISOString()
            },
            message: null
          })
        } else if (path === 'total_keys') {
          const keysByRole = await prisma.apiKey.groupBy({
            by: ['role', 'suspended'],
            _count: { role: true }
          })
          
          const summary = keysByRole.reduce((acc, item) => {
            if (!acc[item.role]) {
              acc[item.role] = { total: 0, active: 0, suspended: 0 }
            }
            acc[item.role].total += item._count.role
            if (item.suspended) {
              acc[item.role].suspended += item._count.role
            } else {
              acc[item.role].active += item._count.role
            }
            return acc
          }, {})
          
          res.json({
            creator: global.creator,
            status: true,
            data: {
              path: 'total_keys',
              summary: summary,
              timestamp: new Date().toISOString()
            },
            message: null
          })
        } else {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Path not found. Available paths: banned-ips, total_keys'
          })
        }
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    protect: true,
    restrict: ['admin', 'dev']
  }
]