import requestIp from 'request-ip'
import Holidays from 'date-holidays'
import { lookup } from 'geoip-country'
import xchange from 'xchange-rates'
import { Address4, Address6 } from 'ip-address'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const geoDatabasePath = path.join(__dirname, '../../data/GeoLite2-Country.mmdb')

let geoLookup = null
try {
  const { open } = await import('maxmind')
  if (fs.existsSync(geoDatabasePath)) {
    geoLookup = await open(geoDatabasePath)
  }
} catch (error) {
  console.warn('MaxMind database not available, using geoip-country fallback')
}

export const routes = [
  {
    category: 'v1',
    path: '/api/v1/network/@me',
    method: 'get',
    execution: async (req, res) => {
      try {
        const clientIP = requestIp.getClientIp(req) || '127.0.0.1'
        
        // Validate IP address
        let ipInfo = {}
        try {
          if (clientIP.includes(':')) {
            const addr = new Address6(clientIP)
            if (addr.isValid()) {
              ipInfo = {
                type: 'IPv6',
                canonical: addr.canonicalForm(),
                v4: addr.is4() ? addr.to4().correctForm() : null,
                subnet: addr.subnet
              }
            }
          } else {
            const addr = new Address4(clientIP)
            if (addr.isValid()) {
              ipInfo = {
                type: 'IPv4',
                canonical: addr.correctForm(),
                subnet: addr.subnetMask,
                broadcast: addr.broadcastAddress
              }
            }
          }
        } catch (ipError) {
          ipInfo.error = 'Invalid IP format'
        }
        
        // Get geolocation
        let geolocation = {}
        try {
          // Try MaxMind first
          if (geoLookup) {
            const geoData = geoLookup.get(clientIP)
            if (geoData) {
              geolocation = {
                country: geoData.country?.names?.en || 'Unknown',
                country_code: geoData.country?.iso_code || 'XX',
                continent: geoData.continent?.names?.en || 'Unknown',
                continent_code: geoData.continent?.code || 'XX',
                accuracy_radius: geoData.location?.accuracy_radius,
                timezone: geoData.location?.time_zone,
                source: 'maxmind'
              }
            }
          }
          
          // Fallback to geoip-country
          if (!geolocation.country) {
            const geoData = lookup(clientIP)
            if (geoData) {
              geolocation = {
                country: geoData.country || 'Unknown',
                country_code: geoData.country || 'XX',
                source: 'geoip-country'
              }
            }
          }
        } catch (geoError) {
          geolocation.error = geoError.message
        }
        
        // Get network info
        let networkInfo = {}
        try {
          const os = await import('os')
          networkInfo = {
            hostname: os.hostname(),
            network_interfaces: Object.keys(os.networkInterfaces()).length,
            local_addresses: Object.values(os.networkInterfaces())
              .flat()
              .filter(i => i && i.family === 'IPv4' && !i.internal)
              .map(i => i.address)
          }
        } catch (error) {
          networkInfo.error = error.message
        }
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            ip: {
              original: clientIP,
              validated: ipInfo.canonical || clientIP,
              ...ipInfo
            },
            geolocation,
            network: networkInfo,
            timestamp: new Date().toISOString(),
            timezone: process.env.TZ || 'Asia/Jakarta'
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'v1',
    path: '/api/v1/network/holiday_calendar',
    method: 'get',
    parameter: ['region'],
    execution: async (req, res) => {
      try {
        const { region = 'ID', year } = req.query
        
        const hd = new Holidays()
        const currentYear = year || new Date().getFullYear()
        
        // Try to set country/state
        let holidays = []
        let regionInfo = {}
        
        try {
          // First try to set the country
          const countrySet = hd.init(region.toUpperCase())
          
          if (countrySet) {
            // Get country info
            const countries = hd.getCountries()
            const states = hd.getStates(region.toUpperCase())
            
            regionInfo = {
              country: region.toUpperCase(),
              country_name: countries[region.toUpperCase()] || region.toUpperCase(),
              states_available: Object.keys(states || {}).length
            }
            
            // Get holidays for the year
            holidays = hd.getHolidays(currentYear)
            
            // Format holidays
            holidays = holidays.map(holiday => ({
              date: holiday.date,
              name: holiday.name,
              local_name: holiday.name,
              type: holiday.type,
              substitute: holiday.substitute || false,
              note: holiday.note || null
            }))
          } else {
            // If country not found, try states/provinces
            const allCountries = hd.getCountries()
            const countryCode = Object.keys(allCountries).find(
              code => allCountries[code].toLowerCase().includes(region.toLowerCase())
            )
            
            if (countryCode) {
              hd.init(countryCode)
              holidays = hd.getHolidays(currentYear)
              
              regionInfo = {
                country: countryCode,
                country_name: allCountries[countryCode],
                original_query: region
              }
              
              holidays = holidays.map(holiday => ({
                date: holiday.date,
                name: holiday.name,
                local_name: holiday.name,
                type: holiday.type
              }))
            } else {
              throw new Error(`Region '${region}' not found`)
            }
          }
        } catch (holidayError) {
          // Fallback: provide common holidays for major countries
          const commonHolidays = {
            'ID': [
              { date: `${currentYear}-01-01`, name: 'New Year\'s Day', type: 'public' },
              { date: `${currentYear}-05-01`, name: 'Labor Day', type: 'public' },
              { date: `${currentYear}-08-17`, name: 'Independence Day', type: 'public' },
              { date: `${currentYear}-12-25`, name: 'Christmas Day', type: 'public' }
            ],
            'US': [
              { date: `${currentYear}-01-01`, name: 'New Year\'s Day', type: 'public' },
              { date: `${currentYear}-07-04`, name: 'Independence Day', type: 'public' },
              { date: `${currentYear}-11-28`, name: 'Thanksgiving', type: 'public' },
              { date: `${currentYear}-12-25`, name: 'Christmas Day', type: 'public' }
            ]
          }
          
          holidays = commonHolidays[region.toUpperCase()] || commonHolidays['ID']
          regionInfo = {
            country: region.toUpperCase(),
            note: 'Using common holidays database'
          }
        }
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            region: regionInfo,
            year: currentYear,
            holidays,
            total: holidays.length,
            source: 'date-holidays',
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'v1',
    path: '/api/v1/network/exchange',
    method: 'get',
    parameter: ['from', 'to'],
    execution: async (req, res) => {
      try {
        const { from = 'IDR', to = 'USD', amount = 1 } = req.query
        
        // Convert amount to number
        const numericAmount = parseFloat(amount) || 1
        
        // Get exchange rates
        let exchangeData = {}
        let rates = {}
        
        try {
          // Try to get live rates
          const exchangeRates = await xchange.latest()
          rates = exchangeRates.rates || {}
          
          // If base currency is not USD, convert
          let fromRate = rates[from.toUpperCase()]
          let toRate = rates[to.toUpperCase()]
          
          if (fromRate && toRate) {
            const converted = (numericAmount / fromRate) * toRate
            
            exchangeData = {
              base: from.toUpperCase(),
              target: to.toUpperCase(),
              rate: parseFloat((toRate / fromRate).toFixed(6)),
              converted_amount: parseFloat(converted.toFixed(2)),
              original_amount: numericAmount,
              rates_available: Object.keys(rates).length,
              last_updated: exchangeRates.date || new Date().toISOString(),
              provider: 'xchange-rates',
              live: true
            }
          } else {
            throw new Error('Currency not found in live rates')
          }
        } catch (liveError) {
          // Fallback to cached/historical rates
          const fallbackRates = {
            'USD': 1,
            'IDR': 15600,
            'EUR': 0.92,
            'GBP': 0.79,
            'JPY': 148,
            'SGD': 1.34,
            'MYR': 4.68,
            'AUD': 1.52,
            'CAD': 1.35,
            'CNY': 7.18
          }
          
          const fromRate = fallbackRates[from.toUpperCase()] || 1
          const toRate = fallbackRates[to.toUpperCase()] || 1
          
          if (fromRate && toRate) {
            const converted = (numericAmount / fromRate) * toRate
            
            exchangeData = {
              base: from.toUpperCase(),
              target: to.toUpperCase(),
              rate: parseFloat((toRate / fromRate).toFixed(6)),
              converted_amount: parseFloat(converted.toFixed(2)),
              original_amount: numericAmount,
              rates_available: Object.keys(fallbackRates).length,
              last_updated: new Date().toISOString(),
              provider: 'zhadev_fallback',
              live: false,
              note: 'Using fallback rates - live rates unavailable'
            }
          } else {
            throw new Error(`Unsupported currency pair: ${from} to ${to}`)
          }
        }
        
        // Add historical comparison if available
        try {
          const historical = await xchange.historical(
            new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          )
          if (historical.rates) {
            const histFromRate = historical.rates[from.toUpperCase()]
            const histToRate = historical.rates[to.toUpperCase()]
            
            if (histFromRate && histToRate) {
              const histRate = histToRate / histFromRate
              const change = ((exchangeData.rate - histRate) / histRate) * 100
              
              exchangeData.historical = {
                week_ago_rate: parseFloat(histRate.toFixed(6)),
                percentage_change: parseFloat(change.toFixed(2)),
                trend: change > 0 ? 'up' : change < 0 ? 'down' : 'stable'
              }
            }
          }
        } catch (histError) {
          // Historical data not critical
        }
        
        res.json({
          creator: global.creator,
          status: true,
          data: exchangeData,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  }
]