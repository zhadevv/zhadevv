import whoiser from 'whoiser'
import captureWebsite from 'capture-website'
import { exec } from 'child_process'
import { promisify } from 'util'
import dns from 'dns'
import isWebsiteVulnerable from 'is-website-vulnerable'
import retire from 'retire'
import https from 'https'
import { Address4, Address6 } from 'ip-address'

const execPromise = promisify(exec)
const dnsResolve = promisify(dns.resolve4)
const dnsResolve6 = promisify(dns.resolve6)
const dnsResolveMx = promisify(dns.resolveMx)
const dnsResolveTxt = promisify(dns.resolveTxt)

export const routes = [
  {
    category: 'v1',
    path: '/api/v1/tools/checkhost',
    method: 'get',
    parameter: ['url'],
    execution: async (req, res) => {
      try {
        const { url } = req.query
        
        if (!url) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'URL parameter is required'
          })
        }
        
        // Parse URL
        let parsedUrl
        try {
          parsedUrl = new URL(url.startsWith('http') ? url : `https://${url}`)
        } catch {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid URL format'
          })
        }
        
        const hostname = parsedUrl.hostname
        const startTime = Date.now()
        
        // Check multiple protocols
        const checks = []
        
        // Check HTTP
        try {
          const httpStart = Date.now()
          const httpResponse = await fetch(`http://${hostname}`, {
            method: 'HEAD',
            timeout: 5000
          }).catch(() => null)
          
          if (httpResponse) {
            checks.push({
              protocol: 'HTTP',
              status: httpResponse.status,
              status_text: httpResponse.statusText,
              response_time: Date.now() - httpStart,
              headers: {
                server: httpResponse.headers.get('server'),
                powered_by: httpResponse.headers.get('x-powered-by')
              }
            })
          }
        } catch {}
        
        // Check HTTPS
        try {
          const httpsStart = Date.now()
          const httpsResponse = await fetch(`https://${hostname}`, {
            method: 'HEAD',
            timeout: 5000
          }).catch(() => null)
          
          if (httpsResponse) {
            checks.push({
              protocol: 'HTTPS',
              status: httpsResponse.status,
              status_text: httpsResponse.statusText,
              response_time: Date.now() - httpsStart,
              headers: {
                server: httpsResponse.headers.get('server'),
                powered_by: httpsResponse.headers.get('x-powered-by'),
                security_headers: {
                  hsts: httpsResponse.headers.get('strict-transport-security') ? true : false,
                  csp: httpsResponse.headers.get('content-security-policy') ? true : false
                }
              }
            })
          }
        } catch {}
        
        // DNS check
        let dnsInfo = {}
        try {
          const [ipv4, ipv6, mx] = await Promise.allSettled([
            dnsResolve(hostname),
            dnsResolve6(hostname),
            dnsResolveMx(hostname)
          ])
          
          dnsInfo = {
            ipv4: ipv4.status === 'fulfilled' ? ipv4.value.slice(0, 5) : [],
            ipv6: ipv6.status === 'fulfilled' ? ipv6.value.slice(0, 5) : [],
            mx_records: mx.status === 'fulfilled' ? mx.value.slice(0, 3) : [],
            total_lookups: 3
          }
        } catch (dnsError) {
          dnsInfo.error = dnsError.message
        }
        
        // Port scan (common ports)
        const commonPorts = [80, 443, 21, 22, 25, 53, 3306, 8080]
        const portChecks = []
        
        for (const port of commonPorts.slice(0, 3)) { // Check first 3 ports
          try {
            const socket = new Promise((resolve, reject) => {
              const net = require('net')
              const client = new net.Socket()
              
              client.setTimeout(2000)
              client.connect(port, hostname, () => {
                client.destroy()
                resolve({ port, open: true })
              })
              
              client.on('error', () => {
                client.destroy()
                resolve({ port, open: false })
              })
              
              client.on('timeout', () => {
                client.destroy()
                resolve({ port, open: false })
              })
            })
            
            portChecks.push(await socket)
          } catch {}
        }
        
        const totalTime = Date.now() - startTime
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            url: parsedUrl.toString(),
            hostname,
            checks,
            dns: dnsInfo,
            ports: portChecks,
            performance: {
              total_check_time: `${totalTime}ms`,
              average_response: checks.length > 0 
                ? `${Math.round(checks.reduce((a, b) => a + b.response_time, 0) / checks.length)}ms`
                : 'N/A'
            },
            summary: {
              online: checks.length > 0,
              https_support: checks.some(c => c.protocol === 'HTTPS' && c.status === 200),
              recommended_protocol: checks.some(c => c.protocol === 'HTTPS') ? 'HTTPS' : 'HTTP'
            },
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'v1',
    path: '/api/v1/tools/whois',
    method: 'get',
    parameter: ['url'],
    execution: async (req, res) => {
      try {
        const { url } = req.query
        
        if (!url) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'URL parameter is required'
          })
        }
        
        // Extract domain from URL
        let domain
        try {
          const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`)
          domain = urlObj.hostname
        } catch {
          domain = url.replace(/^(https?:\/\/)?(www\.)?/, '')
        }
        
        // Remove port if present
        domain = domain.split(':')[0]
        
        // Get WHOIS information
        let whoisData = {}
        let rawData = ''
        
        try {
          const whoisResult = await whoiser(domain, { follow: 2 })
          rawData = JSON.stringify(whoisResult, null, 2)
          
          // Parse WHOIS data
          if (whoisResult && typeof whoisResult === 'object') {
            const firstWhois = Array.isArray(whoisResult) ? whoisResult[0] : whoisResult
            
            whoisData = {
              domain: domain,
              available: firstWhois['Domain Name'] ? false : true,
              created: firstWhois['Creation Date'] || firstWhois['Registered On'] || null,
              expires: firstWhois['Expiry Date'] || firstWhois['Expiration Date'] || null,
              updated: firstWhois['Updated Date'] || firstWhois['Last Updated'] || null,
              registrar: {
                name: firstWhois['Registrar'] || null,
                iana_id: firstWhois['Registrar IANA ID'] || null
              },
              name_servers: firstWhois['Name Server'] || [],
              status: firstWhois['Domain Status'] || [],
              dnssec: firstWhois['DNSSEC'] || null
            }
          }
        } catch (whoisError) {
          // Fallback to system whois command
          try {
            const { stdout } = await execPromise(`whois ${domain}`)
            rawData = stdout.substring(0, 2000)
            
            // Parse common whois fields
            const lines = stdout.split('\n')
            const parsed = {}
            
            lines.forEach(line => {
              if (line.includes(':')) {
                const [key, ...value] = line.split(':')
                if (key.trim() && value.join(':').trim()) {
                  parsed[key.trim().toLowerCase()] = value.join(':').trim()
                }
              }
            })
            
            whoisData = {
              domain: domain,
              available: stdout.toLowerCase().includes('no match') || 
                       stdout.toLowerCase().includes('not found'),
              created: parsed['creation date'] || parsed['registered on'],
              expires: parsed['expiry date'] || parsed['expiration date'],
              registrar: {
                name: parsed['registrar'] || null
              },
              name_servers: [
                parsed['name server'],
                parsed['nserver']
              ].filter(Boolean),
              raw_preview: rawData.substring(0, 500) + '...'
            }
          } catch (cmdError) {
            throw new Error(`WHOIS lookup failed: ${cmdError.message}`)
          }
        }
        
        // Get DNS records as additional info
        let dnsRecords = {}
        try {
          const [a, aaaa, mx, txt, ns] = await Promise.allSettled([
            dnsResolve(domain),
            dnsResolve6(domain),
            dnsResolveMx(domain),
            dnsResolveTxt(domain),
            dns.resolveNs ? promisify(dns.resolveNs)(domain) : Promise.resolve([])
          ])
          
          dnsRecords = {
            a: a.status === 'fulfilled' ? a.value : [],
            aaaa: aaaa.status === 'fulfilled' ? aaaa.value : [],
            mx: mx.status === 'fulfilled' ? mx.value.map(m => ({ exchange: m.exchange, priority: m.priority })) : [],
            txt: txt.status === 'fulfilled' ? txt.value.flat() : [],
            ns: ns.status === 'fulfilled' ? ns.value : []
          }
        } catch (dnsError) {
          dnsRecords.error = dnsError.message
        }
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            query: domain,
            whois: whoisData,
            dns: dnsRecords,
            raw_data_length: rawData.length,
            raw_preview: rawData.substring(0, 300) + (rawData.length > 300 ? '...' : ''),
            source: 'whoiser',
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true
  },
  {
    category: 'v1',
    path: '/api/v1/tools/ssweb',
    method: 'get',
    parameter: ['url'],
    execution: async (req, res) => {
      try {
        const { url, width = 1280, height = 720, fullPage = false, delay = 2 } = req.query
        
        if (!url) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'URL parameter is required'
          })
        }
        
        let parsedUrl
        try {
          parsedUrl = new URL(url.startsWith('http') ? url : `https://${url}`)
        } catch {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid URL format'
          })
        }
        
        // Generate unique filename
        const timestamp = Date.now()
        const screenshotDir = 'public/screenshots'
        const filename = `screenshot_${timestamp}_${Buffer.from(parsedUrl.hostname).toString('base64url')}.png`
        const filepath = `${screenshotDir}/${filename}`
        
        // Create directory if not exists
        const fs = await import('fs')
        const path = await import('path')
        
        if (!fs.existsSync(screenshotDir)) {
          fs.mkdirSync(screenshotDir, { recursive: true })
        }
        
        // Capture website
        const startTime = Date.now()
        
        await captureWebsite.file(parsedUrl.toString(), filepath, {
          width: parseInt(width),
          height: parseInt(height),
          fullPage: fullPage === 'true',
          delay: parseInt(delay),
          timeout: 30000,
          overwrite: true,
          launchOptions: {
            args: ['--no-sandbox', '--disable-setuid-sandbox']
          }
        })
        
        const captureTime = Date.now() - startTime
        
        // Get file info
        const stats = fs.statSync(filepath)
        const imageBuffer = fs.readFileSync(filepath)
        const base64Image = imageBuffer.toString('base64')
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            url: parsedUrl.toString(),
            screenshot: {
              filename,
              path: `/screenshots/${filename}`,
              size_bytes: stats.size,
              size_formatted: `${(stats.size / 1024).toFixed(2)} KB`,
              dimensions: `${width}x${height}`,
              full_page: fullPage === 'true',
              capture_time: `${captureTime}ms`,
              base64_preview: `data:image/png;base64,${base64Image.substring(0, 50000)}...`,
              direct_url: `${req.protocol}://${req.get('host')}/screenshots/${filename}`
            },
            metadata: {
              timestamp: new Date(timestamp).toISOString(),
              user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              viewport: `${width}x${height}`
            },
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true // Screenshots are resource-intensive
  },
  {
    category: 'v1',
    path: '/api/v1/tools/webcheck',
    method: 'get',
    parameter: ['url'],
    execution: async (req, res) => {
      try {
        const { url, apikey } = req.query
        
        if (!url) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'URL parameter is required'
          })
        }
        
        let parsedUrl
        try {
          parsedUrl = new URL(url.startsWith('http') ? url : `https://${url}`)
        } catch {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Invalid URL format'
          })
        }
        
        const startTime = Date.now()
        
        // 1. Vulnerability scan
        let vulnerabilities = []
        try {
          const result = await isWebsiteVulnerable(parsedUrl.toString(), {
            puppeteer: {
              headless: 'new',
              args: ['--no-sandbox']
            }
          })
          
          if (result && result.lhr && result.lhr.audits) {
            vulnerabilities = Object.entries(result.lhr.audits)
              .filter(([_, audit]) => audit.score !== null && audit.score < 1)
              .map(([key, audit]) => ({
                id: key,
                title: audit.title,
                score: audit.score,
                severity: audit.score < 0.5 ? 'high' : audit.score < 0.9 ? 'medium' : 'low',
                description: audit.description,
                details: audit.details
              }))
          }
        } catch (vulnError) {
          vulnerabilities = [{ error: vulnError.message }]
        }
        
        // 2. Retire.js scan for JavaScript libraries
        let jsVulnerabilities = []
        try {
          const options = {
            log: {
              info: () => {},
              debug: () => {},
              warn: () => {},
              error: () => {}
            }
          }
          
          // Note: retire.scanUri is async in newer versions
          const scanResult = await retire.scanUri(parsedUrl.toString(), options)
          
          if (scanResult && scanResult.length > 0) {
            scanResult.forEach(result => {
              if (result.vulnerabilities && result.vulnerabilities.length > 0) {
                jsVulnerabilities.push({
                  component: result.component,
                  version: result.version,
                  vulnerabilities: result.vulnerabilities.map(v => ({
                    info: v.info,
                    severity: v.severity,
                    identifiers: v.identifiers
                  }))
                })
              }
            })
          }
        } catch (retireError) {
          jsVulnerabilities = [{ error: retireError.message }]
        }
        
        // 3. Security headers check
        let securityHeaders = {}
        let response
        try {
          response = await fetch(parsedUrl.toString(), {
            method: 'HEAD',
            timeout: 10000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          })
          
          if (response.headers) {
            securityHeaders = {
              strict_transport_security: response.headers.get('strict-transport-security') ? true : false,
              content_security_policy: response.headers.get('content-security-policy') ? true : false,
              x_frame_options: response.headers.get('x-frame-options') ? true : false,
              x_content_type_options: response.headers.get('x-content-type-options') ? true : false,
              x_xss_protection: response.headers.get('x-xss-protection') ? true : false,
              referrer_policy: response.headers.get('referrer-policy') ? true : false,
              permissions_policy: response.headers.get('permissions-policy') ? true : false
            }
          }
        } catch (headerError) {
          securityHeaders.error = headerError.message
        }
        
        // 4. SSL/TLS check (simplified)
        let sslInfo = {}
        if (parsedUrl.protocol === 'https:') {
          try {
            const https = await import('https')
            const sslPromise = new Promise((resolve, reject) => {
              const req = https.request(parsedUrl.toString(), { method: 'HEAD' }, (res) => {
                const cert = res.socket.getPeerCertificate()
                resolve({
                  valid: true,
                  issuer: cert.issuer,
                  valid_from: cert.valid_from,
                  valid_to: cert.valid_to,
                  subject: cert.subject
                })
              })
              
              req.on('error', (error) => {
                resolve({ valid: false, error: error.message })
              })
              
              req.setTimeout(5000, () => {
                req.destroy()
                resolve({ valid: false, error: 'Timeout' })
              })
              
              req.end()
            })
            
            sslInfo = await sslPromise
          } catch (sslError) {
            sslInfo = { valid: false, error: sslError.message }
          }
        }
        
        // 5. Technology detection
        let technologies = {}
        if (response && response.headers) {
          technologies = {
            server: response.headers.get('server'),
            powered_by: response.headers.get('x-powered-by'),
            framework: response.headers.get('x-aspnet-version') ? 'ASP.NET' : 
                      response.headers.get('x-runtime') ? 'Ruby' :
                      response.headers.get('x-drupal-cache') ? 'Drupal' : null
          }
        }
        
        const totalTime = Date.now() - startTime
        
        // Calculate security score
        const headerScore = Object.values(securityHeaders).filter(v => v === true).length / 7
        const vulnScore = vulnerabilities.length === 0 ? 1 : Math.max(0, 1 - (vulnerabilities.length * 0.1))
        const jsScore = jsVulnerabilities.length === 0 ? 1 : Math.max(0, 1 - (jsVulnerabilities.length * 0.2))
        const sslScore = sslInfo.valid ? 1 : 0
        
        const overallScore = Math.round(((headerScore + vulnScore + jsScore + sslScore) / 4) * 100)
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            url: parsedUrl.toString(),
            scan_summary: {
              total_time: `${totalTime}ms`,
              overall_score: overallScore,
              grade: overallScore >= 90 ? 'A' : 
                     overallScore >= 80 ? 'B' : 
                     overallScore >= 70 ? 'C' : 
                     overallScore >= 60 ? 'D' : 'F',
              tests_performed: 5
            },
            vulnerabilities: {
              lighthouse: vulnerabilities,
              javascript_libraries: jsVulnerabilities,
              total_vulnerabilities_found: vulnerabilities.length + jsVulnerabilities.length
            },
            security_headers: securityHeaders,
            ssl_tls: sslInfo,
            technologies,
            recommendations: [
              ...Object.entries(securityHeaders)
                .filter(([_, value]) => !value)
                .map(([key]) => `Enable ${key.replace(/_/g, ' ').toUpperCase()} header`),
              ...(vulnerabilities.length > 0 ? ['Fix identified vulnerabilities from Lighthouse audit'] : []),
              ...(jsVulnerabilities.length > 0 ? ['Update vulnerable JavaScript libraries'] : []),
              ...(!sslInfo.valid ? ['Fix SSL/TLS configuration'] : [])
            ],
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  }
]