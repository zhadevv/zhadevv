import { Loader } from '@neoxr/webly'

const Scraper = Loader.scrapers

const validateRegion = (region) => {
  const validRegions = ['id', 'en', 'zh', 'ko', 'ja', 'tl', 'th', 'ar', 'pt', 'fr', 'es']
  return validRegions.includes(region.toLowerCase()) ? region.toLowerCase() : 'id'
}

export const routes = [
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/sidecontent',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region } = req.params
        const { apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const response = await scraper.fetchWithRetry('/')
        const result = await scraper.parse_home(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/home',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region } = req.params
        const { apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const response = await scraper.fetchWithRetry('/')
        const result = await scraper.parse_home(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/channel/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region, slug } = req.params
        const { page = 1, apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = page == 1 
          ? `/more/${slug}`
          : `/more/${slug}/${page}`
        
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_channel(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/genres',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region } = req.params
        const { page = 1, apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = page == 1 ? '/browse/0' : `/browse/0/${page}`
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_genres(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/genres/:id',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region, id } = req.params
        const { page = 1, apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = page == 1 ? `/browse/${id}` : `/browse/${id}/${page}`
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_genres(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/search',
    method: 'get',
    parameter: ['q'],
    execution: async (req, res) => {
      try {
        const { region } = req.params
        const { q, page = 1, apikey } = req.query
        
        if (!q || q.trim() === '') {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Search query is required'
          })
        }
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = page == 1 
          ? `/search?searchValue=${encodeURIComponent(q)}`
          : `/search/${page}?searchValue=${encodeURIComponent(q)}`
        
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_search(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/detail/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region, slug } = req.params
        const { apikey } = req.query
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = `/movie/${slug}`
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_detail(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/:region/watch/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { region, slug } = req.params
        const { episode, apikey } = req.query
        
        if (!episode) {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Episode parameter is required'
          })
        }
        
        const validRegion = validateRegion(region)
        const scraper = new Scraper.Dracin({ region: validRegion })
        
        const url = `/ep/${slug}/${episode}`
        const response = await scraper.fetchWithRetry(url)
        const result = await scraper.parse_watch(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: validRegion,
          path: `/${validRegion}`,
          base_url: `https://www.dramaboxdb.com/${validRegion}`,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/dracin/en/resources',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const scraper = new Scraper.Dracin({ region: 'en' })
        const response = await scraper.fetchWithRetry('/resources')
        const result = await scraper.parse_resources(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          region: 'en',
          path: '/en',
          base_url: 'https://www.dramaboxdb.com/en',
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  }
]