import { Loader } from '@neoxr/webly'

const Scraper = Loader.scrapers

export const routes = [
  {
    category: 'v1',
    path: '/api/v1/donghua/sidebar',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const response = await Scraper.Donghua.fetchWithRetry('/')
        const result = await Scraper.Donghua.parse_sidebar(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/schedule',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const response = await Scraper.Donghua.fetchWithRetry('/schedule')
        const result = await Scraper.Donghua.parse_schedule(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/home',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { page = 1, apikey } = req.query
        
        const url = page == 1 ? '/' : `/page/${page}/`
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_home(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/search',
    method: 'get',
    parameter: ['q'],
    execution: async (req, res) => {
      try {
        const { q, page = 1, apikey } = req.query
        
        if (!q || q.trim() === '') {
          return res.status(400).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Search query is required'
          })
        }
        
        const url = page == 1 
          ? `/?s=${encodeURIComponent(q)}`
          : `/page/${page}/?s=${encodeURIComponent(q)}`
        
        Scraper.Donghua.setCurrentUrl(`https://anichin.cafe${url}`)
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_search(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/ongoing',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { page = 1, apikey } = req.query
        
        const url = page == 1 ? '/ongoing' : `/ongoing/page/${page}/`
        Scraper.Donghua.setCurrentUrl(`https://anichin.cafe${url}`)
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_ongoing(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/completed',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { page = 1, apikey } = req.query
        
        const url = page == 1 ? '/completed' : `/completed/page/${page}/`
        Scraper.Donghua.setCurrentUrl(`https://anichin.cafe${url}`)
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_completed(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/az_list',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { page = 1, show, apikey } = req.query
        
        let url = '/az_lists'
        if (page > 1) url += `/page/${page}/`
        if (show) url += `?show=${show}`
        
        Scraper.Donghua.setCurrentUrl(`https://anichin.cafe${url}`)
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_az_list(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/genres/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { slug } = req.params
        const { page = 1, apikey } = req.query
        
        const url = page == 1 
          ? `/genres/${slug}/`
          : `/genres/${slug}/page/${page}/`
        
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_genres(response.data, slug)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/seasons/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { slug } = req.params
        const { apikey } = req.query
        
        const url = `/season/${slug}/`
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_seasons(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/detail/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { slug } = req.params
        const { apikey } = req.query
        
        const url = `/seri/${slug}/`
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_detail(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/watch/:slug',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { slug } = req.params
        const { episode, apikey } = req.query
        
        let watchSlug = slug
        if (episode) {
          watchSlug = `${slug}-episode-${episode}-subtitle-indonesia`
        }
        
        const url = `/${watchSlug}/`
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_watch(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/filters/list-mode',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const url = '/seri/list-mode/'
        const response = await Scraper.Donghua.fetchWithRetry(url)
        const result = await Scraper.Donghua.parse_advanced_search_text_mode(response.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.filters,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/filters',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { 
          status, type, order, sub, genres, studios, seasons,
          page = 1, apikey 
        } = req.query
        
        const params = new URLSearchParams()
        
        if (status) params.append('status', status)
        if (type) params.append('type', type)
        if (order) params.append('order', order)
        if (sub) params.append('sub', sub)
        if (genres) {
          if (Array.isArray(genres)) {
            genres.forEach(g => params.append('genre[]', g))
          } else {
            params.append('genre[]', genres)
          }
        }
        if (studios) params.append('studio', studios)
        if (seasons) params.append('season', seasons)
        if (page > 1) params.append('page', page)
        
        const queryString = params.toString()
        const url = queryString ? `/seri/?${queryString}` : '/seri/'
        
        Scraper.Donghua.setCurrentUrl(`https://anichin.cafe${url}`)
        const response = await Scraper.Donghua.fetchWithRetry(url)
        
        let result
        if (queryString) {
          result = await Scraper.Donghua.parse_advance_search(response.data)
        } else {
          result = await Scraper.Donghua.parse_home(response.data)
        }
        
        res.json({
          creator: global.creator,
          status: true,
          data: result.data,
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  },
  {
    category: 'v1',
    path: '/api/v1/donghua/random',
    method: 'get',
    execution: async (req, res) => {
      try {
        const { apikey } = req.query
        
        const response = await Scraper.Donghua.fetchWithRetry('/seri/list-mode/')
        const result = await Scraper.Donghua.parse_advanced_search_text_mode(response.data)
        
        if (!result.success) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'Failed to fetch donghua list'
          })
        }
        
        const allSlugs = []
        Object.values(result.filters.text_mode).forEach(letterArray => {
          letterArray.forEach(item => {
            if (item.slug) allSlugs.push(item.slug)
          })
        })
        
        if (allSlugs.length === 0) {
          return res.status(404).json({
            creator: global.creator,
            status: false,
            data: null,
            message: 'No donghua found'
          })
        }
        
        const randomSlug = allSlugs[Math.floor(Math.random() * allSlugs.length)]
        const detailUrl = `/seri/${randomSlug}/`
        const detailResponse = await Scraper.Donghua.fetchWithRetry(detailUrl)
        const detailResult = await Scraper.Donghua.parse_detail(detailResponse.data)
        
        res.json({
          creator: global.creator,
          status: true,
          data: {
            random: detailResult.data.detail,
            total_options: allSlugs.length,
            timestamp: new Date().toISOString()
          },
          message: null
        })
      } catch (error) {
        res.status(500).json({
          creator: global.creator,
          status: false,
          data: null,
          message: error.message
        })
      }
    },
    error: false,
    rpm: true,
    premium: true
  }
]