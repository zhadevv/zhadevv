const fs = require('fs');
const path = require('path');

const loadRoutes = (dir) => {
    const routes = [];
    const files = fs.readdirSync(dir);
    
    for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
            routes.push(...loadRoutes(filePath));
        } else if (file.endsWith('.js') && file !== 'index.js') {
            try {
                const routeModule = require(filePath);
                if (Array.isArray(routeModule)) {
                    routes.push(...routeModule);
                } else if (routeModule.routes) {
                    routes.push(...routeModule.routes);
                } else if (routeModule.category && routeModule.path) {
                    routes.push(routeModule);
                }
            } catch (error) {
                console.error(`Error loading route ${filePath}:`, error);
            }
        }
    }
    
    return routes;
};

const routes = loadRoutes(path.join(__dirname));

module.exports = { routes };