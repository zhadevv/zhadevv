import { PrismaClient } from '@prisma/client'
import { defineConfig, env } from 'prisma/config'
import 'dotenv/config'

const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' 
    ? ['query', 'error', 'warn'] 
    : ['error']
})

// Initialize database connection
prisma.$connect()
  .then(() => {
    console.log('✅ Database connected successfully')
    
    // Log connection info in development
    if (process.env.NODE_ENV === 'development') {
      console.log('📊 Prisma Client initialized')
      console.log(`📁 Database: ${process.env.DATABASE_URL?.split('/').pop()}`)
    }
  })
  .catch((error) => {
    console.error('❌ Database connection failed:', error.message)
    console.error('💡 Check your DATABASE_URL in .env file')
    process.exit(1)
  })

// Export Prisma config for migrations
export default defineConfig({
  schema: 'prisma/schema.prisma', // Your schema location[citation:1]
  migrations: {
    path: 'prisma/migrations',
    seed: 'node prisma/seed.js',
  },
  datasource: {
    url: env('DATABASE_URL'),
  },
})

// Export the Prisma Client instance
export { prisma }