const path = require('path');
require('dotenv').config();

module.exports = {
    apps: [{
        name: 'zhadev-api',
        script: 'index.js',
        cwd: __dirname,
        instances: process.env.NODE_ENV === 'production' ? 'max' : 1,
        exec_mode: 'cluster',
        watch: process.env.NODE_ENV === 'development',
        ignore_watch: [
            'node_modules',
            'logs',
            'data',
            '.git',
            '.env',
            'prisma/migrations'
        ],
        max_memory_restart: '1G',
        env: {
            NODE_ENV: 'development',
            PORT: 3000,
            TZ: 'Asia/Jakarta'
        },
        env_production: {
            NODE_ENV: 'production',
            PORT: 3000,
            TZ: 'Asia/Jakarta'
        },
        error_file: path.join(__dirname, 'logs', 'err.log'),
        out_file: path.join(__dirname, 'logs', 'out.log'),
        log_file: path.join(__dirname, 'logs', 'combined.log'),
        time: true,
        merge_logs: true,
        log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
        kill_timeout: 5000,
        listen_timeout: 5000,
        shutdown_with_message: true,
        wait_ready: true,
        max_restarts: 10,
        restart_delay: 5000,
        min_uptime: '10s',
        autorestart: true,
        vizion: true,
        post_update: ['npm install', 'npx prisma generate', 'npx prisma migrate deploy'],
        env_development: {
            NODE_ENV: 'development',
            DEBUG: 'zhadev:*'
        },
        env_staging: {
            NODE_ENV: 'staging',
            PORT: 3001
        }
    }],
    
    deploy: {
        production: {
            user: 'root',
            host: ['your-server-ip'],
            ref: 'origin/main',
            repo: 'git@github.com:yourusername/zhadev-api.git',
            path: '/var/www/zhadev-api',
            'post-deploy': 'npm install && npx prisma generate && npx prisma migrate deploy && pm2 reload ecosystem.config.js --env production',
            env: {
                NODE_ENV: 'production'
            }
        }
    }
};