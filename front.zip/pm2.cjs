import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

async function setupProject() {
  console.log('🚀 Setting up Zhadev API Project...\n')
  
  try {
    console.log('📦 Installing dependencies...')
    const { stdout: installOutput } = await execAsync('npm install')
    console.log(installOutput)
    
    console.log('\n⚙️  Generating Prisma client...')
    const { stdout: prismaOutput } = await execAsync('npx prisma generate')
    console.log(prismaOutput)
    
    console.log('\n🗄️  Running database migrations...')
    const { stdout: migrateOutput } = await execAsync('npx prisma migrate dev --name init')
    console.log(migrateOutput)
    
    console.log('\n✅ Setup completed successfully!')
    console.log('\n📋 Next steps:')
    console.log('1. Edit .env file with your configuration')
    console.log('2. Run API: npm start')
    console.log('3. Development: npm run dev')
    console.log('4. View documentation: http://localhost:3000')
    console.log('\n🎉 Happy coding!')
    
  } catch (error) {
    console.error('❌ Setup failed:', error.message)
    if (error.stderr) {
      console.error('Error details:', error.stderr)
    }
    process.exit(1)
  }
}

setupProject()