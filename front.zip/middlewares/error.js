export default (req, res) => {
  res.status(404).json({
    creator: global.creator,
    status: false,
    msg: 'Feature is currently unavailable'
  })
}