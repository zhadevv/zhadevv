export default function errorHandler(error, req, res, next) {
  console.error('Error:', error)
  
  const statusCode = error.statusCode || 500
  const message = error.message || 'Internal server error'
  
  const response = {
    status: statusCode,
    success: false,
    author: 'zhadevv',
    data: null,
    message: message
  }
  
  res.setHeader('X-Process-Time', Date.now() - res.startTime)
  
  res.status(statusCode).json(response)
}