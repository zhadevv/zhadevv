export default function requiresParams(requiredParams) {
  return function(req, res, next) {
    const missingParams = []
    
    for (const param of requiredParams) {
      if (!req.query[param] && !req.params[param] && !req.body[param]) {
        missingParams.push(param)
      }
    }
    
    if (missingParams.length > 0) {
      return res.status(400).json({
        status: 400,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `Missing required parameters: ${missingParams.join(', ')}`
      })
    }
    
    next()
  }
}