import prisma from '../prisma.config.js'

export default async (req, res, next) => {
  try {
    const apikey = req.query.apikey || req.body.apikey

    if (!apikey) {
      return res.status(400).json({
        creator: global.creator,
        status: false,
        msg: 'Apikey is required'
      })
    }

    const keyData = await prisma.apiKey.findFirst({
      where: { key: apikey }
    })

    if (!keyData) {
      return res.status(403).json({
        creator: global.creator,
        status: false,
        msg: 'Invalid apikey'
      })
    }

    if (keyData.suspended) {
      return res.status(403).json({
        creator: global.creator,
        status: false,
        msg: 'Apikey is suspended'
      })
    }

    const now = new Date()
    if (now > keyData.next_reset) {
      await prisma.apiKey.update({
        where: { id: keyData.id },
        data: {
          requests: 0,
          last_reset: now,
          next_reset: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
        }
      })
    }

    if (keyData.requests >= keyData.max_requests) {
      return res.status(403).json({
        creator: global.creator,
        status: false,
        msg: 'Monthly request limit exceeded'
      })
    }

    req.apikeyData = keyData
    next()
  } catch (error) {
    console.error('Requires middleware error:', error)
    res.status(500).json({
      creator: global.creator,
      status: false,
      msg: 'Internal server error'
    })
  }
}