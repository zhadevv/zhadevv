import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function restrictMiddleware(req, res, next) {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip
  
  try {
    const banned = await prisma.bannedIp.findUnique({
      where: { ip }
    })
    
    if (banned) {
      if (banned.expiresAt && new Date() > banned.expiresAt) {
        await prisma.bannedIp.delete({
          where: { id: banned.id }
        })
      } else {
        return res.status(403).json({
          status: 403,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'IP address banned'
        })
      }
    }
    
    next()
  } catch (error) {
    console.error('Restrict middleware error:', error)
    next()
  }
}