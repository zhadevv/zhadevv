import prisma from '../prisma.config.js'

export default (allowedRoles = []) => {
  return async (req, res, next) => {
    try {
      const apikey = req.query.apikey || req.body.apikey

      if (!apikey) {
        return res.status(401).json({
          creator: global.creator,
          status: false,
          msg: 'Apikey is required'
        })
      }

      const keyData = await prisma.apiKey.findFirst({
        where: { key: apikey }
      })

      if (!keyData) {
        return res.status(403).json({
          creator: global.creator,
          status: false,
          msg: 'Invalid apikey'
        })
      }

      if (allowedRoles.length > 0 && !allowedRoles.includes(keyData.role)) {
        return res.status(403).json({
          creator: global.creator,
          status: false,
          msg: 'Insufficient privileges'
        })
      }

      req.apikeyData = keyData
      next()
    } catch (error) {
      console.error('Restrict middleware error:', error)
      res.status(500).json({
        creator: global.creator,
        status: false,
        msg: 'Internal server error'
      })
    }
  }
}