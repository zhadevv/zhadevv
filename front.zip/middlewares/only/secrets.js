import Config from '../../lib/system/config.js'

export default function secretsMiddleware(req, res, next) {
  const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
  
  if (!apikey) {
    return res.status(401).json({
      status: 401,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Apikey required'
    })
  }
  
  if (!Config.isAdminKey(apikey)) {
    return res.status(403).json({
      status: 403,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Admin access required'
    })
  }
  
  next()
}