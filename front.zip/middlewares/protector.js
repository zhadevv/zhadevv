import requestIp from 'request-ip'
import prisma from '../prisma.config.js'

const requestMap = {}
const BLOCK_THRESHOLD = 100
const TIME_WINDOW = 60000

export default async (req, res, next) => {
  try {
    const userIP = requestIp.getClientIp(req)?.trim()

    if (!userIP) {
      return res.status(400).json({
        creator: global.creator,
        status: false,
        msg: 'Unable to determine client IP'
      })
    }

    const banned = await prisma.bannedIP.findFirst({
      where: {
        ip: userIP,
        OR: [
          { expires_at: null },
          { expires_at: { gt: new Date() } }
        ]
      }
    })

    if (banned) {
      return res.status(403).json({
        creator: global.creator,
        status: false,
        msg: 'IP is blocked'
      })
    }

    if (!requestMap[userIP]) {
      requestMap[userIP] = []
    }

    const now = Date.now()
    requestMap[userIP] = requestMap[userIP].filter(timestamp => now - timestamp < TIME_WINDOW)
    requestMap[userIP].push(now)

    if (requestMap[userIP].length > BLOCK_THRESHOLD) {
      await prisma.bannedIP.create({
        data: {
          ip: userIP,
          reason: 'Automatically blocked due to suspicious activity',
          banned_by: 'system',
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000)
        }
      })

      delete requestMap[userIP]

      return res.status(403).json({
        creator: global.creator,
        status: false,
        msg: 'Automatically blocked due to suspicious activity'
      })
    }

    next()
  } catch (e) {
    console.error('Protector error:', e)
    res.status(500).json({
      creator: global.creator,
      status: false,
      msg: 'Internal Server Error'
    })
  }
}