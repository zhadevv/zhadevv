import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function protectorMiddleware(req, res, next) {
  try {
    const stats = await prisma.systemStats.findFirst({
      orderBy: { lastUpdated: 'desc' }
    })
    
    if (stats) {
      const now = new Date()
      const lastUpdate = new Date(stats.lastUpdated)
      const diffMinutes = (now - lastUpdate) / (1000 * 60)
      
      if (diffMinutes > 5) {
        await prisma.systemStats.create({
          data: {
            totalApikeys: stats.totalApikeys,
            activeApikeys: stats.activeApikeys,
            totalRequests: stats.totalRequests,
            dailyRequests: 0,
            monthlyRequests: stats.monthlyRequests,
            animeRequests: 0,
            donghuaRequests: 0,
            dracinRequests: 0,
            toolsRequests: 0,
            networkRequests: 0,
            guestRequests: 0
          }
        })
      }
    } else {
      await prisma.systemStats.create({
        data: {}
      })
    }
    
    next()
  } catch (error) {
    console.error('Protector middleware error:', error)
    next()
  }
}