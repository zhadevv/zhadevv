export default function premiumMiddleware(requiredRole) {
  return function(req, res, next) {
    const userRole = req.userRole || 'GUEST'
    
    const roleHierarchy = {
      'GUEST': 0,
      'FREE': 1,
      'STARTER': 2,
      'MEDIUM': 3,
      'HIGHEST': 4,
      'ENTERPRISE': 5,
      'ADMIN': 6,
      'DEVELOPER': 7,
      'OWNER': 8
    }
    
    if (roleHierarchy[userRole] < roleHierarchy[requiredRole]) {
      return res.status(403).json({
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: `This endpoint requires ${requiredRole} role or higher`
      })
    }
    
    next()
  }
}