import requestIp from 'request-ip'
import prisma from '../prisma.config.js'

const ipRequests = new Map()

const getRpmLimit = (role) => {
  switch (role) {
    case 'free': return parseInt(process.env.FREE_RPM) || 50
    case 'starter': return parseInt(process.env.PREM_1_RPM) || 100
    case 'medium': return parseInt(process.env.PREM_2_RPM) || 150
    case 'highest': return parseInt(process.env.PREM_3_RPM) || 200
    case 'admin': return parseInt(process.env.ADMIN_RPM) || 500
    case 'dev': return parseInt(process.env.DEV_RPM) || 1000
    case 'owner': return parseInt(process.env.OWNER_RPM) || 0
    default: return parseInt(process.env.GUEST_RPM) || 25
  }
}

export default async (req, res, next) => {
  try {
    const userIP = requestIp.getClientIp(req)
    const currentTime = Date.now()
    const apikey = req.query.apikey || req.body.apikey

    let rpmLimit = getRpmLimit('guest')

    if (apikey) {
      const keyData = await prisma.apiKey.findFirst({
        where: { key: apikey, suspended: false }
      })

      if (keyData) {
        rpmLimit = getRpmLimit(keyData.role)
      }
    }

    if (!ipRequests.has(userIP)) {
      ipRequests.set(userIP, { requests: [], role: apikey ? 'authenticated' : 'guest' })
    }

    const userData = ipRequests.get(userIP)
    const filtered = userData.requests.filter(t => currentTime - t < 60000)

    if (filtered.length >= rpmLimit) {
      return res.status(429).json({
        creator: global.creator,
        status: false,
        msg: 'Too many requests'
      })
    }

    filtered.push(currentTime)
    ipRequests.set(userIP, { requests: filtered, role: userData.role })
    
    res.setHeader('X-RateLimit-Limit', rpmLimit)
    res.setHeader('X-RateLimit-Remaining', rpmLimit - filtered.length)
    
    next()
  } catch (error) {
    console.error('RPM middleware error:', error)
    next()
  }
}