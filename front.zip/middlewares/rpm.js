import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
const requestCounts = new Map()

setInterval(() => {
  requestCounts.clear()
}, 60000)

async function getRpmLimit(role, apikey) {
  const config = {
    GUEST: 25,
    FREE: 50,
    STARTER: 100,
    MEDIUM: 150,
    HIGHEST: 200,
    ENTERPRISE: 0,
    ADMIN: 500,
    DEVELOPER: 1000,
    OWNER: 0
  }
  
  if (apikey) {
    const keyData = await prisma.apiKey.findUnique({
      where: { key: apikey }
    })
    
    if (keyData && keyData.rpmLimit) {
      return keyData.rpmLimit
    }
  }
  
  return config[role] || 25
}

export default async function rpmMiddleware(req, res, next) {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip
  const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
  
  let role = 'GUEST'
  let identifier = ip
  
  if (apikey) {
    const keyData = await prisma.apiKey.findUnique({
      where: { key: apikey, isActive: true, isSuspended: false }
    })
    
    if (keyData) {
      role = keyData.role
      identifier = apikey
      
      if (keyData.expiresAt && new Date() > keyData.expiresAt) {
        return res.status(403).json({
          status: 403,
          success: false,
          author: 'zhadevv',
          data: null,
          message: 'Apikey telah expired'
        })
      }
    }
  }
  
  const rpmLimit = await getRpmLimit(role, apikey)
  
  if (rpmLimit === 0) {
    return next()
  }
  
  const currentCount = requestCounts.get(identifier) || 0
  
  if (currentCount >= rpmLimit) {
    res.setHeader('X-Rate-Limit-Limit', rpmLimit)
    res.setHeader('X-Rate-Limit-Remaining', 0)
    res.setHeader('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 60)
    
    return res.status(429).json({
      status: 429,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Rate limit exceeded'
    })
  }
  
  requestCounts.set(identifier, currentCount + 1)
  
  res.setHeader('X-Rate-Limit-Limit', rpmLimit)
  res.setHeader('X-Rate-Limit-Remaining', rpmLimit - (currentCount + 1))
  res.setHeader('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 60)
  
  next()
}