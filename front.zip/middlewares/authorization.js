import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default async function authorizationMiddleware(req, res, next) {
  const apikey = req.query.apikey || req.headers['authorization']?.replace('Bearer ', '')
  
  if (!apikey) {
    req.userRole = 'GUEST'
    return next()
  }
  
  try {
    const keyData = await prisma.apiKey.findUnique({
      where: { key: apikey }
    })
    
    if (!keyData) {
      return res.status(401).json({
        status: 401,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Invalid apikey'
      })
    }
    
    if (keyData.isSuspended) {
      return res.status(403).json({
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Apikey suspended'
      })
    }
    
    if (!keyData.isActive) {
      return res.status(403).json({
        status: 403,
        success: false,
        author: 'zhadevv',
        data: null,
        message: 'Apikey inactive'
      })
    }
    
    req.userRole = keyData.role
    req.apikeyData = keyData
    
    next()
  } catch (error) {
    console.error('Authorization error:', error)
    res.status(500).json({
      status: 500,
      success: false,
      author: 'zhadevv',
      data: null,
      message: 'Internal server error'
    })
  }
}